<?php
/**
 * Seed Default Boards
 * Run this once to create default boards for your PXLBoard installation
 */

require_once 'config/config.php';
require_once 'includes/database.php';

$db = new FlatFileDB(DATA_DIR);

$defaultBoards = [
    [
        'shortcode' => 'b',
        'name' => 'Random',
        'description' => 'Random discussions about anything and everything',
        'category' => 'General',
        'nsfw' => false,
        'featured' => true
    ],
    [
        'shortcode' => 'g',
        'name' => 'Technology',
        'description' => 'Discussion about technology, programming, and software',
        'category' => 'Technology',
        'nsfw' => false,
        'featured' => true
    ],
    [
        'shortcode' => 'v',
        'name' => 'Video Games',
        'description' => 'Video games discussion and news',
        'category' => 'Entertainment',
        'nsfw' => false,
        'featured' => true
    ],
    [
        'shortcode' => 'art',
        'name' => 'Art & Creative',
        'description' => 'Share and discuss artwork, digital art, and creative projects',
        'category' => 'Creative',
        'nsfw' => false,
        'featured' => true
    ],
    [
        'shortcode' => 'a',
        'name' => 'Anime & Manga',
        'description' => 'Discuss anime, manga, and Japanese culture',
        'category' => 'Entertainment',
        'nsfw' => false,
        'featured' => false
    ],
    [
        'shortcode' => 'mu',
        'name' => 'Music',
        'description' => 'Music discussion and sharing',
        'category' => 'Entertainment',
        'nsfw' => false,
        'featured' => false
    ],
    [
        'shortcode' => 'fit',
        'name' => 'Fitness & Health',
        'description' => 'Health, fitness, and nutrition discussion',
        'category' => 'Community',
        'nsfw' => false,
        'featured' => false
    ],
    [
        'shortcode' => 'diy',
        'name' => 'DIY & Crafts',
        'description' => 'Do it yourself projects and crafting',
        'category' => 'Creative',
        'nsfw' => false,
        'featured' => false
    ],
    [
        'shortcode' => 'sci',
        'name' => 'Science & Math',
        'description' => 'Scientific discussions and discoveries',
        'category' => 'General',
        'nsfw' => false,
        'featured' => false
    ],
    [
        'shortcode' => 'pol',
        'name' => 'Politics & News',
        'description' => 'Current events and political discussion',
        'category' => 'General',
        'nsfw' => false,
        'featured' => false
    ]
];

echo "Creating default boards...\n\n";

foreach ($defaultBoards as $boardData) {
    $boardId = 'board_' . time() . '_' . rand(1000, 9999);
    
    $boardData['user_created'] = false;
    $boardData['created_at'] = time();
    $boardData['thread_count'] = 0;
    $boardData['post_count'] = 0;
    
    if ($db->save('boards', $boardId, $boardData)) {
        echo "✓ Created /{$boardData['shortcode']}/ - {$boardData['name']}\n";
    } else {
        echo "✗ Failed to create /{$boardData['shortcode']}/\n";
    }
    
    // Small delay to ensure unique IDs
    usleep(100000);
}

echo "\n✓ Done! Default boards created successfully.\n";
echo "Visit index.php?page=boards to see your new boards!\n";
