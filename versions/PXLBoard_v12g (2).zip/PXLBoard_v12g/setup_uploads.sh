#!/bin/bash

# PXLBoard Upload Directory Fix Script
# This script sets up the upload directories with proper permissions

echo "================================================"
echo "PXLBoard Upload Directory Setup"
echo "================================================"
echo ""

# Get the directory where this script is located
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

echo "Working directory: $SCRIPT_DIR"
echo ""

# Create directories
echo "Creating upload directories..."
mkdir -p uploads/thumbs
mkdir -p data/images

if [ $? -eq 0 ]; then
    echo "✓ Directories created successfully"
else
    echo "✗ Failed to create directories"
    exit 1
fi

echo ""

# Detect web server user
echo "Detecting web server user..."
WEB_USER=""

if id "www-data" &>/dev/null; then
    WEB_USER="www-data"
elif id "apache" &>/dev/null; then
    WEB_USER="apache"
elif id "_www" &>/dev/null; then
    WEB_USER="_www"
elif id "nginx" &>/dev/null; then
    WEB_USER="nginx"
else
    echo "⚠ Could not auto-detect web server user"
    echo "Common users: www-data, apache, _www, nginx"
    read -p "Enter your web server user (or press Enter to skip): " WEB_USER
fi

if [ -n "$WEB_USER" ]; then
    echo "Using web server user: $WEB_USER"
else
    echo "⚠ No web server user specified - using current user"
fi

echo ""

# Set permissions
echo "Setting permissions..."

if [ -n "$WEB_USER" ]; then
    # Try to set ownership (requires sudo)
    echo "Attempting to set ownership to $WEB_USER (may require sudo)..."
    sudo chown -R "$WEB_USER:$WEB_USER" uploads/ 2>/dev/null
    sudo chown -R "$WEB_USER:$WEB_USER" data/ 2>/dev/null
    
    if [ $? -eq 0 ]; then
        echo "✓ Ownership set successfully"
        chmod -R 755 uploads/
        chmod -R 755 data/
        echo "✓ Permissions set to 755"
    else
        echo "⚠ Could not set ownership (no sudo access)"
        echo "Setting permissions to 777 (less secure)..."
        chmod -R 777 uploads/
        chmod -R 777 data/
        echo "✓ Permissions set to 777"
    fi
else
    # No web user specified, use 777
    echo "Setting permissions to 777..."
    chmod -R 777 uploads/
    chmod -R 777 data/
    echo "✓ Permissions set to 777"
fi

echo ""

# Verify setup
echo "Verifying setup..."
echo ""

echo "Upload directory:"
ls -ld uploads/
echo ""

echo "Thumbs directory:"
ls -ld uploads/thumbs/
echo ""

echo "Data directory:"
ls -ld data/
echo ""

# Test write access
echo "Testing write access..."

if [ -n "$WEB_USER" ]; then
    # Test as web server user
    sudo -u "$WEB_USER" touch uploads/test.txt 2>/dev/null
    if [ $? -eq 0 ]; then
        sudo -u "$WEB_USER" rm uploads/test.txt
        echo "✓ Upload directory is writable by $WEB_USER"
    else
        echo "✗ Upload directory is NOT writable by $WEB_USER"
        echo "  Try running: sudo chown -R $WEB_USER:$WEB_USER uploads/"
    fi
else
    # Test as current user
    touch uploads/test.txt 2>/dev/null
    if [ $? -eq 0 ]; then
        rm uploads/test.txt
        echo "✓ Upload directory is writable"
    else
        echo "✗ Upload directory is NOT writable"
    fi
fi

echo ""
echo "================================================"
echo "Setup Complete!"
echo "================================================"
echo ""
echo "Next steps:"
echo "1. Navigate to: http://yoursite.com/index.php?page=upload&debug=1"
echo "2. Try uploading an image"
echo "3. Check debug output for any errors"
echo ""
echo "If you still have issues:"
echo "- Check Apache error log: tail -f /var/log/apache2/error.log"
echo "- Ensure PHP GD library is installed: php -m | grep -i gd"
echo "- Verify PHP upload settings: upload_max_filesize, post_max_size"
echo ""
