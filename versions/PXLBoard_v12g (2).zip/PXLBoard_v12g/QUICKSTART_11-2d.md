# PXLBoard v11-2d Quick Start Guide

## What You Have

**Version**: 11-2d  
**Release Date**: January 31, 2025  
**Features**: Base v11-2b + Tier 1 Integration

This is the integrated version combining all features from PXLBoard v11-2b with the six Tier 1 enhancements.

---

## Quick Installation

### 1. Extract Files
```bash
unzip PXLBoard_v11-2d.zip
cd integrated_version
```

### 2. Set Permissions
```bash
chmod 755 data/
chmod 755 uploads/
chmod 755 data/user_hides/
chmod 644 data/tag_aliases.json
```

### 3. Upload to Server
Upload all files from `integrated_version/` directory to your web server.

### 4. Run Installation
Navigate to: `http://yoursite.com/index.php?page=install`

Follow the installation wizard to:
- Create admin account
- Configure site settings
- Set up directories

### 5. Verify Installation
After installation, check:
- Can you access the admin panel?
- Can you upload an image?
- Are all pages accessible?

---

## New Features Quick Access

### For Users

**Hide Images**
1. Browse gallery
2. Click "Hide" on any image
3. Manage at Profile Settings → Hidden Images

**Add Image Source**
1. During upload: Fill "Source URL" field
2. After upload: Click "Edit Source" on image page

**Edit Comments**
1. Find your comment on an image
2. Click edit icon
3. Make changes and save

**Upload Anonymously**
1. Go to upload page
2. Check "Upload Anonymously" box
3. Upload as normal

**Manage Avatar**
1. Go to Profile Settings
2. Upload new avatar
3. Adjust preferences

### For Administrators

**Tag Aliases**
1. Go to Admin Panel
2. Click "Tag Aliases"
3. Add alias mappings (e.g., "cat" → "cats")

**View User Hides**
- Users manage their own hides
- Hidden images don't affect other users

**Anonymous Upload Tracking**
- Public sees "Anonymous"
- Admin logs show actual uploader

---

## Tier 1 Features Overview

### 1. Image Hiding (High Impact)
Users can hide images they don't want to see. Hidden images are automatically filtered from their gallery view.

**Files**:
- `includes/hiding.php`
- `pages/manage_hides.php`
- `data/user_hides/`

### 2. Source Tracking (Medium Impact)
Track where images came from with URL references and edit history.

**Files**:
- `pages/edit_source.php`

### 3. Tag Aliases (High Impact)
Redirect alternate tag names to canonical versions for better consistency.

**Files**:
- `includes/tag_aliases.php`
- `pages/admin_tags.php`
- `data/tag_aliases.json`

### 4. Comment Editing (Medium Impact)
Users can edit their comments with full revision history.

**Files**:
- `pages/edit_comment.php`
- `pages/comment_history.php`

### 5. Anonymous Uploads (Medium Impact)
Upload images without showing your username publicly.

**Implementation**: Enhanced upload form

### 6. Enhanced Avatars (Medium Impact)
Better profile picture management with dedicated settings page.

**Files**:
- `pages/profile_settings.php`

---

## Configuration

### Tag Aliases Setup
Edit `data/tag_aliases.json`:
```json
{
  "cat": "cats",
  "doggo": "dog",
  "wallpaper": "wallpapers"
}
```

Or use Admin Panel → Tag Aliases interface.

### Directory Structure
After installation:
```
your-site/
├── config/
├── data/
│   ├── user_hides/      (NEW - stores hide preferences)
│   ├── tag_aliases.json (NEW - tag redirects)
│   ├── users/
│   ├── images/
│   └── ...
├── includes/
│   ├── hiding.php       (NEW)
│   ├── tag_aliases.php  (NEW)
│   └── ...
├── pages/
│   ├── manage_hides.php       (NEW)
│   ├── admin_tags.php         (NEW)
│   ├── edit_source.php        (NEW)
│   ├── edit_comment.php       (NEW)
│   ├── comment_history.php    (NEW)
│   ├── profile_settings.php   (NEW)
│   └── ...
└── uploads/
```

---

## Troubleshooting

### Permission Issues
```bash
# Fix permissions
chmod -R 755 data/
chmod -R 755 uploads/
chown -R www-data:www-data data/ uploads/
```

### 404 Errors
Check `.htaccess` file exists and mod_rewrite is enabled. See `TROUBLESHOOTING_404.md`.

### Upload Issues
See `UPLOAD_FIX_GUIDE.md` for comprehensive upload troubleshooting.

### Feature Not Working
1. Check file permissions
2. Verify PHP version (7.4+ required)
3. Check error logs
4. Review feature-specific documentation

---

## Documentation

### Core Documentation
- `README.md` - Main documentation
- `INSTALLATION_GUIDE.md` - Detailed installation
- `CHANGELOG.md` - Version history

### Tier 1 Documentation
- `VERSION_NOTES_11-2d.md` - Release notes
- `TIER1_IMPLEMENTATION_GUIDE.md` - Feature details
- `TIER1_README.md` - Tier 1 overview
- `INTEGRATION_SUMMARY.md` - Integration details

### Admin Guides
- `ADMIN_QUICK_REFERENCE.md` - Admin functions
- `ADMIN_MIGRATION_GUIDE.md` - Migration help

### Troubleshooting
- `TROUBLESHOOTING_404.md` - Fix 404 errors
- `UPLOAD_FIX_GUIDE.md` - Fix upload issues
- `PROFILE_404_FIX.md` - Fix profile issues

---

## Upgrade from 11-2b

If you're running v11-2b:

1. **Backup** your current installation
2. **Replace** files with v11-2d
3. **Keep** your existing `data/` folder
4. **Add** new directories:
   - `data/user_hides/`
   - `data/tag_aliases.json`
5. **Test** new features

All existing data is compatible. No migrations needed.

---

## Support

### Getting Help
- Check documentation in the package
- Review troubleshooting guides
- Verify server requirements
- Check file permissions

### Requirements Checklist
- ✅ PHP 7.4+
- ✅ GD Extension
- ✅ JSON Extension
- ✅ mod_rewrite (Apache)
- ✅ Writable data/ directory
- ✅ Writable uploads/ directory

---

## What's Different from 11-2b?

### Added Files (8 new pages, 2 new includes)
- User hide management
- Tag alias admin panel
- Source editing
- Comment editing
- Comment history viewer
- Profile settings page
- Hiding system core
- Tag alias system core

### Modified Files (4 enhanced pages)
- Upload form (source + anonymous)
- Image page (hide + source + edit)
- Gallery (hide filtering)
- Database handler (new features)

### New Directories & Config
- `data/user_hides/` folder
- `data/tag_aliases.json` file

### Version Number
- Config version: 11-2d
- All docs updated

---

## Quick Reference

### Common Tasks

**Set up tag aliases**:
Admin → Tag Aliases → Add alias

**Check hidden images**:
Profile Settings → Hidden Images

**Enable anonymous uploads**:
Already enabled, just check box during upload

**Edit comment**:
Click edit icon on your comment

**Add image source**:
Upload form or Edit Source on image

---

**Installation Status**: Ready ✅  
**Version**: 11-2d  
**Date**: January 31, 2025

*Happy image boarding!* 🎨
