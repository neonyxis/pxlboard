# Upgrade Guide: v12c to v12d

## Quick Upgrade (Recommended)

### Prerequisites
- PXLBoard v12c installed and working
- Backup of your `data/` and `uploads/` directories
- FTP/SSH access to your server

### Steps

1. **Backup Your Installation**
   ```bash
   # Create a backup
   cp -r /path/to/pxlboard /path/to/pxlboard_backup_$(date +%Y%m%d)
   
   # Or just backup critical data
   cp -r /path/to/pxlboard/data /backup/location/
   cp -r /path/to/pxlboard/uploads /backup/location/
   ```

2. **Extract v12d**
   ```bash
   # Extract over existing installation
   unzip PXLBoard_v12d.zip -d /path/to/pxlboard/
   
   # Or via FTP: upload and extract on server
   ```

3. **Verify Permissions**
   ```bash
   chmod 755 -R /path/to/pxlboard/
   chmod 777 -R /path/to/pxlboard/data/
   chmod 777 -R /path/to/pxlboard/uploads/
   ```

4. **Clear Cache**
   - Clear your browser cache
   - Clear server cache if using OPcache
   - Optionally delete `data/cache/` contents

5. **Test**
   - Visit your site
   - Try switching themes (user dropdown → theme selector)
   - Test boards page with search and filters
   - Test image view with zoom controls
   - Test tag autocomplete when uploading

**Done!** Your upgrade is complete.

## What's New

### User-Visible Changes

**Themes**:
- New DPBooru theme (modern, colorful)
- New Vichan dark theme (classic dark mode)
- Themes available in user dropdown menu

**Boards Page**:
- Live search (type to filter instantly)
- Sort dropdown (5 options)
- View toggle (grid/list)
- Content filter (SFW/NSFW)
- Keyboard shortcuts (S, ESC, G, L)

**Image Page**:
- Zoom controls (keyboard: +, -, 0)
- Fullscreen mode (keyboard: F)
- Tag categorization by type
- Enhanced metadata panel
- Related images

**Tagging**:
- 7 tag types with colors
- Auto-detection of tag types
- Tag autocomplete
- Tag statistics

### Technical Changes

**New Files**:
- `themes/dpbooru/style.css`
- `themes/vichan/style.css`
- `includes/enhanced_tags.php`
- `pages/boards_enhanced.php` (alternative)
- `pages/image_enhanced.php` (alternative)

**Modified Files**:
- `config/config.php` (version → 12d)
- `README.md` (updated features)
- `pages/boards.php` (enhanced)
- `pages/image.php` (enhanced)

**New Documentation**:
- `CHANGELOG_v12d.md`
- `VERSION_NOTES_v12d.md`
- `UPGRADE_v12c_to_v12d.md` (this file)

## Compatibility

### Backward Compatibility
✅ **Fully Compatible** - No breaking changes

- All existing data works unchanged
- Old tag format still supported
- Existing themes continue to work
- No database migrations needed
- No API changes

### Browser Requirements
- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+
- Modern mobile browsers

## Configuration

### Theme Selection

**Users** can select themes from:
1. Click username in navbar
2. Select theme from dropdown
3. Page reloads with new theme

**Admins** can set default theme:
```php
// Future enhancement - coming soon
// In config.php:
define('DEFAULT_THEME', 'dpbooru');
```

### Using Enhanced Pages

The enhanced pages are integrated into the default pages, but standalone versions are also available:

**Option 1: Use Default (Recommended)**
- `pages/boards.php` - Already enhanced
- `pages/image.php` - Already enhanced
- No changes needed

**Option 2: Use Standalone Versions**
Update routing in `index.php`:
```php
case 'boards':
    require 'pages/boards_enhanced.php';
    break;

case 'image':
    require 'pages/image_enhanced.php';
    break;
```

### Tag System Usage

**Initialize in your code**:
```php
require_once 'includes/enhanced_tags.php';
$tagSystem = new EnhancedTagSystem($db);
```

**Use the API**:
```php
// Parse tags
$tags = $tagSystem->parseTags('artist:john, fluffy, safe');

// Save image tags
$tagSystem->saveImageTags($imageId, 'artist:john, fluffy, safe');

// Get suggestions
$suggestions = $tagSystem->getTagSuggestions('flu', 10);
```

## Troubleshooting

### Themes Not Showing

**Check**:
1. Files exist in `themes/dpbooru/` and `themes/vichan/`
2. File permissions (644 for CSS files)
3. Clear browser cache
4. Check for JavaScript errors in console

**Fix**:
```bash
# Verify theme files
ls -la themes/dpbooru/style.css
ls -la themes/vichan/style.css

# Fix permissions
chmod 644 themes/dpbooru/style.css
chmod 644 themes/vichan/style.css
```

### Search Not Working

**Check**:
1. JavaScript is enabled
2. No console errors
3. Browser compatibility

**Fix**:
- Clear browser cache
- Try different browser
- Check `pages/boards.php` was updated

### Zoom Controls Not Working

**Check**:
1. JavaScript is enabled
2. Image page loaded correctly
3. No console errors

**Fix**:
- Verify `pages/image.php` was updated
- Clear browser cache
- Test keyboard shortcuts (+, -, 0, F)

### Tags Not Categorizing

**Check**:
1. `enhanced_tags.php` exists in `includes/`
2. Tag format: `artist:name` or auto-detected
3. Check image upload/edit pages

**Fix**:
```bash
# Verify file exists
ls -la includes/enhanced_tags.php

# Check if included in code
grep "enhanced_tags.php" pages/upload.php
```

### Performance Issues

**Optimize**:
1. Enable PHP OPcache
2. Clear old cache files
3. Use CDN for assets
4. Check server resources

```bash
# Clear cache
rm -rf data/cache/*

# Check PHP version
php -v

# Enable OPcache in php.ini
opcache.enable=1
opcache.memory_consumption=128
```

## Rollback Instructions

If you need to rollback to v12c:

### Option 1: Restore Backup
```bash
# Remove v12d
rm -rf /path/to/pxlboard/

# Restore backup
cp -r /path/to/pxlboard_backup/ /path/to/pxlboard/
```

### Option 2: Partial Rollback
```bash
# Keep data, rollback code
cd /path/to/pxlboard/
rm -rf themes/dpbooru/
rm -rf themes/vichan/
rm includes/enhanced_tags.php
# Restore old config.php, boards.php, image.php from backup
```

## Post-Upgrade Checklist

After upgrading, verify:

- [ ] Site loads without errors
- [ ] Can log in as admin
- [ ] Can switch themes (user dropdown)
- [ ] Boards page search works
- [ ] Can sort and filter boards
- [ ] Image zoom controls work
- [ ] Fullscreen mode works
- [ ] Can upload images
- [ ] Tags are categorized correctly
- [ ] Tag autocomplete works
- [ ] Comments work
- [ ] All existing images display
- [ ] Mobile view works

## Getting Help

If you encounter issues:

1. **Check Documentation**:
   - `CHANGELOG_v12d.md` - What changed
   - `UI_ENHANCEMENTS.md` - Feature guide
   - `QUICK_START_ENHANCEMENTS.md` - Quick reference

2. **Check Logs**:
   - Browser console (F12)
   - PHP error log
   - Apache/Nginx error log

3. **Common Fixes**:
   - Clear browser cache
   - Check file permissions
   - Verify PHP version (7.4+)
   - Test in different browser

4. **Verify Installation**:
   ```bash
   # Check files exist
   ls -la themes/dpbooru/
   ls -la themes/vichan/
   ls -la includes/enhanced_tags.php
   
   # Check version
   grep "VERSION" config/config.php
   # Should show: define('VERSION', '12d');
   ```

## Additional Resources

- `README.md` - Complete feature list
- `CHANGELOG_v12d.md` - Detailed changelog
- `VERSION_NOTES_v12d.md` - Release notes
- `UI_ENHANCEMENTS.md` - UI documentation
- `QUICK_START_ENHANCEMENTS.md` - Quick reference

## Support

For additional support:
- Review documentation files
- Check code comments
- Test in clean browser
- Verify server requirements
- Check permissions

---

**Upgrade Complexity**: Easy  
**Estimated Time**: 5-10 minutes  
**Risk Level**: Low (fully backward compatible)  
**Rollback**: Easy (restore backup)

**Questions?** Check the documentation or review the code comments.
