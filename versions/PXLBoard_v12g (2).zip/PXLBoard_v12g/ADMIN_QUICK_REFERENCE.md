# Admin Panel Quick Reference

## 🎯 Quick Access
**URL**: `index.php?page=admin`  
**Required Role**: Admin  
**Keyboard Shortcut**: None (bookmark recommended)

---

## 📑 Tab Navigation

### 1️⃣ Statistics Tab
**What it shows**:
- Total counts: Images, Users, Blogs, Wiki Pages, Tags, Storage
- Recent blog posts (last 5)
- Recent wiki pages (last 5)

**Quick Actions**:
- Click blog title → View blog post
- Click wiki title → View wiki page

---

### 2️⃣ Blogs Tab
**What it shows**:
- All blog posts in table format
- Title, Author, Status, Views, Comments, Created date

**Actions Available**:
| Icon | Action | What it does |
|------|--------|--------------|
| ✏️ | Edit | Opens blog editor |
| 🔄 | Toggle Status | Switches published ↔ draft |
| 🗑️ | Delete | Removes post + comments |

**Quick Filters**: None (coming soon)

**Statistics Cards**:
- Total Views across all blogs
- Total Comments
- Published Posts count

---

### 3️⃣ Wiki Tab
**What it shows**:
- All wiki pages in table format
- Title, Category, Author, Views, Revisions, Protection status

**Actions Available**:
| Icon | Action | What it does |
|------|--------|--------------|
| ✏️ | Edit | Opens wiki editor |
| 🛡️ | Toggle Protection | Locks/unlocks page |
| 🗑️ | Delete | Removes page + revisions |

**Protection Status**:
- 🔴 **Protected**: Only admins can edit
- ⚪ **Unprotected**: All users can edit

**Statistics Cards**:
- Total Pages
- Total Views
- Protected Pages count
- Total Revisions

---

### 4️⃣ Settings Tab

#### General Settings
```
Site Name          → Your site's name
Site Description   → Meta description
Site URL           → Full URL (https://example.com)
Admin Email        → Contact email
Max Upload Size    → In megabytes (1-100)
Default Theme      → Theme selection
Timezone           → PHP timezone string
```

#### Feature Settings
```
✓ Enable Blog Feature                → Show/hide blogs
✓ Enable Wiki Feature                → Show/hide wiki
☐ Require Admin Approval for Blogs   → Moderate posts
☐ Require Admin Approval for Wiki    → Moderate edits
```

#### Registration Settings
```
✓ Enable User Registration           → Allow signups
✓ Require Email Verification        → Email validation
```

#### SMTP Settings
```
✓ Enable SMTP                        → Use email server
SMTP Host                            → mail.example.com
SMTP Port                            → Usually 587
SMTP Username                        → Email username
SMTP Password                        → Email password
From Email                           → Reply-to address
```

**⚠️ Important**: Click "Save All Settings" to apply changes!

---

### 5️⃣ Users Tab
**What it shows**:
- All registered users
- Username, Email, Role, Registration date, Verification status

**Actions Available**:
| Action | Effect | Limitations |
|--------|--------|-------------|
| ⬆️ Promote | User → Admin | Can't promote yourself |
| ⬇️ Demote | Admin → User | Can't demote yourself |

**Verification Status**:
- ✅ Verified email
- ❌ Unverified email

---

### 6️⃣ Channels Tab

**Create New Channel**:
```
Channel Name   → Display name
Description    → Short description
[Create] button
```

**Existing Channels Table**:
- Name, Description, Image count, Created date
- Actions: View | Delete

**⚠️ Note**: Deleting a channel does NOT delete images!

---

### 🛡️ Moderation Tab
**Link to**: `index.php?page=moderation`  
**Purpose**: Report management (separate page)

---

## 🔑 Keyboard Shortcuts

Currently none implemented. Consider bookmarking:
- `Admin Home`: index.php?page=admin#stats
- `Blog Management`: index.php?page=admin#blogs
- `Wiki Management`: index.php?page=admin#wiki
- `Settings`: index.php?page=admin#settings

---

## ⚡ Common Tasks

### Publish a Draft Blog Post
1. Go to **Blogs** tab
2. Find post with 🟡 Draft badge
3. Click 🔄 Toggle Status
4. Post becomes 🟢 Published

### Protect a Wiki Page
1. Go to **Wiki** tab
2. Find page (check Protection column)
3. Click 🛡️ Toggle Protection
4. Badge changes to 🔴 Protected

### Delete Spam Blog Post
1. Go to **Blogs** tab
2. Find spam post
3. Click 🗑️ Delete
4. Confirm deletion
5. Post AND all comments deleted

### Create Admin User
1. User must register first
2. Go to **Users** tab
3. Find user
4. Click ⬆️ Promote
5. User becomes admin

### Change Site Name
1. Go to **Settings** tab
2. Update "Site Name" field
3. Scroll down
4. Click "Save All Settings"
5. Refresh page to see changes

---

## 📊 Understanding Statistics

### Blog Metrics
```
Views       → Individual post views (increments on each visit)
Comments    → Total comments across all posts
Published   → Only published posts (excludes drafts)
```

### Wiki Metrics
```
Pages       → Total wiki pages created
Views       → Page views (increments on each visit)
Revisions   → Total edits made (tracks history)
Protected   → Pages locked to admins only
```

### Storage
```
Storage Used → Total size of uploaded images
Calculation  → Sum of all image file sizes
Format       → Auto-formatted (KB, MB, GB)
```

---

## ⚠️ Important Warnings

### Destructive Actions
These actions **cannot be undone**:
- 🗑️ Delete Blog Post (deletes comments too!)
- 🗑️ Delete Wiki Page (deletes revisions too!)
- 🗑️ Delete Channel (images remain)
- ⬇️ Demote Admin (loses admin rights)

Always confirm before clicking!

### Settings Changes
- Changes take effect **immediately** after saving
- Some require page refresh
- SMTP changes need testing
- Timezone affects date displays

### User Management
- Cannot promote/demote yourself
- Cannot delete users (yet)
- Role changes are immediate
- Affects permissions site-wide

---

## 🐛 Troubleshooting

### Tab Won't Switch
- **Cause**: JavaScript not loaded
- **Fix**: Check browser console for errors
- **Fix**: Ensure Bootstrap JS is loaded

### Actions Don't Work
- **Cause**: Not logged in as admin
- **Fix**: Log in with admin account
- **Fix**: Check session hasn't expired

### Statistics Show Zero
- **Cause**: No data in database
- **Fix**: Create test content
- **Fix**: Check data directory permissions

### Settings Won't Save
- **Cause**: File permissions
- **Fix**: Check `data/settings.json` is writable
- **Fix**: Verify web server has write access

---

## 💡 Pro Tips

1. **Bookmark Tabs**: Browser bookmark each tab's direct link
2. **Use Search**: Ctrl+F to find specific posts/pages in tables
3. **Sort Tables**: Click headers to sort (coming soon)
4. **Bulk Actions**: Use moderation queue for bulk operations
5. **Regular Backups**: Backup `data/` directory regularly
6. **Monitor Storage**: Watch storage usage in statistics
7. **Test SMTP**: Send test email after configuring
8. **Review Logs**: Check PHP error logs if issues occur

---

## 🎨 UI Elements Guide

### Badges
- 🟢 **Green**: Active/Published/Verified
- 🟡 **Yellow**: Draft/Pending
- 🔴 **Red**: Protected/Admin/Critical
- ⚪ **Gray**: Inactive/Regular/Neutral

### Buttons
- **Primary** (Blue): Main actions
- **Outline Primary** (Blue outline): Secondary actions
- **Warning** (Yellow): Status toggles
- **Danger** (Red): Destructive actions
- **Success** (Green): Positive actions

### Icons
- ✏️ Edit
- 🗑️ Delete
- 🔄 Toggle
- 🛡️ Protection
- ⬆️ Promote
- ⬇️ Demote
- 👁️ View
- ➕ Create

---

## 📝 Best Practices

### Daily Tasks
- Check recent blog posts for spam
- Review new wiki edits
- Monitor storage usage
- Check moderation queue

### Weekly Tasks
- Review user registrations
- Clean up unused channels
- Backup data directory
- Review error logs

### Monthly Tasks
- Audit admin users
- Review and update settings
- Archive old documentation
- Test email functionality

---

## 🆘 Emergency Procedures

### Site Compromised
1. Go to **Users** tab
2. Demote suspicious admins
3. Change admin passwords
4. Review recent content
5. Check server logs

### Database Corruption
1. Stop making changes
2. Restore from backup
3. Check file permissions
4. Review PHP error logs
5. Contact support

### Out of Storage
1. Check **Statistics** for storage used
2. Go to moderation queue
3. Delete old/unused images
4. Increase hosting storage
5. Implement cleanup policy

---

**Quick Reference Version**: 1.0  
**Last Updated**: 2025-01-31  
**Print-Friendly**: Yes
