# PXLBoard v12g Quick Reference Guide

## 🎯 New Features Quick Access

### Image Grabber
**Access**: Admin Panel → Image Grabber (`?page=admin_grabber`)

**Quick Add Source**:
1. Select Source Type (Danbooru/Gelbooru/RSS)
2. Name your source
3. Add tags (for boorus) or URL (for RSS)
4. Enable Auto-import if desired
5. Click "Add Source"

**Quick Grab**:
- Click "Grab Now" next to any source
- Or click "Run All Sources Now" for batch

### Email Notifications
**Configure**: `config/config.php`

```php
// Quick Gmail Setup
define('SMTP_ENABLED', true);
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'your-email@gmail.com');
define('SMTP_PASSWORD', 'app-password-here');
define('SMTP_FROM', 'noreply@yoursite.com');
define('SMTP_USE_TLS', true);
```

**User Preferences**: Profile Settings → Email Notifications

### Notifications
**View**: Click bell icon in navigation bar

**Types**:
- 💬 Comments on your images
- 💬 Replies to your comments
- 📢 Mentions (@username)
- 👥 New followers
- 📝 Thread replies
- 🎯 Tag watches
- ⭐ Vote milestones
- 🏆 Badges earned
- ⚠️ Moderation actions

## 🐛 Bug Fixes Applied

### Fixed Errors
✅ Missing template: `gallery_card.php` → **Created**
✅ Undefined shortname → **Null checks added**
✅ Null parameter warning → **escape() updated**
✅ Threads not updating → **Sorting fixed**
✅ Dark mode inconsistent → **40+ styles added**

### Verification
```bash
# Check template exists
ls templates/gallery_card.php

# Verify no errors on boards page
# Navigate to: ?page=boards

# Check dark theme
# Switch to dark theme and browse all pages
```

## ⚙️ Configuration Quick Reference

### Minimum Config (config.php)
```php
// Database
define('DB_TYPE', 'mysql');
define('DB_HOST', 'localhost');
define('DB_NAME', 'pxlboard');
define('DB_USER', 'username');
define('DB_PASS', 'password');

// Site
define('SITE_NAME', 'My Board');
define('SITE_URL', 'https://example.com');

// Optional: SMTP
define('SMTP_ENABLED', false);  // true to enable

// Optional: Grabber
define('GRABBER_ENABLED', false);  // true to enable
```

### Email Provider Quick Setup

#### Gmail
```php
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USE_TLS', true);
// Use App Password from Google Account settings
```

#### SendGrid
```php
define('SMTP_HOST', 'smtp.sendgrid.net');
define('SMTP_USERNAME', 'apikey');
define('SMTP_PASSWORD', 'SG.xxxx');
```

#### Mailgun
```php
define('SMTP_HOST', 'smtp.mailgun.org');
define('SMTP_USERNAME', 'postmaster@domain.mailgun.org');
```

## 🤖 Image Grabber Sources

### Danbooru
```
Source Type: danbooru
Tags: rating:safe landscape
Rating: Safe
Channel: landscapes
Auto-import: ✓
```

### Gelbooru
```
Source Type: gelbooru
Tags: cute cat rating:safe
Channel: cats
Auto-import: ✓
```

### RSS Feed
```
Source Type: rss
URL: https://example.com/feed.xml
Channel: external
Auto-import: ✓
```

### Custom URL
```
Source Type: custom
URL: https://example.com/gallery
Channel: scraped
Auto-import: ✗ (review first)
```

## 📝 Common Admin Tasks

### 1. Add Image Source
```
Admin Panel → Image Grabber
→ Add New Source
→ Fill form
→ Save
→ Grab Now (test)
```

### 2. Send Test Email
```php
// Create test file: test_email.php
<?php
require 'config/config.php';
require 'includes/smtp_mailer.php';

$mailer = new SMTPMailer();
$result = $mailer->send(
    'your-email@example.com',
    'Test Email',
    '<p>This is a test email from PXLBoard v12g!</p>',
    true
);

echo json_encode($result);
?>
```

### 3. Check Notification Settings
```
User Profile → Settings
→ Email Notifications section
→ Enable/disable types
→ Save
```

### 4. Verify Dark Mode
```
User Profile → Settings
→ Theme: dark
→ Browse: Gallery, Boards, Community Portal
→ Check: Consistent dark styling
```

## 🔧 File Structure Reference

### New Files
```
/includes/smtp_mailer.php       - SMTP email handler
/includes/image_grabber.php     - Image grabber system
/pages/admin_grabber.php        - Admin interface
/templates/gallery_card.php     - Gallery card template
```

### Updated Files
```
/includes/functions.php         - Enhanced escape()
/includes/notifications.php     - New notification types
/pages/boards.php               - Null handling fixes
/pages/community_portal.php     - Thread sorting fix
/themes/dark/style.css          - Dark mode enhancements
```

## 🚨 Troubleshooting Quick Fixes

### Template Not Found
```bash
# Check file exists
ls templates/gallery_card.php

# If missing, re-extract v12g
unzip -o PXLBoard_v12g.zip "templates/*"
```

### SMTP Not Working
```bash
# 1. Test connection
telnet smtp.gmail.com 587

# 2. Check credentials
# Gmail: Use App Password, not regular password

# 3. Check logs
tail -f /var/log/php_errors.log

# 4. Verify config
php -r "echo SMTP_ENABLED ? 'Enabled' : 'Disabled';"
```

### Grabber Not Working
```bash
# 1. Check cURL
php -m | grep curl

# 2. Test API
curl -I https://danbooru.donmai.us/posts.json

# 3. Check permissions
ls -ld uploads
chmod 755 uploads

# 4. Check config
php -r "echo GRABBER_ENABLED ? 'Enabled' : 'Disabled';"
```

### Dark Mode Issues
```
1. Clear browser cache (Ctrl+Shift+R)
2. Verify theme setting (Profile → Settings)
3. Check CSS loaded (View Source → search for "dark/style.css")
4. Re-extract theme files if needed
```

## 📊 Performance Tips

### Image Grabber
- Start with limit of 10-20 images
- Use cron for automation
- Monitor disk space

### Email
- Enable batching for high traffic
- Use queue for bulk emails
- Monitor SMTP rate limits

### Database
```sql
-- Add these indexes for better performance
CREATE INDEX idx_images_channel ON images(channel);
CREATE INDEX idx_images_uploaded_at ON images(uploaded_at);
```

## 🎨 Theme Customization

### Quick Dark Mode Tweaks
Edit `/themes/dark/style.css`:

```css
/* Change primary color */
:root {
    --primary-color: #your-color;
}

/* Adjust background */
:root {
    --bg-color: #1a1a1a;  /* Darker */
}

/* Adjust card background */
:root {
    --card-bg: #2b2b2b;  /* Lighter */
}
```

## 📋 Checklist: Post-Upgrade

- [ ] Site loads without errors
- [ ] Admin panel accessible
- [ ] Boards page works (no shortname errors)
- [ ] Gallery displays correctly
- [ ] Community portal shows threads
- [ ] Dark mode is consistent
- [ ] SMTP configured (if using)
- [ ] Grabber configured (if using)
- [ ] Notifications working
- [ ] All themes load correctly

## 🔗 Quick Links

### Admin Pages
- Dashboard: `?page=admin`
- Content: `?page=admin_content`
- Forums: `?page=admin_forums`
- **Image Grabber**: `?page=admin_grabber` ⭐ NEW

### User Pages
- Profile: `?page=profile&user=username`
- Settings: `?page=profile_settings`
- Uploads: `?page=user&username`

### Public Pages
- Gallery: `?page=gallery`
- Boards: `?page=boards`
- Community: `?page=community_portal`
- Wiki: `?page=wiki`
- Blogs: `?page=blogs`

## 💡 Pro Tips

### 1. Automated Grabbing
```bash
# Add to crontab (crontab -e)
*/30 * * * * php /path/to/pxlboard/cron_grabber.php >> /var/log/grabber.log 2>&1
```

### 2. Email Testing
Always test with your own email first:
```
1. Configure SMTP
2. Enable notifications in your profile
3. Trigger a notification (comment on own image)
4. Check inbox and spam folder
```

### 3. Gradual Rollout
Enable features one at a time:
```
Day 1: Fix bugs, verify site works
Day 2: Enable SMTP, test emails
Day 3: Add one grabber source, test
Day 4: Enable more sources gradually
```

### 4. Monitor Logs
```bash
# Watch for errors
tail -f /var/log/php_errors.log

# Watch for grabber activity
tail -f /var/log/grabber.log

# Watch for email activity
tail -f /var/log/mail.log
```

## 📞 Getting Help

1. **Check logs**: Error logs usually show the issue
2. **Verify config**: Double-check configuration values
3. **Test individually**: Isolate which feature is failing
4. **Review docs**: Check CHANGELOG_v12g.md for details
5. **Rollback if needed**: Use backup to restore

---

**Quick Reference v12g** - Updated January 31, 2026

For detailed documentation, see README_v12g.md
