# Upload Fix Guide - PXLBoard

## Issue Identified

**Problem:** Nothing happens when uploading files.

## Root Cause

The main issue was a **function name mismatch**:
- `pages/upload.php` was calling `createThumbnail()`
- But `includes/functions.php` defines the function as `generateThumbnail()`

## Fixes Applied

### 1. ✅ Fixed Function Name (CRITICAL FIX)

**File:** `pages/upload.php` (Line 81)

**Before:**
```php
createThumbnail($uploadPath, $thumbPath, THUMBNAIL_WIDTH, THUMBNAIL_HEIGHT);
```

**After:**
```php
generateThumbnail($uploadPath, $thumbPath, THUMBNAIL_WIDTH, THUMBNAIL_HEIGHT);
```

This was causing a **fatal error** that prevented the upload from working at all.

---

## Additional Checks Performed

### ✅ Constants Defined
All required constants are properly defined in `config/config.php`:
- `UPLOADS_DIR` = `/path/to/uploads`
- `MAX_UPLOAD_SIZE` = 10485760 (10MB)
- `ALLOWED_EXTENSIONS` = ['jpg', 'jpeg', 'png', 'gif', 'webp']
- `THUMBNAIL_WIDTH` = 250
- `THUMBNAIL_HEIGHT` = 250

### ✅ Helper Functions Available
All required functions exist in `includes/functions.php`:
- `generateThumbnail()` - Creates image thumbnails
- `formatBytes()` - Formats file sizes
- `timeAgo()` - Formats timestamps
- `sanitizeFilename()` - Cleans filenames

### ✅ Database Methods Working
Required database methods in `includes/database.php`:
- `getNextId()` - Generates unique IDs
- `save()` - Saves data to files
- `getAll()` - Retrieves all records

### ✅ Upload Page Structure
The upload form is properly structured:
- Form method: `POST`
- Encoding: `multipart/form-data`
- File input: `name="images[]"` (supports multiple files)
- Submit button: `name="upload"`

---

## Testing the Fix

### Step 1: Verify PHP GD Library
The thumbnail generation requires PHP GD library. Test with:

```bash
php -m | grep -i gd
```

If not installed:
```bash
# Ubuntu/Debian
sudo apt-get install php-gd

# CentOS/RHEL
sudo yum install php-gd

# Restart Apache
sudo systemctl restart apache2
```

### Step 2: Create Uploads Directory
The upload page will create directories automatically, but you can pre-create them:

```bash
mkdir -p uploads/thumbs
chmod 755 uploads
chmod 755 uploads/thumbs
```

### Step 3: Check File Permissions
Ensure Apache/PHP can write to the uploads directory:

```bash
# Check current ownership
ls -ld uploads/

# Set proper ownership (replace www-data with your web server user)
sudo chown -R www-data:www-data uploads/

# Set proper permissions
chmod 755 uploads
chmod 755 uploads/thumbs
```

### Step 4: Test Upload
1. Navigate to `/upload` or `index.php?page=upload`
2. Click "Choose Files" or drag-and-drop an image
3. Fill in title, tags, description
4. Click "Upload"
5. You should see success message and link to uploaded image

---

## Common Issues & Solutions

### Issue: "Upload failed" error

**Possible Causes:**
1. **Uploads directory not writable**
   ```bash
   chmod 755 uploads/
   sudo chown www-data:www-data uploads/
   ```

2. **PHP file upload disabled**
   Check `php.ini`:
   ```ini
   file_uploads = On
   upload_max_filesize = 10M
   post_max_size = 12M
   ```

3. **Insufficient disk space**
   ```bash
   df -h
   ```

### Issue: Image uploads but no thumbnail

**Possible Causes:**
1. **GD library missing**
   ```bash
   php -m | grep -i gd
   sudo apt-get install php-gd
   sudo systemctl restart apache2
   ```

2. **Thumbs directory not writable**
   ```bash
   mkdir -p uploads/thumbs
   chmod 755 uploads/thumbs
   sudo chown www-data:www-data uploads/thumbs
   ```

### Issue: "File too large" error

**Solution:** Increase upload limits in `.htaccess`:
```apache
php_value upload_max_filesize 50M
php_value post_max_size 52M
php_value memory_limit 256M
```

Or in `php.ini`:
```ini
upload_max_filesize = 50M
post_max_size = 52M
memory_limit = 256M
```

### Issue: Form submits but nothing happens

**Debugging Steps:**

1. **Enable PHP error display** (temporarily):
   ```php
   // Add to top of upload.php
   error_reporting(E_ALL);
   ini_set('display_errors', 1);
   ```

2. **Check error logs:**
   ```bash
   # Apache error log
   tail -f /var/log/apache2/error.log
   
   # PHP error log
   tail -f /var/log/php_errors.log
   ```

3. **Add debug output** to `pages/upload.php`:
   ```php
   // After line 16 (after POST check)
   if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['upload'])) {
       error_log("Upload attempt started");
       error_log("Files: " . print_r($_FILES, true));
       
       // ... rest of code
   }
   ```

---

## Verifying the Fix

### 1. Check for Errors
After uploading, check Apache error log:
```bash
tail -n 50 /var/log/apache2/error.log
```

Should NOT see:
- `Call to undefined function createThumbnail()`
- `Fatal error`

### 2. Check Database
After successful upload, verify image was saved:
```bash
ls -la data/images/
```

You should see `img_1.json`, `img_2.json`, etc.

### 3. Check Uploaded Files
```bash
ls -la uploads/
ls -la uploads/thumbs/
```

You should see:
- Original image in `uploads/`
- Thumbnail in `uploads/thumbs/`

### 4. Check Browser Console
Press F12 in browser and check Console tab for JavaScript errors.

---

## JavaScript Upload Flow

The upload process uses JavaScript for:
1. **Drag & Drop** - Accepts dropped files
2. **Preview** - Shows image previews
3. **Metadata** - Creates input fields for each image
4. **Progress** - Shows upload progress (visual only)

The JavaScript does NOT:
- Actually upload files (this is done by standard form POST)
- Validate file types (server-side validation only)
- Resize images (done server-side)

---

## Upload Process Flow

1. **User selects files** → JavaScript adds to preview
2. **User fills metadata** → JavaScript creates form fields
3. **User clicks "Upload"** → Standard form POST submission
4. **Server receives POST** → PHP processes upload
5. **For each file:**
   - Validate file type and size
   - Generate unique filename
   - Move to `uploads/` directory
   - Create thumbnail with `generateThumbnail()`
   - Save metadata to database
6. **Return success/error** → Display message to user

---

## File Structure After Upload

```
uploads/
├── abc123def456.jpg          # Original image
├── def789ghi012.png          # Another original
└── thumbs/
    ├── abc123def456.jpg      # Thumbnail 250x250
    └── def789ghi012.png      # Another thumbnail

data/
└── images/
    ├── img_1.json            # Image metadata
    ├── img_2.json            # More metadata
    └── _counter.txt          # ID counter
```

---

## Security Considerations

The upload system includes:

✅ **File Type Validation** - Only allowed extensions
✅ **File Size Limits** - Prevents large uploads
✅ **Unique Filenames** - Uses `uniqid()` to prevent overwrites
✅ **Directory Protection** - `.htaccess` blocks direct access to data/
✅ **PHP Execution Disabled** - In uploads directory
✅ **Extension Whitelist** - Only jpg, jpeg, png, gif, webp

---

## Performance Considerations

### Thumbnail Generation
- Uses PHP GD library
- Creates proportionally scaled thumbnails
- Preserves transparency for PNG/GIF
- Quality: 85% for JPEG, 8 compression for PNG

### Memory Usage
- Default: 128M
- Increase if uploading large images
- Each upload uses: file size + ~3x for processing

### Concurrent Uploads
- Uses file locks in database operations
- Counter increments are atomic
- Supports multiple simultaneous uploads

---

## Maintenance

### Regular Cleanup
Consider implementing:
1. **Orphaned file cleanup** - Remove uploaded files with no database entry
2. **Old file deletion** - Remove files from deleted images
3. **Disk space monitoring** - Alert when uploads/ gets too large

### Backup Strategy
Important directories to backup:
- `data/` - All database files
- `uploads/` - All uploaded images
- `config/` - Configuration files

---

## Summary

**Main Fix:** Changed `createThumbnail()` to `generateThumbnail()` in upload.php

**Status:** ✅ FIXED - Upload functionality should now work correctly

**Next Steps:**
1. Deploy the fixed `upload.php` file
2. Test uploading an image
3. Verify thumbnail generation
4. Check database entry creation

---

## Quick Test Checklist

- [ ] Upload page loads without errors
- [ ] Can select/drag files
- [ ] File previews appear
- [ ] Metadata form appears
- [ ] Upload button works
- [ ] Success message displays
- [ ] Image appears in gallery
- [ ] Thumbnail generated
- [ ] Database entry created
- [ ] Can view uploaded image

---

**Fixed By:** Assistant
**Date:** January 31, 2026
**Files Modified:** pages/upload.php (Line 81)
**Severity:** Critical (complete upload failure)
**Resolution:** Function name correction
