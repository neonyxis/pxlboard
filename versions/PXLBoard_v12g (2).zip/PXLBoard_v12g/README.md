# PXLBoard v12d

A feature-rich, flat-file PHP imageboard system inspired by Derpibooru and Philomena, with 4chan-style boards, designed for shared hosting environments.

**Current Version**: 12d (January 31, 2026)  
**Latest Updates**: Enhanced UI Themes + Advanced Tag System + Improved User Experience

## What's New in 12d

### 🎨 Premium Theme System
Complete UI overhaul with professionally designed themes:
- **DPBooru Theme** - Modern Derpibooru-inspired design with gradients, color-coded tags, and smooth animations
- **Vichan Dark Theme** - Classic dark imageboard aesthetic optimized for extended browsing
- **7 Tag Types** - Color-coded tag categorization (Artist, Character, Species, General, Meta, Rating, Content)
- **Consistent Design** - Unified theming across all pages and components

### Enhanced Boards Portal 🚀
Complete redesign of the boards section with modern features:
- **Live Search** - Find boards instantly without page reload
- **Advanced Sorting** - 5 different sort options (activity, name, threads, posts, recent)
- **Dual View Modes** - Switch between Grid and List layouts
- **Activity Tracking** - See which boards are active in real-time
- **SFW/NSFW Filtering** - Separate content by rating
- **Keyboard Shortcuts** - Navigate faster (S, ESC, G, L)
- **Statistics Dashboard** - Overview of community activity

### 🖼️ Enhanced Image View
- **Zoom Controls** - In/out/reset with keyboard shortcuts (+, -, 0)
- **Fullscreen Mode** - Immersive viewing (F key)
- **Tag Categorization** - Tags grouped by type with color coding
- **Improved Metadata** - Comprehensive image information panel
- **Related Images** - Discover similar content
- **Enhanced Comments** - Threaded discussion system
- **Quick Actions** - Share, report, edit, delete

### 🏷️ Advanced Tag System
- **Smart Auto-Detection** - Automatically categorizes common tag patterns
- **Tag Autocomplete** - Suggestions as you type
- **Related Tags** - Discover tags that commonly appear together
- **Tag Analytics** - Statistics and usage data
- **Tag Cloud** - Weighted visualization of popular tags
- **Tag Merging** - Create aliases for consistent tagging
- **Search by Tags** - Advanced tag-based search

### Performance Boost ⚡
- **Board Caching** - 76-99% faster page loads
- **Query Optimization** - Reduced database queries by 80-100%
- **Smart Statistics** - Real-time activity metrics
- **Client-Side Search** - Instant filtering without server requests
- **CSS Animations** - Hardware-accelerated for smooth performance

See `CHANGELOG_v12d.md` and `UI_ENHANCEMENTS.md` for complete details.

---

## Previous Update: 12b

### Board Moderators
- Board creators are automatic top-level moderators
- Top-level mods can add/remove other moderators
- Moderator permissions and controls

### Voting & Karma
- Upvote/downvote on threads and posts
- Karma leaderboard in Rankings
- Vote scores visible on all content

### Threaded Comments
- Reply directly to posts
- Nested comment display
- Visual threading

See `CHANGELOG_v12b.md` for details.

---

## Update: 11-2d

### 🎯 Tier 1 Features
Version 11-2d includes six major user experience enhancements:

1. **Image Hiding System** - Hide images you don't want to see
2. **Source Tracking** - Track image origins with URL references
3. **Tag Aliases** - Redirect alternate tags to canonical versions
4. **Comment Editing** - Edit comments with revision history
5. **Anonymous Uploads** - Upload without showing username
6. **Enhanced Avatars** - Improved profile picture management

See `VERSION_NOTES_11-2d.md` for complete details.

## Features

### Core Features
- **Flat-File Storage** - No database required, all data stored in JSON files
- **User System** - Registration, login, and user profiles
- **Image Upload** - Support for JPG, PNG, GIF, and WebP with automatic thumbnails
- **Gallery Views** - Grid and list view options with multiple sorting methods
- **Advanced Search** - Search by title, description, tags, or channel
- **4chan-Style Boards** - Create and manage discussion boards with threads (NEW in v12a)

### Community Features
- **Enhanced Board Portal** - Advanced board discovery with live search, filters, and dual view modes (NEW v12c)
- **Board Caching** - 76-99% faster board listing performance (NEW v12c)
- **Activity Tracking** - Real-time board activity indicators and statistics (NEW v12c)
- **Keyboard Navigation** - Fast board navigation with shortcuts (NEW v12c)
- **Board Moderators** - Top-level and regular moderator roles (NEW v12b)
- **Voting System** - Upvote/downvote threads and posts with karma tracking (NEW v12b)
- **Board System** - 4chan-style boards with threads and posts
- **User-Created Boards** - Community members can create their own boards
- **Thread Discussions** - Image-based threaded discussions with greentext
- **Anonymous Posting** - Post threads and replies anonymously
- **Rating System** - Users can rate images 1-5 stars
- **Favorites** - Save favorite images to your profile
- **Comments** - Threaded discussions with editing capability
- **User Profiles** - Public profiles showing uploads and favorites
- **Forums/Discussions** - Community forum with categories
- **Channels** - Organize images by category/topic

### Content Organization
- **Tagging System** - Flexible tagging with tag cloud
- **Tag Aliases** - Canonical tag redirects for consistency (NEW)
- **Channels** - Category-based image organization
- **Sorting Options** - Sort by newest, most viewed, highest rated, or most favorited
- **Image Hiding** - Personal content filtering (NEW)
- **Source URLs** - Track image origins (NEW)

### Administration
- **Admin Panel** - Comprehensive dashboard with statistics
- **Admin Content Panel** - Dedicated interface for managing blogs and wiki pages
- **Tag Alias Manager** - Manage tag redirects (NEW)
- **Channel Management** - Create and manage image categories
- **User Management** - View all registered users
- **Content Moderation** - Delete images and manage content
- **SMTP Configuration** - Email notifications and verification
- **Extension Manager** - Install and manage extensions/plugins

### Theming & Customization
- **Multiple Themes** - Default and Dark mode included
- **Theme Switcher** - Users can choose their preferred theme
- **Extension System** - Expandable with custom plugins
- **Responsive Design** - Mobile-friendly using Bootstrap 5

## Requirements

- PHP 7.4 or higher
- GD Library (for image processing)
- JSON extension (standard)
- ZipArchive extension (for extension manager)
- Apache with mod_rewrite (recommended)

## Installation

1. **Extract the files** to your web server directory

2. **Set permissions** (if on Linux/Unix):
   ```bash
   chmod 755 -R .
   chmod 777 -R data/
   chmod 777 -R uploads/
   ```

3. **Access the installation page**:
   Navigate to `http://yourdomain.com/` in your web browser

4. **Complete the installation wizard**:
   - Enter your site details
   - Create an admin account
   - Configure SMTP (optional)

5. **Done!** You can now log in and start using PXLBoard

## Feature Guide

### Gallery Views

The gallery page offers two view modes:
- **Grid View** - Compact thumbnail grid (default)
- **List View** - Detailed list with descriptions

Sorting options:
- Newest (default)
- Most Viewed
- Highest Rated
- Most Favorited

### Forums

Create discussion topics in different categories:
- General Discussion
- Art & Creativity
- Help & Support
- Feedback & Suggestions

Features:
- Pin important topics
- Lock closed discussions
- View counts and reply counts
- User attribution

### Channels

Channels are like categories or subreddits - organized collections of images:
- Admin creates channels
- Users upload images to specific channels
- Browse images by channel
- Each channel has its own page

### Rating System

Users can rate images from 1-5 stars:
- One rating per user per image
- Average rating displayed
- Sort gallery by rating
- Rating counts shown

### Favorites

Save images you love:
- Click the star button on any image
- View all your favorites in your profile
- Public favorite count on each image
- Browse other users' favorites

### Extensions

Extend PXLBoard with custom functionality:
- Upload ZIP extension packages
- Enable/disable extensions
- Uninstall extensions
- Hook system for customization

Available hooks:
- `before_upload` - Before image upload
- `after_upload` - After image upload
- `before_render` - Before page render
- `after_render` - After page render
- `user_login` - When user logs in
- `user_register` - When user registers

## Configuration

### Admin Panel

Access via: User Menu → Admin Panel (admins only)

Main Panel Tabs:
1. **Statistics** - View site statistics
2. **Settings** - Configure site settings, SMTP, registration
3. **Users** - View all registered users
4. **Channels** - Create and manage channels

Content Management Panel (Admin Content):
- **Blog Management** - View, edit, publish/unpublish, feature, and delete blog posts
- **Wiki Management** - View, edit, publish/unpublish, lock/unlock wiki pages, manage revisions
- **Statistics Dashboard** - Real-time content statistics
- **Bulk Actions** - Quick management of multiple content items

### Creating Channels

1. Go to Admin Panel → Channels tab
2. Enter channel name and description
3. Click "Create"
4. Channel is now available in upload form

### Extension Development

Create a ZIP file with this structure:

```
extension-name/
├── extension.json      (Required: metadata)
├── init.php            (Optional: initialization)
├── hooks.php           (Optional: hook handlers)
├── assets/             (Optional: CSS, JS, images)
└── templates/          (Optional: custom templates)
```

Example `extension.json`:
```json
{
    "name": "My Extension",
    "version": "1.0.0",
    "author": "Your Name",
    "description": "Extension description",
    "requires": "1.0.0",
    "hooks": ["before_upload", "after_upload"]
}
```

## Directory Structure

```
pxlboard/
├── config/          # Configuration files
├── data/            # Flat-file database (auto-created)
│   ├── users/       # User accounts
│   ├── images/      # Image metadata
│   ├── tags/        # Tag data
│   ├── comments/    # Image comments
│   ├── ratings/     # Image ratings
│   ├── favorites/   # User favorites
│   ├── forum_topics/    # Forum topics
│   ├── forum_replies/   # Forum replies
│   ├── channels/    # Channel definitions
│   ├── boards/      # Board definitions (NEW)
│   ├── board_threads/   # Board threads (NEW)
│   ├── board_posts/     # Board posts (NEW)
│   └── extensions/  # Installed extensions
├── includes/        # Core PHP files
├── pages/           # Page controllers
├── templates/       # HTML templates
├── themes/          # Theme files
├── uploads/         # Uploaded images (auto-created)
│   └── board_images/    # Board thread images (NEW)
├── extensions/      # Extension files (auto-created)
├── index.php        # Main entry point
├── seed_boards.php  # Create default boards (NEW)
└── .htaccess        # Apache configuration
```

## Security Notes

1. The `data/` directory is protected by `.htaccess`
2. User passwords are hashed using `password_hash()`
3. File uploads are validated and sanitized
4. XSS protection via `htmlspecialchars()`
5. CSRF tokens recommended for production
6. Consider enabling HTTPS

## Troubleshooting

### Images not uploading
1. Check directory permissions: `chmod 777 uploads/ data/`
2. Verify GD library: `php -m | grep gd`
3. Check PHP upload limits in `.htaccess`

### Extensions not installing
1. Verify ZipArchive is enabled: `php -m | grep zip`
2. Check `extensions/` directory permissions
3. Ensure extension package has `extension.json`

### Forums not appearing
Make sure you're logged in - forums require authentication

### Ratings not saving
Users must be logged in to rate images

## Community Features Usage

### For Users
- Upload images and tag them appropriately
- Rate images you enjoy
- Add favorites to your collection
- Participate in forum discussions
- Browse by channels to find specific content

### For Administrators
- Create channels to organize content
- Monitor user activity in admin panel
- Install extensions to add features
- Configure SMTP for email notifications
- Moderate content and manage users

## Performance Tips

1. Enable PHP opcode caching (OPcache)
2. Use CDN for Bootstrap/CSS assets
3. Implement lazy loading for images
4. Regular cleanup of old cache files
5. Consider moving to dedicated hosting for large communities

## Support

For issues, feature requests, or contributions:
- Check the INSTALLATION_GUIDE.md
- Review this README thoroughly
- Check file permissions
- Verify PHP version and extensions

## Credits

- Inspired by Derpibooru and Philomena
- Built with PHP and Bootstrap 5
- Flat-file architecture for simplicity

## License

MIT License - See LICENSE file for details

---

**Version:** 12d  
**Release Date:** January 31, 2026  
**Author:** PXLBoard Team  
**Website:** https://github.com/pxlboard
