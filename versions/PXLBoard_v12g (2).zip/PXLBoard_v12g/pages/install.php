<?php
/**
 * Installation Page
 */

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $siteName = $_POST['site_name'] ?? '';
    $siteUrl = $_POST['site_url'] ?? '';
    $adminUsername = $_POST['admin_username'] ?? '';
    $adminEmail = $_POST['admin_email'] ?? '';
    $adminPassword = $_POST['admin_password'] ?? '';
    
    // Validate
    if (empty($siteName) || empty($siteUrl) || empty($adminUsername) || empty($adminEmail) || empty($adminPassword)) {
        $error = 'All fields are required';
    } elseif (strlen($adminPassword) < PASSWORD_MIN_LENGTH) {
        $error = 'Password must be at least ' . PASSWORD_MIN_LENGTH . ' characters';
    } else {
        // Create settings
        $settings = [
            'site_name' => $siteName,
            'site_description' => $_POST['site_description'] ?? '',
            'site_url' => rtrim($siteUrl, '/'),
            'admin_email' => $adminEmail,
            'max_upload_size' => 10485760,
            'smtp_enabled' => false,
            'registration_enabled' => true,
            'email_verification' => false,
            'default_theme' => 'default',
            'timezone' => 'UTC'
        ];
        
        file_put_contents(DATA_DIR . '/settings.json', json_encode($settings, JSON_PRETTY_PRINT));
        
        // Create admin user
        $adminId = 'admin_' . uniqid();
        $adminData = [
            'username' => $adminUsername,
            'email' => $adminEmail,
            'password' => password_hash($adminPassword, PASSWORD_DEFAULT),
            'role' => 'admin',
            'created_at' => time(),
            'verified' => true
        ];
        
        $db->save('users', $adminId, $adminData);
        
        // Create installation lock
        file_put_contents(DATA_DIR . '/installed.lock', date('Y-m-d H:i:s'));
        
        // Auto-patch .htaccess RewriteBase to match the actual subdirectory.
        // dirname(SCRIPT_NAME) is e.g. "/pxlboard/V11d" or "/" — always correct.
        $htaccessPath = BASE_DIR . '/.htaccess';
        if (file_exists($htaccessPath)) {
            $rewriteBase = dirname($_SERVER['SCRIPT_NAME']);
            if ($rewriteBase !== '/') {
                $rewriteBase = rtrim($rewriteBase, '/') . '/';
            }
            $htaccess = file_get_contents($htaccessPath);
            $htaccess = preg_replace(
                '/^(\s*)RewriteBase\s+.*$/m',
                '$1RewriteBase ' . $rewriteBase,
                $htaccess
            );
            @file_put_contents($htaccessPath, $htaccess);
        }
        
        $success = 'Installation completed successfully! You can now log in.';
        
        // Redirect to login after 2 seconds
        header('Refresh: 2; URL=index.php?page=login');
    }
}

require 'templates/header.php';
?>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h2>Install PXLBoard</h2>
                </div>
                <div class="card-body">
                    <?php if ($error): ?>
                        <div class="alert alert-danger"><?php echo escape($error); ?></div>
                    <?php endif; ?>
                    
                    <?php if ($success): ?>
                        <div class="alert alert-success"><?php echo escape($success); ?></div>
                    <?php else: ?>
                        <form method="POST">
                            <h4>Site Settings</h4>
                            
                            <div class="mb-3">
                                <label class="form-label">Site Name</label>
                                <input type="text" name="site_name" class="form-control" required value="PXLBoard">
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Site Description</label>
                                <input type="text" name="site_description" class="form-control" value="An image board system">
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Site URL (without trailing slash)</label>
                                <input type="url" name="site_url" class="form-control" required 
                                       value="<?php echo (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['SCRIPT_NAME']); ?>">
                            </div>
                            
                            <hr class="my-4">
                            <h4>Administrator Account</h4>
                            
                            <div class="mb-3">
                                <label class="form-label">Username</label>
                                <input type="text" name="admin_username" class="form-control" required value="admin">
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Email</label>
                                <input type="email" name="admin_email" class="form-control" required>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Password (min <?php echo PASSWORD_MIN_LENGTH; ?> characters)</label>
                                <input type="password" name="admin_password" class="form-control" required>
                            </div>
                            
                            <button type="submit" class="btn btn-primary">Install PXLBoard</button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require 'templates/footer.php'; ?>
