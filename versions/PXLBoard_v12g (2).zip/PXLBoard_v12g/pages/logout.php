<?php
/**
 * Logout Page
 */

$auth->logout();
redirect('index.php?page=home');
