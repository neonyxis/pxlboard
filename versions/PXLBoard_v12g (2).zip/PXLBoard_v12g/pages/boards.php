<?php
/**
 * Boards Portal - List all discussion boards
 */

// Fetch all boards
$boards = $db->getAll('boards') ?? [];

// Initialize search query
$search_query = $_GET['search'] ?? '';

// Initialize view mode (grid or list)
$view_mode = $_GET['view'] ?? 'grid';

// Initialize filter variables
$sort_by = $_GET['sort'] ?? 'activity';
$filter_nsfw = $_GET['filter'] ?? 'all';

// Filter boards if search query exists
if (!empty($search_query)) {
    $search_lower = strtolower($search_query);
    $boards = array_filter($boards, function($board) use ($search_lower) {
        return strpos(strtolower($board['name'] ?? ''), $search_lower) !== false ||
               strpos(strtolower($board['description'] ?? ''), $search_lower) !== false ||
               strpos(strtolower($board['tags'] ?? ''), $search_lower) !== false;
    });
}

// Sort boards
switch ($sort_by) {
    case 'name':
        usort($boards, function($a, $b) {
            return strcasecmp($a['name'] ?? '', $b['name'] ?? '');
        });
        break;
    case 'threads':
        usort($boards, function($a, $b) {
            return ($b['thread_count'] ?? 0) - ($a['thread_count'] ?? 0);
        });
        break;
    case 'posts':
        usort($boards, function($a, $b) {
            return ($b['post_count'] ?? 0) - ($a['post_count'] ?? 0);
        });
        break;
    case 'recent':
        usort($boards, function($a, $b) {
            return ($b['last_post_time'] ?? 0) - ($a['last_post_time'] ?? 0);
        });
        break;
    case 'activity':
    default:
        usort($boards, function($a, $b) {
            return ($b['recent_activity'] ?? 0) - ($a['recent_activity'] ?? 0);
        });
        break;
}

require 'templates/header.php';
?>

<!-- Enhanced Boards Portal - Inspired by DPBooru, Vichan, and Shimmie2 -->

<div class="container-fluid px-4 py-4">
    <!-- Page Header -->
    <div class="row mb-4">
        <div class="col">
            <h1 class="display-4 mb-2">
                <i class="bi bi-collection"></i> Boards
            </h1>
            <p class="lead text-muted">
                Explore discussion boards and join the conversation
            </p>
        </div>
        <?php if ($auth->isLoggedIn()): ?>
            <div class="col-auto">
                <a href="index.php?page=create_board" class="btn btn-primary btn-lg">
                    <i class="bi bi-plus-circle"></i> Create Board
                </a>
            </div>
        <?php endif; ?>
    </div>

    <!-- Statistics Banner - DPBooru inspired -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="stats-banner p-3 rounded" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white;">
                <div class="row text-center">
                    <div class="col-md-3 col-6 mb-2 mb-md-0">
                        <div class="stat-item">
                            <i class="bi bi-grid-3x3 fs-1"></i>
                            <div class="stat-value fs-2 fw-bold"><?php echo count($boards); ?></div>
                            <div class="stat-label">Total Boards</div>
                        </div>
                    </div>
                    <div class="col-md-3 col-6 mb-2 mb-md-0">
                        <div class="stat-item">
                            <i class="bi bi-chat-dots fs-1"></i>
                            <div class="stat-value fs-2 fw-bold">
                                <?php 
                                $totalThreads = 0;
                                foreach ($boards as $board) {
                                    $totalThreads += $board['thread_count'] ?? 0;
                                }
                                echo number_format($totalThreads);
                                ?>
                            </div>
                            <div class="stat-label">Total Threads</div>
                        </div>
                    </div>
                    <div class="col-md-3 col-6">
                        <div class="stat-item">
                            <i class="bi bi-activity fs-1"></i>
                            <div class="stat-value fs-2 fw-bold">
                                <?php 
                                $activeBoards = 0;
                                foreach ($boards as $board) {
                                    if (($board['recent_activity'] ?? 0) > 0) {
                                        $activeBoards++;
                                    }
                                }
                                echo $activeBoards;
                                ?>
                            </div>
                            <div class="stat-label">Active Today</div>
                        </div>
                    </div>
                    <div class="col-md-3 col-6">
                        <div class="stat-item">
                            <i class="bi bi-people fs-1"></i>
                            <div class="stat-value fs-2 fw-bold">
                                <?php echo number_format(count($db->getAll('users'))); ?>
                            </div>
                            <div class="stat-label">Community Members</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Filter Controls - Shimmie2 inspired -->
    <div class="filter-controls">
        <div class="row g-3">
            <!-- Search -->
            <div class="col-md-4">
                <div class="filter-section">
                    <label class="filter-label">
                        <i class="bi bi-search"></i> Search Boards
                    </label>
                    <input type="text" 
                           id="boardSearch" 
                           class="form-control" 
                           placeholder="Type to search boards..."
                           value="<?php echo escape($search_query); ?>"
                           autocomplete="off">
                    <small class="text-muted">Search by name, description, or tag</small>
                </div>
            </div>

            <!-- Sort Options -->
            <div class="col-md-3">
                <div class="filter-section">
                    <label class="filter-label">
                        <i class="bi bi-sort-down"></i> Sort By
                    </label>
                    <select id="sortBy" class="form-select">
                        <option value="activity" <?php echo $sort_by === 'activity' ? 'selected' : ''; ?>>
                            Most Active
                        </option>
                        <option value="recent" <?php echo $sort_by === 'recent' ? 'selected' : ''; ?>>
                            Recently Updated
                        </option>
                        <option value="name" <?php echo $sort_by === 'name' ? 'selected' : ''; ?>>
                            Alphabetical
                        </option>
                        <option value="threads" <?php echo $sort_by === 'threads' ? 'selected' : ''; ?>>
                            Most Threads
                        </option>
                        <option value="posts" <?php echo $sort_by === 'posts' ? 'selected' : ''; ?>>
                            Most Posts
                        </option>
                    </select>
                </div>
            </div>

            <!-- Content Rating Filter -->
            <div class="col-md-3">
                <div class="filter-section">
                    <label class="filter-label">
                        <i class="bi bi-shield-check"></i> Content Rating
                    </label>
                    <div class="filter-buttons">
                        <button class="filter-btn <?php echo $filter_nsfw === 'all' ? 'active' : ''; ?>" 
                                data-filter="all">
                            All Boards
                        </button>
                        <button class="filter-btn <?php echo $filter_nsfw === 'sfw' ? 'active' : ''; ?>" 
                                data-filter="sfw">
                            <i class="bi bi-check-circle"></i> SFW Only
                        </button>
                        <button class="filter-btn <?php echo $filter_nsfw === 'nsfw' ? 'active' : ''; ?>" 
                                data-filter="nsfw">
                            <i class="bi bi-exclamation-triangle"></i> NSFW Only
                        </button>
                    </div>
                </div>
            </div>

            <!-- View Mode Toggle -->
            <div class="col-md-2">
                <div class="filter-section">
                    <label class="filter-label">
                        <i class="bi bi-grid"></i> View Mode
                    </label>
                    <div class="view-toggle">
                        <button class="view-toggle-btn <?php echo $view_mode === 'grid' ? 'active' : ''; ?>" 
                                data-view="grid"
                                title="Grid View">
                            <i class="bi bi-grid-3x3"></i>
                        </button>
                        <button class="view-toggle-btn <?php echo $view_mode === 'list' ? 'active' : ''; ?>" 
                                data-view="list"
                                title="List View">
                            <i class="bi bi-list-ul"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Quick Stats -->
        <div class="row mt-3">
            <div class="col">
                <div class="d-flex align-items-center gap-3 flex-wrap">
                    <span class="text-muted">
                        <i class="bi bi-funnel"></i> 
                        Showing <strong id="boardCount"><?php echo count($boards); ?></strong> boards
                    </span>
                    <span class="text-muted">|</span>
                    <button class="btn btn-sm btn-outline-secondary" onclick="resetFilters()">
                        <i class="bi bi-x-circle"></i> Reset Filters
                    </button>
                    <div class="ms-auto">
                        <span class="text-muted">
                            <i class="bi bi-keyboard"></i> 
                            Press <kbd>S</kbd> to search, <kbd>ESC</kbd> to clear
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Boards Grid/List -->
    <div id="boardsContainer">
        <?php if ($view_mode === 'grid'): ?>
            <!-- Grid View - DPBooru inspired -->
            <div class="row g-3" id="boardsGrid">
                <?php foreach ($boards as $board): ?>
                    <div class="col-lg-4 col-md-6 board-item" 
                         data-name="<?php echo escape(strtolower($board['name'])); ?>"
                         data-description="<?php echo escape(strtolower($board['description'] ?? '')); ?>"
                         data-nsfw="<?php echo isset($board['nsfw']) && $board['nsfw'] ? 'nsfw' : 'sfw'; ?>"
                         data-activity="<?php echo $board['recent_activity'] ?? 0; ?>"
                         data-threads="<?php echo $board['thread_count'] ?? 0; ?>"
                         data-updated="<?php echo $board['last_activity'] ?? 0; ?>">
                        <div class="board-card">
                            <!-- Activity Indicator -->
                            <div class="d-flex align-items-center mb-2">
                                <?php 
                                $activity = $board['recent_activity'] ?? 0;
                                $activityClass = $activity > 10 ? 'activity-high' : 
                                               ($activity > 3 ? 'activity-medium' : 'activity-low');
                                ?>
                                <span class="activity-indicator <?php echo $activityClass; ?>"></span>
                                <small class="text-muted">
                                    <?php echo $activity > 0 ? "{$activity} active threads today" : 'No recent activity'; ?>
                                </small>
                                <?php if (isset($board['nsfw']) && $board['nsfw']): ?>
                                    <span class="badge bg-danger ms-auto">NSFW</span>
                                <?php else: ?>
                                    <span class="badge bg-success ms-auto">SFW</span>
                                <?php endif; ?>
                            </div>

                            <!-- Board Title -->
                            <div class="board-title">
                                <a href="<?php echo buildUrl('board', $board['shortname'] ?? $board['id']); ?>">
                                    <?php echo escape($board['name'] ?? 'Untitled Board'); ?>
                                </a>
                            </div>

                            <!-- Board Shortname -->
                            <div class="board-shortname">
                                /<?php echo escape($board['shortname'] ?? 'board_' . $board['id']); ?>/
                            </div>

                            <!-- Board Description -->
                            <div class="board-description">
                                <?php echo escape($board['description'] ?? 'No description provided.'); ?>
                            </div>

                            <!-- Board Stats -->
                            <div class="board-stats">
                                <div class="board-stat">
                                    <div class="board-stat-value">
                                        <?php echo number_format($board['thread_count'] ?? 0); ?>
                                    </div>
                                    <div class="board-stat-label">Threads</div>
                                </div>
                                <div class="board-stat">
                                    <div class="board-stat-value">
                                        <?php echo number_format($board['post_count'] ?? 0); ?>
                                    </div>
                                    <div class="board-stat-label">Posts</div>
                                </div>
                                <div class="board-stat">
                                    <div class="board-stat-value">
                                        <?php 
                                        $lastActivity = $board['last_activity'] ?? 0;
                                        if ($lastActivity > 0) {
                                            $diff = time() - $lastActivity;
                                            if ($diff < 3600) {
                                                echo ceil($diff / 60) . 'm';
                                            } elseif ($diff < 86400) {
                                                echo ceil($diff / 3600) . 'h';
                                            } else {
                                                echo ceil($diff / 86400) . 'd';
                                            }
                                        } else {
                                            echo '-';
                                        }
                                        ?>
                                    </div>
                                    <div class="board-stat-label">Last Post</div>
                                </div>
                            </div>

                            <!-- Admin Actions -->
                            <?php if ($auth->isAdmin()): ?>
                                <div class="mt-3 pt-3 border-top">
                                    <form method="POST" style="display:inline;" 
                                          onsubmit="return confirm('Are you sure you want to delete this board?');">
                                        <input type="hidden" name="delete_board" value="1">
                                        <input type="hidden" name="board_id" value="<?php echo $board['id']; ?>">
                                        <button type="submit" class="btn btn-sm btn-danger">
                                            <i class="bi bi-trash"></i> Delete
                                        </button>
                                    </form>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

        <?php else: ?>
            <!-- List View - Vichan inspired -->
            <div class="board-list" id="boardsList">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th width="5%"></th>
                                <th width="25%">Board</th>
                                <th width="40%">Description</th>
                                <th width="10%" class="text-center">Threads</th>
                                <th width="10%" class="text-center">Posts</th>
                                <th width="10%" class="text-center">Last Activity</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($boards as $board): ?>
                                <tr class="board-item"
                                    data-name="<?php echo escape(strtolower($board['name'])); ?>"
                                    data-description="<?php echo escape(strtolower($board['description'] ?? '')); ?>"
                                    data-nsfw="<?php echo isset($board['nsfw']) && $board['nsfw'] ? 'nsfw' : 'sfw'; ?>"
                                    data-activity="<?php echo $board['recent_activity'] ?? 0; ?>"
                                    data-threads="<?php echo $board['thread_count'] ?? 0; ?>"
                                    data-updated="<?php echo $board['last_activity'] ?? 0; ?>">
                                    <td>
                                        <?php 
                                        $activity = $board['recent_activity'] ?? 0;
                                        $activityClass = $activity > 10 ? 'activity-high' : 
                                                       ($activity > 3 ? 'activity-medium' : 'activity-low');
                                        ?>
                                        <span class="activity-indicator <?php echo $activityClass; ?>"></span>
                                    </td>
                                    <td>
                                        <div class="fw-bold">
                                            <a href="<?php echo buildUrl('board', $board['shortname']); ?>">
                                                <?php echo escape($board['name']); ?>
                                            </a>
                                        </div>
                                        <small class="text-muted">/<?php echo escape($board['shortname']); ?>/</small>
                                        <?php if (isset($board['nsfw']) && $board['nsfw']): ?>
                                            <span class="badge bg-danger ms-1">NSFW</span>
                                        <?php else: ?>
                                            <span class="badge bg-success ms-1">SFW</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php echo escape($board['description'] ?? 'No description'); ?>
                                    </td>
                                    <td class="text-center">
                                        <strong><?php echo number_format($board['thread_count'] ?? 0); ?></strong>
                                    </td>
                                    <td class="text-center">
                                        <strong><?php echo number_format($board['post_count'] ?? 0); ?></strong>
                                    </td>
                                    <td class="text-center">
                                        <small class="text-muted">
                                            <?php 
                                            $lastActivity = $board['last_activity'] ?? 0;
                                            if ($lastActivity > 0) {
                                                echo timeAgo($lastActivity);
                                            } else {
                                                echo 'Never';
                                            }
                                            ?>
                                        </small>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <!-- No Results Message -->
    <div id="noResults" class="text-center py-5" style="display: none;">
        <i class="bi bi-search fs-1 text-muted"></i>
        <h3 class="mt-3">No boards found</h3>
        <p class="text-muted">Try adjusting your search or filters</p>
    </div>
</div>

<!-- Enhanced JavaScript -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('boardSearch');
    const sortSelect = document.getElementById('sortBy');
    const filterButtons = document.querySelectorAll('.filter-btn');
    const viewButtons = document.querySelectorAll('.view-toggle-btn');
    const boardItems = document.querySelectorAll('.board-item');
    const noResults = document.getElementById('noResults');
    const boardCount = document.getElementById('boardCount');

    let currentFilter = '<?php echo $filter_nsfw; ?>';
    let currentView = '<?php echo $view_mode; ?>';
    let currentSort = '<?php echo $sort_by; ?>';

    // Search functionality
    searchInput.addEventListener('input', debounce(filterBoards, 300));

    // Sort functionality
    sortSelect.addEventListener('change', function() {
        currentSort = this.value;
        sortBoards();
        updateURL();
    });

    // Filter buttons
    filterButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            filterButtons.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            currentFilter = this.dataset.filter;
            filterBoards();
            updateURL();
        });
    });

    // View toggle
    viewButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            viewButtons.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            currentView = this.dataset.view;
            updateURL();
            window.location.reload();
        });
    });

    // Filter boards
    function filterBoards() {
        const searchTerm = searchInput.value.toLowerCase();
        let visibleCount = 0;

        boardItems.forEach(item => {
            const name = item.dataset.name;
            const description = item.dataset.description;
            const nsfw = item.dataset.nsfw;

            const matchesSearch = searchTerm === '' || 
                                name.includes(searchTerm) || 
                                description.includes(searchTerm);
            
            const matchesFilter = currentFilter === 'all' || nsfw === currentFilter;

            if (matchesSearch && matchesFilter) {
                item.style.display = '';
                visibleCount++;
            } else {
                item.style.display = 'none';
            }
        });

        boardCount.textContent = visibleCount;
        noResults.style.display = visibleCount === 0 ? 'block' : 'none';
    }

    // Sort boards
    function sortBoards() {
        const container = currentView === 'grid' ? 
                         document.getElementById('boardsGrid') : 
                         document.querySelector('.board-list tbody');
        
        const items = Array.from(boardItems);
        
        items.sort((a, b) => {
            switch(currentSort) {
                case 'activity':
                    return parseInt(b.dataset.activity) - parseInt(a.dataset.activity);
                case 'recent':
                    return parseInt(b.dataset.updated) - parseInt(a.dataset.updated);
                case 'name':
                    return a.dataset.name.localeCompare(b.dataset.name);
                case 'threads':
                    return parseInt(b.dataset.threads) - parseInt(a.dataset.threads);
                case 'posts':
                    return parseInt(b.dataset.posts || 0) - parseInt(a.dataset.posts || 0);
                default:
                    return 0;
            }
        });

        items.forEach(item => {
            container.appendChild(item.closest(currentView === 'grid' ? '.col-lg-4' : 'tr'));
        });
    }

    // Update URL without reload
    function updateURL() {
        const params = new URLSearchParams();
        params.set('page', 'boards');
        if (currentView !== 'grid') params.set('view', currentView);
        if (currentSort !== 'activity') params.set('sort', currentSort);
        if (currentFilter !== 'all') params.set(currentFilter, '1');
        if (searchInput.value) params.set('search', searchInput.value);
        
        history.replaceState(null, '', '?' + params.toString());
    }

    // Keyboard shortcuts
    document.addEventListener('keydown', function(e) {
        if (e.key === 's' && !e.ctrlKey && !e.metaKey) {
            if (document.activeElement !== searchInput) {
                e.preventDefault();
                searchInput.focus();
            }
        } else if (e.key === 'Escape') {
            searchInput.value = '';
            searchInput.blur();
            filterBoards();
        } else if (e.key === 'g' && !e.ctrlKey && !e.metaKey) {
            if (document.activeElement !== searchInput) {
                e.preventDefault();
                viewButtons[0].click();
            }
        } else if (e.key === 'l' && !e.ctrlKey && !e.metaKey) {
            if (document.activeElement !== searchInput) {
                e.preventDefault();
                viewButtons[1].click();
            }
        }
    });

    // Debounce helper
    function debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }

    // Initial sort
    sortBoards();
});

// Reset filters function
function resetFilters() {
    document.getElementById('boardSearch').value = '';
    document.getElementById('sortBy').value = 'activity';
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.classList.remove('active');
        if (btn.dataset.filter === 'all') {
            btn.classList.add('active');
        }
    });
    window.location.href = 'index.php?page=boards';
}
</script>

<style>
/* Additional inline styles for stats banner */
.stats-banner .stat-item {
    transition: transform 0.2s ease;
}

.stats-banner .stat-item:hover {
    transform: translateY(-3px);
}

.stats-banner .stat-value {
    margin: 0.5rem 0;
}

.stats-banner .stat-label {
    font-size: 0.9rem;
    opacity: 0.9;
}

kbd {
    padding: 0.2rem 0.4rem;
    font-size: 0.875rem;
    background-color: var(--bs-gray-200);
    border-radius: 3px;
    border: 1px solid var(--bs-gray-400);
}
</style>

<?php require 'templates/footer.php'; ?>
