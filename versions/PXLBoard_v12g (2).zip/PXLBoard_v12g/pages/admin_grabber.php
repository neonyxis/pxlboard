<?php
/**
 * Admin - Image Grabber Management
 * Interface for configuring and managing image sources
 */

require_once 'includes/image_grabber.php';

// Check admin access
if (!$auth->isLoggedIn() || !$auth->isAdmin()) {
    header('Location: index.php');
    exit;
}

$grabber = new ImageGrabber($db, 'uploads');

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    switch ($action) {
        case 'add_source':
            $type = $_POST['source_type'] ?? '';
            $config = [
                'name' => $_POST['source_name'] ?? '',
                'enabled' => isset($_POST['enabled']),
                'tags' => $_POST['tags'] ?? '',
                'rating' => $_POST['rating'] ?? 's',
                'url' => $_POST['url'] ?? '',
                'auto_import' => isset($_POST['auto_import']),
                'channel' => $_POST['channel'] ?? 'default'
            ];
            
            $result = $grabber->addSource($type, $config);
            if ($result['success']) {
                $message = "Source added successfully!";
                $messageType = "success";
            } else {
                $message = "Error: " . $result['error'];
                $messageType = "danger";
            }
            break;
            
        case 'grab_now':
            $sourceId = $_POST['source_id'] ?? '';
            $limit = intval($_POST['limit'] ?? 10);
            $result = $grabber->grabFromSource($sourceId, $limit);
            
            if ($result['success']) {
                $message = "Grabbed {$result['count']} images from source!";
                $messageType = "success";
                
                // Auto-import if enabled
                if (isset($_POST['auto_import'])) {
                    $imported = 0;
                    foreach ($result['images'] as $img) {
                        $importResult = $grabber->importImage($img, 'AutoGrabber', $_POST['channel'] ?? 'default');
                        if ($importResult['success']) $imported++;
                    }
                    $message .= " Imported {$imported} images.";
                }
            } else {
                $message = "Error: " . $result['error'];
                $messageType = "danger";
            }
            break;
            
        case 'run_all':
            $results = $grabber->runAll(10);
            $totalGrabbed = 0;
            foreach ($results as $result) {
                if (isset($result['count'])) $totalGrabbed += $result['count'];
            }
            $message = "Grabbed {$totalGrabbed} images from all sources!";
            $messageType = "success";
            break;
    }
}

$sources = $db->getAll('grabber_sources') ?? [];

require 'templates/header.php';
?>

<div class="container-fluid px-4 py-4">
    <!-- Page Header -->
    <div class="row mb-4">
        <div class="col">
            <h1 class="display-5 mb-2">
                <i class="bi bi-download"></i> Image Grabber
            </h1>
            <p class="lead text-muted">
                Automatically pull images from external sources
            </p>
        </div>
    </div>

    <?php if (isset($message)): ?>
        <div class="alert alert-<?php echo $messageType; ?> alert-dismissible fade show">
            <?php echo escape($message); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="row">
        <!-- Add New Source -->
        <div class="col-lg-4 mb-4">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0"><i class="bi bi-plus-circle"></i> Add New Source</h5>
                </div>
                <div class="card-body">
                    <form method="post">
                        <input type="hidden" name="action" value="add_source">
                        
                        <div class="mb-3">
                            <label class="form-label">Source Type</label>
                            <select name="source_type" class="form-select" id="sourceTypeSelect" required>
                                <option value="">Select type...</option>
                                <option value="danbooru">Danbooru</option>
                                <option value="gelbooru">Gelbooru</option>
                                <option value="safebooru">Safebooru</option>
                                <option value="konachan">Konachan</option>
                                <option value="rss">RSS Feed</option>
                                <option value="custom">Custom URL</option>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Source Name</label>
                            <input type="text" name="source_name" class="form-control" required>
                        </div>
                        
                        <div class="mb-3" id="booruOptions" style="display: none;">
                            <label class="form-label">Tags (space-separated)</label>
                            <input type="text" name="tags" class="form-control" placeholder="rating:safe cute">
                            <small class="text-muted">Leave empty for all</small>
                        </div>
                        
                        <div class="mb-3" id="booruRating" style="display: none;">
                            <label class="form-label">Rating Filter</label>
                            <select name="rating" class="form-select">
                                <option value="s">Safe</option>
                                <option value="q">Questionable</option>
                                <option value="e">Explicit</option>
                            </select>
                        </div>
                        
                        <div class="mb-3" id="urlOption" style="display: none;">
                            <label class="form-label">URL</label>
                            <input type="url" name="url" class="form-control" placeholder="https://example.com/feed">
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Default Channel</label>
                            <input type="text" name="channel" class="form-control" value="default">
                        </div>
                        
                        <div class="form-check mb-3">
                            <input type="checkbox" name="enabled" class="form-check-input" id="enabledCheck" checked>
                            <label class="form-check-label" for="enabledCheck">Enabled</label>
                        </div>
                        
                        <div class="form-check mb-3">
                            <input type="checkbox" name="auto_import" class="form-check-input" id="autoImportCheck">
                            <label class="form-check-label" for="autoImportCheck">Auto-import grabbed images</label>
                        </div>
                        
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="bi bi-plus"></i> Add Source
                        </button>
                    </form>
                </div>
            </div>

            <!-- Run All Sources -->
            <div class="card mt-3">
                <div class="card-body">
                    <form method="post">
                        <input type="hidden" name="action" value="run_all">
                        <button type="submit" class="btn btn-success w-100">
                            <i class="bi bi-play-circle"></i> Run All Sources Now
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Existing Sources -->
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0"><i class="bi bi-list"></i> Configured Sources</h5>
                </div>
                <div class="card-body">
                    <?php if (empty($sources)): ?>
                        <div class="text-center text-muted py-5">
                            <i class="bi bi-inbox display-4"></i>
                            <p class="mt-3">No sources configured yet</p>
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Type</th>
                                        <th>Status</th>
                                        <th>Last Run</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($sources as $sourceId => $source): ?>
                                        <tr>
                                            <td>
                                                <strong><?php echo escape($source['name']); ?></strong>
                                                <?php if (isset($source['config']['tags']) && !empty($source['config']['tags'])): ?>
                                                    <br><small class="text-muted">Tags: <?php echo escape($source['config']['tags']); ?></small>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <span class="badge bg-info"><?php echo escape($source['type']); ?></span>
                                            </td>
                                            <td>
                                                <?php if ($source['enabled']): ?>
                                                    <span class="badge bg-success">Enabled</span>
                                                <?php else: ?>
                                                    <span class="badge bg-secondary">Disabled</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if ($source['last_run']): ?>
                                                    <?php echo date('M j, Y g:i A', $source['last_run']); ?>
                                                <?php else: ?>
                                                    <span class="text-muted">Never</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <form method="post" class="d-inline">
                                                    <input type="hidden" name="action" value="grab_now">
                                                    <input type="hidden" name="source_id" value="<?php echo escape($sourceId); ?>">
                                                    <input type="hidden" name="limit" value="10">
                                                    <input type="hidden" name="channel" value="<?php echo escape($source['config']['channel'] ?? 'default'); ?>">
                                                    <?php if ($source['config']['auto_import'] ?? false): ?>
                                                        <input type="hidden" name="auto_import" value="1">
                                                    <?php endif; ?>
                                                    <button type="submit" class="btn btn-sm btn-primary" title="Grab Now">
                                                        <i class="bi bi-download"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Documentation -->
            <div class="card mt-4">
                <div class="card-header">
                    <h5 class="mb-0"><i class="bi bi-info-circle"></i> Documentation</h5>
                </div>
                <div class="card-body">
                    <h6>Supported Sources:</h6>
                    <ul>
                        <li><strong>Danbooru:</strong> Popular anime/manga image board with tagging system</li>
                        <li><strong>Gelbooru:</strong> Large anime image board</li>
                        <li><strong>Safebooru:</strong> Safe-for-work version of Gelbooru</li>
                        <li><strong>Konachan:</strong> High-quality anime wallpapers</li>
                        <li><strong>RSS Feed:</strong> Any RSS/Atom feed with images</li>
                        <li><strong>Custom URL:</strong> Scrape images from any webpage</li>
                    </ul>
                    
                    <h6 class="mt-3">Tag Syntax:</h6>
                    <p class="small">Use space-separated tags. Examples:</p>
                    <ul class="small">
                        <li><code>cat rating:safe</code> - Safe images tagged with "cat"</li>
                        <li><code>landscape 1girl</code> - Images with landscape and one girl</li>
                        <li><code>rating:safe order:score</code> - Safe images ordered by score</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Show/hide fields based on source type
document.getElementById('sourceTypeSelect').addEventListener('change', function() {
    const type = this.value;
    const booruTypes = ['danbooru', 'gelbooru', 'safebooru', 'konachan'];
    const urlTypes = ['rss', 'custom'];
    
    document.getElementById('booruOptions').style.display = 
        booruTypes.includes(type) ? 'block' : 'none';
    document.getElementById('booruRating').style.display = 
        booruTypes.includes(type) ? 'block' : 'none';
    document.getElementById('urlOption').style.display = 
        urlTypes.includes(type) ? 'block' : 'none';
});
</script>

<?php require 'templates/footer.php'; ?>
