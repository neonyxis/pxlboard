<?php
/**
 * Enhanced Admin Panel with Blog and Wiki Management
 */

if (!$auth->isAdmin()) {
    redirect('index.php?page=home');
}

$message = '';
$error = '';

// Handle actions
if (isset($_GET['action'])) {
    switch ($_GET['action']) {
        case 'delete_image':
            $imageId = $_GET['id'] ?? '';
            $image = $db->get('images', $imageId);
            
            if ($image) {
                // Delete files
                @unlink(UPLOADS_DIR . '/' . $image['filename']);
                @unlink(UPLOADS_DIR . '/thumbs/' . $image['filename']);
                
                // Delete from database
                $db->delete('images', $imageId);
                
                $message = 'Image deleted successfully';
            }
            break;
            
        case 'delete_blog':
            $blogId = $_GET['id'] ?? '';
            if ($db->get('blog_posts', $blogId)) {
                // Delete associated comments
                $allComments = $db->getAll('blog_comments');
                foreach ($allComments as $comment) {
                    if ($comment['post_id'] === $blogId) {
                        $db->delete('blog_comments', $comment['id']);
                    }
                }
                
                // Delete blog post
                $db->delete('blog_posts', $blogId);
                $message = 'Blog post and associated comments deleted successfully';
            }
            break;
            
        case 'toggle_blog_status':
            $blogId = $_GET['id'] ?? '';
            $blog = $db->get('blog_posts', $blogId);
            if ($blog) {
                $blog['status'] = $blog['status'] === 'published' ? 'draft' : 'published';
                $db->save('blog_posts', $blogId, $blog);
                $message = 'Blog status updated to ' . $blog['status'];
            }
            break;
            
        case 'delete_wiki':
            $wikiId = $_GET['id'] ?? '';
            if ($db->get('wiki_pages', $wikiId)) {
                // Delete revision history
                $allRevisions = $db->getAll('wiki_revisions');
                foreach ($allRevisions as $revision) {
                    if ($revision['page_id'] === $wikiId) {
                        $db->delete('wiki_revisions', $revision['id']);
                    }
                }
                
                // Delete wiki page
                $db->delete('wiki_pages', $wikiId);
                $message = 'Wiki page and revision history deleted successfully';
            }
            break;
            
        case 'toggle_wiki_protection':
            $wikiId = $_GET['id'] ?? '';
            $wiki = $db->get('wiki_pages', $wikiId);
            if ($wiki) {
                $wiki['protected'] = !($wiki['protected'] ?? false);
                $db->save('wiki_pages', $wikiId, $wiki);
                $message = 'Wiki page protection ' . ($wiki['protected'] ? 'enabled' : 'disabled');
            }
            break;
            
        case 'create_channel':
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $channelName = trim($_POST['channel_name'] ?? '');
                $channelDesc = trim($_POST['channel_description'] ?? '');
                
                if (!empty($channelName)) {
                    $channelId = sanitizeFilename(strtolower(str_replace(' ', '-', $channelName)));
                    $db->save('channels', $channelId, [
                        'name' => $channelName,
                        'description' => $channelDesc,
                        'created_at' => time(),
                        'subscribers' => 0
                    ]);
                    $message = 'Channel created successfully';
                }
            }
            break;
            
        case 'delete_channel':
            $channelId = $_GET['id'] ?? '';
            if ($db->get('channels', $channelId)) {
                $db->delete('channels', $channelId);
                $message = 'Channel deleted successfully';
            }
            break;
            
        case 'save_settings':
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $settings = [
                    'site_name' => $_POST['site_name'] ?? SITE_NAME,
                    'site_description' => $_POST['site_description'] ?? SITE_DESCRIPTION,
                    'site_url' => $_POST['site_url'] ?? SITE_URL,
                    'admin_email' => $_POST['admin_email'] ?? ADMIN_EMAIL,
                    'max_upload_size' => (int)($_POST['max_upload_size'] ?? MAX_UPLOAD_SIZE),
                    'smtp_enabled' => isset($_POST['smtp_enabled']),
                    'smtp_host' => $_POST['smtp_host'] ?? '',
                    'smtp_port' => (int)($_POST['smtp_port'] ?? 587),
                    'smtp_username' => $_POST['smtp_username'] ?? '',
                    'smtp_password' => $_POST['smtp_password'] ?? '',
                    'smtp_from' => $_POST['smtp_from'] ?? '',
                    'registration_enabled' => isset($_POST['registration_enabled']),
                    'email_verification' => isset($_POST['email_verification']),
                    'default_theme' => $_POST['default_theme'] ?? DEFAULT_THEME,
                    'timezone' => $_POST['timezone'] ?? 'UTC',
                    'blog_enabled' => isset($_POST['blog_enabled']),
                    'wiki_enabled' => isset($_POST['wiki_enabled']),
                    'blog_require_approval' => isset($_POST['blog_require_approval']),
                    'wiki_require_approval' => isset($_POST['wiki_require_approval'])
                ];
                
                file_put_contents(DATA_DIR . '/settings.json', json_encode($settings, JSON_PRETTY_PRINT));
                $message = 'Settings saved successfully. Please reload the page to see changes.';
            }
            break;
            
        case 'promote_user':
            $userId = $_GET['id'] ?? '';
            $user = $db->get('users', $userId);
            if ($user) {
                $user['role'] = 'admin';
                $db->save('users', $userId, $user);
                $message = 'User promoted to admin';
            }
            break;
            
        case 'demote_user':
            $userId = $_GET['id'] ?? '';
            $user = $db->get('users', $userId);
            if ($user && $userId !== $_SESSION['user_id']) {
                $user['role'] = 'user';
                $db->save('users', $userId, $user);
                $message = 'User demoted to regular user';
            }
            break;
    }
}

// Load current settings
$currentSettings = json_decode(file_get_contents(DATA_DIR . '/settings.json'), true);

// Get statistics
$totalImages = $db->count('images');
$totalUsers = $db->count('users');
$totalTags = $db->count('tags');
$totalBlogs = $db->count('blog_posts');
$totalWiki = $db->count('wiki_pages');
$totalComments = $db->count('blog_comments');

$allImages = $db->getAll('images');
$totalSize = array_sum(array_column($allImages, 'size'));

// Get all blogs
$allBlogs = $db->getAll('blog_posts');
usort($allBlogs, function($a, $b) {
    return $b['created_at'] - $a['created_at'];
});

// Get all wiki pages
$allWikiPages = $db->getAll('wiki_pages');
usort($allWikiPages, function($a, $b) {
    return $b['created_at'] - $a['created_at'];
});

// Get available themes
$themes = [];
$themeDir = __DIR__ . '/../themes';
if (is_dir($themeDir)) {
    foreach (glob($themeDir . '/*/theme.json') as $themeFile) {
        $themeData = json_decode(file_get_contents($themeFile), true);
        $themes[basename(dirname($themeFile))] = $themeData;
    }
}

require 'templates/header.php';
?>

<div class="container mt-4">
    <h2><i class="bi bi-shield-lock"></i> Admin Panel</h2>
    
    <?php if ($message): ?>
        <div class="alert alert-success alert-dismissible">
            <?php echo escape($message); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible">
            <?php echo escape($error); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <ul class="nav nav-tabs mb-4">
        <li class="nav-item">
            <a class="nav-link active" data-bs-toggle="tab" href="#stats">Statistics</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="tab" href="#blogs">Blogs</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="tab" href="#wiki">Wiki</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="tab" href="#settings">Settings</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="tab" href="#users">Users</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="tab" href="#channels">Channels</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="index.php?page=moderation">
                <i class="bi bi-shield-check"></i> Moderation
            </a>
        </li>
    </ul>
    
    <div class="tab-content">
        <!-- Statistics Tab -->
        <div class="tab-pane fade show active" id="stats">
            <div class="row">
                <div class="col-md-2">
                    <div class="card">
                        <div class="card-body text-center">
                            <h3><?php echo number_format($totalImages); ?></h3>
                            <p class="text-muted mb-0">Images</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="card">
                        <div class="card-body text-center">
                            <h3><?php echo number_format($totalUsers); ?></h3>
                            <p class="text-muted mb-0">Users</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="card">
                        <div class="card-body text-center">
                            <h3><?php echo number_format($totalBlogs); ?></h3>
                            <p class="text-muted mb-0">Blogs</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="card">
                        <div class="card-body text-center">
                            <h3><?php echo number_format($totalWiki); ?></h3>
                            <p class="text-muted mb-0">Wiki Pages</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="card">
                        <div class="card-body text-center">
                            <h3><?php echo number_format($totalTags); ?></h3>
                            <p class="text-muted mb-0">Tags</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="card">
                        <div class="card-body text-center">
                            <h3><?php echo formatBytes($totalSize); ?></h3>
                            <p class="text-muted mb-0">Storage</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="row mt-4">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">Recent Activity</h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <h6>Latest Blog Posts</h6>
                                    <ul class="list-group list-group-flush">
                                        <?php 
                                        $recentBlogs = array_slice($allBlogs, 0, 5);
                                        if (empty($recentBlogs)): ?>
                                            <li class="list-group-item text-muted">No blog posts yet</li>
                                        <?php else: ?>
                                            <?php foreach ($recentBlogs as $blog): ?>
                                                <li class="list-group-item">
                                                    <a href="index.php?page=blogs&action=view&id=<?php echo $blog['id']; ?>">
                                                        <?php echo escape($blog['title']); ?>
                                                    </a>
                                                    <small class="text-muted d-block">
                                                        by <?php echo escape($blog['author_username']); ?> • 
                                                        <?php echo timeAgo($blog['created_at']); ?>
                                                        <span class="badge <?php echo $blog['status'] === 'published' ? 'bg-success' : 'bg-warning'; ?>">
                                                            <?php echo $blog['status']; ?>
                                                        </span>
                                                    </small>
                                                </li>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                                <div class="col-md-6">
                                    <h6>Latest Wiki Pages</h6>
                                    <ul class="list-group list-group-flush">
                                        <?php 
                                        $recentWiki = array_slice($allWikiPages, 0, 5);
                                        if (empty($recentWiki)): ?>
                                            <li class="list-group-item text-muted">No wiki pages yet</li>
                                        <?php else: ?>
                                            <?php foreach ($recentWiki as $wiki): ?>
                                                <li class="list-group-item">
                                                    <a href="index.php?page=wiki&action=view&slug=<?php echo urlencode($wiki['slug']); ?>">
                                                        <?php echo escape($wiki['title']); ?>
                                                    </a>
                                                    <small class="text-muted d-block">
                                                        by <?php echo escape($wiki['created_by_username']); ?> • 
                                                        <?php echo timeAgo($wiki['created_at']); ?>
                                                        <?php if ($wiki['protected'] ?? false): ?>
                                                            <span class="badge bg-danger">Protected</span>
                                                        <?php endif; ?>
                                                    </small>
                                                </li>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Blogs Tab -->
        <div class="tab-pane fade" id="blogs">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Blog Management</h5>
                    <a href="index.php?page=blog_edit" class="btn btn-sm btn-primary">
                        <i class="bi bi-plus-circle"></i> New Blog Post
                    </a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Title</th>
                                    <th>Author</th>
                                    <th>Status</th>
                                    <th>Views</th>
                                    <th>Comments</th>
                                    <th>Created</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($allBlogs)): ?>
                                    <tr>
                                        <td colspan="7" class="text-center text-muted">No blog posts found</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($allBlogs as $blog): ?>
                                        <tr>
                                            <td>
                                                <a href="index.php?page=blogs&action=view&id=<?php echo $blog['id']; ?>">
                                                    <?php echo escape(mb_substr($blog['title'], 0, 50)); ?>
                                                </a>
                                            </td>
                                            <td><?php echo escape($blog['author_username']); ?></td>
                                            <td>
                                                <span class="badge <?php echo $blog['status'] === 'published' ? 'bg-success' : 'bg-warning'; ?>">
                                                    <?php echo escape($blog['status']); ?>
                                                </span>
                                            </td>
                                            <td><?php echo number_format($blog['views'] ?? 0); ?></td>
                                            <td><?php echo number_format($blog['comment_count'] ?? 0); ?></td>
                                            <td><?php echo date('Y-m-d', $blog['created_at']); ?></td>
                                            <td>
                                                <div class="btn-group btn-group-sm">
                                                    <a href="index.php?page=blog_edit&id=<?php echo $blog['id']; ?>" 
                                                       class="btn btn-outline-primary" title="Edit">
                                                        <i class="bi bi-pencil"></i>
                                                    </a>
                                                    <a href="index.php?page=admin&action=toggle_blog_status&id=<?php echo $blog['id']; ?>" 
                                                       class="btn btn-outline-warning" 
                                                       title="Toggle Status">
                                                        <i class="bi bi-toggle-on"></i>
                                                    </a>
                                                    <a href="index.php?page=admin&action=delete_blog&id=<?php echo $blog['id']; ?>" 
                                                       class="btn btn-outline-danger" 
                                                       onclick="return confirm('Delete this blog post and all comments?')"
                                                       title="Delete">
                                                        <i class="bi bi-trash"></i>
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <!-- Blog Statistics -->
            <div class="row mt-3">
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-body">
                            <h6>Total Views</h6>
                            <h3><?php echo number_format(array_sum(array_column($allBlogs, 'views'))); ?></h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-body">
                            <h6>Total Comments</h6>
                            <h3><?php echo number_format($totalComments); ?></h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-body">
                            <h6>Published Posts</h6>
                            <h3>
                                <?php 
                                $published = count(array_filter($allBlogs, function($b) {
                                    return $b['status'] === 'published';
                                }));
                                echo number_format($published); 
                                ?>
                            </h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Wiki Tab -->
        <div class="tab-pane fade" id="wiki">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Wiki Management</h5>
                    <a href="index.php?page=wiki_edit" class="btn btn-sm btn-primary">
                        <i class="bi bi-plus-circle"></i> New Wiki Page
                    </a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Title</th>
                                    <th>Category</th>
                                    <th>Author</th>
                                    <th>Views</th>
                                    <th>Revisions</th>
                                    <th>Protected</th>
                                    <th>Created</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($allWikiPages)): ?>
                                    <tr>
                                        <td colspan="8" class="text-center text-muted">No wiki pages found</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($allWikiPages as $wiki): ?>
                                        <tr>
                                            <td>
                                                <a href="index.php?page=wiki&action=view&slug=<?php echo urlencode($wiki['slug']); ?>">
                                                    <?php echo escape(mb_substr($wiki['title'], 0, 50)); ?>
                                                </a>
                                            </td>
                                            <td><?php echo escape($wiki['category'] ?? 'Uncategorized'); ?></td>
                                            <td><?php echo escape($wiki['created_by_username']); ?></td>
                                            <td><?php echo number_format($wiki['views'] ?? 0); ?></td>
                                            <td><?php echo number_format($wiki['revision_count'] ?? 1); ?></td>
                                            <td>
                                                <?php if ($wiki['protected'] ?? false): ?>
                                                    <span class="badge bg-danger">Yes</span>
                                                <?php else: ?>
                                                    <span class="badge bg-secondary">No</span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo date('Y-m-d', $wiki['created_at']); ?></td>
                                            <td>
                                                <div class="btn-group btn-group-sm">
                                                    <a href="index.php?page=wiki_edit&slug=<?php echo urlencode($wiki['slug']); ?>" 
                                                       class="btn btn-outline-primary" title="Edit">
                                                        <i class="bi bi-pencil"></i>
                                                    </a>
                                                    <a href="index.php?page=admin&action=toggle_wiki_protection&id=<?php echo $wiki['id']; ?>" 
                                                       class="btn btn-outline-warning" 
                                                       title="Toggle Protection">
                                                        <i class="bi bi-shield"></i>
                                                    </a>
                                                    <a href="index.php?page=admin&action=delete_wiki&id=<?php echo $wiki['id']; ?>" 
                                                       class="btn btn-outline-danger" 
                                                       onclick="return confirm('Delete this wiki page and all revisions?')"
                                                       title="Delete">
                                                        <i class="bi bi-trash"></i>
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <!-- Wiki Statistics -->
            <div class="row mt-3">
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body">
                            <h6>Total Pages</h6>
                            <h3><?php echo number_format(count($allWikiPages)); ?></h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body">
                            <h6>Total Views</h6>
                            <h3><?php echo number_format(array_sum(array_column($allWikiPages, 'views'))); ?></h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body">
                            <h6>Protected Pages</h6>
                            <h3>
                                <?php 
                                $protected = count(array_filter($allWikiPages, function($w) {
                                    return $w['protected'] ?? false;
                                }));
                                echo number_format($protected); 
                                ?>
                            </h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body">
                            <h6>Total Revisions</h6>
                            <h3><?php echo number_format(array_sum(array_column($allWikiPages, 'revision_count'))); ?></h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Settings Tab -->
        <div class="tab-pane fade" id="settings">
            <form method="POST" action="index.php?page=admin&action=save_settings">
                <div class="card mb-3">
                    <div class="card-header"><h5>General Settings</h5></div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label class="form-label">Site Name</label>
                            <input type="text" name="site_name" class="form-control" 
                                   value="<?php echo escape($currentSettings['site_name']); ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Site Description</label>
                            <textarea name="site_description" class="form-control" rows="2"><?php echo escape($currentSettings['site_description']); ?></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Site URL</label>
                            <input type="url" name="site_url" class="form-control" 
                                   value="<?php echo escape($currentSettings['site_url']); ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Admin Email</label>
                            <input type="email" name="admin_email" class="form-control" 
                                   value="<?php echo escape($currentSettings['admin_email']); ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Max Upload Size (MB)</label>
                            <input type="number" name="max_upload_size" class="form-control" 
                                   value="<?php echo $currentSettings['max_upload_size']; ?>" min="1" max="100">
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Default Theme</label>
                            <select name="default_theme" class="form-select">
                                <?php foreach ($themes as $themeId => $theme): ?>
                                    <option value="<?php echo $themeId; ?>" 
                                            <?php echo $currentSettings['default_theme'] === $themeId ? 'selected' : ''; ?>>
                                        <?php echo escape($theme['display_name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Timezone</label>
                            <input type="text" name="timezone" class="form-control" 
                                   value="<?php echo escape($currentSettings['timezone']); ?>">
                        </div>
                    </div>
                </div>
                
                <div class="card mb-3">
                    <div class="card-header"><h5>Feature Settings</h5></div>
                    <div class="card-body">
                        <div class="form-check mb-2">
                            <input class="form-check-input" type="checkbox" name="blog_enabled" 
                                   <?php echo ($currentSettings['blog_enabled'] ?? true) ? 'checked' : ''; ?>>
                            <label class="form-check-label">Enable Blog Feature</label>
                        </div>
                        
                        <div class="form-check mb-2">
                            <input class="form-check-input" type="checkbox" name="wiki_enabled" 
                                   <?php echo ($currentSettings['wiki_enabled'] ?? true) ? 'checked' : ''; ?>>
                            <label class="form-check-label">Enable Wiki Feature</label>
                        </div>
                        
                        <div class="form-check mb-2">
                            <input class="form-check-input" type="checkbox" name="blog_require_approval" 
                                   <?php echo ($currentSettings['blog_require_approval'] ?? false) ? 'checked' : ''; ?>>
                            <label class="form-check-label">Require Admin Approval for Blog Posts</label>
                        </div>
                        
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="wiki_require_approval" 
                                   <?php echo ($currentSettings['wiki_require_approval'] ?? false) ? 'checked' : ''; ?>>
                            <label class="form-check-label">Require Admin Approval for Wiki Edits</label>
                        </div>
                    </div>
                </div>
                
                <div class="card mb-3">
                    <div class="card-header"><h5>Registration Settings</h5></div>
                    <div class="card-body">
                        <div class="form-check mb-2">
                            <input class="form-check-input" type="checkbox" name="registration_enabled" 
                                   <?php echo $currentSettings['registration_enabled'] ? 'checked' : ''; ?>>
                            <label class="form-check-label">Enable User Registration</label>
                        </div>
                        
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="email_verification" 
                                   <?php echo $currentSettings['email_verification'] ? 'checked' : ''; ?>>
                            <label class="form-check-label">Require Email Verification</label>
                        </div>
                    </div>
                </div>
                
                <div class="card mb-3">
                    <div class="card-header"><h5>SMTP Settings</h5></div>
                    <div class="card-body">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" name="smtp_enabled" 
                                   <?php echo $currentSettings['smtp_enabled'] ? 'checked' : ''; ?>>
                            <label class="form-check-label">Enable SMTP</label>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">SMTP Host</label>
                            <input type="text" name="smtp_host" class="form-control" 
                                   value="<?php echo escape($currentSettings['smtp_host'] ?? ''); ?>">
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">SMTP Port</label>
                            <input type="number" name="smtp_port" class="form-control" 
                                   value="<?php echo $currentSettings['smtp_port'] ?? 587; ?>">
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">SMTP Username</label>
                            <input type="text" name="smtp_username" class="form-control" 
                                   value="<?php echo escape($currentSettings['smtp_username'] ?? ''); ?>">
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">SMTP Password</label>
                            <input type="password" name="smtp_password" class="form-control" 
                                   value="<?php echo escape($currentSettings['smtp_password'] ?? ''); ?>">
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">From Email</label>
                            <input type="email" name="smtp_from" class="form-control" 
                                   value="<?php echo escape($currentSettings['smtp_from'] ?? ''); ?>">
                        </div>
                    </div>
                </div>
                
                <button type="submit" class="btn btn-primary btn-lg">
                    <i class="bi bi-save"></i> Save All Settings
                </button>
            </form>
        </div>
        
        <!-- Users Tab -->
        <div class="tab-pane fade" id="users">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">User Management</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Username</th>
                                    <th>Email</th>
                                    <th>Role</th>
                                    <th>Registered</th>
                                    <th>Verified</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($db->getAll('users') as $user): ?>
                                    <tr>
                                        <td>
                                            <a href="index.php?page=user&username=<?php echo urlencode($user['username']); ?>">
                                                <?php echo escape($user['username']); ?>
                                            </a>
                                        </td>
                                        <td><?php echo escape($user['email']); ?></td>
                                        <td>
                                            <span class="badge <?php echo $user['role'] === 'admin' ? 'bg-danger' : 'bg-secondary'; ?>">
                                                <?php echo escape($user['role']); ?>
                                            </span>
                                        </td>
                                        <td><?php echo date('Y-m-d H:i', $user['created_at']); ?></td>
                                        <td>
                                            <?php if ($user['verified']): ?>
                                                <span class="text-success"><i class="bi bi-check-circle-fill"></i></span>
                                            <?php else: ?>
                                                <span class="text-warning"><i class="bi bi-x-circle-fill"></i></span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($user['id'] !== $_SESSION['user_id']): ?>
                                                <div class="btn-group btn-group-sm">
                                                    <?php if ($user['role'] !== 'admin'): ?>
                                                        <a href="index.php?page=admin&action=promote_user&id=<?php echo $user['id']; ?>" 
                                                           class="btn btn-outline-success"
                                                           onclick="return confirm('Promote this user to admin?')">
                                                            <i class="bi bi-arrow-up"></i> Promote
                                                        </a>
                                                    <?php else: ?>
                                                        <a href="index.php?page=admin&action=demote_user&id=<?php echo $user['id']; ?>" 
                                                           class="btn btn-outline-warning"
                                                           onclick="return confirm('Demote this admin to regular user?')">
                                                            <i class="bi bi-arrow-down"></i> Demote
                                                        </a>
                                                    <?php endif; ?>
                                                </div>
                                            <?php else: ?>
                                                <span class="text-muted small">Current User</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Channels Tab -->
        <div class="tab-pane fade" id="channels">
            <div class="card mb-3">
                <div class="card-header">
                    <h5>Create New Channel</h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="index.php?page=admin&action=create_channel">
                        <div class="row g-3">
                            <div class="col-md-4">
                                <input type="text" name="channel_name" class="form-control" placeholder="Channel Name" required>
                            </div>
                            <div class="col-md-6">
                                <input type="text" name="channel_description" class="form-control" placeholder="Description">
                            </div>
                            <div class="col-md-2">
                                <button type="submit" class="btn btn-primary w-100">Create</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <h5>Existing Channels</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Description</th>
                                    <th>Images</th>
                                    <th>Created</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $channels = $db->getAll('channels');
                                $allImages = $db->getAll('images');
                                foreach ($channels as $channel): 
                                    $imageCount = count(array_filter($allImages, function($img) use ($channel) {
                                        return ($img['channel'] ?? '') === $channel['id'];
                                    }));
                                ?>
                                    <tr>
                                        <td><strong><?php echo escape($channel['name']); ?></strong></td>
                                        <td><?php echo escape($channel['description']); ?></td>
                                        <td><?php echo $imageCount; ?></td>
                                        <td><?php echo date('Y-m-d', $channel['created_at']); ?></td>
                                        <td>
                                            <a href="index.php?page=channel&id=<?php echo $channel['id']; ?>" class="btn btn-sm btn-primary">View</a>
                                            <a href="index.php?page=admin&action=delete_channel&id=<?php echo $channel['id']; ?>" 
                                               class="btn btn-sm btn-danger"
                                               onclick="return confirm('Delete this channel? Images will not be deleted.')">
                                                Delete
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.card {
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.nav-tabs .nav-link {
    color: #495057;
}

.nav-tabs .nav-link.active {
    font-weight: bold;
}

.table-hover tbody tr:hover {
    background-color: rgba(0,0,0,0.02);
}

.btn-group-sm .btn {
    padding: 0.25rem 0.5rem;
}
</style>

<?php require 'templates/footer.php'; ?>
