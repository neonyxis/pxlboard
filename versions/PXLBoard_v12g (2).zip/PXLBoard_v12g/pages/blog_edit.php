<?php
/**
 * Blog Post Editor
 * Create and edit blog posts
 */

if (!$auth->isLoggedIn()) {
    redirect('index.php?page=login');
}

$postId = $_GET['id'] ?? '';
$message = '';
$error = '';
$post = null;

// Load existing post if editing
if (!empty($postId)) {
    $post = $db->get('blog_posts', $postId);
    
    // Check ownership
    if ($post && $post['author_id'] !== $_SESSION['user_id']) {
        $error = 'You do not have permission to edit this post';
        $post = null;
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $content = trim($_POST['content'] ?? '');
    $excerpt = trim($_POST['excerpt'] ?? '');
    $category = trim($_POST['category'] ?? '');
    $tags = array_filter(array_map('trim', explode(',', $_POST['tags'] ?? '')));
    $status = $_POST['status'] ?? 'draft';
    
    if (isset($_POST['save_draft'])) {
        $status = 'draft';
    } elseif (isset($_POST['publish'])) {
        $status = 'published';
    }
    
    if (empty($title)) {
        $error = 'Title is required';
    } elseif (empty($content)) {
        $error = 'Content is required';
    } else {
        if ($post) {
            // Update existing post
            $post['title'] = $title;
            $post['content'] = $content;
            $post['excerpt'] = $excerpt;
            $post['category'] = $category;
            $post['tags'] = $tags;
            $post['status'] = $status;
            $post['updated_at'] = time();
            
            if ($status === 'published' && empty($post['published_at'])) {
                $post['published_at'] = time();
            }
            
            $db->save('blog_posts', $postId, $post);
            
            $message = $status === 'published' ? 'Post published successfully!' : 'Draft saved successfully!';
            redirect('index.php?page=blogs&action=view&id=' . $postId);
            
        } else {
            // Create new post
            $newPostId = $db->getNextId('blog_posts');
            $newPost = [
                'title' => $title,
                'content' => $content,
                'excerpt' => $excerpt,
                'category' => $category,
                'tags' => $tags,
                'author_id' => $_SESSION['user_id'],
                'author_username' => $_SESSION['username'],
                'created_at' => time(),
                'updated_at' => time(),
                'published_at' => $status === 'published' ? time() : null,
                'status' => $status,
                'views' => 0,
                'comment_count' => 0
            ];
            
            $db->save('blog_posts', $newPostId, $newPost);
            
            $message = $status === 'published' ? 'Post published successfully!' : 'Draft saved successfully!';
            redirect('index.php?page=blogs&action=view&id=' . $newPostId);
        }
    }
}

// Handle delete
if (isset($_POST['delete_post']) && $post) {
    $db->delete('blog_posts', $postId);
    redirect('index.php?page=blogs&user=' . urlencode($_SESSION['username']));
}

require 'templates/header.php';
?>

<div class="container mt-4">
    <div class="row">
        <div class="col-lg-9">
            <h2>
                <i class="bi bi-pencil"></i> 
                <?php echo $post ? 'Edit Blog Post' : 'Create New Blog Post'; ?>
            </h2>
            <p class="text-muted">
                <?php echo $post ? 'Update your blog post' : 'Share your thoughts with the community'; ?>
            </p>
            
            <?php if ($message): ?>
                <div class="alert alert-success alert-dismissible fade show">
                    <?php echo htmlspecialchars($message); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show">
                    <?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <div class="card">
                <div class="card-body">
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Title *</label>
                            <input type="text" name="title" class="form-control" required
                                   value="<?php echo escape($post['title'] ?? ''); ?>"
                                   placeholder="Enter post title">
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Excerpt</label>
                            <textarea name="excerpt" class="form-control" rows="2"
                                      placeholder="Brief summary (optional, will use first 200 chars if empty)"
                                      maxlength="300"><?php echo escape($post['excerpt'] ?? ''); ?></textarea>
                            <small class="text-muted">Max 300 characters</small>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Content *</label>
                            <textarea name="content" class="form-control" rows="15" required
                                      placeholder="Write your blog post content here..."><?php echo escape($post['content'] ?? ''); ?></textarea>
                            <small class="text-muted">
                                <strong>Tip:</strong> Use line breaks for paragraphs. 
                                Future version will support markdown formatting.
                            </small>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Category</label>
                                <input type="text" name="category" class="form-control"
                                       value="<?php echo escape($post['category'] ?? ''); ?>"
                                       placeholder="e.g., Tutorial, News, Review"
                                       list="categoryList">
                                <datalist id="categoryList">
                                    <?php
                                    $categories = [];
                                    foreach ($db->getAll('blog_posts') as $p) {
                                        if (!empty($p['category'])) {
                                            $categories[$p['category']] = true;
                                        }
                                    }
                                    foreach (array_keys($categories) as $cat):
                                    ?>
                                    <option value="<?php echo escape($cat); ?>">
                                    <?php endforeach; ?>
                                </datalist>
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Tags</label>
                                <input type="text" name="tags" class="form-control"
                                       value="<?php echo escape(implode(', ', $post['tags'] ?? [])); ?>"
                                       placeholder="tag1, tag2, tag3">
                                <small class="text-muted">Comma-separated</small>
                            </div>
                        </div>
                        
                        <div class="d-flex gap-2 align-items-center">
                            <button type="submit" name="save_draft" class="btn btn-secondary">
                                <i class="bi bi-save"></i> Save as Draft
                            </button>
                            <button type="submit" name="publish" class="btn btn-primary">
                                <i class="bi bi-check-circle"></i> 
                                <?php echo ($post && $post['status'] === 'published') ? 'Update' : 'Publish'; ?>
                            </button>
                            <a href="<?php echo $post ? 'index.php?page=blogs&action=view&id=' . $postId : 'index.php?page=blogs'; ?>" 
                               class="btn btn-outline-secondary">
                                <i class="bi bi-x-circle"></i> Cancel
                            </a>
                            
                            <?php if ($post): ?>
                            <button type="button" class="btn btn-outline-danger ms-auto" 
                                    data-bs-toggle="modal" data-bs-target="#deleteModal">
                                <i class="bi bi-trash"></i> Delete
                            </button>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Delete Confirmation Modal -->
            <?php if ($post): ?>
            <div class="modal fade" id="deleteModal" tabindex="-1">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <form method="POST">
                            <div class="modal-header">
                                <h5 class="modal-title">Delete Blog Post</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body">
                                <p>Are you sure you want to delete this blog post?</p>
                                <p class="text-danger"><strong>Warning:</strong> This action cannot be undone.</p>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                <button type="submit" name="delete_post" class="btn btn-danger">Delete Post</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
        
        <div class="col-lg-3">
            <div class="card mb-3">
                <div class="card-header">
                    <strong>Writing Tips</strong>
                </div>
                <div class="card-body small">
                    <h6>Content Guidelines</h6>
                    <ul>
                        <li>Write clear and engaging content</li>
                        <li>Break up long paragraphs</li>
                        <li>Use descriptive titles</li>
                        <li>Add relevant tags</li>
                        <li>Proofread before publishing</li>
                    </ul>
                    
                    <h6>Best Practices</h6>
                    <ul>
                        <li>Save drafts frequently</li>
                        <li>Categorize your posts</li>
                        <li>Engage with commenters</li>
                        <li>Be respectful and authentic</li>
                    </ul>
                </div>
            </div>
            
            <?php if ($post): ?>
            <div class="card mb-3">
                <div class="card-header">
                    <strong>Post Stats</strong>
                </div>
                <div class="card-body small">
                    <p class="mb-1">
                        <strong>Status:</strong> 
                        <?php if ($post['status'] === 'published'): ?>
                            <span class="badge bg-success">Published</span>
                        <?php else: ?>
                            <span class="badge bg-warning text-dark">Draft</span>
                        <?php endif; ?>
                    </p>
                    <p class="mb-1">
                        <strong>Created:</strong><br>
                        <?php echo date('F j, Y', $post['created_at']); ?>
                    </p>
                    <?php if (!empty($post['published_at'])): ?>
                    <p class="mb-1">
                        <strong>Published:</strong><br>
                        <?php echo date('F j, Y', $post['published_at']); ?>
                    </p>
                    <?php endif; ?>
                    <p class="mb-0">
                        <strong>Views:</strong> <?php echo number_format($post['views'] ?? 0); ?><br>
                        <strong>Comments:</strong> <?php echo number_format($post['comment_count'] ?? 0); ?>
                    </p>
                </div>
            </div>
            <?php endif; ?>
            
            <div class="card">
                <div class="card-header">
                    <strong>My Drafts</strong>
                </div>
                <div class="list-group list-group-flush">
                    <?php
                    $myDrafts = array_filter($db->getAll('blog_posts'), function($p) {
                        return $p['author_id'] === $_SESSION['user_id'] && $p['status'] === 'draft';
                    });
                    
                    if (empty($myDrafts)):
                    ?>
                        <div class="list-group-item text-muted small">No drafts</div>
                    <?php else: ?>
                        <?php foreach (array_slice($myDrafts, 0, 5) as $draft): ?>
                        <a href="index.php?page=blog_edit&id=<?php echo $draft['id']; ?>" 
                           class="list-group-item list-group-item-action small">
                            <?php echo escape(mb_substr($draft['title'], 0, 30)); ?>
                            <br>
                            <span class="text-muted"><?php echo timeAgo($draft['updated_at']); ?></span>
                        </a>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require 'templates/footer.php'; ?>
