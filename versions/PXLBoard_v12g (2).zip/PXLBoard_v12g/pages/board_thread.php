<?php
/**
 * Board Thread View - with voting and threaded comments
 */

require_once 'includes/board_moderators.php';
require_once 'includes/board_voting.php';

$boardMods = new BoardModerators($db);
$voting = new BoardVoting($db);

$threadId = $_GET['id'] ?? '';
if (empty($threadId)) {
    header('Location: index.php?page=boards');
    exit;
}

$thread = $db->get('board_threads', $threadId);
if (!$thread) {
    header('Location: index.php?page=boards');
    exit;
}

$board = $db->get('boards', $thread['board_id']);
$user = $auth->getCurrentUser();
$isModerator = $user && $boardMods->isModerator($thread['board_id'], $user['id']);

// Handle voting
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['vote']) && $auth->isLoggedIn()) {
    $voteType = $_POST['vote'];
    $itemType = $_POST['item_type'];
    $itemId = $_POST['item_id'];
    
    if ($voting->vote($itemType, $itemId, $user['id'], $voteType)) {
        // Update karma
        $voting->updateUserKarma($user['id']);
    }
    
    header('Location: index.php?page=board_thread&id=' . $threadId);
    exit;
}

// Handle post creation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_post']) && $auth->isLoggedIn()) {
    if (!($thread['locked'] ?? false)) {
        $content = trim($_POST['content'] ?? '');
        $anonymous = isset($_POST['anonymous']);
        $parentId = $_POST['parent_id'] ?? null;
        
        if (!empty($content)) {
            $postId = 'post_' . time() . '_' . rand(1000, 9999);
            
            $imagePath = null;
            if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
                $uploadDir = 'uploads/board_images/';
                if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
                
                $extension = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
                if (in_array($extension, ['jpg', 'jpeg', 'png', 'gif', 'webp'])) {
                    $filename = $postId . '_' . time() . '.' . $extension;
                    $targetPath = $uploadDir . $filename;
                    if (move_uploaded_file($_FILES['image']['tmp_name'], $targetPath)) {
                        $imagePath = $targetPath;
                    }
                }
            }
            
            $postData = [
                'thread_id' => $threadId,
                'board_id' => $thread['board_id'],
                'content' => $content,
                'author_id' => $anonymous ? null : $user['id'],
                'author_name' => $anonymous ? 'Anonymous' : $user['username'],
                'image' => $imagePath,
                'parent_id' => $parentId,
                'created_at' => time(),
                'votes' => [],
                'vote_score' => 0
            ];
            
            if ($db->save('board_posts', $postId, $postData)) {
                $thread['reply_count'] = ($thread['reply_count'] ?? 0) + 1;
                $thread['updated_at'] = time();
                $db->save('board_threads', $threadId, $thread);
                
                if ($board) {
                    $board['post_count'] = ($board['post_count'] ?? 0) + 1;
                    $db->save('boards', $thread['board_id'], $board);
                }
                
                $_SESSION['success'] = "Reply posted!";
                header('Location: index.php?page=board_thread&id=' . $threadId);
                exit;
            }
        }
    }
}

// Handle post deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_post'])) {
    $postId = $_POST['post_id'];
    $post = $db->get('board_posts', $postId);
    
    if ($post && ($isModerator || $auth->isAdmin() || ($user && $post['author_id'] === $user['id']))) {
        if (!empty($post['image']) && file_exists($post['image'])) {
            unlink($post['image']);
        }
        
        $db->delete('board_posts', $postId);
        
        $thread['reply_count'] = max(0, ($thread['reply_count'] ?? 1) - 1);
        $db->save('board_threads', $threadId, $thread);
        
        if ($board) {
            $board['post_count'] = max(0, ($board['post_count'] ?? 1) - 1);
            $db->save('boards', $thread['board_id'], $board);
        }
        
        $_SESSION['success'] = "Post deleted";
    }
    header('Location: index.php?page=board_thread&id=' . $threadId);
    exit;
}

// Get posts
$allPosts = $db->getAll('board_posts');
$posts = array_filter($allPosts, function($post) use ($threadId) {
    return $post['thread_id'] === $threadId;
});

usort($posts, function($a, $b) {
    return ($a['created_at'] ?? 0) - ($b['created_at'] ?? 0);
});

// Build threaded structure
function buildThreadedPosts($posts, $parentId = null) {
    $threaded = [];
    foreach ($posts as $post) {
        if (($post['parent_id'] ?? null) === $parentId) {
            $post['children'] = buildThreadedPosts($posts, $post['id']);
            $threaded[] = $post;
        }
    }
    return $threaded;
}

$threadedPosts = buildThreadedPosts($posts);

$pageTitle = $thread['title'] . ' - ' . SITE_NAME;
include 'templates/header.php';
?>

<style>
.thread-container { max-width: 1000px; margin: 0 auto; }
.thread-header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 10px; margin-bottom: 20px; }
.thread-header h2 { margin: 0; font-size: 1.8em; }
.post-container { background: white; border: 1px solid #ddd; border-radius: 5px; margin-bottom: 15px; overflow: hidden; }
.post-container.op-post { border: 2px solid #667eea; background: #f8f9ff; }
.post-container.threaded { margin-left: 40px; border-left: 3px solid #667eea; }
.post-header { background: #f5f5f5; padding: 10px 15px; border-bottom: 1px solid #ddd; display: flex; justify-content: space-between; align-items: center; }
.post-container.op-post .post-header { background: #e8ebff; }
.post-author { font-weight: bold; color: #667eea; }
.post-date { color: #888; font-size: 0.9em; }
.post-number { color: #667eea; font-family: monospace; }
.post-body { padding: 15px; display: flex; gap: 15px; }
.post-image img { max-width: 250px; max-height: 250px; border-radius: 5px; cursor: pointer; }
.post-content { flex: 1; white-space: pre-wrap; word-wrap: break-word; font-family: 'Courier New', monospace; font-size: 13px; }
.vote-buttons { display: flex; gap: 5px; align-items: center; margin-top: 10px; }
.vote-btn { border: 1px solid #ddd; background: white; padding: 5px 12px; border-radius: 3px; cursor: pointer; font-size: 14px; }
.vote-btn:hover { background: #f0f0f0; }
.vote-btn.active { font-weight: bold; }
.vote-btn.up.active { background: #ff8b60; color: white; border-color: #ff8b60; }
.vote-btn.down.active { background: #9494ff; color: white; border-color: #9494ff; }
.vote-score { font-weight: bold; color: #667eea; margin: 0 5px; }
.reply-form { position: sticky; bottom: 20px; background: white; border: 2px solid #667eea; border-radius: 8px; padding: 20px; margin-top: 20px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
.greentext { color: #789922; }
.op-badge { background: #667eea; color: white; padding: 2px 6px; border-radius: 3px; font-size: 0.75em; font-weight: bold; margin-left: 5px; }
.reply-to-btn { background: #667eea; color: white; border: none; padding: 4px 12px; border-radius: 3px; font-size: 12px; cursor: pointer; margin-left: 10px; }
.reply-to-btn:hover { background: #5566cc; }
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.post-content').forEach(function(content) {
        let html = content.textContent;
        html = html.split('\n').map(line => {
            if (line.trim().startsWith('>')) {
                return '<span class="greentext">' + line + '</span>';
            }
            return line;
        }).join('\n');
        content.innerHTML = html;
    });
});

function zoomImage(img) {
    if (img.style.maxWidth === 'none') {
        img.style.maxWidth = '250px';
        img.style.maxHeight = '250px';
    } else {
        img.style.maxWidth = 'none';
        img.style.maxHeight = 'none';
    }
}

function replyTo(postId, username) {
    const form = document.getElementById('reply-form');
    document.getElementById('parent_id').value = postId;
    document.getElementById('reply-to-label').textContent = 'Replying to ' + username;
    document.getElementById('reply-to-cancel').style.display = 'inline';
    form.scrollIntoView({ behavior: 'smooth' });
    document.querySelector('textarea[name="content"]').focus();
}

function cancelReply() {
    document.getElementById('parent_id').value = '';
    document.getElementById('reply-to-label').textContent = 'Post Reply';
    document.getElementById('reply-to-cancel').style.display = 'none';
}
</script>

<div class="container thread-container">
    <div class="thread-header">
        <nav style="font-size: 0.9em; margin-bottom: 10px;">
            <a href="index.php?page=boards" style="color: white;">Boards</a> /
            <a href="index.php?page=board&id=<?php echo $thread['board_id']; ?>" style="color: white;">
                /<?php echo htmlspecialchars($board['shortcode'] ?? 'board'); ?>/
            </a>
        </nav>
        <h2><?php echo htmlspecialchars($thread['title']); ?></h2>
        <?php if ($thread['pinned'] ?? false): ?>
            <span class="badge bg-warning">📌 Pinned</span>
        <?php endif; ?>
        <?php if ($thread['locked'] ?? false): ?>
            <span class="badge bg-secondary">🔒 Locked</span>
        <?php endif; ?>
    </div>

    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success">
            <?php echo htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?>
        </div>
    <?php endif; ?>

    <!-- Original Post -->
    <div class="post-container op-post">
        <div class="post-header">
            <div>
                <span class="post-author"><?php echo htmlspecialchars($thread['author_name']); ?></span>
                <span class="op-badge">OP</span>
                <span class="post-date"><?php echo date('m/d/y(D)H:i:s', $thread['created_at']); ?></span>
                <span class="post-number">No.<?php echo substr($thread['id'], -8); ?></span>
            </div>
        </div>
        <div class="post-body">
            <?php if (!empty($thread['image'])): ?>
                <div class="post-image">
                    <img src="<?php echo htmlspecialchars($thread['image']); ?>" alt="Thread image" onclick="zoomImage(this)">
                </div>
            <?php endif; ?>
            <div>
                <div class="post-content"><?php echo htmlspecialchars($thread['content']); ?></div>
                
                <?php if ($auth->isLoggedIn()): ?>
                    <?php 
                    $threadVotes = $voting->getVoteCounts('thread', $thread['id']);
                    $userVote = $voting->getUserVote('thread', $thread['id'], $user['id']);
                    ?>
                    <div class="vote-buttons">
                        <form method="post" style="display: inline;">
                            <input type="hidden" name="item_type" value="thread">
                            <input type="hidden" name="item_id" value="<?php echo $thread['id']; ?>">
                            <button type="submit" name="vote" value="up" class="vote-btn up <?php echo $userVote === 'up' ? 'active' : ''; ?>">
                                ▲
                            </button>
                        </form>
                        <span class="vote-score"><?php echo $threadVotes['score']; ?></span>
                        <form method="post" style="display: inline;">
                            <input type="hidden" name="item_type" value="thread">
                            <input type="hidden" name="item_id" value="<?php echo $thread['id']; ?>">
                            <button type="submit" name="vote" value="down" class="vote-btn down <?php echo $userVote === 'down' ? 'active' : ''; ?>">
                                ▼
                            </button>
                        </form>
                    </div>
                <?php else: ?>
                    <div class="vote-score">⬆ <?php echo $thread['vote_score'] ?? 0; ?> points</div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Replies -->
    <?php if (!empty($threadedPosts)): ?>
        <h4 style="margin: 20px 0 10px 0;"><?php echo count($posts); ?> Replies</h4>
        <?php
        function renderPost($post, $user, $voting, $auth, $isModerator, $depth = 0) {
            $isAuthor = $user && isset($post['author_id']) && $post['author_id'] === $user['id'];
            ?>
            <div class="post-container <?php echo $depth > 0 ? 'threaded' : ''; ?>">
                <div class="post-header">
                    <div>
                        <span class="post-author"><?php echo htmlspecialchars($post['author_name']); ?></span>
                        <span class="post-date"><?php echo date('m/d/y(D)H:i:s', $post['created_at']); ?></span>
                        <span class="post-number">No.<?php echo substr($post['id'], -8); ?></span>
                        <?php if ($auth->isLoggedIn()): ?>
                            <button class="reply-to-btn" onclick="replyTo('<?php echo $post['id']; ?>', '<?php echo htmlspecialchars($post['author_name']); ?>')">
                                Reply
                            </button>
                        <?php endif; ?>
                    </div>
                    <?php if ($isModerator || $isAuthor): ?>
                        <form method="post" onsubmit="return confirm('Delete this post?');" style="margin: 0;">
                            <input type="hidden" name="post_id" value="<?php echo $post['id']; ?>">
                            <button type="submit" name="delete_post" class="btn btn-sm btn-danger">Delete</button>
                        </form>
                    <?php endif; ?>
                </div>
                <div class="post-body">
                    <?php if (!empty($post['image'])): ?>
                        <div class="post-image">
                            <img src="<?php echo htmlspecialchars($post['image']); ?>" alt="Post image" onclick="zoomImage(this)">
                        </div>
                    <?php endif; ?>
                    <div>
                        <div class="post-content"><?php echo htmlspecialchars($post['content']); ?></div>
                        
                        <?php if ($auth->isLoggedIn() && $user): ?>
                            <?php 
                            $postVotes = $voting->getVoteCounts('post', $post['id']);
                            $userVote = $voting->getUserVote('post', $post['id'], $user['id']);
                            ?>
                            <div class="vote-buttons">
                                <form method="post" style="display: inline;">
                                    <input type="hidden" name="item_type" value="post">
                                    <input type="hidden" name="item_id" value="<?php echo $post['id']; ?>">
                                    <button type="submit" name="vote" value="up" class="vote-btn up <?php echo $userVote === 'up' ? 'active' : ''; ?>">
                                        ▲
                                    </button>
                                </form>
                                <span class="vote-score"><?php echo $postVotes['score']; ?></span>
                                <form method="post" style="display: inline;">
                                    <input type="hidden" name="item_type" value="post">
                                    <input type="hidden" name="item_id" value="<?php echo $post['id']; ?>">
                                    <button type="submit" name="vote" value="down" class="vote-btn down <?php echo $userVote === 'down' ? 'active' : ''; ?>">
                                        ▼
                                    </button>
                                </form>
                            </div>
                        <?php else: ?>
                            <div class="vote-score">⬆ <?php echo $post['vote_score'] ?? 0; ?> points</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php
            if (!empty($post['children']) && $depth < 5) {
                foreach ($post['children'] as $child) {
                    renderPost($child, $user, $voting, $auth, $isModerator, $depth + 1);
                }
            }
        }
        
        foreach ($threadedPosts as $post) {
            renderPost($post, $user, $voting, $auth, $isModerator);
        }
        ?>
    <?php endif; ?>

    <!-- Reply Form -->
    <?php if ($auth->isLoggedIn()): ?>
        <?php if (!($thread['locked'] ?? false)): ?>
            <div class="reply-form" id="reply-form">
                <h5 id="reply-to-label">Post Reply</h5>
                <button id="reply-to-cancel" onclick="cancelReply()" class="btn btn-sm btn-secondary" style="display: none;">Cancel Reply</button>
                <form method="post" enctype="multipart/form-data">
                    <input type="hidden" name="parent_id" id="parent_id" value="">
                    <div class="mb-3">
                        <textarea name="content" class="form-control" rows="6" 
                                  placeholder="Your reply... (use >text for greentext)" required></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Attach Image (optional)</label>
                        <input type="file" name="image" class="form-control" accept="image/*">
                    </div>
                    <div class="mb-3 form-check">
                        <input type="checkbox" name="anonymous" class="form-check-input" id="anonymous">
                        <label class="form-check-label" for="anonymous">Post anonymously</label>
                    </div>
                    <button type="submit" name="create_post" class="btn btn-primary">Post Reply</button>
                    <a href="index.php?page=board&id=<?php echo $thread['board_id']; ?>" class="btn btn-secondary">Back to Board</a>
                </form>
            </div>
        <?php else: ?>
            <div class="reply-form">
                <p class="text-center mb-0"><strong>🔒 This thread is locked</strong></p>
            </div>
        <?php endif; ?>
    <?php else: ?>
        <div class="alert alert-info text-center">
            <a href="index.php?page=login">Log in</a> to reply to this thread
        </div>
    <?php endif; ?>
</div>

<?php include 'templates/footer.php'; ?>
