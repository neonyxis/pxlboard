<?php
/**
 * Wiki Edit Page
 * Create and edit wiki pages
 */

if (!$auth->isLoggedIn()) {
    redirect('index.php?page=login');
}

$slug = $_GET['slug'] ?? '';
$message = '';
$error = '';
$page = null;

// Load existing page if editing
if (!empty($slug)) {
    $wikiPages = $db->getAll('wiki_pages');
    foreach ($wikiPages as $wp) {
        if ($wp['slug'] === $slug) {
            $page = $wp;
            break;
        }
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_page'])) {
    $title = trim($_POST['title'] ?? '');
    $content = trim($_POST['content'] ?? '');
    $summary = trim($_POST['summary'] ?? '');
    $category = trim($_POST['category'] ?? '');
    $editSummary = trim($_POST['edit_summary'] ?? '');
    $isProtected = isset($_POST['is_protected']);
    
    if (empty($title)) {
        $error = 'Title is required';
    } elseif (empty($content)) {
        $error = 'Content is required';
    } else {
        $newSlug = !empty($slug) ? $slug : createSlug($title);
        
        // Check if slug exists (only for new pages)
        if (empty($slug)) {
            $wikiPages = $db->getAll('wiki_pages');
            foreach ($wikiPages as $wp) {
                if ($wp['slug'] === $newSlug) {
                    $error = 'A page with this title already exists';
                    break;
                }
            }
        }
        
        if (empty($error)) {
            if ($page) {
                // Update existing page
                $pageId = $page['id'];
                
                // Save revision
                $revisionId = $db->getNextId('wiki_revisions');
                $revision = [
                    'page_id' => $pageId,
                    'content' => $page['content'],
                    'edited_by' => $_SESSION['user_id'],
                    'edited_by_username' => $_SESSION['username'],
                    'edited_at' => time(),
                    'edit_summary' => $editSummary,
                    'revision_number' => $page['revision_count'] ?? 1
                ];
                $db->save('wiki_revisions', $revisionId, $revision);
                
                // Update page
                $page['title'] = $title;
                $page['content'] = $content;
                $page['summary'] = $summary;
                $page['category'] = $category;
                $page['last_edited_by'] = $_SESSION['user_id'];
                $page['last_edited_by_username'] = $_SESSION['username'];
                $page['last_edited_at'] = time();
                $page['revision_count'] = ($page['revision_count'] ?? 1) + 1;
                
                if ($rbac->hasPermission($_SESSION['user_id'], 'manage_wiki')) {
                    $page['is_protected'] = $isProtected;
                }
                
                $db->save('wiki_pages', $pageId, $page);
                
                $message = 'Page updated successfully!';
                redirect('index.php?page=wiki&action=view&slug=' . urlencode($newSlug));
                
            } else {
                // Create new page
                $pageId = $db->getNextId('wiki_pages');
                $newPage = [
                    'slug' => $newSlug,
                    'title' => $title,
                    'content' => $content,
                    'summary' => $summary,
                    'category' => $category,
                    'created_by' => $_SESSION['user_id'],
                    'created_by_username' => $_SESSION['username'],
                    'created_at' => time(),
                    'last_edited_by' => $_SESSION['user_id'],
                    'last_edited_by_username' => $_SESSION['username'],
                    'last_edited_at' => time(),
                    'views' => 0,
                    'revision_count' => 1,
                    'is_protected' => false,
                    'related_pages' => []
                ];
                
                $db->save('wiki_pages', $pageId, $newPage);
                
                $message = 'Page created successfully!';
                redirect('index.php?page=wiki&action=view&slug=' . urlencode($newSlug));
            }
        }
    }
}

require 'templates/header.php';
?>

<div class="container mt-4">
    <div class="row">
        <div class="col-lg-9">
            <h2>
                <i class="bi bi-pencil"></i> 
                <?php echo $page ? 'Edit Wiki Page' : 'Create New Wiki Page'; ?>
            </h2>
            <p class="text-muted">
                <?php echo $page ? 'Make changes to this wiki page' : 'Create a new page in the wiki'; ?>
            </p>
            
            <?php if ($message): ?>
                <div class="alert alert-success alert-dismissible fade show">
                    <?php echo htmlspecialchars($message); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show">
                    <?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <div class="card">
                <div class="card-body">
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Title *</label>
                            <input type="text" name="title" class="form-control" required
                                   value="<?php echo escape($page['title'] ?? ''); ?>"
                                   placeholder="Enter page title">
                            <?php if (!$page): ?>
                                <small class="text-muted">
                                    URL slug will be automatically generated from the title
                                </small>
                            <?php endif; ?>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Summary</label>
                            <input type="text" name="summary" class="form-control"
                                   value="<?php echo escape($page['summary'] ?? ''); ?>"
                                   placeholder="Brief description (shown in listings)"
                                   maxlength="200">
                            <small class="text-muted">Max 200 characters</small>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Category</label>
                            <input type="text" name="category" class="form-control"
                                   value="<?php echo escape($page['category'] ?? ''); ?>"
                                   placeholder="e.g., Characters, Locations, Lore">
                            <small class="text-muted">Used to organize pages</small>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Content *</label>
                            <textarea name="content" class="form-control" rows="15" required
                                      placeholder="Enter wiki page content..."><?php echo escape($page['content'] ?? ''); ?></textarea>
                            <small class="text-muted">
                                <strong>Tip:</strong> You can use line breaks for formatting. 
                                Future version will support markdown.
                            </small>
                        </div>
                        
                        <?php if ($page): ?>
                        <div class="mb-3">
                            <label class="form-label">Edit Summary</label>
                            <input type="text" name="edit_summary" class="form-control"
                                   placeholder="Briefly describe your changes (optional)"
                                   maxlength="200">
                            <small class="text-muted">Helps others understand what you changed</small>
                        </div>
                        <?php endif; ?>
                        
                        <?php if ($rbac->hasPermission($_SESSION['user_id'], 'manage_wiki')): ?>
                        <div class="mb-3 form-check">
                            <input type="checkbox" name="is_protected" class="form-check-input" 
                                   id="isProtected" <?php echo ($page['is_protected'] ?? false) ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="isProtected">
                                <i class="bi bi-shield-lock"></i> Protected page (only admins can edit)
                            </label>
                        </div>
                        <?php endif; ?>
                        
                        <div class="d-flex gap-2">
                            <button type="submit" name="save_page" class="btn btn-primary">
                                <i class="bi bi-check-circle"></i> 
                                <?php echo $page ? 'Save Changes' : 'Create Page'; ?>
                            </button>
                            <a href="<?php echo $page ? 'index.php?page=wiki&action=view&slug=' . urlencode($slug) : 'index.php?page=wiki'; ?>" 
                               class="btn btn-secondary">
                                <i class="bi bi-x-circle"></i> Cancel
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="col-lg-3">
            <div class="card mb-3">
                <div class="card-header">
                    <strong>Editing Tips</strong>
                </div>
                <div class="card-body small">
                    <h6>General Guidelines</h6>
                    <ul>
                        <li>Use clear, concise language</li>
                        <li>Stay neutral and factual</li>
                        <li>Cite sources when possible</li>
                        <li>Organize content with headers</li>
                    </ul>
                    
                    <h6>Formatting</h6>
                    <ul>
                        <li>Use line breaks for paragraphs</li>
                        <li>Keep paragraphs short</li>
                        <li>Use consistent style</li>
                    </ul>
                </div>
            </div>
            
            <?php if ($page): ?>
            <div class="card">
                <div class="card-header">
                    <strong>Page Info</strong>
                </div>
                <div class="card-body small">
                    <p class="mb-1"><strong>Created:</strong><br>
                    <?php echo date('F j, Y', $page['created_at']); ?><br>
                    by <?php echo escape($page['created_by_username']); ?></p>
                    
                    <?php if (isset($page['last_edited_at'])): ?>
                    <p class="mb-1"><strong>Last edited:</strong><br>
                    <?php echo date('F j, Y', $page['last_edited_at']); ?><br>
                    by <?php echo escape($page['last_edited_by_username']); ?></p>
                    <?php endif; ?>
                    
                    <p class="mb-0">
                        <strong>Revisions:</strong> <?php echo number_format($page['revision_count'] ?? 1); ?><br>
                        <strong>Views:</strong> <?php echo number_format($page['views'] ?? 0); ?>
                    </p>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require 'templates/footer.php'; ?>
