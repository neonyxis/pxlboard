<?php
/**
 * Enhanced Forums - PXLBoard v12e
 * Modern forum system with image uploads, voting, moderation, and more
 */

$action = $_GET['action'] ?? 'list';
$topicId = $_GET['topic'] ?? '';
$category = $_GET['category'] ?? '';
$sort = $_GET['sort'] ?? 'latest';
$searchQuery = $_GET['q'] ?? '';

// Create forum uploads directory if it doesn't exist
if (!file_exists(UPLOADS_DIR . '/forum')) {
    mkdir(UPLOADS_DIR . '/forum', 0755, true);
}

// Load forum settings
$settingsFile = DATA_DIR . '/forum_settings.json';
if (!file_exists($settingsFile)) {
    $defaultSettings = [
        'allow_images' => true,
        'max_images_per_post' => 5,
        'allow_file_attachments' => true,
        'max_file_size' => 5,
        'allowed_extensions' => ['jpg', 'jpeg', 'png', 'gif', 'pdf', 'zip'],
        'require_approval' => false,
        'allow_anonymous' => false,
        'allow_voting' => true,
        'allow_best_answer' => true,
        'min_post_length' => 10,
        'max_post_length' => 10000,
        'posts_per_page' => 20,
        'allow_editing' => true,
        'edit_time_limit' => 3600,
        'auto_lock_days' => 0
    ];
    file_put_contents($settingsFile, json_encode($defaultSettings, JSON_PRETTY_PRINT));
}
$forumSettings = json_decode(file_get_contents($settingsFile), true);

// Load forum categories
$categoriesFile = DATA_DIR . '/forum_categories.json';
if (!file_exists($categoriesFile)) {
    $defaultCategories = [
        'general' => ['name' => 'General Discussion', 'icon' => 'chat-dots', 'color' => '#6c757d', 'description' => 'General topics and discussions', 'enabled' => true, 'order' => 1],
        'art' => ['name' => 'Art & Creativity', 'icon' => 'palette', 'color' => '#e83e8c', 'description' => 'Share and discuss creative works', 'enabled' => true, 'order' => 2],
        'support' => ['name' => 'Help & Support', 'icon' => 'question-circle', 'color' => '#fd7e14', 'description' => 'Get help from the community', 'enabled' => true, 'order' => 3],
        'feedback' => ['name' => 'Feedback', 'icon' => 'lightbulb', 'color' => '#20c997', 'description' => 'Suggestions and feedback', 'enabled' => true, 'order' => 4],
        'showcase' => ['name' => 'Showcase', 'icon' => 'star', 'color' => '#ffc107', 'description' => 'Show off your work', 'enabled' => true, 'order' => 5],
        'meta' => ['name' => 'Site Discussion', 'icon' => 'gear', 'color' => '#17a2b8', 'description' => 'Discuss the site itself', 'enabled' => true, 'order' => 6]
    ];
    file_put_contents($categoriesFile, json_encode($defaultCategories, JSON_PRETTY_PRINT));
}
$categories = json_decode(file_get_contents($categoriesFile), true);

// Filter only enabled categories
$categories = array_filter($categories, fn($c) => $c['enabled'] ?? true);

// Handle file upload
function handleForumFileUpload($files) {
    global $forumSettings;
    
    $uploaded = [];
    $maxSize = $forumSettings['max_file_size'] * 1024 * 1024; // Convert MB to bytes
    $allowedExts = $forumSettings['allowed_extensions'];
    
    if (is_array($files['name'])) {
        // Multiple files
        for ($i = 0; $i < count($files['name']); $i++) {
            if ($files['error'][$i] === UPLOAD_ERR_OK) {
                $filename = $files['name'][$i];
                $tmpName = $files['tmp_name'][$i];
                $size = $files['size'][$i];
                $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
                
                if ($size <= $maxSize && in_array($ext, $allowedExts)) {
                    $newFilename = uniqid() . '_' . sanitizeFilename($filename);
                    $destination = UPLOADS_DIR . '/forum/' . $newFilename;
                    
                    if (move_uploaded_file($tmpName, $destination)) {
                        $uploaded[] = $newFilename;
                    }
                }
            }
        }
    } else {
        // Single file
        if ($files['error'] === UPLOAD_ERR_OK) {
            $filename = $files['name'];
            $tmpName = $files['tmp_name'];
            $size = $files['size'];
            $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
            
            if ($size <= $maxSize && in_array($ext, $allowedExts)) {
                $newFilename = uniqid() . '_' . sanitizeFilename($filename);
                $destination = UPLOADS_DIR . '/forum/' . $newFilename;
                
                if (move_uploaded_file($tmpName, $destination)) {
                    $uploaded[] = $newFilename;
                }
            }
        }
    }
    
    return $uploaded;
}

// Handle voting on topics
if ($action === 'vote_topic' && $_SERVER['REQUEST_METHOD'] === 'POST' && $auth->isLoggedIn()) {
    if ($forumSettings['allow_voting']) {
        $topicId = $_POST['topic_id'] ?? '';
        $voteType = $_POST['vote_type'] ?? '';
        
        if ($topicId && in_array($voteType, ['up', 'down'])) {
            $topic = $db->get('forum_topics', $topicId);
            if ($topic) {
                $votes = $topic['votes'] ?? [];
                $userId = $_SESSION['user_id'];
                
                $votes = array_filter($votes, function($v) use ($userId) {
                    return $v['user_id'] !== $userId;
                });
                
                $votes[] = [
                    'user_id' => $userId,
                    'type' => $voteType,
                    'timestamp' => time()
                ];
                
                $topic['votes'] = $votes;
                $topic['score'] = calculateScore($votes);
                $db->save('forum_topics', $topicId, $topic);
                
                echo json_encode(['success' => true, 'score' => $topic['score']]);
                exit;
            }
        }
    }
}

// Handle voting on replies
if ($action === 'vote_reply' && $_SERVER['REQUEST_METHOD'] === 'POST' && $auth->isLoggedIn()) {
    if ($forumSettings['allow_voting']) {
        $replyId = $_POST['reply_id'] ?? '';
        $voteType = $_POST['vote_type'] ?? '';
        
        if ($replyId && in_array($voteType, ['up', 'down'])) {
            $reply = $db->get('forum_replies', $replyId);
            if ($reply) {
                $votes = $reply['votes'] ?? [];
                $userId = $_SESSION['user_id'];
                
                $votes = array_filter($votes, function($v) use ($userId) {
                    return $v['user_id'] !== $userId;
                });
                
                $votes[] = [
                    'user_id' => $userId,
                    'type' => $voteType,
                    'timestamp' => time()
                ];
                
                $reply['votes'] = $votes;
                $reply['score'] = calculateScore($votes);
                $db->save('forum_replies', $replyId, $reply);
                
                echo json_encode(['success' => true, 'score' => $reply['score']]);
                exit;
            }
        }
    }
}

// Handle flag/report
if ($action === 'flag' && $_SERVER['REQUEST_METHOD'] === 'POST' && $auth->isLoggedIn()) {
    $itemType = $_POST['item_type'] ?? ''; // 'topic' or 'reply'
    $itemId = $_POST['item_id'] ?? '';
    $reason = trim($_POST['reason'] ?? '');
    
    if ($itemType && $itemId && $reason) {
        $collection = $itemType === 'topic' ? 'forum_topics' : 'forum_replies';
        $item = $db->get($collection, $itemId);
        
        if ($item) {
            $flags = $item['flags'] ?? [];
            $flags[] = [
                'user_id' => $_SESSION['user_id'],
                'username' => $_SESSION['username'],
                'reason' => $reason,
                'timestamp' => time()
            ];
            $item['flags'] = $flags;
            $db->save($collection, $itemId, $item);
            
            echo json_encode(['success' => true]);
            exit;
        }
    }
}

// Handle new topic creation
if ($action === 'create' && $_SERVER['REQUEST_METHOD'] === 'POST' && $auth->isLoggedIn()) {
    $title = trim($_POST['title'] ?? '');
    $content = trim($_POST['content'] ?? '');
    $categoryKey = $_POST['category'] ?? 'general';
    $tags = array_filter(array_map('trim', explode(',', $_POST['tags'] ?? '')));
    
    // Validate content length
    if (strlen($content) < $forumSettings['min_post_length']) {
        $_SESSION['error'] = "Post content must be at least {$forumSettings['min_post_length']} characters.";
    } elseif (strlen($content) > $forumSettings['max_post_length']) {
        $_SESSION['error'] = "Post content must not exceed {$forumSettings['max_post_length']} characters.";
    } elseif (!empty($title) && !empty($content)) {
        $attachments = [];
        
        // Handle image uploads
        if ($forumSettings['allow_images'] && !empty($_FILES['images']['name'][0])) {
            $attachments = handleForumFileUpload($_FILES['images']);
            if (count($attachments) > $forumSettings['max_images_per_post']) {
                $attachments = array_slice($attachments, 0, $forumSettings['max_images_per_post']);
            }
        }
        
        $topicIdNew = $db->getNextId('forum_topics');
        $topicData = [
            'title' => $title,
            'content' => $content,
            'category' => $categoryKey,
            'tags' => $tags,
            'author_id' => $_SESSION['user_id'],
            'author' => $_SESSION['username'],
            'created_at' => time(),
            'updated_at' => time(),
            'last_reply_at' => time(),
            'views' => 0,
            'replies' => 0,
            'votes' => [],
            'score' => 0,
            'locked' => false,
            'pinned' => false,
            'solved' => false,
            'attachments' => $attachments,
            'approved' => !$forumSettings['require_approval']
        ];
        
        if ($db->save('forum_topics', $topicIdNew, $topicData)) {
            if ($forumSettings['require_approval']) {
                $_SESSION['success'] = 'Topic submitted for approval.';
                redirect('index.php?page=forums');
            } else {
                redirect('index.php?page=forums&action=view&topic=' . $topicIdNew);
            }
        }
    }
}

// Handle reply
if ($action === 'reply' && $_SERVER['REQUEST_METHOD'] === 'POST' && $auth->isLoggedIn()) {
    $content = trim($_POST['content'] ?? '');
    
    if (strlen($content) < $forumSettings['min_post_length']) {
        $_SESSION['error'] = "Reply must be at least {$forumSettings['min_post_length']} characters.";
        redirect('index.php?page=forums&action=view&topic=' . $topicId);
    } elseif (strlen($content) > $forumSettings['max_post_length']) {
        $_SESSION['error'] = "Reply must not exceed {$forumSettings['max_post_length']} characters.";
        redirect('index.php?page=forums&action=view&topic=' . $topicId);
    } elseif (!empty($content) && !empty($topicId)) {
        $topic = $db->get('forum_topics', $topicId);
        if ($topic && !$topic['locked']) {
            $attachments = [];
            
            // Handle image uploads
            if ($forumSettings['allow_images'] && !empty($_FILES['images']['name'][0])) {
                $attachments = handleForumFileUpload($_FILES['images']);
                if (count($attachments) > $forumSettings['max_images_per_post']) {
                    $attachments = array_slice($attachments, 0, $forumSettings['max_images_per_post']);
                }
            }
            
            $replyId = $db->getNextId('forum_replies');
            $replyData = [
                'topic_id' => $topicId,
                'author_id' => $_SESSION['user_id'],
                'author' => $_SESSION['username'],
                'content' => $content,
                'created_at' => time(),
                'votes' => [],
                'score' => 0,
                'best_answer' => false,
                'attachments' => $attachments
            ];
            
            if ($db->save('forum_replies', $replyId, $replyData)) {
                $topic['replies'] = ($topic['replies'] ?? 0) + 1;
                $topic['updated_at'] = time();
                $topic['last_reply_at'] = time();
                $db->save('forum_topics', $topicId, $topic);
                redirect('index.php?page=forums&action=view&topic=' . $topicId . '#reply-' . $replyId);
            }
        }
    }
}

// Handle marking reply as best answer
if ($action === 'mark_best' && $_SERVER['REQUEST_METHOD'] === 'POST' && $auth->isLoggedIn()) {
    if ($forumSettings['allow_best_answer']) {
        $replyId = $_POST['reply_id'] ?? '';
        $topicId = $_POST['topic_id'] ?? '';
        
        $topic = $db->get('forum_topics', $topicId);
        if ($topic && $topic['author_id'] === $_SESSION['user_id']) {
            // Unmark all previous best answers
            $allReplies = $db->getAll('forum_replies');
            foreach ($allReplies as $id => $reply) {
                if ($reply['topic_id'] === $topicId && ($reply['best_answer'] ?? false)) {
                    $reply['best_answer'] = false;
                    $db->save('forum_replies', $id, $reply);
                }
            }
            
            // Mark new best answer
            $reply = $db->get('forum_replies', $replyId);
            if ($reply) {
                $reply['best_answer'] = true;
                $db->save('forum_replies', $replyId, $reply);
                
                $topic['solved'] = true;
                $db->save('forum_topics', $topicId, $topic);
            }
            
            redirect('index.php?page=forums&action=view&topic=' . $topicId . '#reply-' . $replyId);
        }
    }
}

// Helper function to calculate score from votes
function calculateScore($votes) {
    $upvotes = count(array_filter($votes, fn($v) => $v['type'] === 'up'));
    $downvotes = count(array_filter($votes, fn($v) => $v['type'] === 'down'));
    return $upvotes - $downvotes;
}

// Get user's vote on an item
function getUserVote($votes, $userId) {
    foreach ($votes as $vote) {
        if ($vote['user_id'] === $userId) {
            return $vote['type'];
        }
    }
    return null;
}

require 'templates/header.php';

if ($action === 'list'):
    // List all topics
    $topics = $db->getAll('forum_topics');
    
    // Filter unapproved topics unless admin
    if (!$auth->isAdmin()) {
        $topics = array_filter($topics, fn($t) => $t['approved'] ?? true);
    }
    
    // Filter by category
    if (!empty($category)) {
        $topics = array_filter($topics, fn($t) => $t['category'] === $category);
    }
    
    // Filter by search
    if (!empty($searchQuery)) {
        $searchLower = strtolower($searchQuery);
        $topics = array_filter($topics, function($t) use ($searchLower) {
            return strpos(strtolower($t['title']), $searchLower) !== false ||
                   strpos(strtolower($t['content']), $searchLower) !== false ||
                   (isset($t['tags']) && count(array_filter($t['tags'], fn($tag) => 
                       strpos(strtolower($tag), $searchLower) !== false)) > 0);
        });
    }
    
    // Sort topics
    switch ($sort) {
        case 'hot':
            usort($topics, function($a, $b) {
                $scoreA = ($a['score'] ?? 0) / max(1, (time() - $a['created_at']) / 3600);
                $scoreB = ($b['score'] ?? 0) / max(1, (time() - $b['created_at']) / 3600);
                return $scoreB <=> $scoreA;
            });
            break;
        case 'top':
            usort($topics, fn($a, $b) => ($b['score'] ?? 0) <=> ($a['score'] ?? 0));
            break;
        case 'latest':
        default:
            usort($topics, function($a, $b) {
                if (($a['pinned'] ?? false) !== ($b['pinned'] ?? false)) {
                    return ($b['pinned'] ?? false) - ($a['pinned'] ?? false);
                }
                return ($b['last_reply_at'] ?? $b['updated_at']) <=> ($a['last_reply_at'] ?? $a['updated_at']);
            });
            break;
    }
    
    $totalTopics = count($topics);
    $totalReplies = count($db->getAll('forum_replies'));
?>


<style>
/* Flarum/Discourse inspired styling */
.forum-header {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 3rem 0;
    margin-bottom: 2rem;
}

.forum-stats {
    display: flex;
    gap: 2rem;
    margin-top: 1.5rem;
}

.forum-stat {
    text-align: center;
}

.forum-stat-value {
    font-size: 2rem;
    font-weight: bold;
    display: block;
}

.forum-stat-label {
    font-size: 0.9rem;
    opacity: 0.9;
}

.category-pills {
    display: flex;
    gap: 0.5rem;
    flex-wrap: wrap;
    margin-bottom: 2rem;
}

.category-pill {
    padding: 0.5rem 1rem;
    border-radius: 50px;
    border: 2px solid #dee2e6;
    background: white;
    text-decoration: none;
    color: #495057;
    transition: all 0.2s;
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
}

.category-pill:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}

.category-pill.active {
    border-color: currentColor;
    font-weight: bold;
}

.topic-card {
    background: white;
    border: 1px solid #dee2e6;
    border-radius: 8px;
    margin-bottom: 1rem;
    padding: 1.5rem;
    transition: all 0.2s;
    cursor: pointer;
    text-decoration: none;
    color: inherit;
    display: block;
}

.topic-card:hover {
    transform: translateX(5px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    border-color: #667eea;
}

.topic-voting {
    display: flex;
    flex-direction: column;
    align-items: center;
    margin-right: 1rem;
    min-width: 60px;
}

.vote-btn {
    background: none;
    border: none;
    cursor: pointer;
    font-size: 1.5rem;
    color: #6c757d;
    padding: 0.25rem;
    transition: all 0.2s;
}

.vote-btn:hover {
    transform: scale(1.2);
}

.vote-btn.upvoted {
    color: #ff6b35;
}

.vote-btn.downvoted {
    color: #4a5899;
}

.vote-score {
    font-weight: bold;
    font-size: 1.1rem;
    margin: 0.25rem 0;
}

.vote-score.positive {
    color: #ff6b35;
}

.vote-score.negative {
    color: #4a5899;
}

.topic-content {
    flex: 1;
}

.topic-title {
    font-size: 1.2rem;
    font-weight: 600;
    margin-bottom: 0.5rem;
    color: #212529;
}

.topic-meta {
    display: flex;
    align-items: center;
    gap: 1rem;
    font-size: 0.9rem;
    color: #6c757d;
    margin-top: 0.5rem;
}

.topic-tags {
    display: flex;
    gap: 0.5rem;
    flex-wrap: wrap;
    margin-top: 0.5rem;
}

.topic-tag {
    background: #e9ecef;
    padding: 0.25rem 0.75rem;
    border-radius: 50px;
    font-size: 0.85rem;
    color: #495057;
    text-decoration: none;
}

.topic-tag:hover {
    background: #dee2e6;
}

.topic-stats {
    display: flex;
    align-items: center;
    gap: 1.5rem;
    margin-left: auto;
    text-align: center;
}

.topic-stat {
    display: flex;
    flex-direction: column;
}

.topic-stat-value {
    font-weight: bold;
    font-size: 1.1rem;
}

.topic-stat-label {
    font-size: 0.75rem;
    color: #6c757d;
}

.badge-solved {
    background: #28a745;
    color: white;
}

.badge-pinned {
    background: #ffc107;
    color: #000;
}

.badge-locked {
    background: #6c757d;
    color: white;
}

.search-bar {
    max-width: 600px;
    margin: 0 auto 2rem;
}

.sort-tabs {
    display: flex;
    gap: 0.5rem;
    margin-bottom: 1.5rem;
    border-bottom: 2px solid #dee2e6;
}

.sort-tab {
    padding: 0.75rem 1.5rem;
    border: none;
    background: none;
    cursor: pointer;
    color: #6c757d;
    font-weight: 500;
    border-bottom: 3px solid transparent;
    transition: all 0.2s;
    text-decoration: none;
}

.sort-tab:hover {
    color: #495057;
}

.sort-tab.active {
    color: #667eea;
    border-bottom-color: #667eea;
}

.topic-header {
    background: white;
    border: 1px solid #dee2e6;
    border-radius: 8px;
    padding: 2rem;
    margin-bottom: 2rem;
}

.reply-card {
    background: white;
    border: 1px solid #dee2e6;
    border-radius: 8px;
    padding: 1.5rem;
    margin-bottom: 1rem;
    transition: all 0.2s;
}

.reply-card:hover {
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

.reply-card.best-answer {
    border: 2px solid #28a745;
    background: #f8fff9;
}

.reply-voting {
    display: flex;
    flex-direction: column;
    align-items: center;
    margin-right: 1.5rem;
    min-width: 60px;
}

.reply-author {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    margin-bottom: 1rem;
    padding-bottom: 1rem;
    border-bottom: 1px solid #dee2e6;
}

.author-avatar {
    width: 48px;
    height: 48px;
    border-radius: 50%;
    background: linear-gradient(135deg, #667eea, #764ba2);
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-weight: bold;
    font-size: 1.25rem;
}

.author-info {
    flex: 1;
}

.author-name {
    font-weight: 600;
    font-size: 1.1rem;
}

.author-meta {
    font-size: 0.9rem;
    color: #6c757d;
}

.reply-content {
    line-height: 1.6;
    margin-bottom: 1rem;
}

.reply-actions {
    display: flex;
    gap: 1rem;
    padding-top: 1rem;
    border-top: 1px solid #dee2e6;
}

.reply-action-btn {
    background: none;
    border: none;
    color: #6c757d;
    cursor: pointer;
    padding: 0.5rem 1rem;
    border-radius: 4px;
    transition: all 0.2s;
}

.reply-action-btn:hover {
    background: #e9ecef;
    color: #495057;
}

.compose-box {
    background: white;
    border: 1px solid #dee2e6;
    border-radius: 8px;
    padding: 1.5rem;
}

.compose-box textarea {
    border: 1px solid #dee2e6;
    border-radius: 4px;
    min-height: 120px;
    resize: vertical;
}

.breadcrumb-custom {
    background: none;
    padding: 0;
    margin-bottom: 1.5rem;
}

.attachment-preview {
    display: inline-block;
    margin: 0.5rem;
    position: relative;
}

.attachment-preview img {
    max-width: 200px;
    max-height: 200px;
    border-radius: 4px;
    border: 1px solid #dee2e6;
}

.attachment-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
    gap: 1rem;
    margin: 1rem 0;
}

.attachment-item {
    border: 1px solid #dee2e6;
    border-radius: 8px;
    overflow: hidden;
}

.attachment-item img {
    width: 100%;
    height: 200px;
    object-fit: cover;
    cursor: pointer;
}

.attachment-item img:hover {
    opacity: 0.9;
}

@media (max-width: 768px) {
    .topic-card {
        flex-direction: column;
    }
    
    .topic-stats {
        margin-left: 0;
        margin-top: 1rem;
    }
}
</style>

<div class="forum-header">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <h1 class="display-4 mb-2">
                    <i class="bi bi-chat-square-text"></i> Community Forums
                </h1>
                <p class="lead mb-0">Join the discussion, share ideas, and get help from the community</p>
                
                <div class="forum-stats">
                    <div class="forum-stat">
                        <span class="forum-stat-value"><?php echo number_format($totalTopics); ?></span>
                        <span class="forum-stat-label">Discussions</span>
                    </div>
                    <div class="forum-stat">
                        <span class="forum-stat-value"><?php echo number_format($totalReplies); ?></span>
                        <span class="forum-stat-label">Replies</span>
                    </div>
                    <div class="forum-stat">
                        <span class="forum-stat-value"><?php echo number_format(count($db->getAll('users'))); ?></span>
                        <span class="forum-stat-label">Members</span>
                    </div>
                </div>
            </div>
            <div class="col-md-4 text-end align-self-center">
                <?php if ($auth->isLoggedIn()): ?>
                    <a href="index.php?page=forums&action=create" class="btn btn-light btn-lg">
                        <i class="bi bi-plus-circle"></i> Start Discussion
                    </a>
                <?php else: ?>
                    <a href="index.php?page=login" class="btn btn-light btn-lg">
                        <i class="bi bi-box-arrow-in-right"></i> Login to Post
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="container mb-5">
    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="bi bi-check-circle"></i> <?php echo escape($_SESSION['success']); unset($_SESSION['success']); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <i class="bi bi-exclamation-triangle"></i> <?php echo escape($_SESSION['error']); unset($_SESSION['error']); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <!-- Search Bar -->
    <div class="search-bar">
        <form method="GET" action="index.php">
            <input type="hidden" name="page" value="forums">
            <?php if ($category): ?>
                <input type="hidden" name="category" value="<?php echo escape($category); ?>">
            <?php endif; ?>
            <div class="input-group input-group-lg">
                <span class="input-group-text"><i class="bi bi-search"></i></span>
                <input type="text" 
                       name="q" 
                       class="form-control" 
                       placeholder="Search discussions, tags, or topics..."
                       value="<?php echo escape($searchQuery); ?>">
                <?php if ($searchQuery): ?>
                    <a href="index.php?page=forums<?php echo $category ? '&category=' . $category : ''; ?>" 
                       class="btn btn-outline-secondary">
                        <i class="bi bi-x"></i>
                    </a>
                <?php endif; ?>
            </div>
        </form>
    </div>
    
    <!-- Category Pills -->
    <div class="category-pills">
        <a href="index.php?page=forums" 
           class="category-pill <?php echo empty($category) ? 'active' : ''; ?>">
            <i class="bi bi-grid"></i>
            All Topics
        </a>
        <?php foreach ($categories as $catKey => $catData): ?>
            <a href="index.php?page=forums&category=<?php echo $catKey; ?>" 
               class="category-pill <?php echo $category === $catKey ? 'active' : ''; ?>"
               style="<?php echo $category === $catKey ? 'color: ' . $catData['color'] : ''; ?>">
                <i class="bi bi-<?php echo $catData['icon']; ?>"></i>
                <?php echo $catData['name']; ?>
            </a>
        <?php endforeach; ?>
    </div>
    
    <!-- Sort Tabs -->
    <div class="sort-tabs">
        <a href="?page=forums<?php echo $category ? '&category=' . $category : ''; ?><?php echo $searchQuery ? '&q=' . urlencode($searchQuery) : ''; ?>&sort=latest" 
           class="sort-tab <?php echo $sort === 'latest' ? 'active' : ''; ?>">
            <i class="bi bi-clock"></i> Latest
        </a>
        <a href="?page=forums<?php echo $category ? '&category=' . $category : ''; ?><?php echo $searchQuery ? '&q=' . urlencode($searchQuery) : ''; ?>&sort=hot" 
           class="sort-tab <?php echo $sort === 'hot' ? 'active' : ''; ?>">
            <i class="bi bi-fire"></i> Hot
        </a>
        <a href="?page=forums<?php echo $category ? '&category=' . $category : ''; ?><?php echo $searchQuery ? '&q=' . urlencode($searchQuery) : ''; ?>&sort=top" 
           class="sort-tab <?php echo $sort === 'top' ? 'active' : ''; ?>">
            <i class="bi bi-trophy"></i> Top
        </a>
    </div>
    
    <!-- Topics List -->
    <?php if (empty($topics)): ?>
        <div class="text-center py-5">
            <i class="bi bi-chat-dots" style="font-size: 4rem; color: #dee2e6;"></i>
            <h3 class="mt-3">No discussions found</h3>
            <p class="text-muted">
                <?php if ($searchQuery): ?>
                    Try adjusting your search terms
                <?php else: ?>
                    Be the first to start a discussion!
                <?php endif; ?>
            </p>
            <?php if ($auth->isLoggedIn() && !$searchQuery): ?>
                <a href="index.php?page=forums&action=create" class="btn btn-primary mt-3">
                    <i class="bi bi-plus-circle"></i> Start Discussion
                </a>
            <?php endif; ?>
        </div>
    <?php else: ?>
        <?php foreach ($topics as $topicItem): 
            $userVote = $auth->isLoggedIn() ? getUserVote($topicItem['votes'] ?? [], $_SESSION['user_id']) : null;
            $topicScore = $topicItem['score'] ?? 0;
        ?>
            <div class="topic-card" onclick="window.location='index.php?page=forums&action=view&topic=<?php echo $topicItem['id']; ?>'">
                <div class="d-flex">
                    <?php if ($forumSettings['allow_voting']): ?>
                    <div class="topic-voting" onclick="event.stopPropagation()">
                        <button class="vote-btn <?php echo $userVote === 'up' ? 'upvoted' : ''; ?>" 
                                onclick="vote('topic', '<?php echo $topicItem['id']; ?>', 'up')"
                                <?php echo !$auth->isLoggedIn() ? 'disabled' : ''; ?>>
                            <i class="bi bi-arrow-up-circle-fill"></i>
                        </button>
                        <span class="vote-score <?php echo $topicScore > 0 ? 'positive' : ($topicScore < 0 ? 'negative' : ''); ?>" 
                              id="topic-score-<?php echo $topicItem['id']; ?>">
                            <?php echo $topicScore; ?>
                        </span>
                        <button class="vote-btn <?php echo $userVote === 'down' ? 'downvoted' : ''; ?>" 
                                onclick="vote('topic', '<?php echo $topicItem['id']; ?>', 'down')"
                                <?php echo !$auth->isLoggedIn() ? 'disabled' : ''; ?>>
                            <i class="bi bi-arrow-down-circle-fill"></i>
                        </button>
                    </div>
                    <?php endif; ?>
                    
                    <div class="topic-content">
                        <div class="topic-title">
                            <?php if ($topicItem['pinned'] ?? false): ?>
                                <span class="badge badge-pinned me-2">
                                    <i class="bi bi-pin-fill"></i> Pinned
                                </span>
                            <?php endif; ?>
                            <?php if ($topicItem['locked'] ?? false): ?>
                                <span class="badge badge-locked me-2">
                                    <i class="bi bi-lock-fill"></i> Locked
                                </span>
                            <?php endif; ?>
                            <?php if ($topicItem['solved'] ?? false): ?>
                                <span class="badge badge-solved me-2">
                                    <i class="bi bi-check-circle-fill"></i> Solved
                                </span>
                            <?php endif; ?>
                            <?php echo escape($topicItem['title']); ?>
                        </div>
                        
                        <?php if (!empty($topicItem['tags'])): ?>
                            <div class="topic-tags">
                                <?php foreach ($topicItem['tags'] as $tag): ?>
                                    <a href="index.php?page=forums&q=<?php echo urlencode($tag); ?>" 
                                       class="topic-tag"
                                       onclick="event.stopPropagation()">
                                        <i class="bi bi-tag"></i> <?php echo escape($tag); ?>
                                    </a>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                        
                        <div class="topic-meta">
                            <span>
                                <i class="bi bi-<?php echo $categories[$topicItem['category']]['icon'] ?? 'chat-dots'; ?>"></i>
                                <?php echo $categories[$topicItem['category']]['name'] ?? 'General'; ?>
                            </span>
                            <span>
                                <i class="bi bi-person"></i>
                                <?php echo escape($topicItem['author']); ?>
                            </span>
                            <span>
                                <i class="bi bi-clock"></i>
                                <?php echo timeAgo($topicItem['created_at']); ?>
                            </span>
                        </div>
                    </div>
                    
                    <div class="topic-stats">
                        <div class="topic-stat">
                            <span class="topic-stat-value">
                                <i class="bi bi-eye"></i> <?php echo number_format($topicItem['views'] ?? 0); ?>
                            </span>
                            <span class="topic-stat-label">views</span>
                        </div>
                        <div class="topic-stat">
                            <span class="topic-stat-value">
                                <i class="bi bi-chat"></i> <?php echo number_format($topicItem['replies'] ?? 0); ?>
                            </span>
                            <span class="topic-stat-label">replies</span>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<?php elseif ($action === 'view'): 
    // View topic
    $topic = $db->get('forum_topics', $topicId);
    if (!$topic) {
        require 'pages/404.php';
        exit;
    }
    
    // Check if topic is approved or user is admin/author
    if (!($topic['approved'] ?? true) && !$auth->isAdmin() && (!$auth->isLoggedIn() || $topic['author_id'] !== $_SESSION['user_id'])) {
        echo '<div class="container mt-5"><div class="alert alert-warning">This topic is pending approval.</div></div>';
        require 'templates/footer.php';
        exit;
    }
    
    // Increment views (only once per session)
    if (!isset($_SESSION['viewed_topics']) || !in_array($topicId, $_SESSION['viewed_topics'])) {
        $topic['views'] = ($topic['views'] ?? 0) + 1;
        $db->save('forum_topics', $topicId, $topic);
        $_SESSION['viewed_topics'] = $_SESSION['viewed_topics'] ?? [];
        $_SESSION['viewed_topics'][] = $topicId;
    }
    
    // Get replies
    $allReplies = $db->getAll('forum_replies');
    $replies = array_filter($allReplies, function($r) use ($topicId) {
        return $r['topic_id'] === $topicId;
    });
    usort($replies, function($a, $b) {
        // Best answer first, then by score, then by date
        if (($a['best_answer'] ?? false) !== ($b['best_answer'] ?? false)) {
            return ($b['best_answer'] ?? false) - ($a['best_answer'] ?? false);
        }
        if (($a['score'] ?? 0) !== ($b['score'] ?? 0)) {
            return ($b['score'] ?? 0) - ($a['score'] ?? 0);
        }
        return $a['created_at'] - $b['created_at'];
    });
    
    $userVote = $auth->isLoggedIn() ? getUserVote($topic['votes'] ?? [], $_SESSION['user_id']) : null;
    $topicScore = $topic['score'] ?? 0;
?>

<div class="container mt-4 mb-5">
    <nav aria-label="breadcrumb" class="breadcrumb-custom">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php?page=forums">Forums</a></li>
            <li class="breadcrumb-item">
                <a href="index.php?page=forums&category=<?php echo $topic['category']; ?>">
                    <i class="bi bi-<?php echo $categories[$topic['category']]['icon'] ?? 'chat-dots'; ?>"></i>
                    <?php echo $categories[$topic['category']]['name'] ?? 'General'; ?>
                </a>
            </li>
            <li class="breadcrumb-item active"><?php echo escape($topic['title']); ?></li>
        </ol>
    </nav>
    
    <!-- Topic Header -->
    <div class="topic-header">
        <div class="d-flex">
            <?php if ($forumSettings['allow_voting']): ?>
            <div class="topic-voting">
                <button class="vote-btn <?php echo $userVote === 'up' ? 'upvoted' : ''; ?>" 
                        onclick="vote('topic', '<?php echo $topicId; ?>', 'up')"
                        <?php echo !$auth->isLoggedIn() ? 'disabled' : ''; ?>>
                    <i class="bi bi-arrow-up-circle-fill"></i>
                </button>
                <span class="vote-score <?php echo $topicScore > 0 ? 'positive' : ($topicScore < 0 ? 'negative' : ''); ?>" 
                      id="topic-score-<?php echo $topicId; ?>">
                    <?php echo $topicScore; ?>
                </span>
                <button class="vote-btn <?php echo $userVote === 'down' ? 'downvoted' : ''; ?>" 
                        onclick="vote('topic', '<?php echo $topicId; ?>', 'down')"
                        <?php echo !$auth->isLoggedIn() ? 'disabled' : ''; ?>>
                    <i class="bi bi-arrow-down-circle-fill"></i>
                </button>
            </div>
            <?php endif; ?>
            
            <div class="flex-grow-1">
                <div class="mb-3">
                    <?php if ($topic['pinned'] ?? false): ?>
                        <span class="badge badge-pinned me-2">
                            <i class="bi bi-pin-fill"></i> Pinned
                        </span>
                    <?php endif; ?>
                    <?php if ($topic['locked'] ?? false): ?>
                        <span class="badge badge-locked me-2">
                            <i class="bi bi-lock-fill"></i> Locked
                        </span>
                    <?php endif; ?>
                    <?php if ($topic['solved'] ?? false): ?>
                        <span class="badge badge-solved me-2">
                            <i class="bi bi-check-circle-fill"></i> Solved
                        </span>
                    <?php endif; ?>
                    <?php if (!($topic['approved'] ?? true)): ?>
                        <span class="badge bg-warning text-dark me-2">
                            <i class="bi bi-clock"></i> Pending Approval
                        </span>
                    <?php endif; ?>
                </div>
                
                <h1 class="mb-3"><?php echo escape($topic['title']); ?></h1>
                
                <?php if (!empty($topic['tags'])): ?>
                    <div class="topic-tags mb-3">
                        <?php foreach ($topic['tags'] as $tag): ?>
                            <a href="index.php?page=forums&q=<?php echo urlencode($tag); ?>" class="topic-tag">
                                <i class="bi bi-tag"></i> <?php echo escape($tag); ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
                
                <div class="topic-meta">
                    <span>
                        <i class="bi bi-person"></i>
                        <strong><?php echo escape($topic['author']); ?></strong>
                    </span>
                    <span>
                        <i class="bi bi-clock"></i>
                        <?php echo timeAgo($topic['created_at']); ?>
                    </span>
                    <span>
                        <i class="bi bi-eye"></i>
                        <?php echo number_format($topic['views']); ?> views
                    </span>
                    <span>
                        <i class="bi bi-chat"></i>
                        <?php echo count($replies); ?> replies
                    </span>
                </div>
                
                <hr class="my-3">
                
                <div class="reply-content">
                    <?php echo nl2br(escape($topic['content'])); ?>
                </div>
                
                <?php if (!empty($topic['attachments'])): ?>
                    <div class="attachment-grid">
                        <?php foreach ($topic['attachments'] as $attachment): 
                            $ext = strtolower(pathinfo($attachment, PATHINFO_EXTENSION));
                            $isImage = in_array($ext, ['jpg', 'jpeg', 'png', 'gif']);
                        ?>
                            <div class="attachment-item">
                                <?php if ($isImage): ?>
                                    <img src="<?php echo UPLOADS_DIR; ?>/forum/<?php echo $attachment; ?>" 
                                         alt="Attachment" 
                                         onclick="window.open(this.src, '_blank')">
                                <?php else: ?>
                                    <div class="p-3 text-center">
                                        <i class="bi bi-file-earmark" style="font-size: 3rem;"></i>
                                        <div class="mt-2">
                                            <a href="<?php echo UPLOADS_DIR; ?>/forum/<?php echo $attachment; ?>" 
                                               download class="btn btn-sm btn-outline-primary">
                                                <i class="bi bi-download"></i> Download
                                            </a>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Replies -->
    <h3 class="mb-3">
        <i class="bi bi-chat-left-text"></i> 
        <?php echo count($replies); ?> 
        <?php echo count($replies) === 1 ? 'Reply' : 'Replies'; ?>
    </h3>
    
    <?php foreach ($replies as $replyId => $reply): 
        $replyUserVote = $auth->isLoggedIn() ? getUserVote($reply['votes'] ?? [], $_SESSION['user_id']) : null;
        $replyScore = $reply['score'] ?? 0;
        $isBestAnswer = $reply['best_answer'] ?? false;
    ?>
        <div class="reply-card <?php echo $isBestAnswer ? 'best-answer' : ''; ?>" id="reply-<?php echo $replyId; ?>">
            <?php if ($isBestAnswer): ?>
                <div class="alert alert-success mb-3">
                    <i class="bi bi-check-circle-fill"></i> 
                    <strong>Best Answer</strong> - Marked as solution by the topic author
                </div>
            <?php endif; ?>
            
            <div class="d-flex">
                <?php if ($forumSettings['allow_voting']): ?>
                <div class="reply-voting">
                    <button class="vote-btn <?php echo $replyUserVote === 'up' ? 'upvoted' : ''; ?>" 
                            onclick="vote('reply', '<?php echo $replyId; ?>', 'up')"
                            <?php echo !$auth->isLoggedIn() ? 'disabled' : ''; ?>>
                        <i class="bi bi-arrow-up-circle-fill"></i>
                    </button>
                    <span class="vote-score <?php echo $replyScore > 0 ? 'positive' : ($replyScore < 0 ? 'negative' : ''); ?>" 
                          id="reply-score-<?php echo $replyId; ?>">
                        <?php echo $replyScore; ?>
                    </span>
                    <button class="vote-btn <?php echo $replyUserVote === 'down' ? 'downvoted' : ''; ?>" 
                            onclick="vote('reply', '<?php echo $replyId; ?>', 'down')"
                            <?php echo !$auth->isLoggedIn() ? 'disabled' : ''; ?>>
                        <i class="bi bi-arrow-down-circle-fill"></i>
                    </button>
                </div>
                <?php endif; ?>
                
                <div class="flex-grow-1">
                    <div class="reply-author">
                        <div class="author-avatar">
                            <?php echo strtoupper(substr($reply['author'], 0, 1)); ?>
                        </div>
                        <div class="author-info">
                            <div class="author-name"><?php echo escape($reply['author']); ?></div>
                            <div class="author-meta">
                                <i class="bi bi-clock"></i> <?php echo timeAgo($reply['created_at']); ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="reply-content">
                        <?php echo nl2br(escape($reply['content'])); ?>
                    </div>
                    
                    <?php if (!empty($reply['attachments'])): ?>
                        <div class="attachment-grid">
                            <?php foreach ($reply['attachments'] as $attachment): 
                                $ext = strtolower(pathinfo($attachment, PATHINFO_EXTENSION));
                                $isImage = in_array($ext, ['jpg', 'jpeg', 'png', 'gif']);
                            ?>
                                <div class="attachment-item">
                                    <?php if ($isImage): ?>
                                        <img src="<?php echo UPLOADS_DIR; ?>/forum/<?php echo $attachment; ?>" 
                                             alt="Attachment" 
                                             onclick="window.open(this.src, '_blank')">
                                    <?php else: ?>
                                        <div class="p-3 text-center">
                                            <i class="bi bi-file-earmark" style="font-size: 2rem;"></i>
                                            <div class="mt-2">
                                                <a href="<?php echo UPLOADS_DIR; ?>/forum/<?php echo $attachment; ?>" 
                                                   download class="btn btn-sm btn-outline-primary">
                                                    <i class="bi bi-download"></i> Download
                                                </a>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                    
                    <div class="reply-actions">
                        <?php if ($forumSettings['allow_best_answer'] && $auth->isLoggedIn() && $topic['author_id'] === $_SESSION['user_id'] && !$isBestAnswer && !($topic['solved'] ?? false)): ?>
                            <form method="POST" action="index.php?page=forums&action=mark_best" style="display: inline;">
                                <input type="hidden" name="reply_id" value="<?php echo $replyId; ?>">
                                <input type="hidden" name="topic_id" value="<?php echo $topicId; ?>">
                                <button type="submit" class="reply-action-btn">
                                    <i class="bi bi-check-circle"></i> Mark as Best Answer
                                </button>
                            </form>
                        <?php endif; ?>
                        
                        <?php if ($auth->isLoggedIn()): ?>
                            <button class="reply-action-btn" onclick="reportContent('reply', '<?php echo $replyId; ?>')">
                                <i class="bi bi-flag"></i> Report
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
    
    <!-- Reply Form -->
    <?php if ($auth->isLoggedIn() && !($topic['locked'] ?? false)): ?>
        <div class="compose-box mt-4">
            <h4 class="mb-3"><i class="bi bi-pencil"></i> Post a Reply</h4>
            <form method="POST" action="index.php?page=forums&action=reply&topic=<?php echo $topicId; ?>" enctype="multipart/form-data">
                <div class="mb-3">
                    <textarea name="content" class="form-control" rows="5" required 
                              placeholder="Share your thoughts..."
                              minlength="<?php echo $forumSettings['min_post_length']; ?>"
                              maxlength="<?php echo $forumSettings['max_post_length']; ?>"></textarea>
                    <small class="text-muted">
                        Minimum <?php echo $forumSettings['min_post_length']; ?> characters
                    </small>
                </div>
                
                <?php if ($forumSettings['allow_images']): ?>
                    <div class="mb-3">
                        <label class="form-label">
                            <i class="bi bi-image"></i> Attach Images (optional)
                        </label>
                        <input type="file" name="images[]" class="form-control" accept="image/*" multiple>
                        <small class="text-muted">
                            Max <?php echo $forumSettings['max_images_per_post']; ?> images, 
                            <?php echo $forumSettings['max_file_size']; ?>MB each
                        </small>
                    </div>
                <?php endif; ?>
                
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-send"></i> Post Reply
                </button>
            </form>
        </div>
    <?php elseif (!$auth->isLoggedIn()): ?>
        <div class="alert alert-info mt-4">
            <i class="bi bi-info-circle"></i> 
            <a href="index.php?page=login">Login</a> or 
            <a href="index.php?page=register">register</a> to reply to this discussion
        </div>
    <?php elseif ($topic['locked'] ?? false): ?>
        <div class="alert alert-warning mt-4">
            <i class="bi bi-lock-fill"></i> This discussion is locked and no longer accepts replies
        </div>
    <?php endif; ?>
</div>

<?php elseif ($action === 'create'): ?>

<style>
.create-form {
    max-width: 800px;
    margin: 2rem auto;
}

.form-card {
    background: white;
    border: 1px solid #dee2e6;
    border-radius: 8px;
    padding: 2rem;
}

.form-help {
    font-size: 0.9rem;
    color: #6c757d;
    margin-top: 0.25rem;
}

.category-select {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
    gap: 1rem;
    margin-top: 0.5rem;
}

.category-option {
    border: 2px solid #dee2e6;
    border-radius: 8px;
    padding: 1rem;
    cursor: pointer;
    transition: all 0.2s;
    text-align: center;
}

.category-option:hover {
    border-color: #667eea;
    transform: translateY(-2px);
}

.category-option input[type="radio"] {
    display: none;
}

.category-option input[type="radio"]:checked + label {
    color: #667eea;
    font-weight: bold;
}

.category-option.selected {
    border-color: #667eea;
    background: #f8f9ff;
}
</style>

<div class="container create-form mb-5">
    <h2 class="mb-4">
        <i class="bi bi-plus-circle"></i> Start a New Discussion
    </h2>
    
    <div class="form-card">
        <form method="POST" action="index.php?page=forums&action=create" id="createForm" enctype="multipart/form-data">
            <div class="mb-4">
                <label class="form-label fw-bold">Choose a Category</label>
                <div class="category-select">
                    <?php foreach ($categories as $catKey => $catData): ?>
                        <div class="category-option" onclick="selectCategory('<?php echo $catKey; ?>')">
                            <input type="radio" name="category" value="<?php echo $catKey; ?>" id="cat-<?php echo $catKey; ?>" required>
                            <label for="cat-<?php echo $catKey; ?>" style="cursor: pointer;">
                                <div style="font-size: 2rem; margin-bottom: 0.5rem;">
                                    <i class="bi bi-<?php echo $catData['icon']; ?>" style="color: <?php echo $catData['color']; ?>"></i>
                                </div>
                                <div><?php echo $catData['name']; ?></div>
                            </label>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            
            <div class="mb-4">
                <label class="form-label fw-bold">Discussion Title</label>
                <input type="text" 
                       name="title" 
                       class="form-control form-control-lg" 
                       required 
                       maxlength="200"
                       placeholder="What's your discussion about?">
                <div class="form-help">
                    Be specific and clear - a good title helps others find and understand your discussion
                </div>
            </div>
            
            <div class="mb-4">
                <label class="form-label fw-bold">Tags (optional)</label>
                <input type="text" 
                       name="tags" 
                       class="form-control" 
                       placeholder="e.g. beginner, tutorial, question">
                <div class="form-help">
                    Separate tags with commas. Tags help categorize your discussion and make it easier to find.
                </div>
            </div>
            
            <div class="mb-4">
                <label class="form-label fw-bold">Content</label>
                <textarea name="content" 
                          class="form-control" 
                          rows="10" 
                          required
                          minlength="<?php echo $forumSettings['min_post_length']; ?>"
                          maxlength="<?php echo $forumSettings['max_post_length']; ?>"
                          placeholder="Provide details, context, and what you're looking for..."></textarea>
                <div class="form-help">
                    The more details you provide, the better responses you'll get 
                    (Minimum <?php echo $forumSettings['min_post_length']; ?> characters)
                </div>
            </div>
            
            <?php if ($forumSettings['allow_images']): ?>
                <div class="mb-4">
                    <label class="form-label fw-bold">
                        <i class="bi bi-image"></i> Attach Images (optional)
                    </label>
                    <input type="file" name="images[]" class="form-control" accept="image/*" multiple>
                    <div class="form-help">
                        You can upload up to <?php echo $forumSettings['max_images_per_post']; ?> images. 
                        Max <?php echo $forumSettings['max_file_size']; ?>MB per image.
                    </div>
                </div>
            <?php endif; ?>
            
            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-primary btn-lg">
                    <i class="bi bi-send"></i> Create Discussion
                </button>
                <a href="index.php?page=forums" class="btn btn-outline-secondary btn-lg">
                    Cancel
                </a>
            </div>
        </form>
    </div>
</div>

<script>
function selectCategory(catKey) {
    document.querySelectorAll('.category-option').forEach(opt => {
        opt.classList.remove('selected');
    });
    event.currentTarget.classList.add('selected');
    document.getElementById('cat-' + catKey).checked = true;
}
</script>

<?php endif; ?>

<!-- Report Modal -->
<div class="modal fade" id="reportModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-flag"></i> Report Content</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="reportForm">
                    <input type="hidden" id="reportItemType" name="item_type">
                    <input type="hidden" id="reportItemId" name="item_id">
                    
                    <div class="mb-3">
                        <label class="form-label">Reason for reporting</label>
                        <select name="reason" class="form-select" required>
                            <option value="">Select a reason...</option>
                            <option value="spam">Spam or advertising</option>
                            <option value="harassment">Harassment or abuse</option>
                            <option value="inappropriate">Inappropriate content</option>
                            <option value="misinformation">Misinformation</option>
                            <option value="other">Other</option>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Additional details (optional)</label>
                        <textarea name="details" class="form-control" rows="3"></textarea>
                    </div>
                    
                    <button type="submit" class="btn btn-danger">Submit Report</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
<?php if ($forumSettings['allow_voting']): ?>
function vote(type, id, voteType) {
    if (!<?php echo $auth->isLoggedIn() ? 'true' : 'false'; ?>) {
        window.location = 'index.php?page=login';
        return;
    }
    
    const formData = new FormData();
    formData.append(type + '_id', id);
    formData.append('vote_type', voteType);
    
    fetch('index.php?page=forums&action=vote_' + type, {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            const scoreElement = document.getElementById(type + '-score-' + id);
            scoreElement.textContent = data.score;
            scoreElement.className = 'vote-score ' + (data.score > 0 ? 'positive' : (data.score < 0 ? 'negative' : ''));
            
            // Update button states
            const container = scoreElement.closest('.topic-voting, .reply-voting');
            const upBtn = container.querySelector('.vote-btn:first-child');
            const downBtn = container.querySelector('.vote-btn:last-child');
            
            if (voteType === 'up') {
                upBtn.classList.add('upvoted');
                downBtn.classList.remove('downvoted');
            } else {
                downBtn.classList.add('downvoted');
                upBtn.classList.remove('upvoted');
            }
            
            // Reload to update the button states correctly
            setTimeout(() => location.reload(), 500);
        }
    });
}
<?php endif; ?>

function reportContent(type, id) {
    document.getElementById('reportItemType').value = type;
    document.getElementById('reportItemId').value = id;
    new bootstrap.Modal(document.getElementById('reportModal')).show();
}

document.getElementById('reportForm')?.addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    const reason = formData.get('reason');
    const details = formData.get('details');
    
    formData.set('reason', reason + (details ? ': ' + details : ''));
    formData.delete('details');
    
    fetch('index.php?page=forums&action=flag', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            bootstrap.Modal.getInstance(document.getElementById('reportModal')).hide();
            alert('Content reported. Moderators will review it shortly.');
        }
    });
});
</script>

<?php require 'templates/footer.php'; ?>
