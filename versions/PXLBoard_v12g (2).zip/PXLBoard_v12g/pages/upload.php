<?php
/**
 * Enhanced Upload Page - FIXED VERSION
 * With proper error handling and debugging
 */

require_once 'includes/tag_aliases.php';

if (!$auth->isLoggedIn()) {
    redirect('index.php?page=login');
}

$message = '';
$error = '';
$uploadedImages = [];
$debugInfo = [];

// Enable error reporting for debugging (comment out in production)
// error_reporting(E_ALL);
// ini_set('display_errors', 1);

// Handle upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['upload'])) {
    // Add debug info
    $debugInfo[] = "POST request received";
    $debugInfo[] = "FILES array: " . (!empty($_FILES) ? "present" : "empty");
    
    // Check if files were actually uploaded
    if (!isset($_FILES['images'])) {
        $error = 'No file input found. Please try again.';
        $debugInfo[] = "ERROR: \$_FILES['images'] not set";
    } elseif (empty($_FILES['images']['name'])) {
        $error = 'No files selected. Please choose at least one image to upload.';
        $debugInfo[] = "ERROR: No files in upload";
    } elseif (is_array($_FILES['images']['name']) && empty($_FILES['images']['name'][0])) {
        $error = 'No files selected. Please choose at least one image to upload.';
        $debugInfo[] = "ERROR: Empty file array";
    } else {
        $files = $_FILES['images'];
        $debugInfo[] = "Files detected: " . (is_array($files['name']) ? count($files['name']) : 1);
        
        // Common metadata for all uploads
        $channel = $_POST['channel'] ?? '';
        $tags = isset($_POST['tags']) ? array_filter(array_map('trim', explode(',', $_POST['tags']))) : [];
        
        // Resolve tag aliases
        if (!empty($tags)) {
            $tags = resolveTags($tags);
            $tags = array_values(array_unique($tags)); // Remove duplicates after resolving
        }
        
        $sourceUrl = trim($_POST['source_url'] ?? '');
        $isAnonymous = isset($_POST['anonymous']) && $_POST['anonymous'] === '1';
        
        // Determine if multiple files
        $isMultiple = is_array($files['name']);
        $fileCount = $isMultiple ? count($files['name']) : 1;
        
        // Process each file
        for ($i = 0; $i < $fileCount; $i++) {
            // Extract file info
            if ($isMultiple) {
                $file = [
                    'name' => $files['name'][$i],
                    'type' => $files['type'][$i],
                    'tmp_name' => $files['tmp_name'][$i],
                    'error' => $files['error'][$i],
                    'size' => $files['size'][$i]
                ];
                $title = isset($_POST['titles'][$i]) && !empty($_POST['titles'][$i]) 
                    ? $_POST['titles'][$i] 
                    : pathinfo($file['name'], PATHINFO_FILENAME);
                $description = $_POST['descriptions'][$i] ?? '';
            } else {
                $file = [
                    'name' => $files['name'],
                    'type' => $files['type'],
                    'tmp_name' => $files['tmp_name'],
                    'error' => $files['error'],
                    'size' => $files['size']
                ];
                $title = isset($_POST['title']) && !empty($_POST['title']) 
                    ? $_POST['title'] 
                    : pathinfo($file['name'], PATHINFO_FILENAME);
                $description = $_POST['description'] ?? '';
            }
            
            $debugInfo[] = "Processing file: {$file['name']}";
            
            // Skip empty files
            if ($file['error'] === UPLOAD_ERR_NO_FILE) {
                $debugInfo[] = "Skipping empty file";
                continue;
            }
            
            // Check for upload errors
            if ($file['error'] !== UPLOAD_ERR_OK) {
                $errorMessages = [
                    UPLOAD_ERR_INI_SIZE => 'File exceeds upload_max_filesize in php.ini',
                    UPLOAD_ERR_FORM_SIZE => 'File exceeds MAX_FILE_SIZE in HTML form',
                    UPLOAD_ERR_PARTIAL => 'File was only partially uploaded',
                    UPLOAD_ERR_NO_TMP_DIR => 'Missing temporary folder',
                    UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk',
                    UPLOAD_ERR_EXTENSION => 'PHP extension stopped the upload'
                ];
                $error = $errorMessages[$file['error']] ?? 'Unknown upload error: ' . $file['error'];
                $error .= ' (File: ' . $file['name'] . ')';
                $debugInfo[] = "ERROR: " . $error;
                continue;
            }
            
            // Validate file size
            if ($file['size'] > MAX_UPLOAD_SIZE) {
                $error = 'File too large: ' . $file['name'] . ' (max ' . formatBytes(MAX_UPLOAD_SIZE) . ')';
                $debugInfo[] = "ERROR: File too large - {$file['size']} bytes";
                continue;
            }
            
            // Validate file type
            $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            if (!in_array($extension, ALLOWED_EXTENSIONS)) {
                $error = 'Invalid file type: ' . $file['name'] . ' (allowed: ' . implode(', ', ALLOWED_EXTENSIONS) . ')';
                $debugInfo[] = "ERROR: Invalid extension - $extension";
                continue;
            }
            
            $debugInfo[] = "File validated successfully";
            
            // Generate unique filename
            $filename = uniqid('img_', true) . '.' . $extension;
            $uploadPath = UPLOADS_DIR . '/' . $filename;
            $thumbPath = UPLOADS_DIR . '/thumbs/' . $filename;
            
            $debugInfo[] = "Upload path: $uploadPath";
            
            // Create uploads directories if they don't exist
            if (!is_dir(UPLOADS_DIR)) {
                $created = mkdir(UPLOADS_DIR, 0755, true);
                $debugInfo[] = "Created uploads dir: " . ($created ? "success" : "failed");
            }
            if (!is_dir(UPLOADS_DIR . '/thumbs')) {
                $created = mkdir(UPLOADS_DIR . '/thumbs', 0755, true);
                $debugInfo[] = "Created thumbs dir: " . ($created ? "success" : "failed");
            }
            
            // Check if directories are writable
            if (!is_writable(UPLOADS_DIR)) {
                $error = 'Upload directory is not writable. Please check permissions.';
                $debugInfo[] = "ERROR: Upload directory not writable";
                break;
            }
            
            // Move uploaded file
            if (move_uploaded_file($file['tmp_name'], $uploadPath)) {
                $debugInfo[] = "File moved successfully";
                
                // Create thumbnail
                $thumbCreated = generateThumbnail($uploadPath, $thumbPath, THUMBNAIL_WIDTH, THUMBNAIL_HEIGHT);
                $debugInfo[] = "Thumbnail created: " . ($thumbCreated ? "success" : "failed");
                
                // Save to database
                $imageId = $db->getNextId('images');
                $debugInfo[] = "Generated image ID: $imageId";
                
                $imageData = [
                    'id' => 'img_' . $imageId,
                    'title' => $title,
                    'description' => $description,
                    'filename' => $filename,
                    'uploader' => $_SESSION['username'],
                    'uploader_id' => $_SESSION['user_id'],
                    'anonymous' => $isAnonymous,
                    'uploaded_at' => time(),
                    'views' => 0,
                    'likes' => 0,
                    'favorites' => 0,
                    'comments_count' => 0,
                    'tags' => $tags,
                    'channel' => $channel,
                    'filesize' => $file['size'],
                    'extension' => $extension,
                    'source_url' => !empty($sourceUrl) ? $sourceUrl : null,
                    'source_history' => []
                ];
                
                if ($db->save('images', 'img_' . $imageId, $imageData)) {
                    $uploadedImages[] = [
                        'id' => 'img_' . $imageId,
                        'title' => $title,
                        'filename' => $filename
                    ];
                    $debugInfo[] = "Saved to database successfully";
                } else {
                    $error = 'Failed to save image data to database';
                    $debugInfo[] = "ERROR: Database save failed";
                }
            } else {
                $error = 'Failed to move uploaded file: ' . $file['name'];
                $debugInfo[] = "ERROR: move_uploaded_file failed";
                $debugInfo[] = "Temp file: {$file['tmp_name']}";
                $debugInfo[] = "Destination: $uploadPath";
                $debugInfo[] = "Temp file exists: " . (file_exists($file['tmp_name']) ? "yes" : "no");
            }
        }
        
        if (!empty($uploadedImages)) {
            $message = count($uploadedImages) . ' image(s) uploaded successfully!';
        } elseif (empty($error)) {
            $error = 'No files were uploaded. Please try again.';
        }
    }
}

// Get available channels
$channels = $db->getAll('channels');

require 'templates/header.php';
?>

<style>
.upload-area {
    border: 3px dashed #dee2e6;
    border-radius: 10px;
    padding: 40px;
    text-align: center;
    background: #f8f9fa;
    transition: all 0.3s;
    cursor: pointer;
}

.upload-area:hover, .upload-area.dragover {
    border-color: #0d6efd;
    background: #e7f3ff;
}

.upload-area.dragover {
    border-style: solid;
}

.file-preview {
    position: relative;
    display: inline-block;
    margin: 10px;
}

.file-preview img {
    width: 150px;
    height: 150px;
    object-fit: cover;
    border-radius: 8px;
    border: 2px solid #dee2e6;
}

.file-preview .remove-file {
    position: absolute;
    top: -8px;
    right: -8px;
    background: #dc3545;
    color: white;
    border-radius: 50%;
    width: 24px;
    height: 24px;
    border: none;
    cursor: pointer;
    font-size: 14px;
    line-height: 24px;
}

.progress-container {
    display: none;
    margin-top: 20px;
}

.file-progress {
    margin-bottom: 15px;
    padding: 10px;
    border: 1px solid #dee2e6;
    border-radius: 5px;
    background: #fff;
}

.file-progress-name {
    font-weight: bold;
    margin-bottom: 5px;
}

.upload-success {
    animation: slideIn 0.3s ease-out;
}

@keyframes slideIn {
    from {
        opacity: 0;
        transform: translateY(-10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.debug-info {
    background: #f8f9fa;
    border: 1px solid #dee2e6;
    border-radius: 5px;
    padding: 10px;
    font-family: monospace;
    font-size: 12px;
    max-height: 300px;
    overflow-y: auto;
}
</style>

<div class="container mt-4">
    <h2><i class="bi bi-upload"></i> Upload Images</h2>
    <p class="text-muted">Share your images with the community</p>
    
    <?php if ($message): ?>
        <div class="alert alert-success alert-dismissible fade show upload-success">
            <i class="bi bi-check-circle"></i> <?php echo htmlspecialchars($message); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            
            <?php if (!empty($uploadedImages)): ?>
                <hr>
                <p class="mb-2"><strong>View your uploads:</strong></p>
                <?php foreach ($uploadedImages as $img): ?>
                    <a href="index.php?page=image&id=<?php echo htmlspecialchars($img['id']); ?>" 
                       class="btn btn-sm btn-outline-primary me-2 mb-2">
                        <?php echo htmlspecialchars($img['title']); ?>
                    </a>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <i class="bi bi-exclamation-triangle"></i> <?php echo htmlspecialchars($error); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <?php if (!empty($debugInfo) && isset($_GET['debug'])): ?>
        <div class="alert alert-info">
            <strong>Debug Information:</strong>
            <div class="debug-info mt-2">
                <?php foreach ($debugInfo as $info): ?>
                    <div><?php echo htmlspecialchars($info); ?></div>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endif; ?>
    
    <div class="row">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header">
                    <strong>Upload Form</strong>
                    <small class="text-muted float-end">
                        <a href="?page=upload&debug=1" class="text-decoration-none">
                            <i class="bi bi-bug"></i> Enable Debug Mode
                        </a>
                    </small>
                </div>
                <div class="card-body">
                    <form method="POST" enctype="multipart/form-data" id="uploadForm">
                        <div class="mb-3">
                            <label class="form-label"><i class="bi bi-image"></i> Select Image(s)</label>
                            <input type="file" name="images[]" id="fileInput" class="form-control" 
                                   multiple accept="image/*" required>
                            <small class="text-muted">
                                Supported: <?php echo implode(', ', array_map('strtoupper', ALLOWED_EXTENSIONS)); ?> 
                                | Max: <?php echo formatBytes(MAX_UPLOAD_SIZE); ?> per file
                            </small>
                        </div>
                        
                        <div id="filePreviews" class="mb-3"></div>
                        
                        <div class="mb-3">
                            <label class="form-label"><i class="bi bi-tag"></i> Tags (comma separated)</label>
                            <input type="text" name="tags" class="form-control" 
                                   placeholder="tag1, tag2, tag3">
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label"><i class="bi bi-link-45deg"></i> Source URL (optional)</label>
                            <input type="url" name="source_url" class="form-control" 
                                   placeholder="https://example.com/original-source">
                            <small class="text-muted">
                                If this image is from another source, provide the URL
                            </small>
                        </div>
                        
                        <div class="mb-3">
                            <div class="form-check">
                                <input type="checkbox" name="anonymous" value="1" 
                                       id="anonymousUpload" class="form-check-input">
                                <label class="form-check-label" for="anonymousUpload">
                                    <i class="bi bi-incognito"></i> Upload anonymously
                                </label>
                                <small class="text-muted d-block">
                                    Your username will not be shown publicly (admins can still see it)
                                </small>
                            </div>
                        </div>
                        
                        <?php if (!empty($channels)): ?>
                            <div class="mb-3">
                                <label class="form-label"><i class="bi bi-folder"></i> Channel</label>
                                <select name="channel" class="form-select">
                                    <option value="">No channel</option>
                                    <?php foreach ($channels as $ch): ?>
                                        <option value="<?php echo htmlspecialchars($ch['id']); ?>">
                                            <?php echo htmlspecialchars($ch['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        <?php endif; ?>
                        
                        <div id="fileMetadata"></div>
                        
                        <button type="submit" name="upload" class="btn btn-success btn-lg w-100">
                            <i class="bi bi-upload"></i> Upload Images
                        </button>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="col-lg-4">
            <div class="card">
                <div class="card-header">
                    <strong><i class="bi bi-info-circle"></i> Upload Guidelines</strong>
                </div>
                <div class="card-body">
                    <h6>Allowed Content</h6>
                    <ul class="small">
                        <li>Original artwork</li>
                        <li>Photography</li>
                        <li>Digital art</li>
                        <li>Screenshots (with context)</li>
                    </ul>
                    
                    <h6>Tips</h6>
                    <ul class="small">
                        <li>Use descriptive titles</li>
                        <li>Add relevant tags</li>
                        <li>Choose appropriate channel</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
const fileInput = document.getElementById('fileInput');
const filePreviews = document.getElementById('filePreviews');
const fileMetadata = document.getElementById('fileMetadata');

fileInput.addEventListener('change', function(e) {
    const files = Array.from(this.files);
    
    // Clear previous previews and metadata
    filePreviews.innerHTML = '';
    fileMetadata.innerHTML = '';
    
    if (files.length === 0) return;
    
    // Show file previews
    files.forEach((file, index) => {
        const preview = document.createElement('div');
        preview.className = 'file-preview';
        preview.innerHTML = `
            <img src="${URL.createObjectURL(file)}" alt="Preview">
            <div class="mt-1 small text-center">${escapeHtml(file.name)}</div>
        `;
        filePreviews.appendChild(preview);
        
        // Add metadata fields for each file
        const metaCard = document.createElement('div');
        metaCard.className = 'card mb-2';
        metaCard.innerHTML = `
            <div class="card-body py-2">
                <h6 class="mb-2">${escapeHtml(file.name)}</h6>
                <div class="mb-2">
                    <label class="form-label small mb-1">Title</label>
                    <input type="text" name="titles[]" class="form-control form-control-sm" 
                           value="${escapeHtml(file.name.replace(/\.[^/.]+$/, ''))}" required>
                </div>
                <div>
                    <label class="form-label small mb-1">Description (optional)</label>
                    <textarea name="descriptions[]" class="form-control form-control-sm" 
                              rows="2" placeholder="Describe this image..."></textarea>
                </div>
            </div>
        `;
        fileMetadata.appendChild(metaCard);
    });
});

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}
</script>

<?php require 'templates/footer.php'; ?>
