<?php
/**
 * Admin Forums Management - PXLBoard v12e
 * Comprehensive forum moderation and category management
 */

if (!$auth->isAdmin()) {
    redirect('index.php?page=home');
}

$tab = $_GET['tab'] ?? 'overview';
$message = '';
$error = '';

// Load forum categories from config
$categoriesFile = DATA_DIR . '/forum_categories.json';
if (!file_exists($categoriesFile)) {
    $defaultCategories = [
        'general' => ['name' => 'General Discussion', 'icon' => 'chat-dots', 'color' => '#6c757d', 'description' => 'General topics and discussions', 'enabled' => true, 'order' => 1],
        'art' => ['name' => 'Art & Creativity', 'icon' => 'palette', 'color' => '#e83e8c', 'description' => 'Share and discuss creative works', 'enabled' => true, 'order' => 2],
        'support' => ['name' => 'Help & Support', 'icon' => 'question-circle', 'color' => '#fd7e14', 'description' => 'Get help from the community', 'enabled' => true, 'order' => 3],
        'feedback' => ['name' => 'Feedback', 'icon' => 'lightbulb', 'color' => '#20c997', 'description' => 'Suggestions and feedback', 'enabled' => true, 'order' => 4],
        'showcase' => ['name' => 'Showcase', 'icon' => 'star', 'color' => '#ffc107', 'description' => 'Show off your work', 'enabled' => true, 'order' => 5],
        'meta' => ['name' => 'Site Discussion', 'icon' => 'gear', 'color' => '#17a2b8', 'description' => 'Discuss the site itself', 'enabled' => true, 'order' => 6]
    ];
    file_put_contents($categoriesFile, json_encode($defaultCategories, JSON_PRETTY_PRINT));
}

$forumCategories = json_decode(file_get_contents($categoriesFile), true);

// Handle category actions
if ($tab === 'categories' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    switch ($action) {
        case 'add_category':
            $catId = sanitizeFilename(strtolower(str_replace(' ', '_', $_POST['cat_id'] ?? '')));
            $catName = trim($_POST['cat_name'] ?? '');
            $catIcon = trim($_POST['cat_icon'] ?? 'chat-dots');
            $catColor = trim($_POST['cat_color'] ?? '#6c757d');
            $catDesc = trim($_POST['cat_description'] ?? '');
            
            if ($catId && $catName) {
                $forumCategories[$catId] = [
                    'name' => $catName,
                    'icon' => $catIcon,
                    'color' => $catColor,
                    'description' => $catDesc,
                    'enabled' => true,
                    'order' => count($forumCategories) + 1
                ];
                file_put_contents($categoriesFile, json_encode($forumCategories, JSON_PRETTY_PRINT));
                $message = 'Category added successfully!';
            }
            break;
            
        case 'edit_category':
            $catId = $_POST['cat_id'] ?? '';
            if (isset($forumCategories[$catId])) {
                $forumCategories[$catId]['name'] = trim($_POST['cat_name'] ?? '');
                $forumCategories[$catId]['icon'] = trim($_POST['cat_icon'] ?? '');
                $forumCategories[$catId]['color'] = trim($_POST['cat_color'] ?? '');
                $forumCategories[$catId]['description'] = trim($_POST['cat_description'] ?? '');
                $forumCategories[$catId]['enabled'] = isset($_POST['cat_enabled']);
                file_put_contents($categoriesFile, json_encode($forumCategories, JSON_PRETTY_PRINT));
                $message = 'Category updated successfully!';
            }
            break;
            
        case 'delete_category':
            $catId = $_POST['cat_id'] ?? '';
            if (isset($forumCategories[$catId])) {
                // Check if any topics use this category
                $topics = $db->getAll('forum_topics');
                $usageCount = count(array_filter($topics, fn($t) => $t['category'] === $catId));
                
                if ($usageCount > 0) {
                    $error = "Cannot delete category with $usageCount active topics. Move or delete topics first.";
                } else {
                    unset($forumCategories[$catId]);
                    file_put_contents($categoriesFile, json_encode($forumCategories, JSON_PRETTY_PRINT));
                    $message = 'Category deleted successfully!';
                }
            }
            break;
    }
}

// Handle moderation actions
if ($tab === 'moderation' && isset($_GET['action'])) {
    $action = $_GET['action'];
    
    switch ($action) {
        case 'delete_topic':
            $topicId = $_GET['id'] ?? '';
            $topic = $db->get('forum_topics', $topicId);
            if ($topic) {
                // Delete all replies
                $replies = $db->getAll('forum_replies');
                foreach ($replies as $replyId => $reply) {
                    if ($reply['topic_id'] === $topicId) {
                        // Delete reply attachments
                        if (!empty($reply['attachments'])) {
                            foreach ($reply['attachments'] as $attachment) {
                                @unlink(UPLOADS_DIR . '/forum/' . $attachment);
                            }
                        }
                        $db->delete('forum_replies', $replyId);
                    }
                }
                
                // Delete topic attachments
                if (!empty($topic['attachments'])) {
                    foreach ($topic['attachments'] as $attachment) {
                        @unlink(UPLOADS_DIR . '/forum/' . $attachment);
                    }
                }
                
                $db->delete('forum_topics', $topicId);
                $message = 'Topic and all replies deleted successfully!';
            }
            break;
            
        case 'lock_topic':
            $topicId = $_GET['id'] ?? '';
            $topic = $db->get('forum_topics', $topicId);
            if ($topic) {
                $topic['locked'] = !($topic['locked'] ?? false);
                $db->save('forum_topics', $topicId, $topic);
                $message = 'Topic ' . ($topic['locked'] ? 'locked' : 'unlocked') . ' successfully!';
            }
            break;
            
        case 'pin_topic':
            $topicId = $_GET['id'] ?? '';
            $topic = $db->get('forum_topics', $topicId);
            if ($topic) {
                $topic['pinned'] = !($topic['pinned'] ?? false);
                $db->save('forum_topics', $topicId, $topic);
                $message = 'Topic ' . ($topic['pinned'] ? 'pinned' : 'unpinned') . ' successfully!';
            }
            break;
            
        case 'delete_reply':
            $replyId = $_GET['id'] ?? '';
            $reply = $db->get('forum_replies', $replyId);
            if ($reply) {
                // Delete attachments
                if (!empty($reply['attachments'])) {
                    foreach ($reply['attachments'] as $attachment) {
                        @unlink(UPLOADS_DIR . '/forum/' . $attachment);
                    }
                }
                
                // Update topic reply count
                $topic = $db->get('forum_topics', $reply['topic_id']);
                if ($topic) {
                    $topic['replies'] = max(0, ($topic['replies'] ?? 0) - 1);
                    $db->save('forum_topics', $reply['topic_id'], $topic);
                }
                
                $db->delete('forum_replies', $replyId);
                $message = 'Reply deleted successfully!';
            }
            break;
            
        case 'move_topic':
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $topicId = $_POST['topic_id'] ?? '';
                $newCategory = $_POST['new_category'] ?? '';
                $topic = $db->get('forum_topics', $topicId);
                
                if ($topic && isset($forumCategories[$newCategory])) {
                    $topic['category'] = $newCategory;
                    $db->save('forum_topics', $topicId, $topic);
                    $message = 'Topic moved successfully!';
                }
            }
            break;
    }
}

// Handle settings
if ($tab === 'settings' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $settingsFile = DATA_DIR . '/forum_settings.json';
    
    $forumSettings = [
        'allow_images' => isset($_POST['allow_images']),
        'max_images_per_post' => (int)($_POST['max_images_per_post'] ?? 5),
        'allow_file_attachments' => isset($_POST['allow_file_attachments']),
        'max_file_size' => (int)($_POST['max_file_size'] ?? 5),
        'allowed_extensions' => array_filter(array_map('trim', explode(',', $_POST['allowed_extensions'] ?? 'jpg,jpeg,png,gif,pdf,zip'))),
        'require_approval' => isset($_POST['require_approval']),
        'allow_anonymous' => isset($_POST['allow_anonymous']),
        'allow_voting' => isset($_POST['allow_voting']),
        'allow_best_answer' => isset($_POST['allow_best_answer']),
        'min_post_length' => (int)($_POST['min_post_length'] ?? 10),
        'max_post_length' => (int)($_POST['max_post_length'] ?? 10000),
        'posts_per_page' => (int)($_POST['posts_per_page'] ?? 20),
        'allow_editing' => isset($_POST['allow_editing']),
        'edit_time_limit' => (int)($_POST['edit_time_limit'] ?? 3600),
        'auto_lock_days' => (int)($_POST['auto_lock_days'] ?? 0)
    ];
    
    file_put_contents($settingsFile, json_encode($forumSettings, JSON_PRETTY_PRINT));
    $message = 'Forum settings saved successfully!';
}

// Load current settings
$settingsFile = DATA_DIR . '/forum_settings.json';
if (!file_exists($settingsFile)) {
    $defaultSettings = [
        'allow_images' => true,
        'max_images_per_post' => 5,
        'allow_file_attachments' => true,
        'max_file_size' => 5,
        'allowed_extensions' => ['jpg', 'jpeg', 'png', 'gif', 'pdf', 'zip'],
        'require_approval' => false,
        'allow_anonymous' => false,
        'allow_voting' => true,
        'allow_best_answer' => true,
        'min_post_length' => 10,
        'max_post_length' => 10000,
        'posts_per_page' => 20,
        'allow_editing' => true,
        'edit_time_limit' => 3600,
        'auto_lock_days' => 0
    ];
    file_put_contents($settingsFile, json_encode($defaultSettings, JSON_PRETTY_PRINT));
}

$forumSettings = json_decode(file_get_contents($settingsFile), true);

// Get statistics
$allTopics = $db->getAll('forum_topics');
$allReplies = $db->getAll('forum_replies');
$totalTopics = count($allTopics);
$totalReplies = count($allReplies);
$totalViews = array_sum(array_column($allTopics, 'views'));

// Recent activity
$recentTopics = $allTopics;
usort($recentTopics, fn($a, $b) => ($b['created_at'] ?? 0) - ($a['created_at'] ?? 0));
$recentTopics = array_slice($recentTopics, 0, 10);

// Flagged content
$flaggedTopics = array_filter($allTopics, fn($t) => !empty($t['flags']));
$flaggedReplies = array_filter($allReplies, fn($r) => !empty($r['flags']));

require 'templates/header.php';
?>

<style>
.admin-header {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 2rem 0;
    margin-bottom: 2rem;
}

.stat-card {
    background: white;
    border-radius: 8px;
    padding: 1.5rem;
    text-align: center;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.stat-value {
    font-size: 2.5rem;
    font-weight: bold;
    color: #667eea;
}

.stat-label {
    color: #6c757d;
    margin-top: 0.5rem;
}

.category-card {
    background: white;
    border: 1px solid #dee2e6;
    border-radius: 8px;
    padding: 1rem;
    margin-bottom: 1rem;
}

.category-icon {
    width: 50px;
    height: 50px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.5rem;
    color: white;
}

.topic-row {
    background: white;
    border: 1px solid #dee2e6;
    border-radius: 8px;
    padding: 1rem;
    margin-bottom: 0.5rem;
}

.topic-row:hover {
    background: #f8f9fa;
}

.badge-status {
    padding: 0.25rem 0.75rem;
    border-radius: 50px;
    font-size: 0.85rem;
}

.badge-pinned { background: #ffc107; color: #000; }
.badge-locked { background: #6c757d; color: white; }
.badge-solved { background: #28a745; color: white; }
.badge-flagged { background: #dc3545; color: white; }
</style>

<div class="admin-header">
    <div class="container">
        <h1 class="display-4">
            <i class="bi bi-shield-check"></i> Forum Administration
        </h1>
        <p class="lead mb-0">Manage categories, moderate content, and configure forum settings</p>
    </div>
</div>

<div class="container mb-5">
    <?php if ($message): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="bi bi-check-circle"></i> <?php echo escape($message); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <i class="bi bi-exclamation-triangle"></i> <?php echo escape($error); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <!-- Navigation Tabs -->
    <ul class="nav nav-tabs mb-4">
        <li class="nav-item">
            <a class="nav-link <?php echo $tab === 'overview' ? 'active' : ''; ?>" 
               href="?page=admin_forums&tab=overview">
                <i class="bi bi-graph-up"></i> Overview
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo $tab === 'categories' ? 'active' : ''; ?>" 
               href="?page=admin_forums&tab=categories">
                <i class="bi bi-grid"></i> Categories
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo $tab === 'moderation' ? 'active' : ''; ?>" 
               href="?page=admin_forums&tab=moderation">
                <i class="bi bi-shield"></i> Moderation
                <?php if (count($flaggedTopics) + count($flaggedReplies) > 0): ?>
                    <span class="badge bg-danger"><?php echo count($flaggedTopics) + count($flaggedReplies); ?></span>
                <?php endif; ?>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo $tab === 'settings' ? 'active' : ''; ?>" 
               href="?page=admin_forums&tab=settings">
                <i class="bi bi-gear"></i> Settings
            </a>
        </li>
    </ul>
    
    <?php if ($tab === 'overview'): ?>
        <!-- Overview Tab -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-value"><?php echo number_format($totalTopics); ?></div>
                    <div class="stat-label">Total Topics</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-value"><?php echo number_format($totalReplies); ?></div>
                    <div class="stat-label">Total Replies</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-value"><?php echo number_format($totalViews); ?></div>
                    <div class="stat-label">Total Views</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-value"><?php echo count($forumCategories); ?></div>
                    <div class="stat-label">Categories</div>
                </div>
            </div>
        </div>
        
        <h3 class="mb-3">Recent Topics</h3>
        <?php foreach ($recentTopics as $topic): ?>
            <div class="topic-row">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="mb-1">
                            <?php if ($topic['pinned'] ?? false): ?>
                                <span class="badge badge-pinned"><i class="bi bi-pin-fill"></i></span>
                            <?php endif; ?>
                            <?php if ($topic['locked'] ?? false): ?>
                                <span class="badge badge-locked"><i class="bi bi-lock-fill"></i></span>
                            <?php endif; ?>
                            <?php echo escape($topic['title']); ?>
                        </h5>
                        <small class="text-muted">
                            by <?php echo escape($topic['author']); ?> • 
                            <?php echo timeAgo($topic['created_at']); ?> • 
                            <?php echo $forumCategories[$topic['category']]['name'] ?? 'Unknown'; ?>
                        </small>
                    </div>
                    <div class="text-end">
                        <small class="text-muted">
                            <?php echo $topic['views'] ?? 0; ?> views • 
                            <?php echo $topic['replies'] ?? 0; ?> replies
                        </small>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
        
    <?php elseif ($tab === 'categories'): ?>
        <!-- Categories Tab -->
        <div class="row">
            <div class="col-md-8">
                <h3 class="mb-3">Forum Categories</h3>
                <?php foreach ($forumCategories as $catId => $category): ?>
                    <div class="category-card">
                        <div class="d-flex align-items-center">
                            <div class="category-icon me-3" style="background: <?php echo $category['color']; ?>">
                                <i class="bi bi-<?php echo $category['icon']; ?>"></i>
                            </div>
                            <div class="flex-grow-1">
                                <h5 class="mb-0"><?php echo escape($category['name']); ?></h5>
                                <small class="text-muted"><?php echo escape($category['description']); ?></small>
                                <?php if (!$category['enabled']): ?>
                                    <span class="badge bg-secondary ms-2">Disabled</span>
                                <?php endif; ?>
                            </div>
                            <div>
                                <button class="btn btn-sm btn-outline-primary me-2" 
                                        data-bs-toggle="modal" 
                                        data-bs-target="#editCategoryModal<?php echo $catId; ?>">
                                    <i class="bi bi-pencil"></i> Edit
                                </button>
                                <button class="btn btn-sm btn-outline-danger" 
                                        data-bs-toggle="modal" 
                                        data-bs-target="#deleteCategoryModal<?php echo $catId; ?>">
                                    <i class="bi bi-trash"></i> Delete
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Edit Modal -->
                    <div class="modal fade" id="editCategoryModal<?php echo $catId; ?>">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <form method="POST">
                                    <div class="modal-header">
                                        <h5 class="modal-title">Edit Category</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                    </div>
                                    <div class="modal-body">
                                        <input type="hidden" name="action" value="edit_category">
                                        <input type="hidden" name="cat_id" value="<?php echo $catId; ?>">
                                        
                                        <div class="mb-3">
                                            <label class="form-label">Category Name</label>
                                            <input type="text" name="cat_name" class="form-control" 
                                                   value="<?php echo escape($category['name']); ?>" required>
                                        </div>
                                        
                                        <div class="mb-3">
                                            <label class="form-label">Icon (Bootstrap Icons name)</label>
                                            <input type="text" name="cat_icon" class="form-control" 
                                                   value="<?php echo escape($category['icon']); ?>">
                                            <small class="text-muted">e.g., chat-dots, palette, question-circle</small>
                                        </div>
                                        
                                        <div class="mb-3">
                                            <label class="form-label">Color</label>
                                            <input type="color" name="cat_color" class="form-control" 
                                                   value="<?php echo escape($category['color']); ?>">
                                        </div>
                                        
                                        <div class="mb-3">
                                            <label class="form-label">Description</label>
                                            <textarea name="cat_description" class="form-control" rows="2"><?php echo escape($category['description']); ?></textarea>
                                        </div>
                                        
                                        <div class="form-check">
                                            <input type="checkbox" name="cat_enabled" class="form-check-input" 
                                                   id="enabled<?php echo $catId; ?>" 
                                                   <?php echo $category['enabled'] ? 'checked' : ''; ?>>
                                            <label class="form-check-label" for="enabled<?php echo $catId; ?>">
                                                Category Enabled
                                            </label>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                        <button type="submit" class="btn btn-primary">Save Changes</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Delete Modal -->
                    <div class="modal fade" id="deleteCategoryModal<?php echo $catId; ?>">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <form method="POST">
                                    <div class="modal-header">
                                        <h5 class="modal-title">Delete Category</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                    </div>
                                    <div class="modal-body">
                                        <input type="hidden" name="action" value="delete_category">
                                        <input type="hidden" name="cat_id" value="<?php echo $catId; ?>">
                                        <p>Are you sure you want to delete the category "<strong><?php echo escape($category['name']); ?></strong>"?</p>
                                        <p class="text-danger">This action cannot be undone.</p>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                        <button type="submit" class="btn btn-danger">Delete Category</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="bi bi-plus-circle"></i> Add New Category</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <input type="hidden" name="action" value="add_category">
                            
                            <div class="mb-3">
                                <label class="form-label">Category ID</label>
                                <input type="text" name="cat_id" class="form-control" 
                                       placeholder="e.g., gaming" required>
                                <small class="text-muted">Lowercase, no spaces</small>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Category Name</label>
                                <input type="text" name="cat_name" class="form-control" 
                                       placeholder="e.g., Gaming" required>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Icon</label>
                                <input type="text" name="cat_icon" class="form-control" 
                                       placeholder="e.g., controller" value="chat-dots">
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Color</label>
                                <input type="color" name="cat_color" class="form-control" value="#6c757d">
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Description</label>
                                <textarea name="cat_description" class="form-control" rows="2"></textarea>
                            </div>
                            
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="bi bi-plus"></i> Add Category
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        
    <?php elseif ($tab === 'moderation'): ?>
        <!-- Moderation Tab -->
        <div class="row">
            <div class="col-12">
                <h3 class="mb-3">Content Moderation</h3>
                
                <!-- Filter -->
                <div class="mb-3">
                    <div class="btn-group">
                        <a href="?page=admin_forums&tab=moderation" class="btn btn-outline-primary">
                            All Topics
                        </a>
                        <a href="?page=admin_forums&tab=moderation&filter=flagged" class="btn btn-outline-danger">
                            Flagged (<?php echo count($flaggedTopics) + count($flaggedReplies); ?>)
                        </a>
                        <a href="?page=admin_forums&tab=moderation&filter=pinned" class="btn btn-outline-warning">
                            Pinned
                        </a>
                        <a href="?page=admin_forums&tab=moderation&filter=locked" class="btn btn-outline-secondary">
                            Locked
                        </a>
                    </div>
                </div>
                
                <?php 
                $filter = $_GET['filter'] ?? '';
                $displayTopics = $allTopics;
                
                if ($filter === 'flagged') {
                    $displayTopics = $flaggedTopics;
                } elseif ($filter === 'pinned') {
                    $displayTopics = array_filter($allTopics, fn($t) => $t['pinned'] ?? false);
                } elseif ($filter === 'locked') {
                    $displayTopics = array_filter($allTopics, fn($t) => $t['locked'] ?? false);
                }
                
                usort($displayTopics, fn($a, $b) => ($b['created_at'] ?? 0) - ($a['created_at'] ?? 0));
                ?>
                
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Topic</th>
                                <th>Author</th>
                                <th>Category</th>
                                <th>Stats</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($displayTopics as $topicId => $topic): ?>
                                <tr>
                                    <td>
                                        <a href="index.php?page=forums&action=view&topic=<?php echo $topicId; ?>" target="_blank">
                                            <?php echo escape($topic['title']); ?>
                                        </a>
                                    </td>
                                    <td><?php echo escape($topic['author']); ?></td>
                                    <td>
                                        <span class="badge" style="background: <?php echo $forumCategories[$topic['category']]['color'] ?? '#6c757d'; ?>">
                                            <?php echo $forumCategories[$topic['category']]['name'] ?? 'Unknown'; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <small>
                                            <?php echo $topic['views'] ?? 0; ?> views<br>
                                            <?php echo $topic['replies'] ?? 0; ?> replies
                                        </small>
                                    </td>
                                    <td>
                                        <?php if ($topic['pinned'] ?? false): ?>
                                            <span class="badge badge-pinned"><i class="bi bi-pin-fill"></i> Pinned</span>
                                        <?php endif; ?>
                                        <?php if ($topic['locked'] ?? false): ?>
                                            <span class="badge badge-locked"><i class="bi bi-lock-fill"></i> Locked</span>
                                        <?php endif; ?>
                                        <?php if (!empty($topic['flags'])): ?>
                                            <span class="badge badge-flagged"><i class="bi bi-flag-fill"></i> Flagged</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="btn-group btn-group-sm">
                                            <a href="?page=admin_forums&tab=moderation&action=pin_topic&id=<?php echo $topicId; ?>" 
                                               class="btn btn-outline-warning" title="<?php echo ($topic['pinned'] ?? false) ? 'Unpin' : 'Pin'; ?>">
                                                <i class="bi bi-pin"></i>
                                            </a>
                                            <a href="?page=admin_forums&tab=moderation&action=lock_topic&id=<?php echo $topicId; ?>" 
                                               class="btn btn-outline-secondary" title="<?php echo ($topic['locked'] ?? false) ? 'Unlock' : 'Lock'; ?>">
                                                <i class="bi bi-lock"></i>
                                            </a>
                                            <button class="btn btn-outline-primary" 
                                                    data-bs-toggle="modal" 
                                                    data-bs-target="#moveTopicModal<?php echo $topicId; ?>" 
                                                    title="Move">
                                                <i class="bi bi-arrow-right"></i>
                                            </button>
                                            <a href="?page=admin_forums&tab=moderation&action=delete_topic&id=<?php echo $topicId; ?>" 
                                               class="btn btn-outline-danger" 
                                               onclick="return confirm('Delete this topic and all replies?')" 
                                               title="Delete">
                                                <i class="bi bi-trash"></i>
                                            </a>
                                        </div>
                                        
                                        <!-- Move Topic Modal -->
                                        <div class="modal fade" id="moveTopicModal<?php echo $topicId; ?>">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <form method="POST" action="?page=admin_forums&tab=moderation&action=move_topic">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title">Move Topic</h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <input type="hidden" name="topic_id" value="<?php echo $topicId; ?>">
                                                            <label class="form-label">Select New Category</label>
                                                            <select name="new_category" class="form-select" required>
                                                                <?php foreach ($forumCategories as $catId => $category): ?>
                                                                    <option value="<?php echo $catId; ?>" 
                                                                            <?php echo $topic['category'] === $catId ? 'selected' : ''; ?>>
                                                                        <?php echo escape($category['name']); ?>
                                                                    </option>
                                                                <?php endforeach; ?>
                                                            </select>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                            <button type="submit" class="btn btn-primary">Move Topic</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
    <?php elseif ($tab === 'settings'): ?>
        <!-- Settings Tab -->
        <form method="POST">
            <div class="row">
                <div class="col-md-6">
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5 class="mb-0"><i class="bi bi-image"></i> Media & Attachments</h5>
                        </div>
                        <div class="card-body">
                            <div class="form-check mb-3">
                                <input type="checkbox" name="allow_images" class="form-check-input" id="allowImages"
                                       <?php echo $forumSettings['allow_images'] ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="allowImages">
                                    Allow image uploads in posts
                                </label>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Max images per post</label>
                                <input type="number" name="max_images_per_post" class="form-control" 
                                       value="<?php echo $forumSettings['max_images_per_post']; ?>" min="1" max="20">
                            </div>
                            
                            <div class="form-check mb-3">
                                <input type="checkbox" name="allow_file_attachments" class="form-check-input" id="allowFiles"
                                       <?php echo $forumSettings['allow_file_attachments'] ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="allowFiles">
                                    Allow file attachments
                                </label>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Max file size (MB)</label>
                                <input type="number" name="max_file_size" class="form-control" 
                                       value="<?php echo $forumSettings['max_file_size']; ?>" min="1" max="50">
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Allowed file extensions (comma-separated)</label>
                                <input type="text" name="allowed_extensions" class="form-control" 
                                       value="<?php echo implode(', ', $forumSettings['allowed_extensions']); ?>">
                            </div>
                        </div>
                    </div>
                    
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5 class="mb-0"><i class="bi bi-pencil"></i> Posting Settings</h5>
                        </div>
                        <div class="card-body">
                            <div class="mb-3">
                                <label class="form-label">Minimum post length (characters)</label>
                                <input type="number" name="min_post_length" class="form-control" 
                                       value="<?php echo $forumSettings['min_post_length']; ?>" min="1">
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Maximum post length (characters)</label>
                                <input type="number" name="max_post_length" class="form-control" 
                                       value="<?php echo $forumSettings['max_post_length']; ?>" min="100">
                            </div>
                            
                            <div class="form-check mb-3">
                                <input type="checkbox" name="allow_editing" class="form-check-input" id="allowEditing"
                                       <?php echo $forumSettings['allow_editing'] ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="allowEditing">
                                    Allow users to edit their posts
                                </label>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Edit time limit (seconds, 0 = unlimited)</label>
                                <input type="number" name="edit_time_limit" class="form-control" 
                                       value="<?php echo $forumSettings['edit_time_limit']; ?>" min="0">
                                <small class="text-muted">3600 = 1 hour</small>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5 class="mb-0"><i class="bi bi-gear"></i> Forum Features</h5>
                        </div>
                        <div class="card-body">
                            <div class="form-check mb-3">
                                <input type="checkbox" name="allow_voting" class="form-check-input" id="allowVoting"
                                       <?php echo $forumSettings['allow_voting'] ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="allowVoting">
                                    Enable voting system
                                </label>
                            </div>
                            
                            <div class="form-check mb-3">
                                <input type="checkbox" name="allow_best_answer" class="form-check-input" id="allowBestAnswer"
                                       <?php echo $forumSettings['allow_best_answer'] ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="allowBestAnswer">
                                    Allow marking best answers
                                </label>
                            </div>
                            
                            <div class="form-check mb-3">
                                <input type="checkbox" name="allow_anonymous" class="form-check-input" id="allowAnonymous"
                                       <?php echo $forumSettings['allow_anonymous'] ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="allowAnonymous">
                                    Allow anonymous posting
                                </label>
                            </div>
                            
                            <div class="form-check mb-3">
                                <input type="checkbox" name="require_approval" class="form-check-input" id="requireApproval"
                                       <?php echo $forumSettings['require_approval'] ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="requireApproval">
                                    Require admin approval for new topics
                                </label>
                            </div>
                        </div>
                    </div>
                    
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5 class="mb-0"><i class="bi bi-list"></i> Display Settings</h5>
                        </div>
                        <div class="card-body">
                            <div class="mb-3">
                                <label class="form-label">Posts per page</label>
                                <input type="number" name="posts_per_page" class="form-control" 
                                       value="<?php echo $forumSettings['posts_per_page']; ?>" min="10" max="100">
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Auto-lock topics after (days, 0 = never)</label>
                                <input type="number" name="auto_lock_days" class="form-control" 
                                       value="<?php echo $forumSettings['auto_lock_days']; ?>" min="0">
                                <small class="text-muted">Topics with no activity will be automatically locked</small>
                            </div>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn btn-primary btn-lg w-100">
                        <i class="bi bi-save"></i> Save Settings
                    </button>
                </div>
            </div>
        </form>
    <?php endif; ?>
</div>

<?php require 'templates/footer.php'; ?>
