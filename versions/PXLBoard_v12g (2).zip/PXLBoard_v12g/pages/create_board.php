<?php
/**
 * Create Board Page
 */

// Require login
if (!$auth->isLoggedIn()) {
    $_SESSION['error'] = "You must be logged in to create a board";
    header('Location: index.php?page=login');
    exit;
}

$user = $auth->getCurrentUser();
$errors = [];

// Handle board creation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_board'])) {
    $shortcode = trim($_POST['shortcode'] ?? '');
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $category = $_POST['category'] ?? 'Other';
    $nsfw = isset($_POST['nsfw']);
    
    // Validation
    if (empty($shortcode)) {
        $errors[] = "Shortcode is required";
    } elseif (!preg_match('/^[a-z0-9]{1,10}$/i', $shortcode)) {
        $errors[] = "Shortcode must be 1-10 alphanumeric characters";
    } else {
        // Check if shortcode already exists
        $existingBoards = $db->getAll('boards');
        foreach ($existingBoards as $board) {
            if (strtolower($board['shortcode']) === strtolower($shortcode)) {
                $errors[] = "This shortcode is already taken";
                break;
            }
        }
    }
    
    if (empty($name)) {
        $errors[] = "Board name is required";
    } elseif (strlen($name) > 100) {
        $errors[] = "Board name must be 100 characters or less";
    }
    
    if (strlen($description) > 500) {
        $errors[] = "Description must be 500 characters or less";
    }
    
    // Create board if no errors
    if (empty($errors)) {
        $boardId = 'board_' . time() . '_' . rand(1000, 9999);
        $boardData = [
            'shortcode' => $shortcode,
            'name' => $name,
            'description' => $description,
            'category' => $category,
            'nsfw' => $nsfw,
            'user_created' => true,
            'creator_id' => $user['id'],
            'creator_name' => $user['username'],
            'created_at' => time(),
            'thread_count' => 0,
            'post_count' => 0,
            'featured' => false
        ];
        
        // Admins can mark as featured
        if ($auth->isAdmin() && isset($_POST['featured'])) {
            $boardData['featured'] = true;
        }
        
        if ($db->save('boards', $boardId, $boardData)) {
            $_SESSION['success'] = "Board created successfully!";
            header('Location: index.php?page=board&id=' . $boardId);
            exit;
        } else {
            $errors[] = "Failed to create board. Please try again.";
        }
    }
}

include 'templates/header.php';
?>

<style>
.create-board-container {
    max-width: 800px;
    margin: 40px auto;
    padding: 30px;
    background: white;
    border-radius: 10px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

.create-board-header {
    text-align: center;
    margin-bottom: 30px;
    padding-bottom: 20px;
    border-bottom: 3px solid #667eea;
}

.create-board-header h1 {
    color: #333;
    margin-bottom: 10px;
}

.form-group {
    margin-bottom: 20px;
}

.form-group label {
    font-weight: bold;
    color: #555;
    margin-bottom: 8px;
    display: block;
}

.form-control {
    width: 100%;
    padding: 12px;
    border: 2px solid #e0e0e0;
    border-radius: 5px;
    font-size: 1em;
    transition: border-color 0.3s;
}

.form-control:focus {
    outline: none;
    border-color: #667eea;
}

.form-hint {
    font-size: 0.85em;
    color: #888;
    margin-top: 5px;
}

.category-select {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    gap: 10px;
    margin-top: 10px;
}

.category-option {
    position: relative;
}

.category-option input[type="radio"] {
    position: absolute;
    opacity: 0;
}

.category-option label {
    display: block;
    padding: 15px;
    text-align: center;
    border: 2px solid #e0e0e0;
    border-radius: 5px;
    cursor: pointer;
    transition: all 0.3s;
    font-weight: normal;
}

.category-option input[type="radio"]:checked + label {
    border-color: #667eea;
    background: #f0f4ff;
    font-weight: bold;
}

.checkbox-group {
    margin-top: 15px;
}

.checkbox-label {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 12px;
    border: 2px solid #e0e0e0;
    border-radius: 5px;
    cursor: pointer;
    transition: all 0.3s;
}

.checkbox-label:hover {
    background: #f9f9f9;
}

.checkbox-label input[type="checkbox"] {
    width: 20px;
    height: 20px;
    cursor: pointer;
}

.submit-btn {
    width: 100%;
    padding: 15px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    border: none;
    border-radius: 5px;
    font-size: 1.1em;
    font-weight: bold;
    cursor: pointer;
    transition: transform 0.2s;
}

.submit-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
}

.example-box {
    background: #f9f9f9;
    border-left: 4px solid #667eea;
    padding: 15px;
    margin-top: 10px;
    border-radius: 3px;
}
</style>

<div class="container create-board-container">
    <div class="create-board-header">
        <h1>📋 Create a New Board</h1>
        <p>Start your own community on PXLBoard</p>
    </div>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
            <strong>Please fix the following errors:</strong>
            <ul>
                <?php foreach ($errors as $error): ?>
                    <li><?php echo htmlspecialchars($error); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="post" action="">
        <div class="form-group">
            <label for="shortcode">Board Shortcode *</label>
            <input type="text" id="shortcode" name="shortcode" class="form-control" 
                   placeholder="e.g., tech, art, gaming" 
                   value="<?php echo htmlspecialchars($_POST['shortcode'] ?? ''); ?>"
                   maxlength="10" required>
            <div class="form-hint">
                1-10 characters, letters and numbers only. This will be shown as /shortcode/
            </div>
            <div class="example-box">
                <strong>Example:</strong> "tech" becomes <code>/tech/</code>
            </div>
        </div>

        <div class="form-group">
            <label for="name">Board Name *</label>
            <input type="text" id="name" name="name" class="form-control" 
                   placeholder="e.g., Technology & Gadgets" 
                   value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>"
                   maxlength="100" required>
            <div class="form-hint">
                The full, descriptive name of your board (max 100 characters)
            </div>
        </div>

        <div class="form-group">
            <label for="description">Board Description</label>
            <textarea id="description" name="description" class="form-control" 
                      rows="4" placeholder="Describe what this board is about..."
                      maxlength="500"><?php echo htmlspecialchars($_POST['description'] ?? ''); ?></textarea>
            <div class="form-hint">
                Optional. Help users understand what kind of content belongs here (max 500 characters)
            </div>
        </div>

        <div class="form-group">
            <label>Category *</label>
            <div class="category-select">
                <div class="category-option">
                    <input type="radio" id="cat-general" name="category" value="General" 
                           <?php echo ($_POST['category'] ?? 'General') === 'General' ? 'checked' : ''; ?>>
                    <label for="cat-general">📰 General</label>
                </div>
                <div class="category-option">
                    <input type="radio" id="cat-creative" name="category" value="Creative"
                           <?php echo ($_POST['category'] ?? '') === 'Creative' ? 'checked' : ''; ?>>
                    <label for="cat-creative">🎨 Creative</label>
                </div>
                <div class="category-option">
                    <input type="radio" id="cat-tech" name="category" value="Technology"
                           <?php echo ($_POST['category'] ?? '') === 'Technology' ? 'checked' : ''; ?>>
                    <label for="cat-tech">💻 Technology</label>
                </div>
                <div class="category-option">
                    <input type="radio" id="cat-entertainment" name="category" value="Entertainment"
                           <?php echo ($_POST['category'] ?? '') === 'Entertainment' ? 'checked' : ''; ?>>
                    <label for="cat-entertainment">🎮 Entertainment</label>
                </div>
                <div class="category-option">
                    <input type="radio" id="cat-community" name="category" value="Community"
                           <?php echo ($_POST['category'] ?? '') === 'Community' ? 'checked' : ''; ?>>
                    <label for="cat-community">👥 Community</label>
                </div>
                <div class="category-option">
                    <input type="radio" id="cat-other" name="category" value="Other"
                           <?php echo ($_POST['category'] ?? '') === 'Other' ? 'checked' : ''; ?>>
                    <label for="cat-other">📦 Other</label>
                </div>
            </div>
        </div>

        <div class="form-group">
            <label>Board Settings</label>
            <div class="checkbox-group">
                <label class="checkbox-label">
                    <input type="checkbox" name="nsfw" <?php echo isset($_POST['nsfw']) ? 'checked' : ''; ?>>
                    <span>
                        <strong>NSFW (Not Safe For Work)</strong><br>
                        <small>Mark this board as containing adult or sensitive content</small>
                    </span>
                </label>
            </div>
            
            <?php if ($auth->isAdmin()): ?>
                <div class="checkbox-group">
                    <label class="checkbox-label">
                        <input type="checkbox" name="featured" <?php echo isset($_POST['featured']) ? 'checked' : ''; ?>>
                        <span>
                            <strong>⭐ Featured Board (Admin Only)</strong><br>
                            <small>Show this board prominently on the boards page</small>
                        </span>
                    </label>
                </div>
            <?php endif; ?>
        </div>

        <button type="submit" name="create_board" class="submit-btn">
            Create Board
        </button>
    </form>

    <div style="margin-top: 20px; text-align: center;">
        <a href="index.php?page=boards" class="btn btn-secondary">← Back to Boards</a>
    </div>
</div>

<?php include 'templates/footer.php'; ?>
