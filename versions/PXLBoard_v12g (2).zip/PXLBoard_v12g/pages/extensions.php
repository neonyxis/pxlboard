<?php
/**
 * Extensions Manager Page
 */

if (!$auth->isAdmin()) {
    redirect('index.php?page=home');
}

$message = '';
$error = '';

// Handle extension installation
if (isset($_POST['install_extension']) && isset($_FILES['extension_file'])) {
    $file = $_FILES['extension_file'];
    
    if ($file['error'] === UPLOAD_ERR_OK) {
        $tmpName = $file['tmp_name'];
        $zipName = basename($file['name']);
        
        if (getFileExtension($zipName) === 'zip') {
            $extensionsDir = BASE_DIR . '/extensions';
            if (!is_dir($extensionsDir)) {
                mkdir($extensionsDir, 0755, true);
            }
            
            $zip = new ZipArchive;
            if ($zip->open($tmpName) === TRUE) {
                $extensionName = pathinfo($zipName, PATHINFO_FILENAME);
                $extractPath = $extensionsDir . '/' . $extensionName;
                
                $zip->extractTo($extractPath);
                $zip->close();
                
                // Load extension info
                $infoFile = $extractPath . '/extension.json';
                if (file_exists($infoFile)) {
                    $extInfo = json_decode(file_get_contents($infoFile), true);
                    
                    // Save to installed extensions
                    $db->save('extensions', $extensionName, [
                        'name' => $extInfo['name'] ?? $extensionName,
                        'version' => $extInfo['version'] ?? '1.0.0',
                        'author' => $extInfo['author'] ?? 'Unknown',
                        'description' => $extInfo['description'] ?? '',
                        'enabled' => false,
                        'installed_at' => time(),
                        'path' => $extractPath
                    ]);
                    
                    $message = 'Extension installed successfully!';
                } else {
                    $error = 'Invalid extension package - missing extension.json';
                }
            } else {
                $error = 'Failed to extract extension';
            }
        } else {
            $error = 'Extension must be a ZIP file';
        }
    } else {
        $error = 'Upload error';
    }
}

// Handle enable/disable
if (isset($_GET['action'])) {
    $extId = $_GET['ext'] ?? '';
    $extension = $db->get('extensions', $extId);
    
    if ($extension) {
        switch ($_GET['action']) {
            case 'enable':
                $extension['enabled'] = true;
                $db->save('extensions', $extId, $extension);
                $message = 'Extension enabled';
                break;
            case 'disable':
                $extension['enabled'] = false;
                $db->save('extensions', $extId, $extension);
                $message = 'Extension disabled';
                break;
            case 'uninstall':
                // Remove files
                if (is_dir($extension['path'])) {
                    rrmdir($extension['path']);
                }
                $db->delete('extensions', $extId);
                $message = 'Extension uninstalled';
                break;
        }
        redirect('index.php?page=extensions');
    }
}

$extensions = $db->getAll('extensions');

require 'templates/header.php';
?>

<div class="container mt-4">
    <h2>Extensions Manager</h2>
    
    <?php if ($message): ?>
        <div class="alert alert-success alert-dismissible">
            <?php echo escape($message); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible">
            <?php echo escape($error); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <div class="row mb-4">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h5>Install New Extension</h5>
                </div>
                <div class="card-body">
                    <form method="POST" enctype="multipart/form-data">
                        <div class="row g-3 align-items-end">
                            <div class="col-md-8">
                                <label class="form-label">Extension Package (ZIP)</label>
                                <input type="file" name="extension_file" class="form-control" accept=".zip" required>
                                <small class="text-muted">Upload a valid PXLBoard extension package</small>
                            </div>
                            <div class="col-md-4">
                                <button type="submit" name="install_extension" class="btn btn-primary w-100">
                                    Install Extension
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <h3>Installed Extensions</h3>
    
    <?php if (empty($extensions)): ?>
        <div class="alert alert-info">
            No extensions installed yet. Upload an extension package to get started.
        </div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Version</th>
                        <th>Author</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($extensions as $ext): ?>
                        <tr>
                            <td><strong><?php echo escape($ext['name']); ?></strong></td>
                            <td><?php echo escape($ext['description']); ?></td>
                            <td><?php echo escape($ext['version']); ?></td>
                            <td><?php echo escape($ext['author']); ?></td>
                            <td>
                                <?php if ($ext['enabled']): ?>
                                    <span class="badge bg-success">Enabled</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">Disabled</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($ext['enabled']): ?>
                                    <a href="?page=extensions&action=disable&ext=<?php echo $ext['id']; ?>" class="btn btn-sm btn-warning">Disable</a>
                                <?php else: ?>
                                    <a href="?page=extensions&action=enable&ext=<?php echo $ext['id']; ?>" class="btn btn-sm btn-success">Enable</a>
                                <?php endif; ?>
                                <a href="?page=extensions&action=uninstall&ext=<?php echo $ext['id']; ?>" 
                                   class="btn btn-sm btn-danger"
                                   onclick="return confirm('Are you sure you want to uninstall this extension?')">
                                    Uninstall
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
    
    <hr class="my-5">
    
    <h3>Creating Extensions</h3>
    
    <div class="card">
        <div class="card-body">
            <h5>Extension Structure</h5>
            <p>PXLBoard extensions are ZIP packages with the following structure:</p>
            
            <pre class="bg-light p-3"><code>extension-name/
├── extension.json      (Required: Extension metadata)
├── init.php            (Optional: Initialization code)
├── hooks.php           (Optional: Hook implementations)
├── assets/             (Optional: CSS, JS, images)
│   ├── style.css
│   └── script.js
└── templates/          (Optional: Custom templates)
    └── custom.php</code></pre>
    
            <h5 class="mt-4">extension.json Example</h5>
            <pre class="bg-light p-3"><code>{
    "name": "My Extension",
    "version": "1.0.0",
    "author": "Your Name",
    "description": "Extension description",
    "requires": "1.0.0",
    "hooks": [
        "before_upload",
        "after_upload",
        "before_render"
    ]
}</code></pre>
            
            <h5 class="mt-4">Available Hooks</h5>
            <ul>
                <li><code>before_upload</code> - Before image upload</li>
                <li><code>after_upload</code> - After image upload</li>
                <li><code>before_render</code> - Before page render</li>
                <li><code>after_render</code> - After page render</li>
                <li><code>user_login</code> - When user logs in</li>
                <li><code>user_register</code> - When user registers</li>
            </ul>
            
            <p class="mb-0">
                <a href="https://github.com/pxlboard/extension-examples" target="_blank" class="btn btn-primary">
                    View Extension Examples
                </a>
            </p>
        </div>
    </div>
</div>

<?php require 'templates/footer.php'; ?>
