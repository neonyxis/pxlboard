<?php
/**
 * Enhanced Profile Page
 * User settings, avatar upload, bio, statistics
 */

if (!$auth->isLoggedIn()) {
    redirect('index.php?page=login');
}

require_once __DIR__ . '/../includes/avatar.php';
$avatarManager = new AvatarManager($db);

$user = $auth->getCurrentUser();

// Guard: session is valid but the user record no longer exists (deleted / corrupt)
if ($user === null) {
    session_destroy();
    redirect('index.php?page=login');
}

$message = '';
$error = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_profile'])) {
        // Update profile information
        $bio = trim($_POST['bio'] ?? '');
        $website = trim($_POST['website'] ?? '');
        $location = trim($_POST['location'] ?? '');
        $twitter = trim($_POST['twitter'] ?? '');
        $discord = trim($_POST['discord'] ?? '');
        
        // Validate website URL
        if (!empty($website) && !filter_var($website, FILTER_VALIDATE_URL)) {
            $error = 'Invalid website URL';
        } else {
            $user['bio'] = $bio;
            $user['website'] = $website;
            $user['location'] = $location;
            $user['social_twitter'] = $twitter;
            $user['social_discord'] = $discord;
            
            if ($db->save('users', $user['id'], $user)) {
                $message = 'Profile updated successfully';
            } else {
                $error = 'Failed to update profile';
            }
        }
    }
    
    if (isset($_POST['upload_avatar'])) {
        // Handle avatar upload
        if (isset($_FILES['avatar'])) {
            $result = $avatarManager->uploadAvatar($_FILES['avatar'], $user['id']);
            if ($result['success']) {
                $message = 'Avatar uploaded successfully';
                $user = $db->get('users', $user['id']); // Refresh user data
            } else {
                $error = $result['error'];
            }
        }
    }
    
    if (isset($_POST['delete_avatar'])) {
        // Delete avatar
        if ($avatarManager->deleteAvatar($user['id'])) {
            $message = 'Avatar deleted successfully';
            $user = $db->get('users', $user['id']); // Refresh user data
        } else {
            $error = 'Failed to delete avatar';
        }
    }
    
    if (isset($_POST['change_password'])) {
        // Change password
        $currentPassword = $_POST['current_password'] ?? '';
        $newPassword = $_POST['new_password'] ?? '';
        $confirmPassword = $_POST['confirm_password'] ?? '';
        
        if (!password_verify($currentPassword, $user['password'])) {
            $error = 'Current password is incorrect';
        } elseif (strlen($newPassword) < PASSWORD_MIN_LENGTH) {
            $error = 'New password must be at least ' . PASSWORD_MIN_LENGTH . ' characters';
        } elseif ($newPassword !== $confirmPassword) {
            $error = 'Passwords do not match';
        } else {
            $user['password'] = password_hash($newPassword, PASSWORD_DEFAULT);
            if ($db->save('users', $user['id'], $user)) {
                $message = 'Password changed successfully';
            } else {
                $error = 'Failed to change password';
            }
        }
    }
}

// Get user statistics
$userImages = array_filter($db->getAll('images'), function($img) use ($user) {
    return isset($img['uploader_id']) && $img['uploader_id'] === $user['id'];
});

$userComments = array_filter($db->getAll('comments'), function($comment) use ($user) {
    return isset($comment['user_id']) && $comment['user_id'] === $user['id'];
});

$userFavorites = array_filter($db->getAll('favorites'), function($fav) use ($user) {
    return isset($fav['user_id']) && $fav['user_id'] === $user['id'];
});

$totalViews = array_sum(array_column($userImages, 'views'));
$totalLikes = array_sum(array_map(function($img) {
    return $img['likes'] ?? 0;
}, $userImages));

require 'templates/header.php';
?>

<div class="container mt-4">
    <?php if ($message): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="bi bi-check-circle"></i> <?php echo htmlspecialchars($message); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <i class="bi bi-exclamation-triangle"></i> <?php echo htmlspecialchars($error); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3">
            <div class="card mb-4 text-center">
                <div class="card-body">
                    <!-- Avatar -->
                    <div class="mb-3">
                        <?php echo $avatarManager->getAvatarHtml($user['id'], 'large', 'mb-3'); ?>
                    </div>
                    
                    <h4><?php echo htmlspecialchars($user['username']); ?></h4>
                    <p class="text-muted small mb-2">
                        <span class="badge bg-<?php echo $user['role'] === 'admin' ? 'danger' : ($user['role'] === 'moderator' ? 'warning' : 'secondary'); ?>">
                            <?php echo htmlspecialchars(ucfirst($user['role'])); ?>
                        </span>
                    </p>
                    <p class="text-muted small">
                        <i class="bi bi-calendar"></i> Joined <?php echo date('M Y', $user['created_at']); ?>
                    </p>
                    
                    <?php if (!empty($user['location'])): ?>
                        <p class="text-muted small mb-1">
                            <i class="bi bi-geo-alt"></i> <?php echo htmlspecialchars($user['location']); ?>
                        </p>
                    <?php endif; ?>
                    
                    <?php if (!empty($user['website'])): ?>
                        <p class="mb-1">
                            <a href="<?php echo htmlspecialchars($user['website']); ?>" target="_blank" class="text-decoration-none">
                                <i class="bi bi-link-45deg"></i> Website
                            </a>
                        </p>
                    <?php endif; ?>
                    
                    <?php if (!empty($user['social_twitter'])): ?>
                        <p class="mb-1">
                            <a href="https://twitter.com/<?php echo htmlspecialchars($user['social_twitter']); ?>" target="_blank" class="text-decoration-none">
                                <i class="bi bi-twitter"></i> @<?php echo htmlspecialchars($user['social_twitter']); ?>
                            </a>
                        </p>
                    <?php endif; ?>
                    
                    <?php if (!empty($user['social_discord'])): ?>
                        <p class="mb-1">
                            <i class="bi bi-discord"></i> <?php echo htmlspecialchars($user['social_discord']); ?>
                        </p>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Quick Stats -->
            <div class="card mb-4">
                <div class="card-header">
                    <strong><i class="bi bi-bar-chart"></i> Statistics</strong>
                </div>
                <div class="list-group list-group-flush">
                    <div class="list-group-item d-flex justify-content-between">
                        <span>Uploads</span>
                        <strong><?php echo number_format(count($userImages)); ?></strong>
                    </div>
                    <div class="list-group-item d-flex justify-content-between">
                        <span>Comments</span>
                        <strong><?php echo number_format(count($userComments)); ?></strong>
                    </div>
                    <div class="list-group-item d-flex justify-content-between">
                        <span>Favorites</span>
                        <strong><?php echo number_format(count($userFavorites)); ?></strong>
                    </div>
                    <div class="list-group-item d-flex justify-content-between">
                        <span>Total Views</span>
                        <strong><?php echo number_format($totalViews); ?></strong>
                    </div>
                    <div class="list-group-item d-flex justify-content-between">
                        <span>Total Likes</span>
                        <strong><?php echo number_format($totalLikes); ?></strong>
                    </div>
                </div>
            </div>
            
            <a href="<?php echo buildUrl('user', $user['username']); ?>" class="btn btn-outline-primary w-100 mb-2">
                <i class="bi bi-person"></i> View Public Profile
            </a>
        </div>
        
        <!-- Main Content -->
        <div class="col-md-9">
            <!-- Tabs -->
            <ul class="nav nav-tabs mb-4">
                <li class="nav-item">
                    <a class="nav-link active" data-bs-toggle="tab" href="#profile">
                        <i class="bi bi-person-circle"></i> Profile
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-bs-toggle="tab" href="#avatar">
                        <i class="bi bi-image"></i> Avatar
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-bs-toggle="tab" href="#security">
                        <i class="bi bi-shield-lock"></i> Security
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-bs-toggle="tab" href="#uploads">
                        <i class="bi bi-images"></i> My Uploads
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-bs-toggle="tab" href="#favorites">
                        <i class="bi bi-star"></i> Favorites
                    </a>
                </li>
            </ul>
            
            <div class="tab-content">
                <!-- Profile Tab -->
                <div class="tab-pane fade show active" id="profile">
                    <div class="card">
                        <div class="card-header">
                            <strong>Edit Profile Information</strong>
                        </div>
                        <div class="card-body">
                            <form method="POST">
                                <div class="mb-3">
                                    <label class="form-label">Username</label>
                                    <input type="text" class="form-control" value="<?php echo htmlspecialchars($user['username']); ?>" disabled>
                                    <small class="text-muted">Username cannot be changed</small>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">Email</label>
                                    <input type="email" class="form-control" value="<?php echo htmlspecialchars($user['email']); ?>" disabled>
                                    <small class="text-muted">Contact admin to change email</small>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">Bio</label>
                                    <textarea name="bio" class="form-control" rows="4" maxlength="500" placeholder="Tell us about yourself..."><?php echo htmlspecialchars($user['bio'] ?? ''); ?></textarea>
                                    <small class="text-muted">Maximum 500 characters</small>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">Location</label>
                                    <input type="text" name="location" class="form-control" maxlength="100" 
                                           value="<?php echo htmlspecialchars($user['location'] ?? ''); ?>" 
                                           placeholder="City, Country">
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">Website</label>
                                    <input type="url" name="website" class="form-control" 
                                           value="<?php echo htmlspecialchars($user['website'] ?? ''); ?>" 
                                           placeholder="https://example.com">
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">Twitter Username</label>
                                    <div class="input-group">
                                        <span class="input-group-text">@</span>
                                        <input type="text" name="twitter" class="form-control" 
                                               value="<?php echo htmlspecialchars($user['social_twitter'] ?? ''); ?>" 
                                               placeholder="username">
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">Discord Username</label>
                                    <input type="text" name="discord" class="form-control" 
                                           value="<?php echo htmlspecialchars($user['social_discord'] ?? ''); ?>" 
                                           placeholder="username#1234">
                                </div>
                                
                                <button type="submit" name="update_profile" class="btn btn-primary">
                                    <i class="bi bi-save"></i> Save Changes
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
                
                <!-- Avatar Tab -->
                <div class="tab-pane fade" id="avatar">
                    <div class="card">
                        <div class="card-header">
                            <strong>Manage Avatar</strong>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-4 text-center mb-3">
                                    <h6>Current Avatar</h6>
                                    <?php echo $avatarManager->getAvatarHtml($user['id'], 'large', 'mb-2'); ?>
                                    
                                    <?php if (isset($user['avatar'])): ?>
                                        <form method="POST" style="display: inline;">
                                            <button type="submit" name="delete_avatar" class="btn btn-sm btn-danger" 
                                                    onclick="return confirm('Delete your avatar?')">
                                                <i class="bi bi-trash"></i> Delete Avatar
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="col-md-8">
                                    <form method="POST" enctype="multipart/form-data">
                                        <div class="mb-3">
                                            <label class="form-label">Upload New Avatar</label>
                                            <input type="file" name="avatar" class="form-control" accept="image/*" required>
                                            <small class="text-muted">
                                                Accepted formats: JPEG, PNG, GIF, WebP<br>
                                                Maximum size: 2MB<br>
                                                Image will be cropped to square
                                            </small>
                                        </div>
                                        
                                        <button type="submit" name="upload_avatar" class="btn btn-primary">
                                            <i class="bi bi-upload"></i> Upload Avatar
                                        </button>
                                    </form>
                                    
                                    <hr>
                                    
                                    <h6>Or use Gravatar</h6>
                                    <p class="text-muted small">
                                        If you don't upload a custom avatar, your Gravatar will be displayed automatically 
                                        based on your email address. <a href="https://gravatar.com" target="_blank">Get a Gravatar</a>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Security Tab -->
                <div class="tab-pane fade" id="security">
                    <div class="card">
                        <div class="card-header">
                            <strong>Change Password</strong>
                        </div>
                        <div class="card-body">
                            <form method="POST">
                                <div class="mb-3">
                                    <label class="form-label">Current Password</label>
                                    <input type="password" name="current_password" class="form-control" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">New Password</label>
                                    <input type="password" name="new_password" class="form-control" 
                                           minlength="<?php echo PASSWORD_MIN_LENGTH; ?>" required>
                                    <small class="text-muted">Minimum <?php echo PASSWORD_MIN_LENGTH; ?> characters</small>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">Confirm New Password</label>
                                    <input type="password" name="confirm_password" class="form-control" required>
                                </div>
                                
                                <button type="submit" name="change_password" class="btn btn-warning">
                                    <i class="bi bi-key"></i> Change Password
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
                
                <!-- My Uploads Tab -->
                <div class="tab-pane fade" id="uploads">
                    <h5 class="mb-3">My Uploads (<?php echo count($userImages); ?>)</h5>
                    
                    <?php if (empty($userImages)): ?>
                        <div class="text-center py-5">
                            <i class="bi bi-images" style="font-size: 4rem; color: #ccc;"></i>
                            <p class="text-muted mt-3">You haven't uploaded any images yet</p>
                            <a href="index.php?page=upload" class="btn btn-primary">
                                <i class="bi bi-upload"></i> Upload Now
                            </a>
                        </div>
                    <?php else: ?>
                        <div class="row">
                            <?php foreach (array_slice($userImages, 0, 12) as $image): ?>
                                <div class="col-lg-3 col-md-4 col-sm-6 mb-3">
                                    <div class="card h-100">
                                        <a href="index.php?page=image&id=<?php echo htmlspecialchars($image['id']); ?>">
                                            <img src="uploads/thumbs/<?php echo htmlspecialchars($image['filename']); ?>" 
                                                 class="card-img-top" 
                                                 alt="<?php echo htmlspecialchars($image['title'] ?? 'Untitled'); ?>"
                                                 style="height: 200px; object-fit: cover;">
                                        </a>
                                        <div class="card-body p-2">
                                            <h6 class="card-title small mb-1">
                                                <?php echo htmlspecialchars(mb_substr($image['title'] ?? 'Untitled', 0, 30)); ?>
                                            </h6>
                                            <small class="text-muted">
                                                <i class="bi bi-eye"></i> <?php echo number_format($image['views'] ?? 0); ?>
                                                <i class="bi bi-heart ms-2"></i> <?php echo number_format($image['likes'] ?? 0); ?>
                                            </small>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        
                        <?php if (count($userImages) > 12): ?>
                            <div class="text-center mt-3">
                                <a href="<?php echo buildUrl('user', $user['username']); ?>" class="btn btn-outline-primary">
                                    View All Uploads
                                </a>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
                
                <!-- Favorites Tab -->
                <div class="tab-pane fade" id="favorites">
                    <h5 class="mb-3">My Favorites (<?php echo count($userFavorites); ?>)</h5>
                    
                    <?php if (empty($userFavorites)): ?>
                        <div class="text-center py-5">
                            <i class="bi bi-star" style="font-size: 4rem; color: #ccc;"></i>
                            <p class="text-muted mt-3">You haven't favorited any images yet</p>
                            <a href="index.php?page=gallery" class="btn btn-primary">
                                <i class="bi bi-images"></i> Browse Gallery
                            </a>
                        </div>
                    <?php else: ?>
                        <div class="row">
                            <?php 
                            $favoriteImages = [];
                            foreach ($userFavorites as $fav) {
                                $img = $db->get('images', $fav['image_id']);
                                if ($img) {
                                    $favoriteImages[] = $img;
                                }
                            }
                            
                            foreach (array_slice($favoriteImages, 0, 12) as $image): 
                            ?>
                                <div class="col-lg-3 col-md-4 col-sm-6 mb-3">
                                    <div class="card h-100">
                                        <a href="index.php?page=image&id=<?php echo htmlspecialchars($image['id']); ?>">
                                            <img src="uploads/thumbs/<?php echo htmlspecialchars($image['filename']); ?>" 
                                                 class="card-img-top" 
                                                 alt="<?php echo htmlspecialchars($image['title'] ?? 'Untitled'); ?>"
                                                 style="height: 200px; object-fit: cover;">
                                        </a>
                                        <div class="card-body p-2">
                                            <h6 class="card-title small mb-1">
                                                <?php echo htmlspecialchars(mb_substr($image['title'] ?? 'Untitled', 0, 30)); ?>
                                            </h6>
                                            <small class="text-muted">
                                                by <?php echo htmlspecialchars($image['uploader'] ?? 'Unknown'); ?>
                                            </small>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require 'templates/footer.php'; ?>
