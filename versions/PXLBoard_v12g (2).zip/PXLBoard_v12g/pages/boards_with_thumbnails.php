<?php
/**
 * Boards Portal - Enhanced with Thumbnail Support
 * List all discussion boards with board thumbnails
 */

require_once 'includes/board_thumbnails.php';

$thumbnailManager = new BoardThumbnailManager($db);

// Fetch all boards
$boards = $db->getAll('boards') ?? [];

// Initialize search query
$search_query = $_GET['search'] ?? '';

// Initialize view mode (grid or list)
$view_mode = $_GET['view'] ?? 'grid';

// Initialize filter variables
$sort_by = $_GET['sort'] ?? 'activity';
$filter_nsfw = $_GET['filter'] ?? 'all';

// Filter boards if search query exists
if (!empty($search_query)) {
    $search_lower = strtolower($search_query);
    $boards = array_filter($boards, function($board) use ($search_lower) {
        return strpos(strtolower($board['name'] ?? ''), $search_lower) !== false ||
               strpos(strtolower($board['description'] ?? ''), $search_lower) !== false ||
               strpos(strtolower($board['tags'] ?? ''), $search_lower) !== false;
    });
}

// Sort boards
switch ($sort_by) {
    case 'name':
        usort($boards, function($a, $b) {
            return strcasecmp($a['name'] ?? '', $b['name'] ?? '');
        });
        break;
    case 'threads':
        usort($boards, function($a, $b) {
            return ($b['thread_count'] ?? 0) - ($a['thread_count'] ?? 0);
        });
        break;
    case 'posts':
        usort($boards, function($a, $b) {
            return ($b['post_count'] ?? 0) - ($a['post_count'] ?? 0);
        });
        break;
    case 'recent':
        usort($boards, function($a, $b) {
            return ($b['last_post_time'] ?? 0) - ($a['last_post_time'] ?? 0);
        });
        break;
    case 'activity':
    default:
        usort($boards, function($a, $b) {
            return ($b['recent_activity'] ?? 0) - ($a['recent_activity'] ?? 0);
        });
        break;
}

require 'templates/header.php';
?>

<div class="boards-enhanced">
    <!-- Page Header -->
    <div class="boards-header py-5" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white;">
        <div class="container-fluid px-4">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h1 class="display-4 mb-2">
                        <i class="bi bi-collection"></i> Discussion Boards
                    </h1>
                    <p class="lead mb-0">Explore boards and join the conversation</p>
                </div>
                <div class="col-md-4 text-md-end mt-3 mt-md-0">
                    <?php if ($auth->isLoggedIn()): ?>
                        <a href="index.php?page=create_board" class="btn btn-light btn-lg">
                            <i class="bi bi-plus-circle"></i> Create Board
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Statistics Banner -->
    <div class="container-fluid px-4 mt-4">
        <div class="row mb-4">
            <div class="col-12">
                <div class="stats-banner p-4 rounded shadow-lg" style="background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%); color: white;">
                    <div class="row text-center g-3">
                        <div class="col-md-3 col-6">
                            <div class="stat-item">
                                <i class="bi bi-grid-3x3 fs-1"></i>
                                <div class="stat-value fs-2 fw-bold"><?php echo count($boards); ?></div>
                                <div class="stat-label">Total Boards</div>
                            </div>
                        </div>
                        <div class="col-md-3 col-6">
                            <div class="stat-item">
                                <i class="bi bi-chat-dots fs-1"></i>
                                <div class="stat-value fs-2 fw-bold">
                                    <?php 
                                    $totalThreads = 0;
                                    foreach ($boards as $board) {
                                        $totalThreads += $board['thread_count'] ?? 0;
                                    }
                                    echo number_format($totalThreads);
                                    ?>
                                </div>
                                <div class="stat-label">Total Threads</div>
                            </div>
                        </div>
                        <div class="col-md-3 col-6">
                            <div class="stat-item">
                                <i class="bi bi-activity fs-1"></i>
                                <div class="stat-value fs-2 fw-bold">
                                    <?php 
                                    $activeBoards = 0;
                                    foreach ($boards as $board) {
                                        if (($board['recent_activity'] ?? 0) > 0) {
                                            $activeBoards++;
                                        }
                                    }
                                    echo $activeBoards;
                                    ?>
                                </div>
                                <div class="stat-label">Active Today</div>
                            </div>
                        </div>
                        <div class="col-md-3 col-6">
                            <div class="stat-item">
                                <i class="bi bi-people fs-1"></i>
                                <div class="stat-value fs-2 fw-bold">
                                    <?php echo number_format(count($db->getAll('users'))); ?>
                                </div>
                                <div class="stat-label">Community Members</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Filter Controls -->
        <div class="row mb-4">
            <div class="col-md-4">
                <div class="input-group">
                    <span class="input-group-text"><i class="bi bi-search"></i></span>
                    <input type="text" class="form-control" placeholder="Search boards..." 
                           value="<?php echo escape($search_query); ?>"
                           onchange="window.location.href='?page=boards&search='+encodeURIComponent(this.value)">
                </div>
            </div>
            <div class="col-md-4">
                <select class="form-select" onchange="window.location.href='?page=boards&sort='+this.value+'&view=<?php echo $view_mode; ?>'">
                    <option value="activity" <?php echo $sort_by === 'activity' ? 'selected' : ''; ?>>Most Active</option>
                    <option value="recent" <?php echo $sort_by === 'recent' ? 'selected' : ''; ?>>Recently Updated</option>
                    <option value="threads" <?php echo $sort_by === 'threads' ? 'selected' : ''; ?>>Most Threads</option>
                    <option value="posts" <?php echo $sort_by === 'posts' ? 'selected' : ''; ?>>Most Posts</option>
                    <option value="name" <?php echo $sort_by === 'name' ? 'selected' : ''; ?>>Name (A-Z)</option>
                </select>
            </div>
            <div class="col-md-4 text-end">
                <div class="btn-group" role="group">
                    <a href="?page=boards&view=grid&sort=<?php echo $sort_by; ?>" 
                       class="btn btn-outline-secondary <?php echo $view_mode === 'grid' ? 'active' : ''; ?>">
                        <i class="bi bi-grid-3x3"></i> Grid
                    </a>
                    <a href="?page=boards&view=list&sort=<?php echo $sort_by; ?>" 
                       class="btn btn-outline-secondary <?php echo $view_mode === 'list' ? 'active' : ''; ?>">
                        <i class="bi bi-list-ul"></i> List
                    </a>
                </div>
            </div>
        </div>

        <!-- Boards Display -->
        <?php if (empty($boards)): ?>
            <div class="text-center py-5">
                <i class="bi bi-inbox text-muted" style="font-size: 5rem;"></i>
                <h3 class="mt-3">No boards found</h3>
                <p class="text-muted">Be the first to create a board!</p>
                <?php if ($auth->isLoggedIn()): ?>
                    <a href="index.php?page=create_board" class="btn btn-primary">
                        <i class="bi bi-plus-circle"></i> Create Board
                    </a>
                <?php endif; ?>
            </div>
        <?php elseif ($view_mode === 'grid'): ?>
            <!-- Grid View -->
            <div class="row g-4 mb-5">
                <?php foreach ($boards as $board): ?>
                    <div class="col-lg-3 col-md-4 col-sm-6">
                        <div class="card board-card h-100 shadow-sm">
                            <div class="position-relative">
                                <?php
                                $thumbnailUrl = $thumbnailManager->getThumbnailUrl($board['id']);
                                if (file_exists($thumbnailUrl)):
                                ?>
                                    <img src="<?php echo $thumbnailUrl; ?>" 
                                         class="card-img-top" 
                                         alt="<?php echo escape($board['name']); ?>"
                                         style="height: 180px; object-fit: cover;">
                                <?php else: ?>
                                    <div class="board-placeholder" style="height: 180px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); display: flex; align-items: center; justify-content: center; color: white;">
                                        <div class="text-center">
                                            <i class="bi bi-collection fs-1"></i>
                                            <div class="mt-2 fw-bold"><?php echo escape(substr($board['name'], 0, 1)); ?></div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                
                                <?php if ($board['is_pinned'] ?? false): ?>
                                    <div class="position-absolute top-0 start-0 m-2">
                                        <span class="badge bg-warning">
                                            <i class="bi bi-pin-angle-fill"></i> Pinned
                                        </span>
                                    </div>
                                <?php endif; ?>
                                
                                <?php if ($auth->isLoggedIn() && $thumbnailManager->canManageThumbnail($auth->getCurrentUser()['id'], $board['id'])): ?>
                                    <div class="position-absolute top-0 end-0 m-2">
                                        <a href="index.php?page=board&id=<?php echo $board['id']; ?>&action=manage_thumbnail" 
                                           class="btn btn-sm btn-light" title="Manage Thumbnail">
                                            <i class="bi bi-image"></i>
                                        </a>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="card-body">
                                <h5 class="card-title">
                                    <a href="index.php?page=board&id=<?php echo $board['id']; ?>" class="text-decoration-none">
                                        <?php echo escape($board['name'] ?? 'Untitled'); ?>
                                    </a>
                                </h5>
                                <p class="card-text text-muted small">
                                    <?php echo escape(substr($board['description'] ?? '', 0, 100)); ?>
                                    <?php echo strlen($board['description'] ?? '') > 100 ? '...' : ''; ?>
                                </p>
                                
                                <div class="d-flex justify-content-between align-items-center mt-3">
                                    <div class="small text-muted">
                                        <i class="bi bi-chat-dots"></i> <?php echo number_format($board['thread_count'] ?? 0); ?> threads
                                    </div>
                                    <div class="small text-muted">
                                        <i class="bi bi-chat-text"></i> <?php echo number_format($board['post_count'] ?? 0); ?> posts
                                    </div>
                                </div>
                                
                                <?php if (!empty($board['tags'])): ?>
                                    <div class="mt-2">
                                        <?php foreach (array_slice(explode(',', $board['tags']), 0, 3) as $tag): ?>
                                            <span class="badge bg-secondary"><?php echo escape(trim($tag)); ?></span>
                                        <?php endforeach; ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <!-- List View -->
            <div class="list-group mb-5">
                <?php foreach ($boards as $board): ?>
                    <div class="list-group-item list-group-item-action">
                        <div class="row align-items-center">
                            <div class="col-md-2">
                                <?php
                                $thumbnailUrl = $thumbnailManager->getThumbnailUrl($board['id']);
                                if (file_exists($thumbnailUrl)):
                                ?>
                                    <img src="<?php echo $thumbnailUrl; ?>" 
                                         class="img-fluid rounded" 
                                         alt="<?php echo escape($board['name']); ?>"
                                         style="height: 100px; width: 100%; object-fit: cover;">
                                <?php else: ?>
                                    <div class="board-placeholder rounded" style="height: 100px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); display: flex; align-items: center; justify-content: center; color: white;">
                                        <i class="bi bi-collection fs-1"></i>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-7">
                                <h5 class="mb-1">
                                    <a href="index.php?page=board&id=<?php echo $board['id']; ?>" class="text-decoration-none">
                                        <?php echo escape($board['name'] ?? 'Untitled'); ?>
                                    </a>
                                    <?php if ($board['is_pinned'] ?? false): ?>
                                        <span class="badge bg-warning ms-2">
                                            <i class="bi bi-pin-angle-fill"></i> Pinned
                                        </span>
                                    <?php endif; ?>
                                </h5>
                                <p class="mb-1 text-muted">
                                    <?php echo escape($board['description'] ?? ''); ?>
                                </p>
                                <small class="text-muted">
                                    Created by <?php echo escape($board['creator'] ?? 'Unknown'); ?>
                                    <?php if (!empty($board['last_post_time'])): ?>
                                        • Last activity <?php echo timeAgo($board['last_post_time']); ?>
                                    <?php endif; ?>
                                </small>
                            </div>
                            <div class="col-md-3 text-end">
                                <div class="board-stats">
                                    <div class="mb-2">
                                        <i class="bi bi-chat-dots"></i> 
                                        <strong><?php echo number_format($board['thread_count'] ?? 0); ?></strong> threads
                                    </div>
                                    <div>
                                        <i class="bi bi-chat-text"></i> 
                                        <strong><?php echo number_format($board['post_count'] ?? 0); ?></strong> posts
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<style>
.board-card {
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    overflow: hidden;
}

.board-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(0,0,0,0.2) !important;
}

.board-card img {
    transition: transform 0.3s ease;
}

.board-card:hover img {
    transform: scale(1.05);
}

.stat-item {
    padding: 10px;
}

.boards-header {
    border-bottom: 4px solid rgba(255,255,255,0.2);
}

.list-group-item:hover {
    background-color: #f8f9fa;
}
</style>

<?php require 'templates/footer.php'; ?>
