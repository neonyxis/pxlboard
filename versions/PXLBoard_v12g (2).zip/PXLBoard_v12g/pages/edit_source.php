<?php
/**
 * Edit Image Source Page
 */

if (!$auth->isLoggedIn()) {
    redirect('index.php?page=login');
}

$imageId = $_GET['id'] ?? '';
$image = $db->get('images', $imageId);

if (!$image) {
    require 'pages/404.php';
    exit;
}

// Only allow uploader or admin to edit source
if ($_SESSION['user_id'] !== $image['uploader_id'] && !$auth->isAdmin()) {
    redirect('index.php?page=image&id=' . $imageId);
}

$message = '';
$error = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_source'])) {
    $newSource = trim($_POST['source_url'] ?? '');
    
    // Validate URL if provided
    if (!empty($newSource) && !filter_var($newSource, FILTER_VALIDATE_URL)) {
        $error = 'Invalid URL format';
    } else {
        // Initialize source history if not present
        if (!isset($image['source_history'])) {
            $image['source_history'] = [];
        }
        
        // Add current source to history if it exists and is different
        if (isset($image['source_url']) && $image['source_url'] !== $newSource) {
            $image['source_history'][] = [
                'url' => $image['source_url'],
                'updated_at' => time(),
                'updated_by' => $_SESSION['username']
            ];
        }
        
        // Update source URL
        $image['source_url'] = $newSource;
        
        if ($db->save('images', $imageId, $image)) {
            $message = 'Source URL updated successfully';
            // Redirect to image page after short delay
            header('refresh:2;url=index.php?page=image&id=' . $imageId);
        } else {
            $error = 'Failed to update source URL';
        }
    }
}

require 'templates/header.php';
?>

<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h4><i class="bi bi-link-45deg"></i> Edit Image Source</h4>
                </div>
                <div class="card-body">
                    <?php if ($message): ?>
                        <div class="alert alert-success alert-dismissible fade show">
                            <i class="bi bi-check-circle"></i> <?php echo htmlspecialchars($message); ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($error): ?>
                        <div class="alert alert-danger alert-dismissible fade show">
                            <i class="bi bi-exclamation-triangle"></i> <?php echo htmlspecialchars($error); ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>
                    
                    <div class="mb-3 text-center">
                        <img src="uploads/thumbs/<?php echo htmlspecialchars($image['filename']); ?>" 
                             alt="<?php echo htmlspecialchars($image['title']); ?>"
                             class="img-thumbnail"
                             style="max-height: 200px;">
                        <p class="mt-2 mb-0"><strong><?php echo htmlspecialchars($image['title']); ?></strong></p>
                    </div>
                    
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Source URL</label>
                            <input type="url" name="source_url" class="form-control" 
                                   value="<?php echo htmlspecialchars($image['source_url'] ?? ''); ?>"
                                   placeholder="https://example.com/original-source">
                            <small class="text-muted">
                                Enter the URL where this image was originally found or created.
                                Leave blank if this is original content.
                            </small>
                        </div>
                        
                        <div class="d-flex justify-content-between">
                            <a href="index.php?page=image&id=<?php echo htmlspecialchars($imageId); ?>" 
                               class="btn btn-secondary">
                                <i class="bi bi-x-circle"></i> Cancel
                            </a>
                            <button type="submit" name="save_source" class="btn btn-primary">
                                <i class="bi bi-check-circle"></i> Save Source
                            </button>
                        </div>
                    </form>
                    
                    <?php if (!empty($image['source_history'])): ?>
                        <hr class="my-4">
                        <h5>Source History</h5>
                        <div class="list-group list-group-flush">
                            <?php foreach (array_reverse($image['source_history']) as $history): ?>
                                <div class="list-group-item">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <div>
                                            <a href="<?php echo htmlspecialchars($history['url']); ?>" 
                                               target="_blank" class="text-break">
                                                <?php echo htmlspecialchars($history['url']); ?>
                                                <i class="bi bi-box-arrow-up-right small"></i>
                                            </a>
                                        </div>
                                    </div>
                                    <small class="text-muted">
                                        Updated by <?php echo htmlspecialchars($history['updated_by']); ?>
                                        on <?php echo date('Y-m-d H:i', $history['updated_at']); ?>
                                    </small>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require 'templates/footer.php'; ?>
