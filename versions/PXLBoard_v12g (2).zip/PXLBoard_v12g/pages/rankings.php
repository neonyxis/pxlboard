<?php
/**
 * Rankings/Leaderboards Page
 * Displays top users, images, and statistics
 */

require_once 'includes/board_voting.php';
$voting = new BoardVoting($db);

$tab = $_GET['tab'] ?? 'uploaders';

// Get all data
$users = $db->getAll('users');
$images = $db->getAll('images');
$comments = $db->getAll('comments');
$ratings = $db->getAll('ratings');
$threads = $db->getAll('board_threads');
$posts = $db->getAll('board_posts');

// Calculate top uploaders
$uploaderStats = [];
foreach ($images as $image) {
    $uploaderId = $image['uploader_id'] ?? '';
    if (!isset($uploaderStats[$uploaderId])) {
        $uploaderStats[$uploaderId] = [
            'username' => $image['uploader'] ?? 'Unknown',
            'uploads' => 0,
            'total_views' => 0,
            'total_favorites' => 0,
            'total_likes' => 0,
            'avg_rating' => 0
        ];
    }
    $uploaderStats[$uploaderId]['uploads']++;
    $uploaderStats[$uploaderId]['total_views'] += $image['views'] ?? 0;
    $uploaderStats[$uploaderId]['total_favorites'] += $image['favorites'] ?? 0;
    $uploaderStats[$uploaderId]['total_likes'] += $image['likes'] ?? 0;
}

// Calculate board karma
$karmaStats = [];
foreach ($users as $user) {
    $karma = 0;
    foreach ($threads as $thread) {
        if (($thread['author_id'] ?? null) === $user['id']) {
            $karma += $thread['vote_score'] ?? 0;
        }
    }
    foreach ($posts as $post) {
        if (($post['author_id'] ?? null) === $user['id']) {
            $karma += $post['vote_score'] ?? 0;
        }
    }
    
    if ($karma > 0) {
        $karmaStats[] = [
            'username' => $user['username'],
            'karma' => $karma,
            'user_id' => $user['id']
        ];
    }
}

usort($karmaStats, function($a, $b) {
    return $b['karma'] - $a['karma'];
});
$topKarma = array_slice($karmaStats, 0, 50);

// Calculate average ratings
foreach ($uploaderStats as $userId => &$stats) {
    $userImages = array_filter($images, function($img) use ($userId) {
        return ($img['uploader_id'] ?? '') === $userId;
    });
    
    $totalRating = 0;
    $ratingCount = 0;
    foreach ($userImages as $img) {
        if (isset($img['rating']) && $img['rating'] > 0) {
            $totalRating += $img['rating'];
            $ratingCount++;
        }
    }
    
    $stats['avg_rating'] = $ratingCount > 0 ? $totalRating / $ratingCount : 0;
}

// Sort by uploads
usort($uploaderStats, function($a, $b) {
    return $b['uploads'] - $a['uploads'];
});
$topUploaders = array_slice($uploaderStats, 0, 50);

// Calculate top commenters
$commenterStats = [];
foreach ($comments as $comment) {
    $userId = $comment['user_id'] ?? '';
    if (!isset($commenterStats[$userId])) {
        $commenterStats[$userId] = [
            'username' => $comment['username'] ?? 'Unknown',
            'comments' => 0
        ];
    }
    $commenterStats[$userId]['comments']++;
}

usort($commenterStats, function($a, $b) {
    return $b['comments'] - $a['comments'];
});
$topCommenters = array_slice($commenterStats, 0, 50);

// Top rated images
$topRatedImages = array_filter($images, function($img) {
    return isset($img['rating']) && $img['rating'] > 0;
});
usort($topRatedImages, function($a, $b) {
    return ($b['rating'] ?? 0) - ($a['rating'] ?? 0);
});
$topRatedImages = array_slice($topRatedImages, 0, 20);

// Most viewed images
$mostViewedImages = $images;
usort($mostViewedImages, function($a, $b) {
    return ($b['views'] ?? 0) - ($a['views'] ?? 0);
});
$mostViewedImages = array_slice($mostViewedImages, 0, 20);

// Most favorited images
$mostFavoritedImages = $images;
usort($mostFavoritedImages, function($a, $b) {
    return ($b['favorites'] ?? 0) - ($a['favorites'] ?? 0);
});
$mostFavoritedImages = array_slice($mostFavoritedImages, 0, 20);

require 'templates/header.php';
?>

<style>
.rank-number {
    width: 40px;
    height: 40px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    font-weight: bold;
    margin-right: 10px;
}

.rank-1 { background: linear-gradient(135deg, #FFD700, #FFA500); color: white; }
.rank-2 { background: linear-gradient(135deg, #C0C0C0, #808080); color: white; }
.rank-3 { background: linear-gradient(135deg, #CD7F32, #8B4513); color: white; }
.rank-other { background: #f8f9fa; color: #6c757d; }

.stat-card {
    background: white;
    border: 1px solid #dee2e6;
    border-radius: 8px;
    padding: 15px;
    margin-bottom: 10px;
    transition: all 0.2s;
}

.stat-card:hover {
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    transform: translateY(-2px);
}

.trophy-icon {
    font-size: 24px;
}
</style>

<div class="container mt-4">
    <div class="row mb-4">
        <div class="col-md-8">
            <h1><i class="bi bi-trophy"></i> Rankings & Leaderboards</h1>
            <p class="text-muted">Top contributors and most popular content</p>
        </div>
        <div class="col-md-4 text-end">
            <small class="text-muted">Updated in real-time</small>
        </div>
    </div>
    
    <!-- Navigation Tabs -->
    <ul class="nav nav-tabs mb-4" role="tablist">
        <li class="nav-item">
            <a class="nav-link <?php echo $tab === 'uploaders' ? 'active' : ''; ?>" 
               href="?page=rankings&tab=uploaders">
                <i class="bi bi-upload"></i> Top Uploaders
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo $tab === 'karma' ? 'active' : ''; ?>" 
               href="?page=rankings&tab=karma">
                <i class="bi bi-arrow-up-circle"></i> Board Karma
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo $tab === 'commenters' ? 'active' : ''; ?>" 
               href="?page=rankings&tab=commenters">
                <i class="bi bi-chat"></i> Top Commenters
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo $tab === 'rated' ? 'active' : ''; ?>" 
               href="?page=rankings&tab=rated">
                <i class="bi bi-star"></i> Top Rated Images
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo $tab === 'viewed' ? 'active' : ''; ?>" 
               href="?page=rankings&tab=viewed">
                <i class="bi bi-eye"></i> Most Viewed
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo $tab === 'favorited' ? 'active' : ''; ?>" 
               href="?page=rankings&tab=favorited">
                <i class="bi bi-heart"></i> Most Favorited
            </a>
        </li>
    </ul>
    
    <!-- Tab Content -->
    <div class="tab-content">
        <?php if ($tab === 'uploaders'): ?>
            <!-- Top Uploaders -->
            <div class="row">
                <div class="col-12">
                    <h3 class="mb-3">Top Uploaders</h3>
                    <?php if (empty($topUploaders)): ?>
                        <p class="text-muted">No data available yet.</p>
                    <?php else: ?>
                        <?php foreach ($topUploaders as $index => $uploader): ?>
                            <div class="stat-card">
                                <div class="d-flex align-items-center">
                                    <span class="rank-number rank-<?php echo $index < 3 ? ($index + 1) : 'other'; ?>">
                                        #<?php echo $index + 1; ?>
                                    </span>
                                    <div class="flex-grow-1">
                                        <h5 class="mb-1"><?php echo escape($uploader['username']); ?></h5>
                                        <div class="row g-3 small text-muted">
                                            <div class="col-auto">
                                                <i class="bi bi-images"></i> <?php echo number_format($uploader['uploads']); ?> uploads
                                            </div>
                                            <div class="col-auto">
                                                <i class="bi bi-eye"></i> <?php echo number_format($uploader['total_views']); ?> views
                                            </div>
                                            <div class="col-auto">
                                                <i class="bi bi-heart"></i> <?php echo number_format($uploader['total_likes']); ?> likes
                                            </div>
                                            <div class="col-auto">
                                                <i class="bi bi-star"></i> <?php echo number_format($uploader['avg_rating'], 2); ?> avg rating
                                            </div>
                                        </div>
                                    </div>
                                    <?php if ($index === 0): ?>
                                        <span class="trophy-icon">🏆</span>
                                    <?php elseif ($index === 1): ?>
                                        <span class="trophy-icon">🥈</span>
                                    <?php elseif ($index === 2): ?>
                                        <span class="trophy-icon">🥉</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
            
        <?php elseif ($tab === 'karma'): ?>
            <!-- Board Karma Leaderboard -->
            <div class="row">
                <div class="col-12">
                    <h3 class="mb-3">Board Karma Leaders</h3>
                    <p class="text-muted">Users with the most upvoted threads and posts</p>
                    <?php if (empty($topKarma)): ?>
                        <p class="text-muted">No karma data available yet.</p>
                    <?php else: ?>
                        <?php foreach ($topKarma as $index => $user): ?>
                            <div class="stat-card">
                                <div class="d-flex align-items-center">
                                    <span class="rank-number rank-<?php echo $index < 3 ? ($index + 1) : 'other'; ?>">
                                        #<?php echo $index + 1; ?>
                                    </span>
                                    <div class="flex-grow-1">
                                        <h5 class="mb-1"><?php echo escape($user['username']); ?></h5>
                                        <div class="small text-muted">
                                            <i class="bi bi-arrow-up-circle"></i> <?php echo number_format($user['karma']); ?> karma points
                                        </div>
                                    </div>
                                    <?php if ($index === 0): ?>
                                        <span class="trophy-icon">🏆</span>
                                    <?php elseif ($index === 1): ?>
                                        <span class="trophy-icon">🥈</span>
                                    <?php elseif ($index === 2): ?>
                                        <span class="trophy-icon">🥉</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
            
        <?php elseif ($tab === 'commenters'): ?>
            <!-- Top Commenters -->
            <div class="row">
                <div class="col-12">
                    <h3 class="mb-3">Top Commenters</h3>
                    <?php if (empty($topCommenters)): ?>
                        <p class="text-muted">No data available yet.</p>
                    <?php else: ?>
                        <?php foreach ($topCommenters as $index => $commenter): ?>
                            <div class="stat-card">
                                <div class="d-flex align-items-center">
                                    <span class="rank-number rank-<?php echo $index < 3 ? ($index + 1) : 'other'; ?>">
                                        #<?php echo $index + 1; ?>
                                    </span>
                                    <div class="flex-grow-1">
                                        <h5 class="mb-1"><?php echo escape($commenter['username']); ?></h5>
                                        <div class="small text-muted">
                                            <i class="bi bi-chat"></i> <?php echo number_format($commenter['comments']); ?> comments
                                        </div>
                                    </div>
                                    <?php if ($index === 0): ?>
                                        <span class="trophy-icon">🏆</span>
                                    <?php elseif ($index === 1): ?>
                                        <span class="trophy-icon">🥈</span>
                                    <?php elseif ($index === 2): ?>
                                        <span class="trophy-icon">🥉</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
            
        <?php elseif ($tab === 'rated'): ?>
            <!-- Top Rated Images -->
            <div class="row">
                <div class="col-12">
                    <h3 class="mb-3">Top Rated Images</h3>
                    <?php if (empty($topRatedImages)): ?>
                        <p class="text-muted">No rated images yet.</p>
                    <?php else: ?>
                        <div class="row">
                            <?php foreach ($topRatedImages as $index => $image): ?>
                                <div class="col-md-6 col-lg-4 mb-3">
                                    <div class="card">
                                        <div class="position-relative">
                                            <span class="position-absolute top-0 start-0 m-2 rank-number rank-<?php echo $index < 3 ? ($index + 1) : 'other'; ?>" 
                                                  style="z-index: 10;">
                                                #<?php echo $index + 1; ?>
                                            </span>
                                            <a href="index.php?page=image&id=<?php echo $image['id']; ?>">
                                                <img src="uploads/thumbs/<?php echo escape($image['filename']); ?>" 
                                                     class="card-img-top" alt="<?php echo escape($image['title']); ?>">
                                            </a>
                                        </div>
                                        <div class="card-body">
                                            <h6 class="card-title">
                                                <a href="index.php?page=image&id=<?php echo $image['id']; ?>" 
                                                   class="text-decoration-none">
                                                    <?php echo escape(mb_substr($image['title'] ?? 'Untitled', 0, 40)); ?>
                                                </a>
                                            </h6>
                                            <p class="card-text small text-muted mb-2">
                                                by <?php echo escape($image['uploader']); ?>
                                            </p>
                                            <div class="d-flex justify-content-between small">
                                                <span><i class="bi bi-star-fill text-warning"></i> <?php echo number_format($image['rating'], 2); ?></span>
                                                <span><i class="bi bi-eye"></i> <?php echo number_format($image['views']); ?></span>
                                                <span><i class="bi bi-heart"></i> <?php echo number_format($image['likes']); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
        <?php elseif ($tab === 'viewed'): ?>
            <!-- Most Viewed Images -->
            <div class="row">
                <div class="col-12">
                    <h3 class="mb-3">Most Viewed Images</h3>
                    <div class="row">
                        <?php foreach ($mostViewedImages as $index => $image): ?>
                            <div class="col-md-6 col-lg-4 mb-3">
                                <div class="card">
                                    <div class="position-relative">
                                        <span class="position-absolute top-0 start-0 m-2 rank-number rank-<?php echo $index < 3 ? ($index + 1) : 'other'; ?>" 
                                              style="z-index: 10;">
                                            #<?php echo $index + 1; ?>
                                        </span>
                                        <a href="index.php?page=image&id=<?php echo $image['id']; ?>">
                                            <img src="uploads/thumbs/<?php echo escape($image['filename']); ?>" 
                                                 class="card-img-top" alt="<?php echo escape($image['title']); ?>">
                                        </a>
                                    </div>
                                    <div class="card-body">
                                        <h6 class="card-title">
                                            <a href="index.php?page=image&id=<?php echo $image['id']; ?>" 
                                               class="text-decoration-none">
                                                <?php echo escape(mb_substr($image['title'] ?? 'Untitled', 0, 40)); ?>
                                            </a>
                                        </h6>
                                        <p class="card-text small text-muted mb-2">
                                            by <?php echo escape($image['uploader']); ?>
                                        </p>
                                        <div class="d-flex justify-content-between small">
                                            <span><i class="bi bi-eye text-primary"></i> <?php echo number_format($image['views']); ?></span>
                                            <span><i class="bi bi-heart"></i> <?php echo number_format($image['likes'] ?? 0); ?></span>
                                            <span><i class="bi bi-star"></i> <?php echo number_format($image['rating'] ?? 0, 1); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            
        <?php elseif ($tab === 'favorited'): ?>
            <!-- Most Favorited Images -->
            <div class="row">
                <div class="col-12">
                    <h3 class="mb-3">Most Favorited Images</h3>
                    <div class="row">
                        <?php foreach ($mostFavoritedImages as $index => $image): ?>
                            <div class="col-md-6 col-lg-4 mb-3">
                                <div class="card">
                                    <div class="position-relative">
                                        <span class="position-absolute top-0 start-0 m-2 rank-number rank-<?php echo $index < 3 ? ($index + 1) : 'other'; ?>" 
                                              style="z-index: 10;">
                                            #<?php echo $index + 1; ?>
                                        </span>
                                        <a href="index.php?page=image&id=<?php echo $image['id']; ?>">
                                            <img src="uploads/thumbs/<?php echo escape($image['filename']); ?>" 
                                                 class="card-img-top" alt="<?php echo escape($image['title']); ?>">
                                        </a>
                                    </div>
                                    <div class="card-body">
                                        <h6 class="card-title">
                                            <a href="index.php?page=image&id=<?php echo $image['id']; ?>" 
                                               class="text-decoration-none">
                                                <?php echo escape(mb_substr($image['title'] ?? 'Untitled', 0, 40)); ?>
                                            </a>
                                        </h6>
                                        <p class="card-text small text-muted mb-2">
                                            by <?php echo escape($image['uploader']); ?>
                                        </p>
                                        <div class="d-flex justify-content-between small">
                                            <span><i class="bi bi-heart-fill text-danger"></i> <?php echo number_format($image['favorites']); ?></span>
                                            <span><i class="bi bi-eye"></i> <?php echo number_format($image['views'] ?? 0); ?></span>
                                            <span><i class="bi bi-star"></i> <?php echo number_format($image['rating'] ?? 0, 1); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require 'templates/footer.php'; ?>
