<?php
/**
 * Channels Page - Category-based image organization
 */

$channelId = $_GET['id'] ?? '';

if ($channelId) {
    // View specific channel
    $channel = $db->get('channels', $channelId);
    if (!$channel) {
        require 'pages/404.php';
        exit;
    }
    
    // Get images in this channel
    $allImages = $db->getAll('images');
    $channelImages = array_filter($allImages, function($img) use ($channelId) {
        return ($img['channel'] ?? '') === $channelId;
    });
    
    require 'templates/header.php';
    ?>
    
    <div class="container mt-4">
        <div class="card mb-4">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h1><?php echo escape($channel['name']); ?></h1>
                        <p class="text-muted mb-0"><?php echo escape($channel['description']); ?></p>
                        <small class="text-muted">
                            <?php echo count($channelImages); ?> images • 
                            <?php echo $channel['subscribers'] ?? 0; ?> subscribers
                        </small>
                    </div>
                    <div class="col-md-4 text-end">
                        <?php if ($auth->isLoggedIn()): ?>
                            <a href="index.php?page=upload&channel=<?php echo $channelId; ?>" class="btn btn-primary">
                                Upload to Channel
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="row">
            <?php if (empty($channelImages)): ?>
                <div class="col-12 text-center py-5">
                    <h3>No images in this channel yet</h3>
                </div>
            <?php else: ?>
                <?php foreach ($channelImages as $image): ?>
                    <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                        <div class="card image-card">
                            <a href="index.php?page=image&id=<?php echo escape($image['id']); ?>">
                                <img src="uploads/thumbs/<?php echo escape($image['filename']); ?>" 
                                     class="card-img-top" 
                                     alt="<?php echo escape($image['title']); ?>">
                            </a>
                            <div class="card-body">
                                <h6 class="card-title"><?php echo escape($image['title']); ?></h6>
                                <p class="card-text small text-muted">
                                    <?php echo escape($image['uploader']); ?>
                                </p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
    
    <?php
} else {
    // List all channels
    $channels = $db->getAll('channels');
    usort($channels, function($a, $b) {
        return strcmp($a['name'], $b['name']);
    });
    
    require 'templates/header.php';
    ?>
    
    <div class="container mt-4">
        <div class="row mb-4">
            <div class="col-md-8">
                <h1>Channels</h1>
                <p class="text-muted">Browse images by category</p>
            </div>
            <div class="col-md-4 text-end">
                <?php if ($auth->isAdmin()): ?>
                    <a href="index.php?page=admin&action=channels" class="btn btn-primary">Manage Channels</a>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="row">
            <?php if (empty($channels)): ?>
                <div class="col-12 text-center py-5">
                    <h3>No channels created yet</h3>
                    <?php if ($auth->isAdmin()): ?>
                        <p class="text-muted">Create channels to organize images by category</p>
                        <a href="index.php?page=admin&action=channels" class="btn btn-primary">Create Channel</a>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <?php foreach ($channels as $channel): ?>
                    <?php
                    $allImages = $db->getAll('images');
                    $channelImageCount = count(array_filter($allImages, function($img) use ($channel) {
                        return ($img['channel'] ?? '') === $channel['id'];
                    }));
                    ?>
                    <div class="col-lg-4 col-md-6 mb-4">
                        <div class="card h-100">
                            <div class="card-body">
                                <h4>
                                    <a href="index.php?page=channel&id=<?php echo escape($channel['id']); ?>" class="text-decoration-none">
                                        <?php echo escape($channel['name']); ?>
                                    </a>
                                </h4>
                                <p class="text-muted"><?php echo escape($channel['description']); ?></p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <small class="text-muted">
                                        <?php echo number_format($channelImageCount); ?> images
                                    </small>
                                    <a href="index.php?page=channel&id=<?php echo escape($channel['id']); ?>" class="btn btn-sm btn-primary">
                                        Browse
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
    
    <?php
}

require 'templates/footer.php';
?>
