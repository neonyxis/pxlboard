# PXLBoard v12f - Version Notes

**Release Date**: January 31, 2026  
**Version**: 12f  
**Build**: Stable Release

---

## Overview

PXLBoard v12f represents a major enhancement to the platform, introducing community-focused features that transform the site from a simple imageboard into a comprehensive community platform. This release focuses on user engagement, content curation, and modern browsing experiences.

---

## What's New

### 1. Community Portal

The centerpiece of v12f is the new Community Portal - a unified dashboard that brings together all community activities.

**Features**:
- Real-time activity stream showing recent:
  - Image uploads
  - Blog posts
  - Wiki edits
  - Board discussions
- Filterable activity by content type
- Quick navigation to all site sections
- Live statistics dashboard
- Featured images showcase
- Popular boards listing
- Recent wiki updates
- Community status information

**Impact**: Provides users with a single destination to see what's happening across the entire site, increasing engagement and discovery.

### 2. Board Thumbnails

Discussion boards can now have custom thumbnail images, making them more visually distinctive and appealing.

**Features**:
- Upload custom thumbnails (up to 5MB)
- Automatic thumbnail generation (300x200px)
- Permission-based management:
  - Board creators can manage their boards
  - Board moderators can manage assigned boards
  - Admins can manage all boards
- Supports JPEG, PNG, GIF, WebP
- Default placeholder for boards without thumbnails

**Impact**: Makes the boards listing more visually appealing and helps users quickly identify boards.

### 3. Enhanced Gallery

Complete redesign of the gallery interface with modern features inspired by contemporary booru sites.

**Features**:

**View Modes**:
- Grid View: Uniform, compact grid
- Masonry View: Pinterest-style cascading layout
- List View: Detailed list with descriptions

**Advanced Filtering**:
- Tag-based search (comma-separated)
- Match any tag OR match all tags modes
- Uploader name filter
- Channel filter
- Date range selection
- Minimum rating filter
- Score filter (likes minus dislikes)

**Sorting Options**:
- Newest first
- Oldest first
- Most viewed
- Highest score
- Most favorited
- Random shuffle

**UI Improvements**:
- Sticky sidebar filters
- Popular tags cloud with frequencies
- Hover effects with statistics overlay
- Adjustable items per page (12-100)
- Smart pagination with jump to page
- Lazy loading for better performance
- Responsive design for all devices

**Impact**: Provides a modern, feature-rich browsing experience that rivals dedicated booru sites.

### 4. TGP (Thumbnail Gallery Posts)

Brand new feature allowing users to create curated collections of images.

**Features**:

**Collection Creation**:
- Select multiple images from your uploads
- Add title, description, and tags
- Choose category (Art, Photography, Design, etc.)
- Publish publicly or save as draft
- Visual image selector with preview

**Collection Management**:
- Edit your own collections
- Delete collections you created
- Admins can feature collections
- View tracking
- Like/unlike functionality
- Category-based browsing

**Discovery**:
- Browse all public collections
- Filter by category
- Sort by newest, popular, likes, oldest
- Featured collections showcase
- Search by tags
- View author profiles

**Social Features**:
- Like button for collections
- Share links to collections
- View count tracking
- Author attribution
- Related collections

**Impact**: Encourages content curation and gives users a way to showcase themed image sets.

### 5. Photo Rotator

New widget system for displaying rotating image showcases.

**Three Rotator Styles**:

1. **Carousel Rotator**
   - Bootstrap-powered slideshow
   - Full captions with metadata
   - Navigation controls
   - Auto-play option
   - Configurable interval

2. **Compact Rotator**
   - Horizontal scrolling thumbnails
   - Infinite loop animation
   - Pause on hover
   - Smooth transitions
   - Configurable speed

3. **Grid Rotator**
   - Grid of images that randomly rotate
   - Smooth fade transitions
   - Configurable columns
   - Random image selection
   - Continuous updates

**Configuration Options**:
- Image selection criteria (newest, popular, top-rated, featured, random)
- Number of images to display
- Rotation interval
- Height and dimensions
- Auto-play toggle
- Show/hide controls and indicators

**Impact**: Adds dynamic visual interest to pages and showcases quality content.

### 6. Enhanced Navigation

Complete reorganization of the site navigation for better usability.

**Changes**:
- Promoted Community Portal to main menu
- Added Collections (TGP) to main menu
- Enhanced Gallery and Boards links
- Consolidated less-used items in "More" dropdown
- Improved mobile navigation
- Added icons to key menu items
- Styled upload button for prominence

**Impact**: Makes new features easily discoverable and improves overall site navigation.

---

## Technical Improvements

### Code Organization

**New Files**:
- `pages/community_portal.php` (380 lines)
- `pages/gallery_enhanced.php` (540 lines)
- `pages/boards_with_thumbnails.php` (450 lines)
- `pages/tgp.php` (310 lines)
- `pages/tgp_create.php` (360 lines)
- `pages/tgp_view.php` (410 lines)
- `includes/board_thumbnails.php` (235 lines)
- `includes/tgp_manager.php` (260 lines)
- `includes/photo_rotator.php` (285 lines)

**Updated Files**:
- `index.php` - Added routing for new pages
- `pages/home.php` - Integrated community portal and photo rotator
- `pages/api.php` - Added TGP like endpoint
- `templates/header.php` - Updated navigation
- `includes/database.php` - Added TGP collections

**Total New Code**: ~3,230 lines

### Database Extensions

**New Collections**:
- `tgp_posts` - TGP collection data
- `tgp_likes` - User likes on collections

**Enhanced Collections**:
- `boards` - Extended with thumbnail support

### Performance

- Optimized image loading with lazy loading
- Efficient filtering algorithms
- Cached popular tags
- Minimal database queries
- Progressive enhancement approach

### Security

- File upload validation (MIME type checking)
- Permission-based access control
- Input sanitization
- XSS prevention
- CSRF protection (via session)
- Secure file handling

---

## Upgrade Path

### From v12e to v12f

**Automatic**:
- Database schema auto-extends via FlatFileDB
- New directories auto-created on first access
- No manual database migrations needed

**Manual Steps**:
1. Backup data and uploads directories
2. Upload new files
3. Run `setup_v12f.sh` or manually create directories
4. Test new features

**Estimated Time**: 10-15 minutes

### Backward Compatibility

**Maintained**:
- All existing pages still work
- Old gallery still accessible as `?page=gallery`
- Old boards listing still accessible as `?page=boards`
- All user data preserved
- All uploaded images preserved

**Breaking Changes**:
- None! Navigation updated but old URLs still work

---

## Browser Support

**Fully Supported**:
- Chrome 90+ ✓
- Firefox 88+ ✓
- Safari 14+ ✓
- Edge 90+ ✓
- Opera 76+ ✓

**Mobile Support**:
- iOS Safari 14+ ✓
- Chrome Mobile 90+ ✓
- Samsung Internet 14+ ✓

**Requirements**:
- JavaScript enabled
- Cookies enabled
- Modern CSS support

---

## Performance Benchmarks

**Page Load Times** (on typical shared hosting, 100 images):
- Home Page: ~450ms
- Community Portal: ~500ms
- Enhanced Gallery: ~600ms (42 images)
- TGP Browse: ~400ms (12 collections)
- TGP View: ~450ms (8 images)

**Memory Usage**:
- Base: ~2MB per request
- Gallery: +3-5MB (depends on image count)
- Community Portal: +2MB

**Database Operations**:
- Flat-file system (no SQL)
- Average 5-10 file reads per page
- Cached where possible

---

## Known Issues

### Minor Issues

1. **Photo Rotator on Slow Connections**
   - Images may load progressively
   - **Workaround**: Preload critical images

2. **TGP Create on Mobile**
   - Image selector requires scrolling on small screens
   - **Workaround**: Use landscape mode or tablet

3. **Board Thumbnails on Upload**
   - Large images may take time to process
   - **Workaround**: Resize images before upload

### Limitations

1. **Flat-File Database**
   - Not ideal for 10,000+ images
   - **Solution**: Consider MySQL migration for large sites

2. **No Real-time Updates**
   - Activity stream requires page refresh
   - **Future**: WebSocket support planned

3. **Limited Image Formats**
   - No AVIF or JXL support yet
   - **Future**: Planned for v13

---

## Future Roadmap

### v12g (Planned)

- User following system
- Activity notifications
- Enhanced search with full-text
- Mobile app (PWA)

### v13 (Planned)

- Real-time updates (WebSockets)
- Advanced analytics
- API v2 with OAuth
- Plugin system

### Long Term

- Multi-site network support
- Federation protocol
- AI-powered tagging
- Video support

---

## Credits

**Lead Developer**: PXLBoard Team  
**Contributors**: Community feedback and testing  
**Inspiration**: Modern booru sites, contemporary imageboards

**Special Thanks**:
- Bootstrap team for UI framework
- PHP community for guidance
- Beta testers for feedback

---

## Support

**Documentation**:
- README_v12f.md - Getting started
- ENHANCEMENT_GUIDE_v12f.md - Detailed implementation
- CHANGELOG_v12f.md - Complete feature list

**Community**:
- GitHub Issues (for bug reports)
- Community Forums (for discussions)
- Wiki (for guides and tutorials)

---

## License

PXLBoard v12f is released under the MIT License.

---

## Final Notes

Version 12f represents a significant evolution of PXLBoard, transforming it from a simple imageboard into a full-featured community platform. The new features provide users with modern tools for content discovery, curation, and engagement.

We're excited to see how communities use these new features!

**Happy Board Building!**

---

*Last Updated: January 31, 2026*  
*Document Version: 1.0*
