<?php
/**
 * Flat File Database Handler
 */

class FlatFileDB {
    private $dataDir;
    
    public function __construct($dataDir) {
        $this->dataDir = $dataDir;
        $this->init();
    }
    
    private function init() {
        // Create base data directory first
        if (!is_dir($this->dataDir)) {
            @mkdir($this->dataDir, 0755, true);
        }
        
        $dirs = [
            $this->dataDir,
            $this->dataDir . '/users',
            $this->dataDir . '/images',
            $this->dataDir . '/tags',
            $this->dataDir . '/comments',
            $this->dataDir . '/sessions',
            $this->dataDir . '/cache',
            $this->dataDir . '/ratings',
            $this->dataDir . '/favorites',
            $this->dataDir . '/forum_topics',
            $this->dataDir . '/forum_replies',
            $this->dataDir . '/channels',
            $this->dataDir . '/extensions',
            $this->dataDir . '/blog_posts',
            $this->dataDir . '/blog_comments',
            $this->dataDir . '/wiki_pages',
            $this->dataDir . '/wiki_revisions',
            $this->dataDir . '/notifications',
            $this->dataDir . '/moderation_queue',
            $this->dataDir . '/user_hides',
            $this->dataDir . '/boards',
            $this->dataDir . '/board_threads',
            $this->dataDir . '/board_posts',
            $this->dataDir . '/tgp_posts',
            $this->dataDir . '/tgp_likes'
        ];
        
        foreach ($dirs as $dir) {
            if (!is_dir($dir)) {
                @mkdir($dir, 0755, true);
            }
        }
        
        // Create .htaccess to protect data directory
        $htaccess = $this->dataDir . '/.htaccess';
        if (!file_exists($htaccess)) {
            @file_put_contents($htaccess, "Deny from all\n");
        }
    }
    
    // Generic CRUD operations
    public function save($collection, $id, $data) {
        $file = $this->dataDir . '/' . $collection . '/' . $id . '.json';
        $data['updated_at'] = time();
        return file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT)) !== false;
    }
    
    public function get($collection, $id) {
        $file = $this->dataDir . '/' . $collection . '/' . $id . '.json';
        if (!file_exists($file)) {
            return null;
        }
        $data = json_decode(file_get_contents($file), true);
        if ($data !== null) {
            $data['id'] = $id;
        }
        return $data;
    }
    
    public function delete($collection, $id) {
        $file = $this->dataDir . '/' . $collection . '/' . $id . '.json';
        if (file_exists($file)) {
            return unlink($file);
        }
        return false;
    }
    
    public function getAll($collection, $limit = null, $offset = 0) {
        $dir = $this->dataDir . '/' . $collection;
        if (!is_dir($dir)) {
            return [];
        }
        
        $files = glob($dir . '/*.json');
        $items = [];
        
        // Sort by modification time (newest first)
        usort($files, function($a, $b) {
            return filemtime($b) - filemtime($a);
        });
        
        if ($limit !== null) {
            $files = array_slice($files, $offset, $limit);
        }
        
        foreach ($files as $file) {
            $data = json_decode(file_get_contents($file), true);
            $data['id'] = basename($file, '.json');
            $items[] = $data;
        }
        
        return $items;
    }
    
    public function count($collection) {
        $dir = $this->dataDir . '/' . $collection;
        if (!is_dir($dir)) {
            return 0;
        }
        return count(glob($dir . '/*.json'));
    }
    
    public function search($collection, $field, $value) {
        $items = $this->getAll($collection);
        $results = [];
        
        foreach ($items as $item) {
            if (isset($item[$field]) && stripos($item[$field], $value) !== false) {
                $results[] = $item;
            }
        }
        
        return $results;
    }
    
    public function getNextId($collection) {
        $counterFile = $this->dataDir . '/' . $collection . '/_counter.txt';
        
        if (!file_exists($counterFile)) {
            file_put_contents($counterFile, '1');
            return 1;
        }
        
        $counter = (int)file_get_contents($counterFile);
        $counter++;
        file_put_contents($counterFile, $counter);
        
        return $counter;
    }
}
