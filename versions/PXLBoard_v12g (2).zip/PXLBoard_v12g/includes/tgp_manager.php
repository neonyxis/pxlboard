<?php
/**
 * TGP (Thumbnail Gallery Post) System
 * Allows users to create curated gallery posts with multiple images
 */

class TGPManager {
    private $db;
    
    public function __construct($db) {
        $this->db = $db;
        $this->initTGPCollection();
    }
    
    private function initTGPCollection() {
        $dir = 'data/tgp_posts';
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
    }
    
    /**
     * Create a new TGP post
     */
    public function createPost($data, $userId) {
        $postId = uniqid('tgp_', true);
        
        $post = [
            'id' => $postId,
            'title' => $data['title'] ?? 'Untitled Gallery',
            'description' => $data['description'] ?? '',
            'author_id' => $userId,
            'author' => $data['author'] ?? 'Anonymous',
            'images' => $data['images'] ?? [],
            'tags' => $data['tags'] ?? [],
            'category' => $data['category'] ?? 'general',
            'is_featured' => false,
            'views' => 0,
            'likes' => 0,
            'comments_count' => 0,
            'created_at' => time(),
            'updated_at' => time(),
            'status' => 'published' // published, draft, archived
        ];
        
        if ($this->db->save('tgp_posts', $postId, $post)) {
            return ['success' => true, 'post_id' => $postId];
        }
        
        return ['success' => false, 'error' => 'Failed to create TGP post'];
    }
    
    /**
     * Update TGP post
     */
    public function updatePost($postId, $data, $userId) {
        $post = $this->db->get('tgp_posts', $postId);
        
        if (!$post) {
            return ['success' => false, 'error' => 'Post not found'];
        }
        
        // Check permissions
        $user = $this->db->get('users', $userId);
        if ($post['author_id'] !== $userId && $user['role'] !== 'admin') {
            return ['success' => false, 'error' => 'Permission denied'];
        }
        
        // Update fields
        if (isset($data['title'])) $post['title'] = $data['title'];
        if (isset($data['description'])) $post['description'] = $data['description'];
        if (isset($data['images'])) $post['images'] = $data['images'];
        if (isset($data['tags'])) $post['tags'] = $data['tags'];
        if (isset($data['category'])) $post['category'] = $data['category'];
        if (isset($data['status'])) $post['status'] = $data['status'];
        
        $post['updated_at'] = time();
        
        if ($this->db->save('tgp_posts', $postId, $post)) {
            return ['success' => true];
        }
        
        return ['success' => false, 'error' => 'Failed to update post'];
    }
    
    /**
     * Delete TGP post
     */
    public function deletePost($postId, $userId) {
        $post = $this->db->get('tgp_posts', $postId);
        
        if (!$post) {
            return ['success' => false, 'error' => 'Post not found'];
        }
        
        // Check permissions
        $user = $this->db->get('users', $userId);
        if ($post['author_id'] !== $userId && $user['role'] !== 'admin') {
            return ['success' => false, 'error' => 'Permission denied'];
        }
        
        if ($this->db->delete('tgp_posts', $postId)) {
            return ['success' => true];
        }
        
        return ['success' => false, 'error' => 'Failed to delete post'];
    }
    
    /**
     * Get TGP post
     */
    public function getPost($postId) {
        return $this->db->get('tgp_posts', $postId);
    }
    
    /**
     * Get all TGP posts with filtering
     */
    public function getPosts($filters = []) {
        $posts = $this->db->getAll('tgp_posts');
        
        // Filter by category
        if (!empty($filters['category'])) {
            $posts = array_filter($posts, function($post) use ($filters) {
                return $post['category'] === $filters['category'];
            });
        }
        
        // Filter by status
        if (!empty($filters['status'])) {
            $posts = array_filter($posts, function($post) use ($filters) {
                return $post['status'] === $filters['status'];
            });
        } else {
            // Default: only show published posts
            $posts = array_filter($posts, function($post) {
                return $post['status'] === 'published';
            });
        }
        
        // Filter by author
        if (!empty($filters['author_id'])) {
            $posts = array_filter($posts, function($post) use ($filters) {
                return $post['author_id'] === $filters['author_id'];
            });
        }
        
        // Sort
        $sortBy = $filters['sort'] ?? 'newest';
        switch ($sortBy) {
            case 'popular':
                usort($posts, function($a, $b) {
                    return ($b['views'] ?? 0) - ($a['views'] ?? 0);
                });
                break;
            case 'likes':
                usort($posts, function($a, $b) {
                    return ($b['likes'] ?? 0) - ($a['likes'] ?? 0);
                });
                break;
            case 'oldest':
                usort($posts, function($a, $b) {
                    return ($a['created_at'] ?? 0) - ($b['created_at'] ?? 0);
                });
                break;
            case 'newest':
            default:
                usort($posts, function($a, $b) {
                    return ($b['created_at'] ?? 0) - ($a['created_at'] ?? 0);
                });
                break;
        }
        
        return $posts;
    }
    
    /**
     * Increment view count
     */
    public function incrementViews($postId) {
        $post = $this->db->get('tgp_posts', $postId);
        if ($post) {
            $post['views'] = ($post['views'] ?? 0) + 1;
            $this->db->save('tgp_posts', $postId, $post);
        }
    }
    
    /**
     * Toggle like on post
     */
    public function toggleLike($postId, $userId) {
        $likeId = $postId . '_' . $userId;
        $existingLike = $this->db->get('tgp_likes', $likeId);
        
        $post = $this->db->get('tgp_posts', $postId);
        if (!$post) {
            return ['success' => false, 'error' => 'Post not found'];
        }
        
        if ($existingLike) {
            // Unlike
            $this->db->delete('tgp_likes', $likeId);
            $post['likes'] = max(0, ($post['likes'] ?? 0) - 1);
            $this->db->save('tgp_posts', $postId, $post);
            return ['success' => true, 'liked' => false, 'likes' => $post['likes']];
        } else {
            // Like
            $this->db->save('tgp_likes', $likeId, [
                'post_id' => $postId,
                'user_id' => $userId,
                'created_at' => time()
            ]);
            $post['likes'] = ($post['likes'] ?? 0) + 1;
            $this->db->save('tgp_posts', $postId, $post);
            return ['success' => true, 'liked' => true, 'likes' => $post['likes']];
        }
    }
    
    /**
     * Check if user has liked a post
     */
    public function hasLiked($postId, $userId) {
        $likeId = $postId . '_' . $userId;
        return $this->db->get('tgp_likes', $likeId) !== null;
    }
    
    /**
     * Get featured posts
     */
    public function getFeaturedPosts($limit = 5) {
        $posts = $this->db->getAll('tgp_posts');
        $featured = array_filter($posts, function($post) {
            return ($post['is_featured'] ?? false) && $post['status'] === 'published';
        });
        
        usort($featured, function($a, $b) {
            return ($b['created_at'] ?? 0) - ($a['created_at'] ?? 0);
        });
        
        return array_slice($featured, 0, $limit);
    }
    
    /**
     * Set post as featured (admin only)
     */
    public function setFeatured($postId, $featured, $userId) {
        $user = $this->db->get('users', $userId);
        if (!$user || $user['role'] !== 'admin') {
            return ['success' => false, 'error' => 'Permission denied'];
        }
        
        $post = $this->db->get('tgp_posts', $postId);
        if (!$post) {
            return ['success' => false, 'error' => 'Post not found'];
        }
        
        $post['is_featured'] = (bool)$featured;
        $this->db->save('tgp_posts', $postId, $post);
        
        return ['success' => true];
    }
}
