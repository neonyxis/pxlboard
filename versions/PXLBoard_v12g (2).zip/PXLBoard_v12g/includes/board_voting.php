<?php
/**
 * Voting System for Boards
 */

class BoardVoting {
    private $db;
    
    public function __construct($db) {
        $this->db = $db;
    }
    
    /**
     * Vote on a thread or post
     */
    public function vote($itemType, $itemId, $userId, $voteType) {
        if (!in_array($itemType, ['thread', 'post'])) return false;
        if (!in_array($voteType, ['up', 'down'])) return false;
        
        $collection = $itemType === 'thread' ? 'board_threads' : 'board_posts';
        $item = $this->db->get($collection, $itemId);
        if (!$item) return false;
        
        $votes = $item['votes'] ?? [];
        $existingVote = null;
        
        // Check if user already voted
        foreach ($votes as $key => $vote) {
            if ($vote['user_id'] === $userId) {
                $existingVote = $key;
                break;
            }
        }
        
        if ($existingVote !== null) {
            // Update existing vote
            if ($votes[$existingVote]['type'] === $voteType) {
                // Remove vote if clicking same button
                unset($votes[$existingVote]);
                $votes = array_values($votes);
            } else {
                // Change vote
                $votes[$existingVote]['type'] = $voteType;
                $votes[$existingVote]['updated_at'] = time();
            }
        } else {
            // New vote
            $votes[] = [
                'user_id' => $userId,
                'type' => $voteType,
                'created_at' => time()
            ];
        }
        
        $item['votes'] = $votes;
        $item['vote_score'] = $this->calculateScore($votes);
        
        return $this->db->save($collection, $itemId, $item);
    }
    
    /**
     * Calculate vote score
     */
    private function calculateScore($votes) {
        $score = 0;
        foreach ($votes as $vote) {
            $score += $vote['type'] === 'up' ? 1 : -1;
        }
        return $score;
    }
    
    /**
     * Get user's vote on an item
     */
    public function getUserVote($itemType, $itemId, $userId) {
        $collection = $itemType === 'thread' ? 'board_threads' : 'board_posts';
        $item = $this->db->get($collection, $itemId);
        if (!$item) return null;
        
        $votes = $item['votes'] ?? [];
        foreach ($votes as $vote) {
            if ($vote['user_id'] === $userId) {
                return $vote['type'];
            }
        }
        return null;
    }
    
    /**
     * Get vote counts
     */
    public function getVoteCounts($itemType, $itemId) {
        $collection = $itemType === 'thread' ? 'board_threads' : 'board_posts';
        $item = $this->db->get($collection, $itemId);
        if (!$item) return ['up' => 0, 'down' => 0, 'score' => 0];
        
        $votes = $item['votes'] ?? [];
        $up = 0;
        $down = 0;
        
        foreach ($votes as $vote) {
            if ($vote['type'] === 'up') $up++;
            else $down++;
        }
        
        return [
            'up' => $up,
            'down' => $down,
            'score' => $up - $down
        ];
    }
    
    /**
     * Update user karma based on votes
     */
    public function updateUserKarma($userId) {
        $threads = $this->db->getAll('board_threads');
        $posts = $this->db->getAll('board_posts');
        
        $totalKarma = 0;
        
        foreach ($threads as $thread) {
            if (($thread['author_id'] ?? null) === $userId) {
                $totalKarma += $thread['vote_score'] ?? 0;
            }
        }
        
        foreach ($posts as $post) {
            if (($post['author_id'] ?? null) === $userId) {
                $totalKarma += $post['vote_score'] ?? 0;
            }
        }
        
        // Update user karma
        $user = $this->db->get('users', $userId);
        if ($user) {
            $user['board_karma'] = $totalKarma;
            $this->db->save('users', $userId, $user);
        }
        
        return $totalKarma;
    }
}
