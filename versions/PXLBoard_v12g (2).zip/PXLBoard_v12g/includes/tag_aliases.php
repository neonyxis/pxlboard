<?php
/**
 * Tag Aliases System
 * Redirects old/alternate tag names to canonical tags
 */

class TagAliasSystem {
    private $db;
    private $aliasesFile;
    
    public function __construct($db) {
        $this->db = $db;
        $this->aliasesFile = DATA_DIR . '/tag_aliases.json';
    }
    
    /**
     * Get all tag aliases
     */
    public function getAllAliases() {
        if (!file_exists($this->aliasesFile)) {
            return [];
        }
        
        $content = @file_get_contents($this->aliasesFile);
        return $content ? json_decode($content, true) : [];
    }
    
    /**
     * Save aliases to file
     */
    private function saveAliases($aliases) {
        return file_put_contents(
            $this->aliasesFile, 
            json_encode($aliases, JSON_PRETTY_PRINT)
        ) !== false;
    }
    
    /**
     * Add a tag alias
     */
    public function addAlias($alias, $canonical) {
        $aliases = $this->getAllAliases();
        
        // Prevent circular aliases
        if ($this->resolveTags([$canonical])[0] === $alias) {
            return false;
        }
        
        $aliases[$alias] = $canonical;
        return $this->saveAliases($aliases);
    }
    
    /**
     * Remove a tag alias
     */
    public function removeAlias($alias) {
        $aliases = $this->getAllAliases();
        
        if (isset($aliases[$alias])) {
            unset($aliases[$alias]);
            return $this->saveAliases($aliases);
        }
        
        return false;
    }
    
    /**
     * Resolve a single tag to its canonical form
     */
    public function resolveTag($tag) {
        $aliases = $this->getAllAliases();
        $tag = strtolower(trim($tag));
        
        // Follow alias chain (max 10 levels to prevent infinite loops)
        $maxDepth = 10;
        $depth = 0;
        
        while (isset($aliases[$tag]) && $depth < $maxDepth) {
            $tag = $aliases[$tag];
            $depth++;
        }
        
        return $tag;
    }
    
    /**
     * Resolve multiple tags to their canonical forms
     */
    public function resolveTags($tags) {
        return array_map([$this, 'resolveTag'], $tags);
    }
    
    /**
     * Get canonical tag for an alias
     */
    public function getCanonical($alias) {
        $aliases = $this->getAllAliases();
        return $aliases[$alias] ?? null;
    }
    
    /**
     * Get all aliases that point to a canonical tag
     */
    public function getAliasesFor($canonical) {
        $aliases = $this->getAllAliases();
        $results = [];
        
        foreach ($aliases as $alias => $target) {
            if ($this->resolveTag($alias) === $canonical) {
                $results[] = $alias;
            }
        }
        
        return $results;
    }
    
    /**
     * Update all images using an old tag to use the new canonical tag
     */
    public function migrateTag($oldTag, $newTag) {
        $images = $this->db->getAll('images');
        $updated = 0;
        
        foreach ($images as $image) {
            if (isset($image['tags']) && is_array($image['tags'])) {
                $originalTags = $image['tags'];
                $image['tags'] = array_map(function($tag) use ($oldTag, $newTag) {
                    return strcasecmp($tag, $oldTag) === 0 ? $newTag : $tag;
                }, $image['tags']);
                
                // Only save if tags changed
                if ($originalTags !== $image['tags']) {
                    // Remove duplicates
                    $image['tags'] = array_values(array_unique($image['tags']));
                    $this->db->save('images', $image['id'], $image);
                    $updated++;
                }
            }
        }
        
        return $updated;
    }
    
    /**
     * Get statistics about aliases
     */
    public function getStats() {
        $aliases = $this->getAllAliases();
        $canonical = array_unique(array_values($aliases));
        
        return [
            'total_aliases' => count($aliases),
            'canonical_tags' => count($canonical),
            'aliases' => $aliases
        ];
    }
}

/**
 * Global helper functions
 */

/**
 * Get tag alias system instance
 */
function getTagAliasSystem() {
    global $db;
    return new TagAliasSystem($db);
}

/**
 * Resolve a tag to its canonical form
 */
function resolveTag($tag) {
    $system = getTagAliasSystem();
    return $system->resolveTag($tag);
}

/**
 * Resolve multiple tags to their canonical forms
 */
function resolveTags($tags) {
    $system = getTagAliasSystem();
    return $system->resolveTags($tags);
}
