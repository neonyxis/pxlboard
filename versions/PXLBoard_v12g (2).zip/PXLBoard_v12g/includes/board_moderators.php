<?php
/**
 * Board Moderator System
 */

class BoardModerators {
    private $db;
    
    public function __construct($db) {
        $this->db = $db;
    }
    
    /**
     * Check if user is a moderator of a board
     */
    public function isModerator($boardId, $userId) {
        if (!$boardId || !$userId) return false;
        
        $board = $this->db->get('boards', $boardId);
        if (!$board) return false;
        
        // Creator is always top-level mod
        if (isset($board['creator_id']) && $board['creator_id'] === $userId) {
            return true;
        }
        
        // Check moderator list
        $moderators = $board['moderators'] ?? [];
        foreach ($moderators as $mod) {
            if ($mod['user_id'] === $userId) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Check if user is top-level moderator (creator or promoted to top-level)
     */
    public function isTopLevelMod($boardId, $userId) {
        if (!$boardId || !$userId) return false;
        
        $board = $this->db->get('boards', $boardId);
        if (!$board) return false;
        
        // Creator is always top-level
        if (isset($board['creator_id']) && $board['creator_id'] === $userId) {
            return true;
        }
        
        // Check if promoted to top-level
        $moderators = $board['moderators'] ?? [];
        foreach ($moderators as $mod) {
            if ($mod['user_id'] === $userId && ($mod['top_level'] ?? false)) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Add moderator to board
     */
    public function addModerator($boardId, $userId, $username, $topLevel = false) {
        $board = $this->db->get('boards', $boardId);
        if (!$board) return false;
        
        $moderators = $board['moderators'] ?? [];
        
        // Check if already a moderator
        foreach ($moderators as $mod) {
            if ($mod['user_id'] === $userId) {
                return false; // Already a moderator
            }
        }
        
        // Add new moderator
        $moderators[] = [
            'user_id' => $userId,
            'username' => $username,
            'top_level' => $topLevel,
            'added_at' => time()
        ];
        
        $board['moderators'] = $moderators;
        return $this->db->save('boards', $boardId, $board);
    }
    
    /**
     * Remove moderator from board
     */
    public function removeModerator($boardId, $userId) {
        $board = $this->db->get('boards', $boardId);
        if (!$board) return false;
        
        $moderators = $board['moderators'] ?? [];
        $moderators = array_filter($moderators, function($mod) use ($userId) {
            return $mod['user_id'] !== $userId;
        });
        
        $board['moderators'] = array_values($moderators);
        return $this->db->save('boards', $boardId, $board);
    }
    
    /**
     * Get all moderators of a board
     */
    public function getModerators($boardId) {
        $board = $this->db->get('boards', $boardId);
        if (!$board) return [];
        
        $mods = $board['moderators'] ?? [];
        
        // Add creator as first mod
        if (isset($board['creator_id'])) {
            array_unshift($mods, [
                'user_id' => $board['creator_id'],
                'username' => $board['creator_name'] ?? 'Unknown',
                'top_level' => true,
                'is_creator' => true,
                'added_at' => $board['created_at'] ?? time()
            ]);
        }
        
        return $mods;
    }
}
