<?php
/**
 * Image Grabber System
 * Automatically pulls images from websites, boorus, and other sources
 */

class ImageGrabber {
    private $db;
    private $uploadDir;
    private $sources = [];
    
    // Supported source types
    const SOURCE_DANBOORU = 'danbooru';
    const SOURCE_GELBOORU = 'gelbooru';
    const SOURCE_SAFEBOORU = 'safebooru';
    const SOURCE_KONACHAN = 'konachan';
    const SOURCE_YANDERE = 'yandere';
    const SOURCE_RSS_FEED = 'rss';
    const SOURCE_IMGUR = 'imgur';
    const SOURCE_PINTEREST = 'pinterest';
    const SOURCE_CUSTOM_URL = 'custom';
    
    public function __construct($db, $uploadDir = 'uploads') {
        $this->db = $db;
        $this->uploadDir = rtrim($uploadDir, '/');
        $this->loadSources();
    }
    
    /**
     * Load configured sources from database
     */
    private function loadSources() {
        $sources = $this->db->getAll('grabber_sources') ?? [];
        $this->sources = $sources;
    }
    
    /**
     * Add a new source
     * @param string $type Source type
     * @param array $config Source configuration
     * @return array Result
     */
    public function addSource($type, $config) {
        $sourceId = uniqid('source_', true);
        
        $source = [
            'id' => $sourceId,
            'type' => $type,
            'name' => $config['name'] ?? $type,
            'enabled' => $config['enabled'] ?? true,
            'config' => $config,
            'last_run' => null,
            'created_at' => time()
        ];
        
        $this->db->save('grabber_sources', $sourceId, $source);
        $this->sources[$sourceId] = $source;
        
        return ['success' => true, 'source_id' => $sourceId];
    }
    
    /**
     * Grab images from a specific source
     * @param string $sourceId Source ID
     * @param int $limit Maximum number of images to grab
     * @return array Result with grabbed images
     */
    public function grabFromSource($sourceId, $limit = 10) {
        $source = $this->sources[$sourceId] ?? null;
        
        if (!$source || !$source['enabled']) {
            return ['success' => false, 'error' => 'Source not found or disabled'];
        }
        
        $method = 'grab' . ucfirst($source['type']);
        if (!method_exists($this, $method)) {
            return ['success' => false, 'error' => 'Unsupported source type'];
        }
        
        try {
            $images = $this->$method($source['config'], $limit);
            
            // Update last run time
            $source['last_run'] = time();
            $this->db->save('grabber_sources', $sourceId, $source);
            
            return ['success' => true, 'images' => $images, 'count' => count($images)];
            
        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Grab images from Danbooru
     * @param array $config Configuration
     * @param int $limit Limit
     * @return array Images
     */
    private function grabDanbooru($config, $limit = 10) {
        $tags = $config['tags'] ?? '';
        $rating = $config['rating'] ?? 's'; // s=safe, q=questionable, e=explicit
        $api_url = "https://danbooru.donmai.us/posts.json";
        
        $params = [
            'tags' => $tags . " rating:{$rating}",
            'limit' => $limit
        ];
        
        $url = $api_url . '?' . http_build_query($params);
        $response = $this->fetchUrl($url);
        
        if (!$response) {
            return [];
        }
        
        $data = json_decode($response, true);
        $images = [];
        
        foreach ($data as $post) {
            $images[] = [
                'source_url' => "https://danbooru.donmai.us/posts/" . $post['id'],
                'image_url' => $post['file_url'] ?? $post['large_file_url'],
                'thumbnail_url' => $post['preview_file_url'],
                'title' => 'Danbooru #' . $post['id'],
                'tags' => explode(' ', $post['tag_string'] ?? ''),
                'rating' => $post['rating'],
                'artist' => $post['tag_string_artist'] ?? '',
                'source_id' => 'danbooru_' . $post['id'],
                'metadata' => $post
            ];
        }
        
        return $images;
    }
    
    /**
     * Grab images from Gelbooru
     * @param array $config Configuration
     * @param int $limit Limit
     * @return array Images
     */
    private function grabGelbooru($config, $limit = 10) {
        $tags = $config['tags'] ?? '';
        $api_url = "https://gelbooru.com/index.php";
        
        $params = [
            'page' => 'dapi',
            's' => 'post',
            'q' => 'index',
            'json' => '1',
            'tags' => $tags,
            'limit' => $limit
        ];
        
        $url = $api_url . '?' . http_build_query($params);
        $response = $this->fetchUrl($url);
        
        if (!$response) {
            return [];
        }
        
        $data = json_decode($response, true);
        $images = [];
        
        if (isset($data['post']) && is_array($data['post'])) {
            foreach ($data['post'] as $post) {
                $images[] = [
                    'source_url' => "https://gelbooru.com/index.php?page=post&s=view&id=" . $post['id'],
                    'image_url' => $post['file_url'],
                    'thumbnail_url' => $post['preview_url'],
                    'title' => 'Gelbooru #' . $post['id'],
                    'tags' => explode(' ', $post['tags'] ?? ''),
                    'rating' => $post['rating'],
                    'source_id' => 'gelbooru_' . $post['id'],
                    'metadata' => $post
                ];
            }
        }
        
        return $images;
    }
    
    /**
     * Grab images from RSS feed
     * @param array $config Configuration
     * @param int $limit Limit
     * @return array Images
     */
    private function grabRss($config, $limit = 10) {
        $feed_url = $config['url'] ?? '';
        
        if (empty($feed_url)) {
            return [];
        }
        
        $response = $this->fetchUrl($feed_url);
        if (!$response) {
            return [];
        }
        
        $xml = simplexml_load_string($response);
        if (!$xml) {
            return [];
        }
        
        $images = [];
        $count = 0;
        
        // Parse RSS items
        foreach ($xml->channel->item as $item) {
            if ($count >= $limit) break;
            
            // Try to find image in various fields
            $image_url = null;
            
            // Check media:content
            if (isset($item->children('media', true)->content)) {
                $image_url = (string) $item->children('media', true)->content->attributes()->url;
            }
            // Check enclosure
            elseif (isset($item->enclosure)) {
                $image_url = (string) $item->enclosure->attributes()->url;
            }
            // Check description for img tags
            elseif (isset($item->description)) {
                preg_match('/<img[^>]+src=["\']([^"\']+)["\']/', (string) $item->description, $matches);
                if (!empty($matches[1])) {
                    $image_url = $matches[1];
                }
            }
            
            if ($image_url) {
                $images[] = [
                    'source_url' => (string) $item->link,
                    'image_url' => $image_url,
                    'thumbnail_url' => $image_url,
                    'title' => (string) $item->title,
                    'description' => strip_tags((string) $item->description),
                    'tags' => [],
                    'source_id' => md5($image_url),
                    'metadata' => [
                        'pubDate' => (string) $item->pubDate
                    ]
                ];
                $count++;
            }
        }
        
        return $images;
    }
    
    /**
     * Grab images from custom URL
     * @param array $config Configuration
     * @param int $limit Limit
     * @return array Images
     */
    private function grabCustom($config, $limit = 10) {
        $url = $config['url'] ?? '';
        $selector = $config['selector'] ?? 'img';
        
        if (empty($url)) {
            return [];
        }
        
        $html = $this->fetchUrl($url);
        if (!$html) {
            return [];
        }
        
        $images = [];
        
        // Simple regex-based image extraction
        preg_match_all('/<img[^>]+src=["\']([^"\']+)["\'][^>]*>/i', $html, $matches);
        
        $count = 0;
        foreach ($matches[1] as $img_url) {
            if ($count >= $limit) break;
            
            // Make URL absolute if needed
            if (!preg_match('/^https?:\/\//', $img_url)) {
                $base_url = parse_url($url, PHP_URL_SCHEME) . '://' . parse_url($url, PHP_URL_HOST);
                $img_url = $base_url . $img_url;
            }
            
            $images[] = [
                'source_url' => $url,
                'image_url' => $img_url,
                'thumbnail_url' => $img_url,
                'title' => basename($img_url),
                'tags' => [],
                'source_id' => md5($img_url),
                'metadata' => []
            ];
            $count++;
        }
        
        return $images;
    }
    
    /**
     * Download and import an image
     * @param array $imageData Image data from grabber
     * @param string $uploader Uploader username
     * @param string $channel Channel to upload to
     * @return array Result
     */
    public function importImage($imageData, $uploader = 'ImageGrabber', $channel = 'default') {
        try {
            // Check if already imported
            $existing = $this->db->query(
                "SELECT * FROM images WHERE source_id = ?",
                [$imageData['source_id']]
            );
            
            if (!empty($existing)) {
                return ['success' => false, 'error' => 'Image already imported'];
            }
            
            // Download image
            $imageContent = $this->fetchUrl($imageData['image_url']);
            if (!$imageContent) {
                return ['success' => false, 'error' => 'Failed to download image'];
            }
            
            // Generate filename
            $ext = pathinfo(parse_url($imageData['image_url'], PHP_URL_PATH), PATHINFO_EXTENSION);
            $filename = uniqid('grabbed_') . '.' . ($ext ?: 'jpg');
            $filepath = $this->uploadDir . '/' . $filename;
            
            // Save image
            if (!file_put_contents($filepath, $imageContent)) {
                return ['success' => false, 'error' => 'Failed to save image'];
            }
            
            // Create thumbnail
            $thumbnailPath = $this->createThumbnail($filepath);
            
            // Save to database
            $imageId = uniqid('img_', true);
            $image = [
                'id' => $imageId,
                'filename' => $filename,
                'thumbnail' => $thumbnailPath,
                'title' => $imageData['title'] ?? 'Untitled',
                'description' => $imageData['description'] ?? '',
                'tags' => implode(' ', $imageData['tags'] ?? []),
                'uploader' => $uploader,
                'channel' => $channel,
                'source_url' => $imageData['source_url'] ?? '',
                'source_id' => $imageData['source_id'],
                'uploaded_at' => time(),
                'score' => 0,
                'metadata' => $imageData['metadata'] ?? []
            ];
            
            $this->db->save('images', $imageId, $image);
            
            return ['success' => true, 'image_id' => $imageId];
            
        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Fetch URL content
     * @param string $url URL to fetch
     * @return string|false Content or false on failure
     */
    private function fetchUrl($url) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_USERAGENT, 'PXLBoard Image Grabber/1.0');
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        
        $response = curl_exec($ch);
        $error = curl_error($ch);
        curl_close($ch);
        
        return $error ? false : $response;
    }
    
    /**
     * Create thumbnail from image
     * @param string $filepath Original image path
     * @return string Thumbnail path
     */
    private function createThumbnail($filepath) {
        $thumbDir = $this->uploadDir . '/thumbnails';
        if (!is_dir($thumbDir)) {
            mkdir($thumbDir, 0755, true);
        }
        
        $filename = basename($filepath);
        $thumbPath = $thumbDir . '/thumb_' . $filename;
        
        // Simple thumbnail creation (would use GD or Imagick in production)
        copy($filepath, $thumbPath);
        
        return $thumbPath;
    }
    
    /**
     * Run all enabled sources
     * @param int $limitPerSource Limit per source
     * @return array Results
     */
    public function runAll($limitPerSource = 10) {
        $results = [];
        
        foreach ($this->sources as $sourceId => $source) {
            if ($source['enabled']) {
                $results[$sourceId] = $this->grabFromSource($sourceId, $limitPerSource);
            }
        }
        
        return $results;
    }
}
