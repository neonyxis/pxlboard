<?php
/**
 * Utility Functions
 */

function escape($string) {
    if ($string === null) {
        return '';
    }
    return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}

function sendEmail($to, $subject, $message, $html = false) {
    // Use basic mail() if SMTP is not enabled
    if (!SMTP_ENABLED) {
        $headers = "From: " . SMTP_FROM . "\r\n";
        $headers .= "Reply-To: " . SMTP_FROM . "\r\n";
        
        if ($html) {
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
        }
        
        return mail($to, $subject, $message, $headers);
    }
    
    // Use SMTP with socket connection
    try {
        $smtp = fsockopen(SMTP_HOST, SMTP_PORT, $errno, $errstr, 30);
        if (!$smtp) {
            error_log("SMTP connection failed: $errstr ($errno)");
            return false;
        }
        
        // Read greeting
        fgets($smtp, 515);
        
        // Send EHLO
        fputs($smtp, "EHLO " . SMTP_HOST . "\r\n");
        fgets($smtp, 515);
        
        // Start TLS if needed
        if (SMTP_SECURE === 'tls') {
            fputs($smtp, "STARTTLS\r\n");
            fgets($smtp, 515);
            stream_socket_enable_crypto($smtp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT);
            fputs($smtp, "EHLO " . SMTP_HOST . "\r\n");
            fgets($smtp, 515);
        }
        
        // Authenticate
        fputs($smtp, "AUTH LOGIN\r\n");
        fgets($smtp, 515);
        fputs($smtp, base64_encode(SMTP_USERNAME) . "\r\n");
        fgets($smtp, 515);
        fputs($smtp, base64_encode(SMTP_PASSWORD) . "\r\n");
        $auth_response = fgets($smtp, 515);
        
        if (strpos($auth_response, '235') === false) {
            fclose($smtp);
            error_log("SMTP authentication failed");
            return false;
        }
        
        // Send mail
        fputs($smtp, "MAIL FROM: <" . SMTP_FROM . ">\r\n");
        fgets($smtp, 515);
        
        fputs($smtp, "RCPT TO: <" . $to . ">\r\n");
        fgets($smtp, 515);
        
        fputs($smtp, "DATA\r\n");
        fgets($smtp, 515);
        
        // Build message
        $headers = "From: " . SMTP_FROM_NAME . " <" . SMTP_FROM . ">\r\n";
        $headers .= "Reply-To: " . SMTP_FROM . "\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        
        if ($html) {
            $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
        } else {
            $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
        }
        
        $email = "Subject: " . $subject . "\r\n";
        $email .= $headers . "\r\n";
        $email .= $message . "\r\n";
        $email .= ".\r\n";
        
        fputs($smtp, $email);
        fgets($smtp, 515);
        
        // Quit
        fputs($smtp, "QUIT\r\n");
        fclose($smtp);
        
        return true;
        
    } catch (Exception $e) {
        error_log("Email sending failed: " . $e->getMessage());
        return false;
    }
}

function generateThumbnail($sourcePath, $destPath, $width, $height) {
    $imageInfo = getimagesize($sourcePath);
    if (!$imageInfo) {
        return false;
    }
    
    list($origWidth, $origHeight, $type) = $imageInfo;
    
    // Create source image
    switch ($type) {
        case IMAGETYPE_JPEG:
            $source = imagecreatefromjpeg($sourcePath);
            break;
        case IMAGETYPE_PNG:
            $source = imagecreatefrompng($sourcePath);
            break;
        case IMAGETYPE_GIF:
            $source = imagecreatefromgif($sourcePath);
            break;
        case IMAGETYPE_WEBP:
            $source = imagecreatefromwebp($sourcePath);
            break;
        default:
            return false;
    }
    
    // Calculate dimensions
    $ratio = min($width / $origWidth, $height / $origHeight);
    $newWidth = (int)($origWidth * $ratio);
    $newHeight = (int)($origHeight * $ratio);
    
    // Create thumbnail
    $thumbnail = imagecreatetruecolor($newWidth, $newHeight);
    
    // Preserve transparency for PNG and GIF
    if ($type === IMAGETYPE_PNG || $type === IMAGETYPE_GIF) {
        imagealphablending($thumbnail, false);
        imagesavealpha($thumbnail, true);
        $transparent = imagecolorallocatealpha($thumbnail, 255, 255, 255, 127);
        imagefilledrectangle($thumbnail, 0, 0, $newWidth, $newHeight, $transparent);
    }
    
    imagecopyresampled($thumbnail, $source, 0, 0, 0, 0, $newWidth, $newHeight, $origWidth, $origHeight);
    
    // Save thumbnail
    $result = false;
    switch ($type) {
        case IMAGETYPE_JPEG:
            $result = imagejpeg($thumbnail, $destPath, 85);
            break;
        case IMAGETYPE_PNG:
            $result = imagepng($thumbnail, $destPath, 8);
            break;
        case IMAGETYPE_GIF:
            $result = imagegif($thumbnail, $destPath);
            break;
        case IMAGETYPE_WEBP:
            $result = imagewebp($thumbnail, $destPath, 85);
            break;
    }
    
    imagedestroy($source);
    imagedestroy($thumbnail);
    
    return $result;
}

function formatBytes($bytes) {
    $units = ['B', 'KB', 'MB', 'GB'];
    $i = 0;
    
    while ($bytes >= 1024 && $i < count($units) - 1) {
        $bytes /= 1024;
        $i++;
    }
    
    return round($bytes, 2) . ' ' . $units[$i];
}

function timeAgo($timestamp) {
    $diff = time() - $timestamp;
    
    if ($diff < 60) {
        return $diff . ' second' . ($diff !== 1 ? 's' : '') . ' ago';
    }
    
    $diff = floor($diff / 60);
    if ($diff < 60) {
        return $diff . ' minute' . ($diff !== 1 ? 's' : '') . ' ago';
    }
    
    $diff = floor($diff / 60);
    if ($diff < 24) {
        return $diff . ' hour' . ($diff !== 1 ? 's' : '') . ' ago';
    }
    
    $diff = floor($diff / 24);
    if ($diff < 30) {
        return $diff . ' day' . ($diff !== 1 ? 's' : '') . ' ago';
    }
    
    $diff = floor($diff / 30);
    if ($diff < 12) {
        return $diff . ' month' . ($diff !== 1 ? 's' : '') . ' ago';
    }
    
    $diff = floor($diff / 12);
    return $diff . ' year' . ($diff !== 1 ? 's' : '') . ' ago';
}

function sanitizeFilename($filename) {
    $filename = preg_replace('/[^a-zA-Z0-9._-]/', '_', $filename);
    return $filename;
}

function getFileExtension($filename) {
    return strtolower(pathinfo($filename, PATHINFO_EXTENSION));
}

function getTheme() {
    if (isset($_COOKIE['theme'])) {
        $theme = $_COOKIE['theme'];
        if (is_dir(THEMES_DIR . '/' . $theme)) {
            return $theme;
        }
    }
    return DEFAULT_THEME;
}

function setTheme($theme) {
    if (is_dir(THEMES_DIR . '/' . $theme)) {
        setcookie('theme', $theme, time() + 31536000, '/'); // 1 year
        return true;
    }
    return false;
}

function getAvailableThemes() {
    $themes = [];
    $dirs = glob(THEMES_DIR . '/*', GLOB_ONLYDIR);
    
    foreach ($dirs as $dir) {
        $themeName = basename($dir);
        $themeInfo = [
            'name' => $themeName,
            'display_name' => ucfirst($themeName)
        ];
        
        $infoFile = $dir . '/theme.json';
        if (file_exists($infoFile)) {
            $info = json_decode(file_get_contents($infoFile), true);
            $themeInfo = array_merge($themeInfo, $info);
        }
        
        $themes[] = $themeInfo;
    }
    
    return $themes;
}

function redirect($url) {
    header('Location: ' . $url);
    exit;
}

function getCurrentUrl() {
    return $_SERVER['REQUEST_URI'];
}

function rrmdir($dir) {
    if (is_dir($dir)) {
        $objects = scandir($dir);
        foreach ($objects as $object) {
            if ($object != "." && $object != "..") {
                if (is_dir($dir . "/" . $object)) {
                    rrmdir($dir . "/" . $object);
                } else {
                    unlink($dir . "/" . $object);
                }
            }
        }
        rmdir($dir);
    }
}

// ================================================================
// SEO-FRIENDLY URL HELPER FUNCTIONS
// ================================================================

/**
 * Create SEO-friendly slug from title
 * @param string $title Title to convert
 * @return string URL-safe slug
 */
function createSlug($title) {
    // Convert to lowercase
    $slug = strtolower(trim($title));
    
    // Replace non-alphanumeric characters with hyphens
    $slug = preg_replace('/[^a-z0-9-]/', '-', $slug);
    
    // Remove multiple consecutive hyphens
    $slug = preg_replace('/-+/', '-', $slug);
    
    // Trim hyphens from ends
    return trim($slug, '-');
}

/**
 * Build SEO-friendly URL for different page types
 * @param string $page Page type (image, user, channel, wiki, blog, forum)
 * @param string $id Resource ID
 * @param string $title Optional title for slug
 * @return string Complete URL path
 */
function getBasePrefix() {
    // Extract the path portion of SITE_URL so that buildUrl works inside subdirectories.
    // e.g. SITE_URL = "https://example.com/pxlboard/V11d"  →  prefix = "/pxlboard/V11d"
    //      SITE_URL = "https://example.com"                 →  prefix = ""
    $path = rtrim(parse_url(SITE_URL, PHP_URL_PATH) ?? '', '/');
    return $path; // empty string for domain-root deployments
}

function buildUrl($page, $id = '', $title = '') {
    $prefix = getBasePrefix();
    switch ($page) {
        case 'image':
            // Convert img_123 to 123
            $imageNum = str_replace('img_', '', $id);
            $slug = !empty($title) ? '/' . createSlug($title) : '';
            return "{$prefix}/image/{$imageNum}{$slug}";
            
        case 'user':
            // $id should be username for SEO URLs
            return "{$prefix}/user/{$id}";
            
        case 'channel':
            return "{$prefix}/channel/{$id}";
            
        case 'wiki':
            return "{$prefix}/wiki/{$id}";
            
        case 'wiki_edit':
            return "{$prefix}/wiki/{$id}/edit";
            
        case 'blog':
            $slug = !empty($title) ? '/' . createSlug($title) : '';
            return "{$prefix}/blogs/{$id}{$slug}";
            
        case 'blog_edit':
            if (empty($id)) {
                return "{$prefix}/blog/new";
            }
            return "{$prefix}/blog/{$id}/edit";
            
        case 'forum':
        case 'forums':
            if (empty($id)) {
                return "{$prefix}/forums";
            }
            $slug = !empty($title) ? '/' . createSlug($title) : '';
            return "{$prefix}/forums/topic/{$id}{$slug}";
            
        case 'tag':
            return "{$prefix}/tag/{$id}";
            
        case 'search':
            return empty($id) ? "{$prefix}/search" : "{$prefix}/search/" . urlencode($id);
            
        case 'rankings':
            return empty($id) ? "{$prefix}/rankings" : "{$prefix}/rankings/{$id}";
            
        case 'gallery':
            return "{$prefix}/gallery";
            
        case 'upload':
            return "{$prefix}/upload";
            
        case 'login':
            return "{$prefix}/login";
            
        case 'register':
            return "{$prefix}/register";
            
        case 'logout':
            return "{$prefix}/logout";
            
        case 'admin':
            return "{$prefix}/admin";
            
        default:
            return "{$prefix}/{$page}";
    }
}

/**
 * Get canonical URL for current page
 * @return string Canonical URL
 */
function getCanonicalUrl() {
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://';
    $host = $_SERVER['HTTP_HOST'];
    $uri = $_SERVER['REQUEST_URI'];
    
    // Remove query string for canonical
    $uri = strtok($uri, '?');
    
    return $protocol . $host . $uri;
}

/**
 * Build query string preserving existing parameters
 * @param array $newParams New parameters to add/update
 * @param array $removeParams Parameters to remove
 * @return string Query string
 */
function buildQueryString($newParams = [], $removeParams = []) {
    $params = $_GET;
    
    // Remove specified parameters
    foreach ($removeParams as $key) {
        unset($params[$key]);
    }
    
    // Add/update parameters
    foreach ($newParams as $key => $value) {
        if ($value === null) {
            unset($params[$key]);
        } else {
            $params[$key] = $value;
        }
    }
    
    return empty($params) ? '' : '?' . http_build_query($params);
}

/**
 * Check if SEO URLs are enabled
 * @return bool
 */
function usingSeoUrls() {
    // Check if we're accessing via SEO URL pattern
    $uri = $_SERVER['REQUEST_URI'];
    $queryString = $_SERVER['QUERY_STRING'] ?? '';
    
    // If no query string and URI doesn't contain index.php, likely SEO URL
    return empty($queryString) && strpos($uri, 'index.php') === false && $uri !== '/';
}

/**
 * Get URL for pagination
 * @param int $page Page number
 * @return string Pagination URL
 */
function getPaginationUrl($page) {
    if (usingSeoUrls()) {
        $currentUrl = strtok($_SERVER['REQUEST_URI'], '?');
        return $currentUrl . '?p=' . $page;
    } else {
        return buildQueryString(['p' => $page]);
    }
}

