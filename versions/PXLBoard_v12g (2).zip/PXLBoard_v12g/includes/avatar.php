<?php
/**
 * Avatar Management System
 * Handles user profile pictures with upload, resize, and gravatar fallback
 */

class AvatarManager {
    private $db;
    private $uploadsDir;
    private $avatarSizes = [
        'small' => 50,
        'medium' => 100,
        'large' => 200
    ];
    
    public function __construct($db) {
        $this->db = $db;
        $this->uploadsDir = UPLOADS_DIR . '/avatars';
        $this->initDirectory();
    }
    
    /**
     * Initialize avatar directory
     */
    private function initDirectory() {
        if (!is_dir($this->uploadsDir)) {
            @mkdir($this->uploadsDir, 0755, true);
        }
        
        foreach ($this->avatarSizes as $size => $pixels) {
            $sizeDir = $this->uploadsDir . '/' . $size;
            if (!is_dir($sizeDir)) {
                @mkdir($sizeDir, 0755, true);
            }
        }
    }
    
    /**
     * Upload and process avatar
     * @param array $file $_FILES array
     * @param string $userId User ID
     * @return array Result with success status
     */
    public function uploadAvatar($file, $userId) {
        // Validate file
        if (!isset($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
            return ['success' => false, 'error' => 'No file uploaded'];
        }
        
        // Check file size (2MB max)
        if ($file['size'] > 2 * 1024 * 1024) {
            return ['success' => false, 'error' => 'File too large. Maximum size is 2MB'];
        }
        
        // Check file type
        $allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mimeType = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);
        
        if (!in_array($mimeType, $allowedTypes)) {
            return ['success' => false, 'error' => 'Invalid file type. Only JPEG, PNG, GIF, and WebP allowed'];
        }
        
        // Generate filename
        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = $userId . '.' . $extension;
        
        // Delete old avatars
        $this->deleteAvatar($userId);
        
        // Process and save in different sizes
        $sourceImage = $this->loadImage($file['tmp_name'], $mimeType);
        if (!$sourceImage) {
            return ['success' => false, 'error' => 'Failed to process image'];
        }
        
        foreach ($this->avatarSizes as $sizeName => $pixels) {
            $resized = $this->resizeAndCrop($sourceImage, $pixels, $pixels);
            $destination = $this->uploadsDir . '/' . $sizeName . '/' . $filename;
            
            if (!$this->saveImage($resized, $destination, $mimeType)) {
                imagedestroy($sourceImage);
                imagedestroy($resized);
                return ['success' => false, 'error' => 'Failed to save avatar'];
            }
            
            imagedestroy($resized);
        }
        
        imagedestroy($sourceImage);
        
        // Update user record
        $user = $this->db->get('users', $userId);
        if ($user) {
            $user['avatar'] = $filename;
            $user['avatar_updated'] = time();
            $this->db->save('users', $userId, $user);
        }
        
        return ['success' => true, 'filename' => $filename];
    }
    
    /**
     * Delete user avatar
     * @param string $userId User ID
     * @return bool
     */
    public function deleteAvatar($userId) {
        $user = $this->db->get('users', $userId);
        if (!$user || !isset($user['avatar'])) {
            return false;
        }
        
        // Delete all size variants
        foreach ($this->avatarSizes as $sizeName => $pixels) {
            $filepath = $this->uploadsDir . '/' . $sizeName . '/' . $user['avatar'];
            if (file_exists($filepath)) {
                @unlink($filepath);
            }
        }
        
        // Update user record
        unset($user['avatar']);
        unset($user['avatar_updated']);
        $this->db->save('users', $userId, $user);
        
        return true;
    }
    
    /**
     * Get avatar URL for user
     * @param string $userId User ID
     * @param string $size Size: small, medium, large
     * @param bool $useGravatar Use gravatar as fallback
     * @return string Avatar URL
     */
    public function getAvatarUrl($userId, $size = 'medium', $useGravatar = true) {
        $user = $this->db->get('users', $userId);
        
        if ($user && isset($user['avatar'])) {
            $path = 'uploads/avatars/' . $size . '/' . $user['avatar'];
            if (file_exists($path)) {
                return $path . '?' . ($user['avatar_updated'] ?? time());
            }
        }
        
        // Fallback to Gravatar
        if ($useGravatar && $user && isset($user['email'])) {
            return $this->getGravatarUrl($user['email'], $this->avatarSizes[$size]);
        }
        
        // Default avatar
        return $this->getDefaultAvatar($size);
    }
    
    /**
     * Get Gravatar URL
     * @param string $email Email address
     * @param int $size Size in pixels
     * @return string Gravatar URL
     */
    private function getGravatarUrl($email, $size = 100) {
        $hash = md5(strtolower(trim($email)));
        $default = urlencode($this->getDefaultAvatar('medium'));
        return "https://www.gravatar.com/avatar/{$hash}?s={$size}&d={$default}";
    }
    
    /**
     * Get default avatar path
     * @param string $size Size name
     * @return string Path to default avatar
     */
    private function getDefaultAvatar($size) {
        // Return path to default avatar image
        // You can create a simple default avatar or use a data URI
        return 'data:image/svg+xml,' . urlencode($this->generateDefaultAvatarSvg($this->avatarSizes[$size]));
    }
    
    /**
     * Generate default avatar SVG
     * @param int $size Size in pixels
     * @return string SVG markup
     */
    private function generateDefaultAvatarSvg($size) {
        return '<svg xmlns="http://www.w3.org/2000/svg" width="' . $size . '" height="' . $size . '" viewBox="0 0 100 100">
            <rect fill="#6c757d" width="100" height="100"/>
            <circle fill="#ffffff" cx="50" cy="35" r="20"/>
            <path fill="#ffffff" d="M50 60 Q30 60 20 80 L80 80 Q70 60 50 60 Z"/>
        </svg>';
    }
    
    /**
     * Load image from file
     * @param string $filepath File path
     * @param string $mimeType MIME type
     * @return resource|false GD image resource
     */
    private function loadImage($filepath, $mimeType) {
        switch ($mimeType) {
            case 'image/jpeg':
            case 'image/jpg':
                return imagecreatefromjpeg($filepath);
            case 'image/png':
                return imagecreatefrompng($filepath);
            case 'image/gif':
                return imagecreatefromgif($filepath);
            case 'image/webp':
                return imagecreatefromwebp($filepath);
            default:
                return false;
        }
    }
    
    /**
     * Save image to file
     * @param resource $image GD image resource
     * @param string $filepath Destination path
     * @param string $mimeType MIME type
     * @return bool Success status
     */
    private function saveImage($image, $filepath, $mimeType) {
        switch ($mimeType) {
            case 'image/jpeg':
            case 'image/jpg':
                return imagejpeg($image, $filepath, 90);
            case 'image/png':
                return imagepng($image, $filepath, 9);
            case 'image/gif':
                return imagegif($image, $filepath);
            case 'image/webp':
                return imagewebp($image, $filepath, 90);
            default:
                return false;
        }
    }
    
    /**
     * Resize and crop image to square
     * @param resource $source Source image
     * @param int $width Target width
     * @param int $height Target height
     * @return resource New image resource
     */
    private function resizeAndCrop($source, $width, $height) {
        $srcWidth = imagesx($source);
        $srcHeight = imagesy($source);
        
        // Calculate crop dimensions (center crop to square)
        if ($srcWidth > $srcHeight) {
            $cropSize = $srcHeight;
            $srcX = ($srcWidth - $cropSize) / 2;
            $srcY = 0;
        } else {
            $cropSize = $srcWidth;
            $srcX = 0;
            $srcY = ($srcHeight - $cropSize) / 2;
        }
        
        // Create new image
        $destination = imagecreatetruecolor($width, $height);
        
        // Preserve transparency
        imagealphablending($destination, false);
        imagesavealpha($destination, true);
        $transparent = imagecolorallocatealpha($destination, 0, 0, 0, 127);
        imagefilledrectangle($destination, 0, 0, $width, $height, $transparent);
        imagealphablending($destination, true);
        
        // Resize and crop
        imagecopyresampled(
            $destination, $source,
            0, 0, $srcX, $srcY,
            $width, $height, $cropSize, $cropSize
        );
        
        return $destination;
    }
    
    /**
     * Get avatar HTML img tag
     * @param string $userId User ID
     * @param string $size Size name
     * @param string $class CSS classes
     * @param string $alt Alt text
     * @return string HTML img tag
     */
    public function getAvatarHtml($userId, $size = 'medium', $class = '', $alt = '') {
        $url = $this->getAvatarUrl($userId, $size);
        $pixels = $this->avatarSizes[$size];
        
        if (empty($alt)) {
            $user = $this->db->get('users', $userId);
            $alt = $user ? htmlspecialchars($user['username']) : 'User avatar';
        }
        
        return sprintf(
            '<img src="%s" width="%d" height="%d" class="rounded-circle %s" alt="%s" loading="lazy">',
            htmlspecialchars($url),
            $pixels,
            $pixels,
            htmlspecialchars($class),
            htmlspecialchars($alt)
        );
    }
}
