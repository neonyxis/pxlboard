<?php
/**
 * Board Thumbnail Manager
 * Allows board moderators, admins, and creators to set board thumbnails
 */

class BoardThumbnailManager {
    private $db;
    private $uploadsDir;
    private $thumbsDir;
    
    const MAX_FILE_SIZE = 5242880; // 5MB
    const ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    const THUMB_WIDTH = 300;
    const THUMB_HEIGHT = 200;
    
    public function __construct($db, $uploadsDir = 'uploads/board_thumbs') {
        $this->db = $db;
        $this->uploadsDir = $uploadsDir;
        $this->thumbsDir = $uploadsDir . '/thumbs';
        $this->init();
    }
    
    private function init() {
        if (!is_dir($this->uploadsDir)) {
            mkdir($this->uploadsDir, 0755, true);
        }
        if (!is_dir($this->thumbsDir)) {
            mkdir($this->thumbsDir, 0755, true);
        }
    }
    
    /**
     * Check if user can manage board thumbnail
     */
    public function canManageThumbnail($userId, $boardId) {
        $user = $this->db->get('users', $userId);
        $board = $this->db->get('boards', $boardId);
        
        if (!$user || !$board) {
            return false;
        }
        
        // Admin can manage any board
        if ($user['role'] === 'admin') {
            return true;
        }
        
        // Board creator can manage their board
        if ($board['creator_id'] === $userId) {
            return true;
        }
        
        // Check if user is a moderator of this board
        $moderators = $board['moderators'] ?? [];
        if (in_array($userId, $moderators)) {
            return true;
        }
        
        return false;
    }
    
    /**
     * Upload board thumbnail
     */
    public function uploadThumbnail($file, $boardId, $userId) {
        // Validate permissions
        if (!$this->canManageThumbnail($userId, $boardId)) {
            return ['success' => false, 'error' => 'You do not have permission to manage this board thumbnail'];
        }
        
        // Validate file
        if (!isset($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
            return ['success' => false, 'error' => 'No file uploaded'];
        }
        
        // Check file size
        if ($file['size'] > self::MAX_FILE_SIZE) {
            return ['success' => false, 'error' => 'File size exceeds 5MB limit'];
        }
        
        // Check file type
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mimeType = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);
        
        if (!in_array($mimeType, self::ALLOWED_TYPES)) {
            return ['success' => false, 'error' => 'Invalid file type. Only JPEG, PNG, GIF, and WebP are allowed'];
        }
        
        // Generate unique filename
        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = 'board_' . $boardId . '_' . time() . '.' . $extension;
        $filepath = $this->uploadsDir . '/' . $filename;
        $thumbPath = $this->thumbsDir . '/' . $filename;
        
        // Move uploaded file
        if (!move_uploaded_file($file['tmp_name'], $filepath)) {
            return ['success' => false, 'error' => 'Failed to upload file'];
        }
        
        // Create thumbnail
        $this->createThumbnail($filepath, $thumbPath);
        
        // Delete old thumbnail if exists
        $board = $this->db->get('boards', $boardId);
        if (!empty($board['thumbnail'])) {
            $this->deleteThumbnailFiles($board['thumbnail']);
        }
        
        // Update board with new thumbnail
        $board['thumbnail'] = $filename;
        $board['thumbnail_updated_at'] = time();
        $board['thumbnail_updated_by'] = $userId;
        
        if ($this->db->save('boards', $boardId, $board)) {
            return ['success' => true, 'filename' => $filename];
        }
        
        return ['success' => false, 'error' => 'Failed to update board'];
    }
    
    /**
     * Create thumbnail from image
     */
    private function createThumbnail($source, $destination) {
        list($width, $height, $type) = getimagesize($source);
        
        // Calculate dimensions maintaining aspect ratio
        $ratio = min(self::THUMB_WIDTH / $width, self::THUMB_HEIGHT / $height);
        $newWidth = round($width * $ratio);
        $newHeight = round($height * $ratio);
        
        // Create source image
        switch ($type) {
            case IMAGETYPE_JPEG:
                $sourceImage = imagecreatefromjpeg($source);
                break;
            case IMAGETYPE_PNG:
                $sourceImage = imagecreatefrompng($source);
                break;
            case IMAGETYPE_GIF:
                $sourceImage = imagecreatefromgif($source);
                break;
            case IMAGETYPE_WEBP:
                $sourceImage = imagecreatefromwebp($source);
                break;
            default:
                return false;
        }
        
        // Create thumbnail
        $thumb = imagecreatetruecolor($newWidth, $newHeight);
        
        // Preserve transparency for PNG and GIF
        if ($type == IMAGETYPE_PNG || $type == IMAGETYPE_GIF) {
            imagealphablending($thumb, false);
            imagesavealpha($thumb, true);
            $transparent = imagecolorallocatealpha($thumb, 255, 255, 255, 127);
            imagefilledrectangle($thumb, 0, 0, $newWidth, $newHeight, $transparent);
        }
        
        imagecopyresampled($thumb, $sourceImage, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);
        
        // Save thumbnail
        switch ($type) {
            case IMAGETYPE_JPEG:
                imagejpeg($thumb, $destination, 90);
                break;
            case IMAGETYPE_PNG:
                imagepng($thumb, $destination, 9);
                break;
            case IMAGETYPE_GIF:
                imagegif($thumb, $destination);
                break;
            case IMAGETYPE_WEBP:
                imagewebp($thumb, $destination, 90);
                break;
        }
        
        imagedestroy($sourceImage);
        imagedestroy($thumb);
        
        return true;
    }
    
    /**
     * Delete board thumbnail
     */
    public function deleteThumbnail($boardId, $userId) {
        // Validate permissions
        if (!$this->canManageThumbnail($userId, $boardId)) {
            return ['success' => false, 'error' => 'You do not have permission to manage this board thumbnail'];
        }
        
        $board = $this->db->get('boards', $boardId);
        if (!$board || empty($board['thumbnail'])) {
            return ['success' => false, 'error' => 'No thumbnail to delete'];
        }
        
        // Delete files
        $this->deleteThumbnailFiles($board['thumbnail']);
        
        // Update board
        $board['thumbnail'] = null;
        $board['thumbnail_updated_at'] = time();
        $board['thumbnail_updated_by'] = $userId;
        
        if ($this->db->save('boards', $boardId, $board)) {
            return ['success' => true];
        }
        
        return ['success' => false, 'error' => 'Failed to update board'];
    }
    
    /**
     * Delete thumbnail files
     */
    private function deleteThumbnailFiles($filename) {
        $filepath = $this->uploadsDir . '/' . $filename;
        $thumbPath = $this->thumbsDir . '/' . $filename;
        
        if (file_exists($filepath)) {
            @unlink($filepath);
        }
        if (file_exists($thumbPath)) {
            @unlink($thumbPath);
        }
    }
    
    /**
     * Get thumbnail URL
     */
    public function getThumbnailUrl($boardId, $size = 'thumb') {
        $board = $this->db->get('boards', $boardId);
        
        if (!$board || empty($board['thumbnail'])) {
            return $this->getDefaultThumbnail($board);
        }
        
        $dir = $size === 'full' ? $this->uploadsDir : $this->thumbsDir;
        $path = $dir . '/' . $board['thumbnail'];
        
        if (file_exists($path)) {
            return $path;
        }
        
        return $this->getDefaultThumbnail($board);
    }
    
    /**
     * Get default thumbnail based on board properties
     */
    private function getDefaultThumbnail($board) {
        // You can customize this to generate a default thumbnail
        // For now, return a placeholder path
        return 'assets/images/default-board-thumb.png';
    }
    
    /**
     * Get thumbnail HTML
     */
    public function getThumbnailHtml($boardId, $alt = '', $class = 'img-fluid') {
        $url = $this->getThumbnailUrl($boardId);
        $board = $this->db->get('boards', $boardId);
        $altText = !empty($alt) ? $alt : ($board['name'] ?? 'Board thumbnail');
        
        return sprintf(
            '<img src="%s" alt="%s" class="%s">',
            htmlspecialchars($url),
            htmlspecialchars($altText),
            htmlspecialchars($class)
        );
    }
}
