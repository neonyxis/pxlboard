# PXLBoard v12f

**Modern PHP Imageboard System with Community Features**

Version 12f - January 31, 2026

---

## What's New in v12f

### 🎉 Major Features

- **Community Portal** - Centralized hub for all community activities
- **Board Thumbnails** - Custom thumbnails for discussion boards
- **Enhanced Gallery** - Modern image browsing with advanced filtering
- **TGP Collections** - User-curated image gallery posts
- **Photo Rotator** - Dynamic image showcases
- **Improved Navigation** - Streamlined menu with better organization

### 📊 Statistics

- **9 New Files** added
- **3 Enhanced Features** updated
- **~3,230 Lines** of new code
- **100% Bootstrap 5** compatible

---

## Quick Start

### Installation

1. **Upload Files**
   ```bash
   unzip PXLBoard_v12f.zip
   chmod 755 -R PXLBoard_v12f/
   ```

2. **Create Upload Directories**
   ```bash
   cd PXLBoard_v12f
   mkdir -p uploads/board_thumbs/thumbs
   chmod 777 uploads uploads/board_thumbs uploads/board_thumbs/thumbs
   ```

3. **Visit Installation Page**
   ```
   http://yoursite.com/PXLBoard_v12f/index.php?page=install
   ```

4. **Complete Setup**
   - Create admin account
   - Configure site settings
   - Start uploading!

### Upgrading from v12e

1. **Backup Everything**
   ```bash
   cp -r data data_backup
   cp -r uploads uploads_backup
   ```

2. **Extract New Files**
   ```bash
   unzip PXLBoard_v12f.zip -d PXLBoard_v12f_temp
   ```

3. **Copy New Files**
   ```bash
   # Copy new pages
   cp PXLBoard_v12f_temp/pages/community_portal.php pages/
   cp PXLBoard_v12f_temp/pages/gallery_enhanced.php pages/
   cp PXLBoard_v12f_temp/pages/boards_with_thumbnails.php pages/
   cp PXLBoard_v12f_temp/pages/tgp*.php pages/
   
   # Copy new includes
   cp PXLBoard_v12f_temp/includes/board_thumbnails.php includes/
   cp PXLBoard_v12f_temp/includes/tgp_manager.php includes/
   cp PXLBoard_v12f_temp/includes/photo_rotator.php includes/
   
   # Update core files
   cp PXLBoard_v12f_temp/index.php index.php
   cp PXLBoard_v12f_temp/pages/home.php pages/
   cp PXLBoard_v12f_temp/pages/api.php pages/
   cp PXLBoard_v12f_temp/templates/header.php templates/
   cp PXLBoard_v12f_temp/includes/database.php includes/
   ```

4. **Create Directories**
   ```bash
   mkdir -p uploads/board_thumbs/thumbs
   chmod 755 uploads/board_thumbs uploads/board_thumbs/thumbs
   ```

5. **Test Your Site**
   - Visit Community Portal: `?page=community_portal`
   - Browse Collections: `?page=tgp`
   - Check Enhanced Gallery: `?page=gallery_enhanced`

---

## Feature Guide

### Community Portal

Access all community features from one place:

- **Activity Stream** - See recent uploads, posts, and updates
- **Quick Navigation** - Links to all major sections
- **Statistics Dashboard** - Community metrics at a glance
- **Featured Content** - Highlighted images and boards

**URL**: `index.php?page=community_portal`

### Board Thumbnails

Customize your discussion boards with images:

- **Who Can Upload**: Board creators, moderators, and admins
- **Supported Formats**: JPEG, PNG, GIF, WebP
- **Max Size**: 5MB
- **Auto Thumbnail**: 300x200px generated automatically

**How to Use**:
1. Go to your board
2. Click "Manage Thumbnail" (if you have permission)
3. Upload an image
4. Thumbnail appears on boards listing

### Enhanced Gallery

Browse images with modern features:

**View Modes**:
- Grid - Uniform grid layout
- Masonry - Pinterest-style cascading
- List - Detailed list with descriptions

**Filters**:
- Tags (match any/all)
- Uploader name
- Channel
- Date range
- Rating
- Score

**Sorting**:
- Newest/Oldest
- Most Viewed
- Highest Score
- Most Favorited
- Random

**URL**: `index.php?page=gallery_enhanced`

### TGP Collections

Create curated galleries of your images:

**Create Collection**:
1. Go to `index.php?page=tgp_create`
2. Enter title and description
3. Select images to include
4. Add tags and choose category
5. Publish or save as draft

**Features**:
- Like/unlike collections
- View tracking
- Featured collections (admin)
- Category organization
- Social sharing

**URL**: `index.php?page=tgp`

### Photo Rotator

Dynamic image showcases on your site:

**Three Styles**:
1. **Carousel** - Bootstrap slideshow with captions
2. **Compact** - Horizontal scrolling thumbnails
3. **Grid** - Rotating grid of images

**Usage in Code**:
```php
require_once 'includes/photo_rotator.php';
$rotator = new PhotoRotator($db);

// Carousel style
echo $rotator->render([
    'count' => 10,
    'criteria' => 'top_rated',
    'height' => '500px'
]);
```

---

## Configuration

### Site Settings

Edit `config/config.php`:

```php
define('SITE_NAME', 'My Image Board');
define('SITE_DESCRIPTION', 'A community for sharing images');
define('ITEMS_PER_PAGE', 20);
define('REGISTRATION_ENABLED', true);
```

### Theme Selection

Choose from available themes:
- Default (Light)
- Dark
- DPBooru
- Vichan

Change theme from user dropdown menu or set default in config.

### Upload Limits

Adjust in `config/config.php`:

```php
define('MAX_FILE_SIZE', 10485760); // 10MB
define('ALLOWED_IMAGE_TYPES', ['image/jpeg', 'image/png', 'image/gif', 'image/webp']);
```

### Board Thumbnail Settings

Edit `includes/board_thumbnails.php`:

```php
const MAX_FILE_SIZE = 5242880; // 5MB
const THUMB_WIDTH = 300;
const THUMB_HEIGHT = 200;
```

---

## File Structure

```
PXLBoard_v12f/
├── config/
│   └── config.php           # Site configuration
├── data/                    # Database files (auto-created)
├── includes/
│   ├── auth.php
│   ├── database.php
│   ├── functions.php
│   ├── board_thumbnails.php # NEW: Board thumbnail manager
│   ├── tgp_manager.php      # NEW: TGP system
│   └── photo_rotator.php    # NEW: Photo rotator widget
├── pages/
│   ├── home.php            # UPDATED: New layout
│   ├── community_portal.php # NEW: Community hub
│   ├── gallery_enhanced.php # NEW: Enhanced gallery
│   ├── boards_with_thumbnails.php # NEW: Boards with thumbnails
│   ├── tgp.php             # NEW: Browse collections
│   ├── tgp_create.php      # NEW: Create collection
│   ├── tgp_view.php        # NEW: View collection
│   └── ...
├── templates/
│   ├── header.php          # UPDATED: New navigation
│   └── footer.php
├── themes/
│   ├── default/
│   ├── dark/
│   ├── dpbooru/
│   └── vichan/
├── uploads/
│   ├── images/
│   ├── thumbs/
│   ├── avatars/
│   └── board_thumbs/       # NEW: Board thumbnails
│       └── thumbs/
├── index.php               # UPDATED: New routes
└── README.md
```

---

## System Requirements

### Minimum Requirements

- **PHP**: 7.4 or higher
- **Extensions**: 
  - GD Library (for image processing)
  - JSON
  - Session support
- **Web Server**: Apache or Nginx
- **Disk Space**: 100MB minimum (+ image storage)

### Recommended Requirements

- **PHP**: 8.0 or higher
- **Memory**: 128MB PHP memory limit
- **Extensions**:
  - GD Library with WebP support
  - OPcache (for performance)
  - APCu (optional, for caching)
- **Web Server**: Apache with mod_rewrite
- **Disk Space**: 1GB+

### Permissions

```bash
chmod 755 uploads/ data/
chmod 755 uploads/board_thumbs/ uploads/board_thumbs/thumbs/
chmod 755 data/tgp_posts/ data/tgp_likes/
```

---

## Security

### Best Practices

1. **Change Default Admin Password** immediately after installation
2. **Enable HTTPS** for production sites
3. **Regular Backups** of data/ and uploads/ directories
4. **Keep PHP Updated** to latest stable version
5. **Monitor Upload Directory** for suspicious files
6. **Review User Permissions** regularly

### File Upload Security

- File type validation via MIME type
- File size limits enforced
- Automatic sanitization of filenames
- Thumbnail generation prevents code execution

### Access Control

- Role-based permissions (Admin, Moderator, User)
- Board-specific moderator assignments
- Content ownership verification
- Admin-only sensitive features

---

## Troubleshooting

### Common Issues

**Issue**: Board thumbnails won't upload  
**Solution**: Check that `uploads/board_thumbs` is writable (chmod 755)

**Issue**: TGP collections not saving  
**Solution**: Ensure `data/tgp_posts` exists and is writable

**Issue**: Images not displaying  
**Solution**: Check `uploads/` and `uploads/thumbs/` permissions

**Issue**: Getting 404 errors  
**Solution**: Ensure `.htaccess` is uploaded and mod_rewrite is enabled

**Issue**: Photo rotator not working  
**Solution**: Verify Bootstrap 5 JS is loading, check browser console for errors

### Performance Tips

**For Large Installations (1000+ images)**:
- Enable PHP OPcache
- Consider migrating to MySQL/PostgreSQL
- Implement CDN for images
- Add caching layer

**For Slow Page Loads**:
- Enable gzip compression
- Optimize images before upload
- Use lazy loading (already implemented)
- Minimize database calls

### Debug Mode

Enable debug mode in `config/config.php`:

```php
define('DEBUG_MODE', true);
error_reporting(E_ALL);
ini_set('display_errors', 1);
```

Remember to disable in production!

---

## API Documentation

### TGP Manager

```php
require_once 'includes/tgp_manager.php';
$tgpManager = new TGPManager($db);

// Create collection
$result = $tgpManager->createPost([
    'title' => 'My Collection',
    'description' => 'Description here',
    'images' => ['img1', 'img2'],
    'tags' => ['nature', 'landscape'],
    'category' => 'photography'
], $userId);

// Get collections
$posts = $tgpManager->getPosts([
    'category' => 'art',
    'sort' => 'popular'
]);

// Toggle like
$result = $tgpManager->toggleLike($postId, $userId);
```

### Board Thumbnail Manager

```php
require_once 'includes/board_thumbnails.php';
$thumbManager = new BoardThumbnailManager($db);

// Upload thumbnail
$result = $thumbManager->uploadThumbnail($_FILES['thumbnail'], $boardId, $userId);

// Get thumbnail URL
$url = $thumbManager->getThumbnailUrl($boardId);

// Delete thumbnail
$result = $thumbManager->deleteThumbnail($boardId, $userId);
```

### Photo Rotator

```php
require_once 'includes/photo_rotator.php';
$rotator = new PhotoRotator($db);

// Render carousel
echo $rotator->render([
    'count' => 10,
    'criteria' => 'newest',
    'height' => '500px',
    'autoplay' => true
]);

// Render compact
echo $rotator->renderCompact([
    'count' => 8,
    'criteria' => 'popular'
]);

// Render grid
echo $rotator->renderGrid([
    'count' => 6,
    'columns' => 3
]);
```

---

## Support & Resources

### Documentation

- **Installation Guide**: `INSTALLATION.md`
- **Enhancement Guide**: `ENHANCEMENT_GUIDE_v12f.md`
- **Changelog**: `CHANGELOG_v12f.md`
- **Version Notes**: `VERSION_NOTES_v12f.md`

### Getting Help

1. Check documentation files
2. Review inline code comments
3. Test in development environment
4. Check server error logs

### Contributing

PXLBoard is open for contributions:
- Bug fixes
- Feature enhancements
- Theme development
- Documentation improvements

---

## Credits

**Developed by**: PXLBoard Team  
**Version**: 12f  
**Released**: January 31, 2026  
**License**: MIT License

**Technologies Used**:
- PHP 7.4+
- Bootstrap 5.3
- Bootstrap Icons
- Vanilla JavaScript

**Inspiration**:
- Modern booru sites
- Contemporary imageboards
- Social media platforms

---

## License

MIT License

Copyright (c) 2026 PXLBoard

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

---

## Changelog Summary

### v12f (January 31, 2026)

**Added**:
- Community Portal with activity stream
- Board thumbnail system
- Enhanced gallery with modern UI
- TGP (Thumbnail Gallery Posts) system
- Photo rotator widget (3 styles)
- Improved navigation structure

**Changed**:
- Homepage redesigned with community portal link
- Gallery interface modernized
- Boards listing enhanced
- Navigation menu reorganized

**Fixed**:
- Various UI improvements
- Better mobile responsiveness
- Performance optimizations

**Technical**:
- 9 new files
- 5 updated files
- Bootstrap 5 full integration
- Improved code organization

---

**For detailed installation instructions, see ENHANCEMENT_GUIDE_v12f.md**

**For complete feature documentation, see CHANGELOG_v12f.md**

**Thank you for using PXLBoard!**
