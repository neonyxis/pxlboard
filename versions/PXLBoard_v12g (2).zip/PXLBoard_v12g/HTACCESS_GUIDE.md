# .htaccess Configuration Guide for PXLBoard

## Overview

The `.htaccess` file provides comprehensive Apache web server configuration for PXLBoard, including:
- SEO-friendly URL rewriting
- Security hardening
- Performance optimization
- File upload limits
- Caching strategies

---

## Table of Contents

1. [SEO-Friendly URLs](#seo-friendly-urls)
2. [Security Features](#security-features)
3. [Performance Optimization](#performance-optimization)
4. [PHP Configuration](#php-configuration)
5. [Troubleshooting](#troubleshooting)
6. [Customization](#customization)

---

## SEO-Friendly URLs

### URL Structure

The `.htaccess` file enables clean, search-engine-friendly URLs:

#### Before (Query String URLs):
```
index.php?page=image&id=img_123
index.php?page=user&username=john
index.php?page=wiki&action=view&slug=getting_started
```

#### After (SEO-Friendly URLs):
```
/image/123/my-awesome-artwork
/user/john
/wiki/getting_started
```

### URL Patterns Supported

| Old URL | New URL | Example |
|---------|---------|---------|
| `index.php?page=image&id=img_123` | `/image/123/title` | `/image/123/sunset-photo` |
| `index.php?page=user&username=john` | `/user/john` | `/user/john` |
| `index.php?page=channel&id=chan_art` | `/channel/chan_art` | `/channel/art` |
| `index.php?page=wiki&action=view&slug=help` | `/wiki/help` | `/wiki/getting-started` |
| `index.php?page=blogs&action=view&id=5` | `/blogs/5/title` | `/blogs/5/my-first-post` |
| `index.php?page=forums&action=view&topic=t_1` | `/forums/topic/t_1/title` | `/forums/topic/general-discussion` |
| `index.php?page=rankings&tab=uploaders` | `/rankings/uploaders` | `/rankings/uploaders` |
| `index.php?page=search&q=cats` | `/search/cats` | `/search/cats` |
| `index.php?page=tag&tag=nature` | `/tag/nature` | `/tag/nature` |

### Updating Internal Links

After enabling SEO URLs, update your links in templates:

**Old style:**
```php
<a href="index.php?page=image&id=<?php echo $imageId; ?>">View Image</a>
```

**New style:**
```php
<a href="/image/<?php echo str_replace('img_', '', $imageId); ?>/<?php echo createSlug($title); ?>">View Image</a>
```

### Helper Function

Add this function to `/includes/functions.php`:

```php
/**
 * Create SEO-friendly slug from title
 * @param string $title Title to convert
 * @return string URL-safe slug
 */
function createSlug($title) {
    $slug = strtolower(trim($title));
    $slug = preg_replace('/[^a-z0-9-]/', '-', $slug);
    $slug = preg_replace('/-+/', '-', $slug);
    return trim($slug, '-');
}

/**
 * Build SEO-friendly URL
 * @param string $page Page type
 * @param string $id Resource ID
 * @param string $title Optional title for slug
 * @return string Complete URL
 */
function buildUrl($page, $id = '', $title = '') {
    switch ($page) {
        case 'image':
            $imageNum = str_replace('img_', '', $id);
            $slug = !empty($title) ? '/' . createSlug($title) : '';
            return "/image/{$imageNum}{$slug}";
            
        case 'user':
            return "/user/{$id}";
            
        case 'channel':
            return "/channel/{$id}";
            
        case 'wiki':
            return "/wiki/{$id}";
            
        case 'blog':
            $slug = !empty($title) ? '/' . createSlug($title) : '';
            return "/blogs/{$id}{$slug}";
            
        case 'forum':
            $slug = !empty($title) ? '/' . createSlug($title) : '';
            return "/forums/topic/{$id}{$slug}";
            
        default:
            return "/{$page}";
    }
}
```

### Usage Example:

```php
// Image link
echo buildUrl('image', 'img_123', 'Beautiful Sunset');
// Output: /image/123/beautiful-sunset

// User profile link
echo buildUrl('user', 'john');
// Output: /user/john

// Wiki page link
echo buildUrl('wiki', 'getting_started');
// Output: /wiki/getting-started
```

---

## Security Features

### 1. Directory Protection

**Protected Directories:**
- `/data/` - Database files (403 Forbidden)
- `/config/` - Configuration files (403 Forbidden)
- `/includes/` - PHP includes (403 Forbidden)
- `/.git/` - Version control (403 Forbidden)

**Protected File Types:**
- `.log`, `.txt` - Log files
- `.bak`, `.backup`, `.old` - Backup files
- `.env` - Environment files
- `composer.json`, `package.json` - Dependency files

### 2. Upload Directory Security

Prevents PHP execution in upload directories:
```apache
<Directory "uploads">
    php_flag engine off
</Directory>
```

### 3. Security Headers

| Header | Purpose | Value |
|--------|---------|-------|
| `X-Content-Type-Options` | Prevent MIME sniffing | `nosniff` |
| `X-Frame-Options` | Prevent clickjacking | `SAMEORIGIN` |
| `X-XSS-Protection` | XSS filter | `1; mode=block` |
| `Referrer-Policy` | Control referrer info | `strict-origin-when-cross-origin` |

### 4. Injection Attack Protection

Blocks suspicious query strings containing:
- `<script>` tags
- `base64_encode` attempts
- `<iframe>` tags
- `php://input` references
- Global variable manipulation

### 5. Session Security

```apache
php_value session.cookie_httponly 1
php_value session.use_only_cookies 1
php_value session.cookie_samesite Lax
```

---

## Performance Optimization

### 1. GZIP Compression

**Compressed File Types:**
- HTML, CSS, JavaScript
- XML, JSON
- SVG images
- Fonts (TTF, OTF, WOFF)

**Expected Compression:**
- Text files: 60-80% reduction
- JavaScript: 50-70% reduction
- CSS: 50-70% reduction

### 2. Browser Caching

**Cache Durations:**
- Images: 1 year
- CSS/JavaScript: 1 month
- Fonts: 1 year
- HTML/PHP: No cache (always fresh)

### 3. Keep-Alive Connections

Reduces connection overhead by reusing TCP connections.

### 4. Performance Headers

```apache
Cache-Control: max-age=31536000, public  # Images
Cache-Control: max-age=2592000, public   # CSS/JS
Cache-Control: max-age=0, no-cache       # HTML
```

---

## PHP Configuration

### Upload Settings

```apache
php_value upload_max_filesize 10M
php_value post_max_size 12M
php_value max_file_uploads 20
```

**To increase limits:**
```apache
# Allow 50MB uploads
php_value upload_max_filesize 50M
php_value post_max_size 52M
```

### Memory and Execution

```apache
php_value memory_limit 128M
php_value max_execution_time 300
php_value max_input_time 300
```

### Error Handling

**Development Mode:**
```apache
php_flag display_errors on
php_value error_reporting E_ALL
```

**Production Mode:**
```apache
php_flag display_errors off
php_value error_reporting 0
php_flag log_errors on
```

---

## Troubleshooting

### Issue: 404 Errors on All Pages

**Cause:** `mod_rewrite` not enabled

**Solution:**
```bash
# Enable mod_rewrite on Ubuntu/Debian
sudo a2enmod rewrite
sudo systemctl restart apache2

# Enable mod_rewrite on CentOS/RHEL
# Usually enabled by default
```

### Issue: .htaccess Not Working

**Cause:** `AllowOverride` not enabled

**Solution:** Edit Apache config (`/etc/apache2/sites-available/000-default.conf`):
```apache
<Directory /var/www/html>
    AllowOverride All
</Directory>
```

Then restart Apache:
```bash
sudo systemctl restart apache2
```

### Issue: 500 Internal Server Error

**Causes & Solutions:**

1. **Syntax error in .htaccess**
   - Check Apache error log: `tail -f /var/log/apache2/error.log`
   - Validate syntax with online validators

2. **Missing PHP module**
   - Ensure `libapache2-mod-php` is installed
   - Check PHP is working: `php -v`

3. **File permissions**
   - .htaccess should be readable: `chmod 644 .htaccess`

### Issue: Images Not Loading with SEO URLs

**Cause:** Relative paths broken

**Solution:** Use absolute paths:
```php
// Before
<img src="uploads/image.jpg">

// After
<img src="/uploads/image.jpg">
```

### Issue: Upload Limit Not Working

**Cause:** Server-level limits override .htaccess

**Solution:** Edit `php.ini`:
```ini
upload_max_filesize = 10M
post_max_size = 12M
```

Restart Apache after changes.

---

## Customization

### Enable HTTPS Redirect

Uncomment these lines:
```apache
RewriteCond %{HTTPS} off
RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
```

### Enable/Disable www

**Remove www:**
```apache
RewriteCond %{HTTP_HOST} ^www\.(.+)$ [NC]
RewriteRule ^(.*)$ https://%1/$1 [R=301,L]
```

**Force www:**
```apache
RewriteCond %{HTTP_HOST} !^www\. [NC]
RewriteRule ^(.*)$ https://www.%{HTTP_HOST}/$1 [R=301,L]
```

### Add Custom Error Pages

1. Create error page files:
   - `403.php` - Forbidden
   - `404.php` - Not Found
   - `500.php` - Server Error

2. Already configured in .htaccess:
```apache
ErrorDocument 403 /index.php?page=403
ErrorDocument 404 /index.php?page=404
ErrorDocument 500 /index.php?page=500
```

### Increase Upload Size

For larger uploads (e.g., video):
```apache
php_value upload_max_filesize 100M
php_value post_max_size 105M
php_value memory_limit 256M
php_value max_execution_time 600
```

### Block Specific User Agents

```apache
RewriteCond %{HTTP_USER_AGENT} BadBot [NC,OR]
RewriteCond %{HTTP_USER_AGENT} AnotherBadBot [NC]
RewriteRule ^(.*)$ - [F,L]
```

### Add Content Security Policy

Uncomment and customize:
```apache
Header set Content-Security-Policy "default-src 'self'; script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; style-src 'self' 'unsafe-inline';"
```

---

## Testing Your Configuration

### 1. Test SEO URLs

```bash
# Should return image page
curl -I https://yoursite.com/image/123/test

# Should return user page
curl -I https://yoursite.com/user/john
```

### 2. Test GZIP Compression

```bash
curl -H "Accept-Encoding: gzip" -I https://yoursite.com/
# Look for: Content-Encoding: gzip
```

### 3. Test Caching

```bash
curl -I https://yoursite.com/uploads/image.jpg
# Look for: Cache-Control: max-age=31536000
```

### 4. Test Security Headers

```bash
curl -I https://yoursite.com/
# Look for:
# X-Content-Type-Options: nosniff
# X-Frame-Options: SAMEORIGIN
```

### 5. Online Testing Tools

- **Security Headers:** https://securityheaders.com/
- **GTmetrix:** https://gtmetrix.com/ (performance)
- **Google PageSpeed:** https://pagespeed.web.dev/
- **SSL Labs:** https://www.ssllabs.com/ssltest/

---

## Performance Benchmarks

### Expected Improvements

**With .htaccess optimizations:**
- Page load time: 20-40% faster
- Bandwidth usage: 50-70% reduction
- Server requests: 15-30% reduction
- Google PageSpeed score: +15-25 points

**GZIP Compression Savings:**
- HTML: ~70% reduction
- CSS: ~60% reduction
- JavaScript: ~55% reduction
- XML/JSON: ~65% reduction

---

## Security Checklist

- [x] Directory browsing disabled
- [x] Data directory protected
- [x] Config files protected
- [x] Upload directory PHP execution disabled
- [x] Security headers configured
- [x] Session cookies secured
- [x] Injection attack protection
- [x] Error display disabled (production)
- [x] File type restrictions
- [x] Version control files hidden

---

## Apache Modules Required

**Essential:**
- `mod_rewrite` - URL rewriting
- `mod_headers` - HTTP headers
- `mod_expires` - Cache control
- `mod_deflate` - GZIP compression
- `mod_mime` - MIME types

**Check if enabled:**
```bash
apache2ctl -M | grep -E 'rewrite|headers|expires|deflate|mime'
```

**Enable modules:**
```bash
sudo a2enmod rewrite headers expires deflate mime
sudo systemctl restart apache2
```

---

## Notes

1. **Backup First:** Always backup your `.htaccess` before making changes
2. **Test Changes:** Test in development before deploying to production
3. **Monitor Logs:** Watch Apache error logs when troubleshooting
4. **Cache Issues:** Clear browser cache when testing URL changes
5. **Shared Hosting:** Some directives may not work on shared hosting

---

## Support

For issues or questions:
- Check Apache error logs: `/var/log/apache2/error.log`
- Test configuration: `apachectl configtest`
- Community support: PXLBoard forums
- Apache documentation: https://httpd.apache.org/docs/

---

**Last Updated:** January 31, 2026
**Version:** 1.0.0
**Compatible with:** Apache 2.4+, PHP 7.4+
