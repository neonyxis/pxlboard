# PXLBoard Enhancement Implementation Guide
## Version 12f - Community Portal, TGP, and Enhanced Gallery

This guide covers the implementation of new features requested for PXLBoard v12e enhancement.

## Overview of New Features

### 1. Board Thumbnails
- Allows moderators, admins, and board creators to set custom board thumbnails
- Automatic thumbnail generation from uploaded images
- Permission-based management system

### 2. Community Portal
- Centralized hub for all community activities
- Integrated activity stream showing recent images, blogs, wiki updates, and board threads
- Quick navigation to all major site sections
- Statistics dashboard
- Featured content sections

### 3. Enhanced Gallery
- Modern image browsing interface inspired by contemporary booru sites
- Multiple view modes: Grid, Masonry, and List
- Advanced filtering and sorting options
- Tag-based search with "match any" or "match all" modes
- Popular tags cloud
- Sticky sidebar filters
- Enhanced pagination

### 4. TGP (Thumbnail Gallery Post) System
- Allows users to create curated collections of images
- Featured collections system
- Category-based organization
- Like/unlike functionality
- View tracking

### 5. Photo Rotator
- Multiple rotator styles: Carousel, Compact, and Grid
- Automatic image rotation
- Configurable display criteria (newest, popular, top-rated, random)
- Integrated into homepage

### 6. Enhanced User Profiles
- Integrated with community portal
- Activity tracking
- Personal statistics

## File Structure

### New Files Created

```
PXLBoard_v12e/
├── pages/
│   ├── community_portal.php          # Central community hub
│   ├── gallery_enhanced.php          # Enhanced gallery with modern features
│   ├── boards_with_thumbnails.php    # Boards listing with thumbnail support
│   ├── tgp.php                       # TGP browse page
│   ├── tgp_create.php               # TGP creation page (to be created)
│   └── tgp_view.php                 # Individual TGP view (to be created)
│
├── includes/
│   ├── board_thumbnails.php         # Board thumbnail management class
│   ├── tgp_manager.php              # TGP system manager class
│   └── photo_rotator.php            # Photo rotator widget class
│
└── uploads/
    └── board_thumbs/                # Board thumbnail storage
        └── thumbs/                  # Board thumbnail previews
```

### Modified Files

- `pages/home.php` - Updated to link to community portal and include photo rotator
- Database structure automatically handles new collections via FlatFileDB

## Installation Instructions

### Step 1: File Upload

1. Upload all new files to your PXLBoard installation
2. Ensure proper file permissions (755 for directories, 644 for files)

### Step 2: Directory Setup

Create the following directories if they don't exist:

```bash
mkdir -p uploads/board_thumbs/thumbs
mkdir -p data/tgp_posts
mkdir -p data/tgp_likes
chmod 755 uploads/board_thumbs
chmod 755 uploads/board_thumbs/thumbs
chmod 755 data/tgp_posts
chmod 755 data/tgp_likes
```

### Step 3: Database Initialization

The FlatFileDB will automatically create necessary directories when first accessed. The following collections are used:

- `tgp_posts` - Stores TGP gallery posts
- `tgp_likes` - Stores user likes on TGP posts
- `boards` - Extended with thumbnail support

### Step 4: Update Navigation

Add the following links to your site navigation (in `templates/header.php`):

```html
<li class="nav-item">
    <a class="nav-link" href="index.php?page=community_portal">
        <i class="bi bi-compass"></i> Community Portal
    </a>
</li>
<li class="nav-item">
    <a class="nav-link" href="index.php?page=tgp">
        <i class="bi bi-grid-3x3-gap"></i> Collections
    </a>
</li>
```

### Step 5: Replace Gallery

To use the enhanced gallery, update your navigation or routing to use `gallery_enhanced` instead of `gallery`:

In `index.php`, update the page routing:

```php
case 'gallery':
    require 'pages/gallery_enhanced.php';
    break;
```

### Step 6: Replace Boards Page

To use boards with thumbnails, update the routing:

```php
case 'boards':
    require 'pages/boards_with_thumbnails.php';
    break;
```

## Feature Usage Guide

### Using Board Thumbnails

**For Board Creators/Moderators:**

1. Navigate to your board
2. Look for the "Manage Thumbnail" button (visible only to authorized users)
3. Upload an image (max 5MB, JPEG/PNG/GIF/WebP)
4. Thumbnail is automatically generated

**Permissions:**
- Site administrators can manage any board's thumbnail
- Board creators can manage their own board's thumbnail
- Board moderators can manage their assigned board's thumbnail

**API Usage:**

```php
require_once 'includes/board_thumbnails.php';
$thumbnailManager = new BoardThumbnailManager($db);

// Upload thumbnail
$result = $thumbnailManager->uploadThumbnail($_FILES['thumbnail'], $boardId, $userId);

// Delete thumbnail
$result = $thumbnailManager->deleteThumbnail($boardId, $userId);

// Get thumbnail URL
$url = $thumbnailManager->getThumbnailUrl($boardId);

// Get thumbnail HTML
$html = $thumbnailManager->getThumbnailHtml($boardId, 'Board Name', 'img-fluid');
```

### Using the Community Portal

The community portal automatically aggregates:
- Recent image uploads
- New blog posts
- Wiki page updates
- Board thread activity

**Customization:**

Edit `pages/community_portal.php` to adjust:
- Number of items displayed
- Activity types shown
- Featured content criteria

### Using the Enhanced Gallery

**View Modes:**
- **Grid View**: Compact grid of images (default)
- **Masonry View**: Pinterest-style cascading layout
- **List View**: Detailed list with descriptions

**Filtering:**
- Tags (comma-separated, match any/all modes)
- Uploader
- Channel
- Date range
- Minimum rating
- Minimum score

**Sorting:**
- Newest/Oldest
- Most Viewed
- Highest Score
- Most Favorited
- Random

### Using TGP (Thumbnail Gallery Posts)

**Creating a Collection:**

1. Navigate to TGP page
2. Click "Create Collection"
3. Fill in:
   - Title
   - Description
   - Select images
   - Add tags
   - Choose category
4. Publish or save as draft

**Managing Collections:**
- Edit your own collections
- Admins can feature collections
- View tracking automatic
- Like/unlike functionality

### Using the Photo Rotator

**Carousel Rotator:**

```php
require_once 'includes/photo_rotator.php';
$rotator = new PhotoRotator($db);

echo $rotator->render([
    'count' => 10,
    'criteria' => 'top_rated',  // newest, popular, top_rated, featured, random
    'height' => '500px',
    'show_controls' => true,
    'show_indicators' => true,
    'autoplay' => true,
    'interval' => 5000
]);
```

**Compact Rotator (Horizontal Scroll):**

```php
echo $rotator->renderCompact([
    'count' => 8,
    'criteria' => 'newest',
    'interval' => 3000
]);
```

**Grid Rotator (Rotating Grid):**

```php
echo $rotator->renderGrid([
    'count' => 6,
    'criteria' => 'random',
    'columns' => 3,
    'interval' => 4000
]);
```

## Configuration Options

### Board Thumbnails

Edit `includes/board_thumbnails.php`:

```php
const MAX_FILE_SIZE = 5242880; // 5MB
const ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
const THUMB_WIDTH = 300;
const THUMB_HEIGHT = 200;
```

### Photo Rotator

Edit `includes/photo_rotator.php`:

```php
private $rotationInterval = 5000; // milliseconds
```

### Gallery Pagination

Edit `pages/gallery_enhanced.php`:

```php
$perPage = isset($_GET['limit']) ? min(120, max(12, intval($_GET['limit']))) : 42;
```

## Creating Additional TGP Pages

You'll need to create two more pages:

### `pages/tgp_create.php` - Collection Creation Form

This page should include:
- Form for title and description
- Image selector (multi-select from user's uploads)
- Tag input
- Category selector
- Publish/draft toggle

### `pages/tgp_view.php` - Individual Collection View

This page should display:
- Collection title and description
- All images in the collection (grid layout)
- Author information
- Like button
- View count
- Comments section
- Edit/delete buttons (for owner/admin)

## Styling and Customization

### Color Schemes

The new pages use Bootstrap 5 with custom gradient backgrounds:

```css
/* Primary gradient */
background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);

/* Secondary gradient */
background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
```

### Responsive Design

All new pages are fully responsive with Bootstrap 5 breakpoints:
- Mobile: < 576px
- Tablet: 576px - 992px
- Desktop: > 992px

## Troubleshooting

### Board Thumbnails Not Appearing

1. Check directory permissions: `uploads/board_thumbs` should be writable
2. Verify GD library is installed: `php -m | grep gd`
3. Check file upload limits in `php.ini`

### Photo Rotator Not Working

1. Ensure JavaScript is enabled
2. Check Bootstrap 5 JS is loaded
3. Verify images exist in the database

### TGP Collections Not Saving

1. Check `data/tgp_posts` directory exists and is writable
2. Verify user is logged in
3. Check browser console for JavaScript errors

## Performance Optimization

### Caching

Consider implementing caching for:
- Community portal activity feed
- Popular tags calculation
- Board statistics
- TGP collections list

### Image Optimization

For better performance:
1. Use WebP format for thumbnails
2. Implement lazy loading (already included)
3. Consider CDN for image delivery

### Database Queries

The flat-file database loads all records into memory. For large installations:
1. Consider migrating to SQLite or MySQL
2. Implement pagination at the database level
3. Add indexing for frequently queried fields

## Security Considerations

### File Uploads

- File type validation implemented
- File size limits enforced
- Files stored outside web root when possible
- Thumbnail generation prevents code execution

### Permissions

- Role-based access control for board thumbnails
- User ownership verification for TGP posts
- Admin-only features properly protected

### Input Validation

- All user input escaped before display
- SQL injection not applicable (flat-file DB)
- XSS prevention through proper escaping

## Future Enhancements

### Potential Additions

1. **Board Thumbnail Templates**: Pre-made templates for quick setup
2. **TGP Slideshow Mode**: Full-screen slideshow for collections
3. **Advanced Activity Filters**: More granular control in community portal
4. **Gallery Lightbox**: Full-screen image viewer
5. **Mobile App Integration**: API endpoints for mobile apps
6. **Social Sharing**: Share buttons for collections and galleries
7. **RSS Feeds**: Subscribe to activity streams
8. **Email Notifications**: Activity digests and mentions

## Support and Documentation

For additional help:
1. Check the main README.md file
2. Review existing documentation in the `/docs` folder (if available)
3. Examine the code comments in each file
4. Test features in a development environment first

## Version History

### v12f (Current)
- Added community portal
- Implemented board thumbnails
- Created enhanced gallery
- Added TGP system
- Implemented photo rotator
- Updated homepage integration

---

**Note**: This is an enhancement package. Always backup your data before implementing new features.
