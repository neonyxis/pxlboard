# PXLBoard Tier 1 Features - Quick Start

## What's New? 🎉

We've implemented 6 high-impact features that significantly enhance PXLBoard's functionality:

1. **Image Hiding System** - Hide images you don't want to see
2. **Image Source Tracking** - Track where images came from with full history
3. **Tag Aliases** - Redirect old/alternate tag names to canonical tags
4. **Comment Editing** - Edit comments with full revision history
5. **Anonymous Uploads** - Upload images without showing your username
6. **User Avatars** - Upload and manage profile pictures (enhanced interface)

## Quick Installation

### Method 1: Automatic Check (Recommended)

Run the installation verification script:

```bash
php install_tier1.php
```

This will:
- ✓ Check all required files are present
- ✓ Verify modifications to existing files
- ✓ Create necessary directories
- ✓ Set up configuration files
- ✓ Report any issues

### Method 2: Manual Installation

1. **Upload new files** to your PXLBoard directory:
   - `includes/hiding.php`
   - `includes/tag_aliases.php`
   - `pages/manage_hides.php`
   - `pages/admin_tags.php`
   - `pages/edit_source.php`
   - `pages/edit_comment.php`
   - `pages/comment_history.php`
   - `pages/profile_settings.php`

2. **Replace modified files**:
   - `includes/database.php`
   - `pages/upload.php`
   - `pages/image.php`
   - `pages/gallery.php`

3. **Create configuration file**:
   ```bash
   echo '{}' > data/tag_aliases.json
   chmod 644 data/tag_aliases.json
   ```

4. **Set permissions**:
   ```bash
   chmod 755 data/user_hides
   chmod 755 uploads/avatars
   ```

## Feature Overview

### 🙈 Image Hiding System

**What it does**: Hide images from your gallery view

**How to use**:
- Click "Hide Image" button on any image page
- View/manage hidden images at Profile Settings → Hidden Images
- Unhide images individually or clear all at once

**Benefits**:
- Clean up your gallery feed
- Hide content you're not interested in
- Privacy-friendly (only you see what's hidden)

---

### 🔗 Image Source Tracking

**What it does**: Track original sources of images with full history

**How to use**:
- Add source URL when uploading
- Edit source URL on image pages (uploader/admin only)
- View source history to see previous URLs

**Benefits**:
- Proper attribution for artists
- Help prevent duplicate uploads
- Trace image origins

---

### 🏷️ Tag Aliases

**What it does**: Automatically redirect old tags to new canonical tags

**How to use** (Admin only):
- Go to Admin → Tag Aliases
- Add aliases (e.g., "pony" → "mlp")
- Use bulk migration to update existing images
- Tags are automatically resolved on upload

**Benefits**:
- Consistent tagging across the board
- Consolidate similar tags automatically
- Easier search and discovery

**Example aliases**:
```
pony → mlp
pegasus → pegasi
rarity → rarity_(mlp)
```

---

### ✏️ Comment Editing

**What it does**: Edit comments with full revision history

**How to use**:
- Click edit button (pencil icon) on your comments
- Make changes and optionally add edit reason
- Click "edited" timestamp to view full history

**Benefits**:
- Fix typos and mistakes
- Update comments with new information
- Full transparency with edit history

---

### 👤 Anonymous Uploads

**What it does**: Upload images without showing your username

**How to use**:
- Check "Upload anonymously" when uploading
- Your username won't be shown publicly
- You can still edit/delete your uploads
- Admins can still see your username for moderation

**Benefits**:
- Privacy option for sensitive content
- Reduced pressure for new users
- Still allows moderation and accountability

---

### 🎨 User Avatars (Enhanced)

**What it does**: Upload and display profile pictures

**How to use**:
- Go to Profile Settings
- Upload avatar (JPG, PNG, GIF, WebP, max 2MB)
- Delete avatar if desired
- Avatars appear in comments and profiles

**Features**:
- Auto-resize to multiple sizes
- Center-crop to square
- Gravatar fallback
- Three sizes: small (50px), medium (100px), large (200px)

---

## For Regular Users

### Quick Tips

1. **Customize your experience** with hidden images
2. **Upload responsibly** and provide source URLs when possible
3. **Use avatars** to personalize your profile
4. **Edit comments** to fix mistakes (edits are tracked)
5. **Try anonymous uploads** if you prefer privacy

### New Pages

- **Profile Settings** (`/profile_settings`) - Manage avatar and view stats
- **Hidden Images** (`/manage_hides`) - View and manage hidden images

---

## For Administrators

### New Admin Tools

#### Tag Aliases Management
- Access: Admin → Tag Aliases
- Features:
  - Add/remove tag aliases
  - View all aliases and statistics
  - Bulk migrate tags across all images
  - Autocomplete for existing tags

**Pro tip**: Start by aliasing common variations:
```
plural → singular (ponies → pony)
abbreviations → full (mlp → my_little_pony)
typos → correct (rarity → rarity)
```

### Best Practices

1. **Tag Aliases**:
   - Create aliases before bulk uploads
   - Use consistent naming conventions
   - Test aliases before migration
   - Keep statistics for reference

2. **Source Tracking**:
   - Encourage users to add sources
   - Check source history for duplicates
   - Monitor source changes

3. **Anonymous Uploads**:
   - Review for abuse (you can still see uploader)
   - Set community guidelines
   - Balance privacy with accountability

---

## Technical Details

### Database Structure

All features use flat JSON files:

- **User hides**: `data/user_hides/{user_id}.json`
- **Tag aliases**: `data/tag_aliases.json`
- **Image metadata**: Enhanced `data/images/img_*.json`
- **Comment history**: Enhanced `data/comments/*.json`
- **Avatars**: `uploads/avatars/{size}/{user_id}.ext`

### System Requirements

- ✅ PHP 7.4+
- ✅ GD library (for avatars)
- ✅ Writable data directory
- ✅ No database server needed
- ✅ Works on shared hosting

### Performance

- Image hiding: O(n) filter on gallery load
- Tag aliases: O(1) lookup, resolved at upload time
- Avatars: Pre-generated sizes, cacheable
- Comment history: Only loaded when viewing history

---

## Troubleshooting

### Images still showing after hiding
- Clear browser cache
- Ensure you're logged in
- Check that data/user_hides directory exists

### Tag aliases not working
- Verify data/tag_aliases.json exists and is writable
- Check admin interface for aliases
- Test with simple alias first

### Avatar upload fails
- Check file size (must be under 2MB)
- Verify uploads/avatars directory is writable
- Try different image format

### Comment edit not saving
- Ensure you own the comment or are admin
- Check data/comments directory permissions
- Look for JavaScript errors in browser console

---

## What's Next?

### Recommended Order of Setup

1. **Set up your avatar** (Profile Settings)
2. **Create common tag aliases** (Admin → Tag Aliases)
3. **Try hiding an image** to test the system
4. **Upload with source URL** to test tracking
5. **Edit a comment** to see revision history

### Potential Future Enhancements

These features can be extended with:
- Bulk hide by tag/uploader
- Tag suggestions based on aliases
- Comment diff viewer
- Anonymous mode toggle
- Avatar galleries

---

## Support

### Documentation

- **Full Guide**: `TIER1_IMPLEMENTATION_GUIDE.md` - Complete technical documentation
- **This README**: Quick start and user guide
- **Installation Script**: `install_tier1.php` - Verification tool

### Getting Help

1. Check this README
2. Review the implementation guide
3. Run installation verification script
4. Check file permissions and PHP error logs

---

## Version History

**Version 1.1** (2025-01-31)
- Initial release of Tier 1 features
- 6 new features implemented
- Full documentation provided
- Installation verification script

---

## Credits

Developed for PXLBoard - Simple Flat File Image Board

These features are designed to work seamlessly with PXLBoard's philosophy:
- ✅ Simple flat file storage
- ✅ No complex dependencies
- ✅ Shared hosting compatible
- ✅ Easy to install and maintain

---

**Ready to get started?** Run `php install_tier1.php` to verify your installation!
