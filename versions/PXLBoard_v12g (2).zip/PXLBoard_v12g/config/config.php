<?php
/**
 * PXLBoard Configuration
 */

// Define constants
define('VERSION', '12d');
define('BASE_DIR', __DIR__ . '/..');
define('DATA_DIR', BASE_DIR . '/data');
define('UPLOADS_DIR', BASE_DIR . '/uploads');
define('THEMES_DIR', BASE_DIR . '/themes');
define('CACHE_DIR', DATA_DIR . '/cache');

// Site Settings (loaded from data/settings.json after installation)
$settings = [];
if (file_exists(DATA_DIR . '/settings.json')) {
    $settingsContent = @file_get_contents(DATA_DIR . '/settings.json');
    if ($settingsContent) {
        $settings = json_decode($settingsContent, true) ?: [];
    }
}

define('SITE_NAME', $settings['site_name'] ?? 'PXLBoard');
define('SITE_DESCRIPTION', $settings['site_description'] ?? 'An image board system');
define('SITE_URL', $settings['site_url'] ?? 'http://localhost');
define('ADMIN_EMAIL', $settings['admin_email'] ?? 'admin@example.com');

// Upload Settings
define('MAX_UPLOAD_SIZE', $settings['max_upload_size'] ?? 10485760); // 10MB
define('ALLOWED_EXTENSIONS', ['jpg', 'jpeg', 'png', 'gif', 'webp']);
define('THUMBNAIL_WIDTH', 250);
define('THUMBNAIL_HEIGHT', 250);

// Pagination
define('ITEMS_PER_PAGE', 24);

// SMTP Settings
define('SMTP_ENABLED', $settings['smtp_enabled'] ?? false);
define('SMTP_HOST', $settings['smtp_host'] ?? '');
define('SMTP_PORT', $settings['smtp_port'] ?? 587);
define('SMTP_USERNAME', $settings['smtp_username'] ?? '');
define('SMTP_PASSWORD', $settings['smtp_password'] ?? '');
define('SMTP_FROM', $settings['smtp_from'] ?? '');
define('SMTP_FROM_NAME', $settings['smtp_from_name'] ?? SITE_NAME);
define('SMTP_SECURE', $settings['smtp_secure'] ?? 'tls'); // tls or ssl

// Registration Settings
define('REGISTRATION_ENABLED', $settings['registration_enabled'] ?? true);
define('EMAIL_VERIFICATION', $settings['email_verification'] ?? false);

// Theme Settings
define('DEFAULT_THEME', $settings['default_theme'] ?? 'default');

// Security
define('PASSWORD_MIN_LENGTH', 8);
define('SESSION_LIFETIME', 86400); // 24 hours

// Error Reporting (disable in production)
error_reporting(E_ALL);
ini_set('display_errors', '1');

// Timezone
date_default_timezone_set($settings['timezone'] ?? 'UTC');
