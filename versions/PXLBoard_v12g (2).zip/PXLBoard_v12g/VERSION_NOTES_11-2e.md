# PXLBoard Version 11-2e Release Notes

**Release Date:** January 31, 2026  
**Version:** 11-2e

## New Features

### System Information & Debugging Tools

#### Version Indicator
- **Admin Navbar Badge**: Version badge now appears in the navigation bar for admin users
- **Footer Display**: Version information displayed in footer on all pages
- **Quick Copy**: One-click version copying in debug panel

#### Debug Panel (Admin Only)
Added comprehensive debug panel in Admin section with the following sections:

1. **System Version**
   - PXLBoard version display
   - Installation date
   - PHP version
   - Server software information
   - Document root path
   - Server time

2. **Path Configuration**
   - All critical directory paths
   - Writable status indicators for data/upload directories
   - Site URL configuration
   - URL prefix detection
   - Script name and request URI for debugging routing issues

3. **PHP Configuration**
   - Upload limits (max upload size, max POST size)
   - Memory limit
   - Max execution time
   - Error reporting status
   - Extension status (GD Library, JSON)

4. **Database Statistics**
   - Record counts for all collections (users, images, comments, tags, etc.)
   - Visual cards showing counts for 11 different data collections

5. **Recent PHP Errors**
   - Display of recent PHP error log entries
   - Last 20 errors shown in scrollable window
   - Error log path display

6. **Quick Diagnostics**
   - .htaccess file existence check
   - mod_rewrite detection (Apache)
   - Session status and ID
   - Settings file verification
   - Uploads/thumbs directory status
   - Total disk usage calculation

7. **Maintenance Tools**
   - Link to full diagnostic report
   - Page refresh button
   - Copy version to clipboard

## Bug Fixes (from 11-2d)

### Critical Fixes
1. **Database ID Injection**: Fixed `db->get()` not returning the `id` field, which caused profile updates to save to `null.json`
2. **Profile Page Null Guard**: Added null-safety check after `getCurrentUser()` to prevent crashes when user record is missing

### Routing & URL Fixes
3. **Subdirectory Deployment Support**: 
   - Fixed `buildUrl()` to detect and prepend subdirectory prefix from `SITE_URL`
   - Added `getBasePrefix()` helper function
   - All generated URLs now work correctly in subdirectory deployments (e.g., `/pxlboard/V11d/`)

4. **.htaccess Auto-Configuration**:
   - Added auto-detection during installation to set correct `RewriteBase`
   - Installer now patches `.htaccess` with correct subdirectory path
   - Documented manual configuration for existing installations

5. **Public Profile Access**: Fixed 404 errors when accessing user profiles via pretty URLs

## Technical Changes

### Modified Files
- `config/config.php` - Updated VERSION constant to '11-2e'
- `includes/database.php` - Fixed `get()` method to inject `id` field
- `includes/functions.php` - Added `getBasePrefix()` and updated all `buildUrl()` returns
- `pages/profile.php` - Added null guard after `getCurrentUser()`
- `pages/install.php` - Added `.htaccess` auto-patching during installation
- `pages/admin.php` - Added comprehensive Debug tab with system information
- `templates/header.php` - Added version badge for admin users
- `templates/footer.php` - Already displayed version (no changes needed)
- `.htaccess` - Updated comments to document RewriteBase configuration

### New Features Code
- Debug panel with 7 major sections
- Real-time system diagnostics
- Path and permission checking
- Database statistics display
- Error log viewer

## Upgrade Notes

### From 11-2d to 11-2e

1. **Automatic Upgrade**: Simply replace all files
2. **Clean Up Corrupted Data** (if profile errors occurred in 11-2d):
   - Check `data/users/` directory for any `null.json` file
   - Delete `null.json` if it exists (it's not a real user record)
3. **URL Configuration** (if deployed in subdirectory):
   - Method 1: Re-run installer to auto-configure
   - Method 2: Manually edit `.htaccess` and set `RewriteBase` to your subdirectory path
   - Example: `RewriteBase /pxlboard/V11d/`

### Database Changes
- No database schema changes
- No migration required

### Configuration Changes
- No configuration file changes required
- VERSION constant automatically updated

## Known Issues
- None reported

## Security Notes
- Debug panel is admin-only and properly protected
- Error log viewing requires proper file permissions
- No sensitive information exposed to non-admin users

## Performance Impact
- Minimal: Debug tab loads on-demand only
- No impact on regular user pages
- Version badge adds negligible overhead

---

**Previous Versions:**
- [11-2d Release Notes](VERSION_NOTES_11-2d.md)
- [11-2 Release Notes](VERSION_NOTES_11-2.md)
