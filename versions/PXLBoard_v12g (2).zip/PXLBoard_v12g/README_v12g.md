# PXLBoard v12g

**Professional Image Board Platform with Advanced Features**

Version 12g - January 2026

## 🎯 Overview

PXLBoard is a feature-rich image board platform combining the best elements of Danbooru, Vichan, and Shimmie2. Version 12g introduces extensive notification system, SMTP email support, automated image grabber, and comprehensive bug fixes.

## ✨ What's New in v12g

### 🔔 Extensive Notification System
- 13+ notification types (comments, replies, mentions, follows, thread replies, etc.)
- Real-time in-app notifications
- Email notifications via SMTP
- Customizable user preferences
- Template-based email system

### 📧 SMTP Email Support
- Full SMTP implementation (no external dependencies)
- Support for Gmail, SendGrid, Mailgun, Amazon SES
- HTML email templates
- TLS/SSL encryption
- Email queuing and retry mechanism

### 🤖 Image Grabber System
- Automated image import from external sources
- Supported sources:
  - Danbooru
  - Gelbooru
  - Safebooru
  - Konachan
  - RSS/Atom feeds
  - Custom URL scraping
- Admin dashboard for source management
- Tag-based filtering
- Rating filters (Safe/Questionable/Explicit)
- Auto-import functionality

### 🐛 Critical Bug Fixes
- ✅ Fixed missing `gallery_card.php` template
- ✅ Fixed board shortname undefined key errors
- ✅ Fixed PHP 8.1+ null parameter deprecation warnings
- ✅ Fixed community portal thread sorting
- ✅ Fixed dark mode inconsistencies (40+ new style rules)

## 🚀 Features

### Core Features
- **Image Gallery** - Upload and share images with tagging
- **Discussion Boards** - Create threaded discussions
- **Wiki System** - Collaborative documentation
- **Blog Platform** - User and admin blogs
- **Tag System** - Powerful tagging with aliases and implications
- **User System** - Registration, profiles, avatars
- **Moderation** - Reports, bans, content approval
- **Search** - Advanced search across all content
- **Themes** - Multiple themes including enhanced dark mode

### Advanced Features
- **RBAC** - Role-based access control
- **Notifications** - Comprehensive notification system
- **Email** - SMTP email with templates
- **API** - RESTful API for integrations
- **Extensions** - Plugin system
- **TGP** - Thumbnail gallery posts
- **Channels** - Content organization
- **Favorites** - User favorites and collections
- **Comments** - Threaded comments with editing
- **Voting** - Upvote/downvote system

## 📋 Requirements

- **PHP**: 7.4 or higher (8.0+ recommended)
- **Web Server**: Apache or Nginx
- **Extensions**:
  - PDO (MySQL/SQLite)
  - GD or Imagick (image processing)
  - cURL (for image grabber)
  - JSON
  - mbstring
- **Optional**:
  - SMTP server or email service
  - Cron (for automated tasks)

## 🔧 Installation

### Quick Install

```bash
# 1. Extract files
unzip PXLBoard_v12g.zip
cd PXLBoard_v12g

# 2. Set permissions
chmod 755 uploads data
chmod 644 config/config.php

# 3. Configure database
cp config/config.example.php config/config.php
nano config/config.php

# 4. Run installer
# Navigate to: http://yoursite.com/pxlboard/?page=install

# 5. Create admin account
# Follow on-screen instructions
```

### Configuration

Edit `config/config.php`:

```php
<?php
// Database
define('DB_TYPE', 'mysql');
define('DB_HOST', 'localhost');
define('DB_NAME', 'pxlboard');
define('DB_USER', 'username');
define('DB_PASS', 'password');

// Site Settings
define('SITE_NAME', 'My Image Board');
define('SITE_URL', 'https://yoursite.com');
define('THEME', 'dark');

// SMTP Email (New in v12g)
define('SMTP_ENABLED', true);
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'your-email@gmail.com');
define('SMTP_PASSWORD', 'your-app-password');
define('SMTP_FROM', 'noreply@yoursite.com');
define('SMTP_USE_TLS', true);

// Image Grabber (New in v12g)
define('GRABBER_ENABLED', true);
define('GRABBER_AUTO_RUN', false);
define('GRABBER_MAX_IMAGES', 50);

// Uploads
define('UPLOAD_DIR', 'uploads');
define('MAX_FILE_SIZE', 10485760); // 10MB
define('ALLOWED_EXTENSIONS', 'jpg,jpeg,png,gif,webp');
?>
```

## 📖 Documentation

### User Guides
- [Installation Guide](INSTALLATION.md)
- [Upgrade Guide](UPGRADE_v12f_to_v12g.md)
- [Admin Quick Reference](ADMIN_QUICK_REFERENCE.md)
- [Boards Quick Start](BOARDS_QUICK_START.md)

### Technical Documentation
- [Changelog v12g](CHANGELOG_v12g.md)
- [API Documentation](API_DOCUMENTATION.md)
- [Enhancement Guide](ENHANCEMENT_GUIDE_v12f.md)
- [Implementation Status](IMPLEMENTATION_STATUS.md)

## 🎨 Themes

PXLBoard v12g includes enhanced themes:

### Dark Theme (Recommended)
- Comprehensive dark mode coverage
- 40+ new style rules
- Consistent across all components
- Optimized for long viewing sessions

### Other Themes
- **Default** - Clean, modern light theme
- **DPBooru** - Danbooru-inspired theme
- **Vichan** - Imageboard-style theme

Switch themes in user settings or admin panel.

## 📧 Email Setup

### Gmail Configuration

1. **Enable 2-Step Verification**:
   - Go to Google Account → Security
   - Enable 2-Step Verification

2. **Create App Password**:
   - Go to App Passwords
   - Generate new password
   - Copy 16-character password

3. **Configure PXLBoard**:
```php
define('SMTP_ENABLED', true);
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'youremail@gmail.com');
define('SMTP_PASSWORD', 'xxxx xxxx xxxx xxxx'); // App password
define('SMTP_USE_TLS', true);
```

### Other Providers

**SendGrid**:
```php
define('SMTP_HOST', 'smtp.sendgrid.net');
define('SMTP_USERNAME', 'apikey');
define('SMTP_PASSWORD', 'your-api-key');
```

**Mailgun**:
```php
define('SMTP_HOST', 'smtp.mailgun.org');
define('SMTP_USERNAME', 'postmaster@yourdomain.mailgun.org');
define('SMTP_PASSWORD', 'your-smtp-password');
```

## 🤖 Image Grabber Usage

### Setup

1. **Access Admin Panel**:
   - Login as admin
   - Navigate to Image Grabber

2. **Add Source**:
   ```
   Source Type: Danbooru
   Name: Safe Anime Art
   Tags: rating:safe landscape
   Channel: default
   Auto-import: ✓
   ```

3. **Grab Images**:
   - Click "Grab Now" to fetch immediately
   - Or click "Run All Sources" for batch operation

### Automation

Set up cron job for automated grabbing:

```bash
# Run every 30 minutes
*/30 * * * * php /path/to/pxlboard/cron_grabber.php
```

Create `cron_grabber.php`:
```php
<?php
require_once 'config/config.php';
require_once 'includes/database.php';
require_once 'includes/image_grabber.php';

$db = new Database();
$grabber = new ImageGrabber($db, 'uploads');

// Run all enabled sources
$results = $grabber->runAll(20);

// Log results
error_log("Grabber ran: " . json_encode($results));
?>
```

### Supported Tag Syntax

**Danbooru/Gelbooru**:
- `rating:safe` - Safe for work images
- `landscape 1girl` - Multiple tags
- `order:score` - Sort by score
- `-tag` - Exclude tag

**RSS Feeds**:
- Standard RSS/Atom feeds
- Extracts images from media:content, enclosures, or descriptions

## 🛡️ Security

### Best Practices

1. **File Permissions**:
```bash
chmod 755 uploads data
chmod 644 config/config.php
chmod 600 config/database.php  # If separate file
```

2. **HTTPS**: Always use HTTPS in production
3. **Strong Passwords**: Enforce strong user passwords
4. **Regular Updates**: Keep PXLBoard updated
5. **Backups**: Regular automated backups

### .htaccess Security

```apache
# Protect sensitive files
<Files "config.php">
    Require all denied
</Files>

# Prevent directory listing
Options -Indexes

# Prevent access to hidden files
<FilesMatch "^\.">
    Require all denied
</FilesMatch>
```

## 🔌 API

### Authentication

```php
// Get API key from user profile
$apiKey = 'your-api-key';

// Include in requests
curl -H "X-API-Key: $apiKey" https://yoursite.com/api/images
```

### Endpoints

```bash
# Get images
GET /api/images?limit=20&offset=0

# Get specific image
GET /api/images/{id}

# Upload image
POST /api/images
  -F "file=@image.jpg"
  -F "title=My Image"
  -F "tags=landscape sunset"

# Get boards
GET /api/boards

# Get threads
GET /api/boards/{board_id}/threads
```

## 🎯 Usage Examples

### Basic Workflow

1. **User Registration**:
   ```
   Navigate to Register
   Fill in username, email, password
   Confirm email (if SMTP enabled)
   ```

2. **Upload Image**:
   ```
   Click Upload
   Select image file
   Add title and tags
   Choose channel
   Submit
   ```

3. **Create Board Thread**:
   ```
   Navigate to Boards
   Select a board
   Click "New Thread"
   Add subject and content
   Post
   ```

4. **Moderate Content**:
   ```
   Access Admin Panel
   Review reported content
   Approve/reject images
   Ban users if necessary
   ```

### Admin Tasks

#### Managing Sources
```
Admin Panel → Image Grabber
Add Source → Danbooru
Tags: rating:safe cute cat
Enable Auto-import
Save → Grab Now
```

#### Sending Notifications
```php
// Programmatically
$notifier = new NotificationSystem($db);
$notifier->create(
    $userId,
    NotificationSystem::TYPE_COMMENT,
    'New Comment',
    'Someone commented on your image',
    ['image_id' => $imageId],
    true  // Send email
);
```

## 🐛 Troubleshooting

### Common Issues

**Issue**: Images not uploading
```bash
# Check permissions
ls -ld uploads
chmod 755 uploads

# Check PHP upload limits
php -i | grep upload_max_filesize
```

**Issue**: SMTP emails not sending
```bash
# Test SMTP connection
telnet smtp.gmail.com 587

# Check logs
tail -f /var/log/php_errors.log

# Verify credentials
# Gmail requires App Password, not regular password
```

**Issue**: Image grabber not working
```bash
# Check cURL
php -m | grep curl

# Test API access
curl -I https://danbooru.donmai.us/posts.json

# Check firewall
# Ensure outbound HTTPS is allowed
```

**Issue**: Dark mode inconsistent
```bash
# Clear browser cache
# Verify theme is set to 'dark'
# Check CSS file loaded correctly
```

## 📊 Performance Optimization

### Database
```sql
-- Add indexes for better performance
CREATE INDEX idx_images_uploader ON images(uploader);
CREATE INDEX idx_images_channel ON images(channel);
CREATE INDEX idx_images_uploaded_at ON images(uploaded_at);
CREATE INDEX idx_board_threads_board_id ON board_threads(board_id);
```

### Caching
```php
// Enable OPcache in php.ini
opcache.enable=1
opcache.memory_consumption=128
opcache.max_accelerated_files=10000
```

### Image Optimization
```bash
# Install and use ImageMagick for better compression
convert input.jpg -quality 85 output.jpg
```

## 🤝 Contributing

We welcome contributions! Areas for improvement:

- Additional image grabber sources
- Email template designs
- Theme customizations
- Translations
- Bug fixes
- Documentation

## 📜 License

PXLBoard is released under the MIT License. See LICENSE file for details.

## 🙏 Credits

### Inspired By
- **Danbooru** - Tag system and image management
- **Vichan** - Board structure and threading
- **Shimmie2** - Gallery features
- **Reddit** - Notification system design
- **Discord** - Real-time notifications

### Technologies
- PHP
- MySQL/SQLite
- Bootstrap 5
- Bootstrap Icons
- JavaScript

### Community
- Thanks to all contributors and testers
- Special thanks to booru communities for APIs

## 📞 Support

- **Documentation**: Check `/docs` directory
- **Issues**: Review error logs
- **Updates**: Check for new releases regularly

## 🗺️ Roadmap

### Future Plans
- Real-time WebSocket notifications
- Advanced search with filters
- Mobile app (PWA)
- Video support
- AI-powered tagging
- Multi-language support
- S3/CDN integration
- GraphQL API

---

**PXLBoard v12g** - Professional Image Board Platform

*Built with ❤️ for the imageboard community*

Last Updated: January 31, 2026
