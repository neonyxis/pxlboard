# Migration Guide: Enhanced Admin Panel

## Overview
This guide explains how to migrate from the basic admin panel to the new enhanced admin panel with comprehensive blog and wiki management features.

---

## 🎯 **What's New in Enhanced Admin Panel**

### New Features
1. **Blog Management Tab**
   - View all blog posts in a sortable table
   - Toggle post status (published/draft) with one click
   - Delete posts with associated comments
   - Blog statistics (views, comments, published count)
   - Quick edit and view links

2. **Wiki Management Tab**
   - View all wiki pages in a sortable table
   - Toggle page protection status
   - Delete wiki pages with revision history
   - Wiki statistics (views, revisions, protected pages)
   - Category and author information

3. **Enhanced Statistics Dashboard**
   - Blog post count
   - Wiki page count
   - Recent blog posts preview
   - Recent wiki pages preview
   - Comprehensive activity overview

4. **Extended Settings**
   - Blog enable/disable toggle
   - Wiki enable/disable toggle
   - Blog approval requirement setting
   - Wiki edit approval requirement setting

5. **Improved User Management**
   - User promotion to admin
   - Admin demotion to user
   - Better role visualization
   - Quick user profile access

---

## 📦 **Migration Steps**

### Step 1: Backup Current Files
```bash
# Create backup directory
mkdir -p backups/$(date +%Y%m%d)

# Backup current admin panel
cp pages/admin.php backups/$(date +%Y%m%d)/admin.php.backup

# Backup database file
cp includes/database.php backups/$(date +%Y%m%d)/database.php.backup
```

### Step 2: Update Database Collections

The enhanced admin panel requires additional database collections. The updated `database.php` already includes these:

```php
// New collections added:
$this->dataDir . '/blog_posts'
$this->dataDir . '/blog_comments'
$this->dataDir . '/wiki_pages'
$this->dataDir . '/wiki_revisions'
$this->dataDir . '/notifications'
$this->dataDir . '/moderation_queue'
```

✅ **Already completed** - `includes/database.php` has been updated

### Step 3: Deploy Enhanced Admin Panel

**Option A: Replace Existing File (Recommended)**
```bash
# Rename old admin panel
mv pages/admin.php pages/admin_old.php

# Rename enhanced panel to admin.php
mv pages/admin_enhanced.php pages/admin.php
```

**Option B: Keep Both (Testing)**
```bash
# Access enhanced panel at:
# index.php?page=admin_enhanced

# Access old panel at:
# index.php?page=admin
```

### Step 4: Update Settings File

Add new settings to your `data/settings.json`:

```json
{
  "existing_settings": "...",
  "blog_enabled": true,
  "wiki_enabled": true,
  "blog_require_approval": false,
  "wiki_require_approval": false
}
```

Or simply save settings through the new admin panel, which will add these automatically.

### Step 5: Verify Functionality

1. **Access Admin Panel**
   ```
   Navigate to: index.php?page=admin
   ```

2. **Check All Tabs**
   - [ ] Statistics tab loads
   - [ ] Blogs tab shows existing posts
   - [ ] Wiki tab shows existing pages
   - [ ] Settings tab displays all options
   - [ ] Users tab lists all users
   - [ ] Channels tab shows channels

3. **Test Blog Management**
   - [ ] Create a test blog post
   - [ ] Toggle post status
   - [ ] Edit a post
   - [ ] Delete a test post

4. **Test Wiki Management**
   - [ ] Create a test wiki page
   - [ ] Toggle protection status
   - [ ] Edit a page
   - [ ] Delete a test page

5. **Test User Management**
   - [ ] Promote a user (if safe)
   - [ ] Demote back to user
   - [ ] Verify role changes

---

## 🔧 **Configuration Options**

### Enable/Disable Features

In the **Settings** tab, you can now control:

```
✓ Enable Blog Feature
✓ Enable Wiki Feature
□ Require Admin Approval for Blog Posts
□ Require Admin Approval for Wiki Edits
```

### Blog Approval Workflow

When enabled, new blog posts will:
1. Be created with status 'draft'
2. Require admin approval to publish
3. Appear in moderation queue

### Wiki Approval Workflow

When enabled, wiki edits will:
1. Create revision in pending state
2. Require admin approval
3. Appear in moderation queue

---

## 🎨 **UI Improvements**

### Better Visual Hierarchy
- Card-based design for statistics
- Improved table layouts
- Better spacing and typography
- Icon usage for better UX

### Color-Coded Status Badges
- 🟢 Published posts (green)
- 🟡 Draft posts (yellow)
- 🔴 Protected wiki pages (red)
- ⚪ Regular wiki pages (gray)

### Action Buttons
- Grouped actions in button groups
- Icon-based actions for clarity
- Confirmation dialogs for destructive actions

---

## 📊 **New Statistics Available**

### Blog Statistics
- Total blog posts
- Total views across all posts
- Total comments
- Published vs draft count

### Wiki Statistics
- Total wiki pages
- Total views across all pages
- Total revisions made
- Protected pages count

### Activity Overview
- Recent blog posts (last 5)
- Recent wiki pages (last 5)
- Author information
- Timestamps

---

## ⚠️ **Breaking Changes**

### None!
The enhanced admin panel is **fully backward compatible** with the existing system. No database migrations or data changes required.

### Optional Changes
If you want to take full advantage of approval workflows:
1. Enable approval settings in admin panel
2. Update moderation.php to handle blog/wiki approvals
3. Configure notification system for approval requests

---

## 🔍 **Troubleshooting**

### Issue: Tabs Not Switching
**Solution**: Ensure Bootstrap JavaScript is loaded in footer.php:
```html
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
```

### Issue: Statistics Not Showing
**Solution**: Verify database collections exist:
```bash
ls -la data/blog_posts/
ls -la data/wiki_pages/
```

### Issue: Blog/Wiki Tabs Empty
**Solution**: 
1. Check if blog_posts or wiki_pages directories exist
2. Verify permissions on data directories
3. Check error logs for PHP errors

### Issue: Actions Not Working
**Solution**:
1. Verify you're logged in as admin
2. Check URL parameters are correct
3. Verify CSRF protection isn't blocking requests

---

## 🚀 **Next Steps After Migration**

### 1. Review All Settings
- Go through each settings section
- Update any outdated values
- Save settings to generate new settings.json

### 2. Clean Up Old Files
- Delete old backup files (after thorough testing)
- Remove redundant admin panel versions
- Archive old documentation

### 3. Train Administrators
- Show them new blog management features
- Demonstrate wiki management tools
- Explain approval workflows (if enabled)

### 4. Monitor Performance
- Watch for any errors in logs
- Monitor database size growth
- Check page load times

---

## 📚 **Related Documentation**

- [Cleanup Report](CLEANUP_REPORT.md) - Redundant files to remove
- [Implementation Status](IMPLEMENTATION_STATUS.md) - Overall project status
- [Installation Guide](INSTALLATION_GUIDE.md) - Fresh installation steps

---

## 🆘 **Rollback Procedure**

If you need to revert to the old admin panel:

```bash
# Restore old admin panel
cp backups/YYYYMMDD/admin.php.backup pages/admin.php

# Restore old database file (if needed)
cp backups/YYYYMMDD/database.php.backup includes/database.php

# Clear any new settings
# (Edit data/settings.json and remove new keys)
```

---

## ✅ **Post-Migration Checklist**

- [ ] Admin panel loads without errors
- [ ] All tabs are accessible
- [ ] Blog management functions work
- [ ] Wiki management functions work
- [ ] User management functions work
- [ ] Settings save correctly
- [ ] Statistics display accurately
- [ ] No PHP errors in logs
- [ ] Backup created and verified
- [ ] Old files archived (not deleted yet)
- [ ] Team members notified of changes
- [ ] Documentation updated

---

## 📞 **Support**

If you encounter any issues:

1. Check error logs: `tail -f /path/to/php_error.log`
2. Review backup files in `backups/` directory
3. Check database permissions: `ls -la data/`
4. Verify all required files exist
5. Test with different browsers

---

**Migration Version**: 1.0  
**Compatibility**: PXLBoard v8.3+  
**Date**: 2025-01-31  
**Estimated Migration Time**: 15-30 minutes
