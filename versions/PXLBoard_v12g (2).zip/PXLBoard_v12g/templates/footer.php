    </main>
    
    <footer class="bg-light py-4 mt-5">
        <div class="container text-center">
            <p class="text-muted mb-2">
                &copy; <?php echo date('Y'); ?> <?php echo escape(SITE_NAME); ?>. Powered by PXLBoard v<?php echo VERSION; ?>
            </p>
            <p class="text-muted small mb-0">
                <?php
                $totalImages = $db->count('images');
                $totalUsers = $db->count('users');
                echo number_format($totalImages) . ' images · ' . number_format($totalUsers) . ' users';
                ?>
            </p>
        </div>
    </footer>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
