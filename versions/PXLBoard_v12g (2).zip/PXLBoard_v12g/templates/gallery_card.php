<?php
/**
 * Gallery Card Template
 * Reusable template for displaying image cards in gallery views
 * 
 * Expected variables:
 * - $image: Array containing image data (id, title, thumbnail, uploader, etc.)
 */

$imageId = $image['id'] ?? 0;
$imageTitle = escape($image['title'] ?? 'Untitled');
$imageThumbnail = $image['thumbnail'] ?? $image['filename'] ?? '';
$imageUploader = escape($image['uploader'] ?? 'Anonymous');
$imageDate = date('M j, Y', $image['uploaded_at'] ?? time());
$imageScore = $image['score'] ?? 0;
$imageComments = count($db->query("SELECT * FROM comments WHERE image_id = ?", [$imageId]));
?>

<div class="col-md-3 col-sm-6 mb-4">
    <div class="card image-card h-100">
        <a href="<?php echo buildUrl('image', $imageId); ?>">
            <img src="<?php echo escape($imageThumbnail); ?>" 
                 class="card-img-top" 
                 alt="<?php echo $imageTitle; ?>"
                 loading="lazy">
        </a>
        <div class="card-body">
            <h6 class="card-title">
                <a href="<?php echo buildUrl('image', $imageId); ?>">
                    <?php echo $imageTitle; ?>
                </a>
            </h6>
            <div class="small text-muted">
                <i class="bi bi-person"></i> <?php echo $imageUploader; ?>
            </div>
            <div class="small text-muted">
                <i class="bi bi-calendar"></i> <?php echo $imageDate; ?>
            </div>
            <div class="mt-2">
                <span class="badge bg-primary">
                    <i class="bi bi-star-fill"></i> <?php echo $imageScore; ?>
                </span>
                <span class="badge bg-secondary">
                    <i class="bi bi-chat-dots"></i> <?php echo $imageComments; ?>
                </span>
            </div>
        </div>
    </div>
</div>
