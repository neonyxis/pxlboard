# PXLBoard Version 11-2d Release Notes

**Release Date**: January 31, 2025  
**Version**: 11-2d  
**Previous Version**: 11-2b

## Overview

Version 11-2d integrates the Tier 1 feature update into the main PXLBoard codebase, bringing six high-impact user experience enhancements to the platform.

## What's New

### 🎯 Tier 1 Features Integration

This release includes the complete integration of six major features from the Tier 1 update:

#### 1. **Image Hiding System** (High Impact)
- Users can hide images they don't want to see
- Personal preferences stored per user
- Hidden images are filtered from gallery views
- Management interface at Profile Settings → Hidden Images
- **Files**: `includes/hiding.php`, `pages/manage_hides.php`

#### 2. **Image Source Tracking** (Medium Impact)
- Track where images originated with URL references
- Full edit history for source attribution
- Add sources during upload or edit later
- View source history on image pages
- **Files**: `pages/edit_source.php`

#### 3. **Tag Aliases** (High Impact)
- Redirect alternate tag names to canonical tags
- Improves search consistency and tag organization
- Admin interface for managing aliases
- Automatic tag normalization during upload
- **Access**: Admin → Tag Aliases
- **Files**: `includes/tag_aliases.php`, `pages/admin_tags.php`

#### 4. **Comment Editing** (Medium Impact)
- Edit your own comments after posting
- Full revision history tracking
- View complete edit history
- Edited comments are marked with timestamp
- **Files**: `pages/edit_comment.php`, `pages/comment_history.php`

#### 5. **Anonymous Uploads** (Medium Impact)
- Upload images without displaying your username publicly
- Optional checkbox on upload form
- User identity still tracked internally for moderation
- Appears as "Anonymous" to other users
- **Implementation**: Updated `pages/upload.php`

#### 6. **Enhanced Avatar Management** (Medium Impact)
- Dedicated profile settings page
- Improved avatar upload interface
- Better file management
- Integrated with user preferences
- **Files**: `pages/profile_settings.php`

## File Changes

### New Files Added
- `includes/hiding.php` - Image hiding system core
- `includes/tag_aliases.php` - Tag alias management
- `pages/manage_hides.php` - User hide management interface
- `pages/admin_tags.php` - Admin tag alias interface
- `pages/edit_source.php` - Image source editing
- `pages/edit_comment.php` - Comment editing interface
- `pages/comment_history.php` - Comment revision history
- `pages/profile_settings.php` - Enhanced profile settings

### Modified Files
- `pages/upload.php` - Added source URL, anonymous upload
- `pages/image.php` - Added hiding, source display, comment editing
- `pages/gallery.php` - Added hidden image filtering
- `includes/database.php` - Updated for new features

### New Directories
- `data/user_hides/` - Stores user hide preferences

### New Configuration
- `data/tag_aliases.json` - Tag alias mappings

## Technical Details

### System Requirements
- PHP 7.4 or higher
- JSON extension (standard)
- GD extension (for image processing)
- Writable `data/` and `uploads/` directories

### Database Updates
The Tier 1 features use the existing file-based data system:
- User hide data stored in `data/user_hides/{username}.json`
- Tag aliases stored in `data/tag_aliases.json`
- Comment edit history embedded in comment data
- Source history tracked with image metadata

## Upgrade Notes

### From 11-2b to 11-2d
This is a seamless upgrade with backward compatibility:
1. All existing data remains intact
2. New features are opt-in and don't affect existing functionality
3. No database migrations required
4. Users can start using new features immediately

### Directory Permissions
Ensure these directories are writable by the web server:
```
chmod 755 data/
chmod 755 data/user_hides/
chmod 644 data/tag_aliases.json
```

## Feature Access

### For Users
- **Hide Images**: Click hide button on any image → Manage at Profile Settings
- **Add Sources**: Fill source URL field during upload or click "Edit Source" on image page
- **Edit Comments**: Click edit icon next to your comments
- **Anonymous Upload**: Check "Upload Anonymously" box on upload form
- **Manage Avatar**: Visit Profile Settings page

### For Administrators
- **Tag Aliases**: Access via Admin Panel → Tag Aliases
- **View Hidden Stats**: Users can see their hidden image count in profile settings
- **Moderate Anonymous**: Anonymous uploads still show uploader in admin logs

## Configuration

### Tag Aliases Example
```json
{
  "cat": "cats",
  "doggo": "dog",
  "wallpaper": "wallpapers"
}
```

### Hide System
Users can hide unlimited images. Hidden images:
- Don't appear in gallery/search results for that user
- Can still be accessed via direct link
- Can be unhidden at any time

## Security Considerations

1. **Anonymous Uploads**: Username is hidden from public view but logged internally
2. **Comment Editing**: Full edit history prevents abuse
3. **Source URLs**: Validated to prevent XSS attacks
4. **Hide System**: User-specific, doesn't affect other users

## Known Limitations

1. Tag aliases are admin-managed only (no user suggestions yet)
2. Comment editing has no time limit (may be added in future versions)
3. Hidden images count toward upload quotas
4. Anonymous uploads can't be made non-anonymous after upload

## Future Enhancements (Tier 2+)

The following features are planned for future updates:
- Image sets/pools
- Saved searches
- Tag subscriptions
- Advanced filtering
- Bulk operations
- And more...

## Credits

**Development Team**: PXLBoard Development Team  
**Tier 1 Features**: Version 1.1.0  
**Integration Date**: January 31, 2025

## Support

For issues or questions:
- Check the implementation guides in the docs/ folder
- Review TROUBLESHOOTING_404.md for common issues
- Consult TIER1_IMPLEMENTATION_GUIDE.md for feature details

## Changelog Summary

**Version 11-2d** (2025-01-31)
- ✅ Integrated Tier 1 features (6 major enhancements)
- ✅ Added image hiding system
- ✅ Added source URL tracking
- ✅ Added tag alias system
- ✅ Added comment editing with history
- ✅ Added anonymous upload option
- ✅ Enhanced avatar management
- ✅ Updated gallery filtering
- ✅ Updated upload form
- ✅ Updated image display page
- ✅ Created new admin interfaces

---

*This version maintains full backward compatibility with 11-2b while adding powerful new features for users and administrators.*
