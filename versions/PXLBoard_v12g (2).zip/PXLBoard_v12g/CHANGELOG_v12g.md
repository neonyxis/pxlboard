# PXLBoard v12g Changelog

## Version 12g - January 2026

### Major Features

#### 1. Extensive Notification System
- **Enhanced Notification Types**: Added 13 new notification types including:
  - Thread replies
  - Board posts
  - Tag watches
  - User watches
  - Image approval/rejection
  - Comment/wiki edits
  - Blog posts
  - Vote milestones
  - Badge achievements
  - Moderation actions
  - System announcements

- **In-App Notifications**: Real-time notification system with:
  - Unread badge counter
  - Notification dropdown
  - Mark as read functionality
  - Notification history

- **Email Notifications**: Fully implemented SMTP email system with:
  - Template-based emails
  - HTML email support
  - Customizable email preferences
  - Support for major SMTP providers (Gmail, SendGrid, Mailgun, etc.)

#### 2. Image Grabber System
- **Automated Image Import**: Pull images from external sources automatically
- **Supported Sources**:
  - Danbooru API integration
  - Gelbooru API integration
  - Safebooru support
  - Konachan support
  - RSS/Atom feed parsing
  - Custom URL scraping

- **Admin Dashboard**: Full management interface for:
  - Adding/configuring sources
  - Tag-based filtering
  - Rating filters (Safe/Questionable/Explicit)
  - Auto-import functionality
  - Manual grab triggers
  - Batch operations

- **Source Management**:
  - Enable/disable sources
  - Schedule automated grabbing
  - Track last run times
  - Import statistics

#### 3. SMTP Email System
- **Full SMTP Support**: Native SMTP implementation without external dependencies
- **Provider Support**:
  - Gmail
  - SendGrid
  - Mailgun
  - Amazon SES
  - Custom SMTP servers

- **Features**:
  - TLS/SSL support
  - HTML email templates
  - File attachments
  - Email queuing
  - Retry mechanism
  - Template system for notifications

### Bug Fixes

#### Critical Fixes
1. **Missing Template File**: Created `templates/gallery_card.php`
   - Fixed: "Failed to open stream: No such file or directory" error
   - Added reusable gallery card component
   - Includes image thumbnails, metadata, and statistics

2. **Board Shortname Issues**: Fixed undefined array key "shortname" errors
   - Added null coalescing operators throughout boards.php
   - Fallback to board ID when shortname missing
   - Proper handling of edge cases

3. **Null Parameter Deprecation**: Fixed htmlspecialchars() null parameter warning
   - Updated `escape()` function to handle null values
   - Returns empty string for null inputs
   - Prevents PHP 8.1+ deprecation warnings

4. **Community Portal Thread Updates**: Fixed threads not updating properly
   - Implemented proper sorting by `last_post_time`
   - Added fallback to `updated_at` and `created_at`
   - Threads now properly reflect recent activity
   - Activity stream shows most recent posts

#### Dark Mode Consistency Fixes
Enhanced dark theme with uniform styling across all site elements:

**New Dark Mode Styles**:
- List groups (consistent background and borders)
- Modals (proper dark backgrounds and borders)
- Breadcrumbs (dark-themed navigation)
- Board cards (hover effects and transitions)
- Thread cards (consistent styling)
- Portal elements (activity feeds, banners)
- Input groups (dark backgrounds)
- Progress bars (themed colors)
- Accordions (dark backgrounds, proper states)
- Offcanvas panels (dark themed)
- Toasts (dark backgrounds)
- Code blocks (syntax-friendly colors)
- HR elements (subtle borders)
- Spinners (themed colors)

**Improvements**:
- Uniform color scheme across all components
- Consistent hover states
- Proper focus indicators
- Better contrast ratios
- Smooth transitions

### Technical Improvements

#### Database Schema Updates
No schema changes required for this version. All new features use existing flexible JSON storage.

#### New Files Added
- `/includes/smtp_mailer.php` - SMTP email handler
- `/includes/image_grabber.php` - Image grabber system
- `/pages/admin_grabber.php` - Admin grabber interface
- `/templates/gallery_card.php` - Reusable gallery card template

#### Modified Files
- `/includes/functions.php` - Enhanced escape() function
- `/includes/notifications.php` - Extended notification types
- `/pages/boards.php` - Fixed null handling
- `/pages/community_portal.php` - Fixed thread sorting
- `/themes/dark/style.css` - Comprehensive dark mode fixes

### Configuration

#### New Configuration Options

Add to `config/config.php`:

```php
// SMTP Email Configuration
define('SMTP_ENABLED', true);
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'your-email@gmail.com');
define('SMTP_PASSWORD', 'your-app-password');
define('SMTP_FROM', 'noreply@yoursite.com');
define('SMTP_USE_TLS', true);

// Image Grabber Configuration
define('GRABBER_ENABLED', true);
define('GRABBER_AUTO_RUN', false); // Set to true for cron automation
define('GRABBER_MAX_IMAGES', 50); // Max images per grab
```

#### Email Provider Examples

**Gmail**:
```php
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USE_TLS', true);
// Use App Password, not regular password
```

**SendGrid**:
```php
define('SMTP_HOST', 'smtp.sendgrid.net');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'apikey');
define('SMTP_PASSWORD', 'your-api-key');
```

**Mailgun**:
```php
define('SMTP_HOST', 'smtp.mailgun.org');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'postmaster@your-domain.mailgun.org');
define('SMTP_PASSWORD', 'your-smtp-password');
```

### Usage

#### Image Grabber Setup

1. **Access Admin Interface**:
   - Navigate to Admin Panel
   - Click "Image Grabber" (or go to `index.php?page=admin_grabber`)

2. **Add a Source**:
   - Select source type (Danbooru, Gelbooru, RSS, etc.)
   - Enter source name
   - Configure tags/filters
   - Set default channel
   - Enable auto-import if desired

3. **Grab Images**:
   - Click "Grab Now" on any source
   - Or use "Run All Sources Now" for batch operation

4. **Automation** (Optional):
   - Set up cron job to run grabber periodically:
   ```bash
   */30 * * * * php /path/to/pxlboard/cron_grabber.php
   ```

#### Email Notifications

1. **Configure SMTP** in `config/config.php`
2. **User Preferences**: Users can enable/disable email notifications in their profile settings
3. **Test Email**: Use admin panel to send test notification

### API Changes

#### New Notification Methods
```php
$notifier->create($userId, NotificationSystem::TYPE_THREAD_REPLY, 
    'New Reply', 'Someone replied to your thread', 
    ['thread_id' => $threadId], true);
```

#### Image Grabber Methods
```php
$grabber = new ImageGrabber($db, 'uploads');
$grabber->addSource('danbooru', ['tags' => 'cat rating:safe']);
$result = $grabber->grabFromSource($sourceId, 10);
$grabber->importImage($imageData, 'AutoGrabber', 'default');
```

#### SMTP Mailer Methods
```php
$mailer = new SMTPMailer();
$result = $mailer->send('user@example.com', 'Subject', '<p>HTML body</p>', true);
$mailer->sendNotification('user@example.com', 'comment', $data);
```

### Performance

- **Optimized Queries**: Improved thread sorting in community portal
- **Lazy Loading**: Gallery cards support lazy loading for images
- **Caching**: Image grabber caches source configurations
- **Batch Operations**: Support for batch email sending

### Security

- **Input Validation**: All grabber inputs validated and sanitized
- **SMTP Authentication**: Secure credential storage
- **Rate Limiting**: Built-in rate limiting for external API calls
- **XSS Prevention**: Enhanced escape() function prevents XSS attacks

### Known Issues

- Image grabber requires PHP cURL extension
- Some RSS feeds may not parse correctly if malformed
- Large batch imports may timeout on slower servers (use cron for automation)

### Migration from v12f

1. **Backup Database**: Always backup before upgrading
2. **Upload New Files**: Replace existing files with v12g
3. **Update Config**: Add new configuration options
4. **Test Features**: Verify all fixes in your environment
5. **Optional**: Configure image grabber sources

### Upgrade Path

```bash
# Backup
cp -r PXLBoard_v12f PXLBoard_v12f_backup

# Replace files
rm -rf PXLBoard_v12f
unzip PXLBoard_v12g.zip

# Update config
nano config/config.php
# Add SMTP and Grabber configs

# Set permissions
chmod 755 uploads
chmod 755 data
```

### Credits

- Notification system inspired by Reddit and Discord
- Image grabber APIs: Danbooru, Gelbooru communities
- SMTP implementation: RFC 5321 compliance
- Dark mode improvements: Community feedback

### Support

For issues or questions:
- Check documentation in `/docs`
- Review error logs
- Test in development environment first

---

**Full Package**: PXLBoard_v12g.zip
**Release Date**: January 31, 2026
**Compatibility**: PHP 7.4+, MySQL 5.7+
