/**
 * Board Listing Enhancements
 * Inspired by vichan's catalog and board listing features
 */

(function() {
    'use strict';
    
    // Board favorites system (stored in localStorage)
    const BoardFavorites = {
        KEY: 'pxlboard_favorites',
        
        get: function() {
            try {
                return JSON.parse(localStorage.getItem(this.KEY) || '[]');
            } catch(e) {
                return [];
            }
        },
        
        save: function(favorites) {
            localStorage.setItem(this.KEY, JSON.stringify(favorites));
        },
        
        toggle: function(boardId) {
            let favorites = this.get();
            const index = favorites.indexOf(boardId);
            
            if (index === -1) {
                favorites.push(boardId);
            } else {
                favorites.splice(index, 1);
            }
            
            this.save(favorites);
            return index === -1; // return true if added
        },
        
        isFavorite: function(boardId) {
            return this.get().indexOf(boardId) !== -1;
        }
    };
    
    // Live search functionality
    const LiveSearch = {
        delay: 300,
        timeoutHandle: null,
        
        init: function() {
            const searchInput = document.querySelector('.search-box input[name="search"]');
            if (!searchInput) return;
            
            searchInput.addEventListener('input', (e) => {
                clearTimeout(this.timeoutHandle);
                this.timeoutHandle = setTimeout(() => {
                    this.filter(e.target.value);
                }, this.delay);
            });
        },
        
        filter: function(searchTerm) {
            searchTerm = searchTerm.toLowerCase().trim();
            
            document.querySelectorAll('.board-card, .board-list-item').forEach(card => {
                const name = card.querySelector('.board-name')?.textContent.toLowerCase() || '';
                const description = card.querySelector('.board-description')?.textContent.toLowerCase() || '';
                const shortcode = card.querySelector('.board-shortcode, .board-list-icon')?.textContent.toLowerCase() || '';
                
                const matches = !searchTerm || 
                               name.includes(searchTerm) || 
                               description.includes(searchTerm) || 
                               shortcode.includes(searchTerm);
                
                if (matches) {
                    card.style.display = '';
                    card.style.opacity = '1';
                } else {
                    card.style.opacity = '0';
                    setTimeout(() => {
                        if (card.style.opacity === '0') {
                            card.style.display = 'none';
                        }
                    }, 300);
                }
            });
            
            // Update category visibility
            this.updateCategories();
        },
        
        updateCategories: function() {
            document.querySelectorAll('.board-category').forEach(category => {
                const visibleBoards = category.querySelectorAll('.board-card:not([style*="display: none"]), .board-list-item:not([style*="display: none"])');
                
                if (visibleBoards.length === 0) {
                    category.style.display = 'none';
                } else {
                    category.style.display = '';
                }
            });
        }
    };
    
    // Board view preferences
    const ViewPreferences = {
        KEY: 'pxlboard_view_prefs',
        
        get: function() {
            try {
                return JSON.parse(localStorage.getItem(this.KEY) || '{}');
            } catch(e) {
                return {};
            }
        },
        
        save: function(prefs) {
            localStorage.setItem(this.KEY, JSON.stringify(prefs));
        },
        
        getViewMode: function() {
            return this.get().viewMode || 'grid';
        },
        
        setViewMode: function(mode) {
            const prefs = this.get();
            prefs.viewMode = mode;
            this.save(prefs);
        },
        
        getSortBy: function() {
            return this.get().sortBy || 'activity';
        },
        
        setSortBy: function(sort) {
            const prefs = this.get();
            prefs.sortBy = sort;
            this.save(prefs);
        }
    };
    
    // Smooth animations for board cards
    const AnimationEffects = {
        init: function() {
            // Stagger animation for initial load
            this.staggerAnimation();
            
            // Hover effects
            this.setupHoverEffects();
        },
        
        staggerAnimation: function() {
            const cards = document.querySelectorAll('.board-card, .board-list-item');
            cards.forEach((card, index) => {
                card.style.opacity = '0';
                card.style.transform = 'translateY(20px)';
                
                setTimeout(() => {
                    card.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                }, index * 50);
            });
        },
        
        setupHoverEffects: function() {
            document.querySelectorAll('.board-card').forEach(card => {
                card.addEventListener('mouseenter', function() {
                    this.style.transition = 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)';
                });
            });
        }
    };
    
    // Statistics counter animation
    const StatsCounter = {
        init: function() {
            const statNumbers = document.querySelectorAll('.stat-number');
            
            statNumbers.forEach(stat => {
                const target = parseInt(stat.textContent.replace(/,/g, ''));
                if (isNaN(target)) return;
                
                this.animateValue(stat, 0, target, 1500);
            });
        },
        
        animateValue: function(element, start, end, duration) {
            const range = end - start;
            const increment = range / (duration / 16);
            let current = start;
            
            const timer = setInterval(() => {
                current += increment;
                if (current >= end) {
                    element.textContent = end.toLocaleString();
                    clearInterval(timer);
                } else {
                    element.textContent = Math.floor(current).toLocaleString();
                }
            }, 16);
        }
    };
    
    // Compact board list toggle
    const CompactMode = {
        KEY: 'pxlboard_compact_mode',
        
        isCompact: function() {
            return localStorage.getItem(this.KEY) === 'true';
        },
        
        toggle: function() {
            const compact = !this.isCompact();
            localStorage.setItem(this.KEY, compact);
            this.apply(compact);
        },
        
        apply: function(compact) {
            if (compact) {
                document.body.classList.add('compact-mode');
            } else {
                document.body.classList.remove('compact-mode');
            }
        },
        
        init: function() {
            // Add compact mode styles
            if (!document.getElementById('compact-mode-styles')) {
                const style = document.createElement('style');
                style.id = 'compact-mode-styles';
                style.textContent = `
                    .compact-mode .board-card {
                        padding: 12px;
                    }
                    .compact-mode .board-shortcode {
                        font-size: 1.5em;
                    }
                    .compact-mode .board-name {
                        font-size: 1.1em;
                    }
                    .compact-mode .board-description {
                        font-size: 0.8em;
                        min-height: 30px;
                    }
                    .compact-mode .board-stats {
                        font-size: 0.75em;
                    }
                `;
                document.head.appendChild(style);
            }
            
            this.apply(this.isCompact());
        }
    };
    
    // Quick board navigation (keyboard shortcuts)
    const KeyboardNav = {
        init: function() {
            document.addEventListener('keydown', (e) => {
                // Don't interfere with typing in inputs
                if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') {
                    return;
                }
                
                switch(e.key) {
                    case 's':
                        e.preventDefault();
                        document.querySelector('.search-box input')?.focus();
                        break;
                        
                    case 'Escape':
                        const searchInput = document.querySelector('.search-box input');
                        if (searchInput === document.activeElement) {
                            searchInput.blur();
                            searchInput.value = '';
                            LiveSearch.filter('');
                        }
                        break;
                        
                    case 'c':
                        if (e.ctrlKey || e.metaKey) {
                            return; // Don't interfere with copy
                        }
                        const createBtn = document.querySelector('.create-board-btn');
                        if (createBtn) {
                            e.preventDefault();
                            createBtn.click();
                        }
                        break;
                        
                    case 'g':
                        // Toggle grid/list view
                        if (!e.ctrlKey && !e.altKey) {
                            e.preventDefault();
                            const currentView = new URLSearchParams(window.location.search).get('view') || 'grid';
                            const newView = currentView === 'grid' ? 'list' : 'grid';
                            window.location.href = this.updateURLParameter(window.location.href, 'view', newView);
                        }
                        break;
                }
            });
        },
        
        updateURLParameter: function(url, param, value) {
            const urlObj = new URL(url, window.location.origin);
            urlObj.searchParams.set(param, value);
            return urlObj.toString();
        }
    };
    
    // Add "Back to Top" button
    const BackToTop = {
        init: function() {
            const button = document.createElement('button');
            button.className = 'back-to-top';
            button.innerHTML = '↑';
            button.style.cssText = `
                position: fixed;
                bottom: 100px;
                right: 30px;
                width: 50px;
                height: 50px;
                border-radius: 50%;
                background: #667eea;
                color: white;
                border: none;
                font-size: 1.5em;
                cursor: pointer;
                opacity: 0;
                transition: opacity 0.3s, transform 0.3s;
                z-index: 999;
                box-shadow: 0 2px 8px rgba(0,0,0,0.2);
            `;
            
            document.body.appendChild(button);
            
            // Show/hide based on scroll
            window.addEventListener('scroll', () => {
                if (window.scrollY > 300) {
                    button.style.opacity = '1';
                    button.style.pointerEvents = 'auto';
                } else {
                    button.style.opacity = '0';
                    button.style.pointerEvents = 'none';
                }
            });
            
            button.addEventListener('click', () => {
                window.scrollTo({ top: 0, behavior: 'smooth' });
            });
            
            button.addEventListener('mouseenter', () => {
                button.style.transform = 'scale(1.1)';
            });
            
            button.addEventListener('mouseleave', () => {
                button.style.transform = 'scale(1)';
            });
        }
    };
    
    // Board preview on hover (tooltip)
    const BoardPreview = {
        init: function() {
            document.querySelectorAll('.board-card, .board-list-item').forEach(card => {
                card.addEventListener('mouseenter', function() {
                    // Could expand to show recent threads preview
                    const stats = this.querySelector('.board-stats');
                    if (stats) {
                        stats.style.borderColor = '#667eea';
                    }
                });
                
                card.addEventListener('mouseleave', function() {
                    const stats = this.querySelector('.board-stats');
                    if (stats) {
                        stats.style.borderColor = '#e0e0e0';
                    }
                });
            });
        }
    };
    
    // Initialize everything when DOM is ready
    function init() {
        // Only run on boards page
        if (!window.location.search.includes('page=boards') && 
            !document.querySelector('.board-portal')) {
            return;
        }
        
        LiveSearch.init();
        AnimationEffects.init();
        StatsCounter.init();
        CompactMode.init();
        KeyboardNav.init();
        BackToTop.init();
        BoardPreview.init();
        
        // Log keyboard shortcuts info to console
        console.log('%c PXLBoard Keyboard Shortcuts ', 'background: #667eea; color: white; font-weight: bold; padding: 5px;');
        console.log('s - Focus search');
        console.log('Esc - Clear search');
        console.log('c - Create new board');
        console.log('g - Toggle grid/list view');
    }
    
    // Run when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
    
    // Export for potential external use
    window.PXLBoardEnhancements = {
        BoardFavorites,
        LiveSearch,
        ViewPreferences,
        CompactMode
    };
})();
