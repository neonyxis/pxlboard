# Upgrade Guide: v12g to v12h

## Overview
PXLBoard v12h introduces multi-database support and fixes critical PHP 8.3/8.4 compatibility issues. This guide will help you upgrade safely.

## What's New
- Multi-database support (FlatFile, SQLite, MySQL)
- PHP 8.3/8.4 compatibility fixes
- Improved error handling
- Better performance options

## Pre-Upgrade Checklist

### 1. Backup Everything
```bash
# Backup your data directory
cp -r data data_backup_$(date +%Y%m%d)

# Backup your uploads
cp -r uploads uploads_backup_$(date +%Y%m%d)

# Backup your database (if using external DB)
# For MySQL:
mysqldump -u username -p database_name > backup.sql
```

### 2. Check PHP Version
```bash
php -v
```
v12h works with PHP 7.4+, but is optimized for PHP 8.3/8.4.

### 3. Note Your Current Settings
- Database type (currently FlatFile only in v12g)
- Custom themes
- Any custom modifications

## Upgrade Methods

### Method 1: Simple File Replacement (Recommended)

#### Step 1: Download v12h
Download and extract PXLBoard_v12h.zip

#### Step 2: Backup Current Installation
```bash
cp -r /path/to/pxlboard /path/to/pxlboard_v12g_backup
```

#### Step 3: Replace Files
```bash
# Navigate to your installation
cd /path/to/pxlboard

# Preserve data and uploads
mv data data_preserve
mv uploads uploads_preserve

# Remove old files (be careful!)
rm -rf *

# Extract new version
unzip PXLBoard_v12h.zip
mv PXLBoard_v12h/* .

# Restore data and uploads
rm -rf data uploads
mv data_preserve data
mv uploads_preserve uploads
```

#### Step 4: Set Permissions
```bash
chmod 755 -R .
chmod 777 data
chmod 777 uploads
```

#### Step 5: Test
Visit your site. It should work immediately with your existing data!

### Method 2: Git Pull (For Git Users)

```bash
cd /path/to/pxlboard
git pull origin main
git checkout v12h
```

### Method 3: Fresh Install + Data Migration

If you want a completely fresh start:

1. Install v12h in a new directory
2. Copy `data/` from old installation
3. Copy `uploads/` from old installation
4. Copy `.htaccess` settings if modified
5. Update config if needed

## Post-Upgrade Steps

### 1. Verify Installation
Visit: `https://yoursite.com/pxlboard/`
You should see your site working normally.

### 2. Check for Errors
Look in your server error logs for any deprecation warnings:
```bash
tail -f /var/log/apache2/error.log
# or
tail -f /var/log/php-fpm/error.log
```

### 3. Clear Cache
```bash
rm -rf data/cache/*
```

### 4. Test Critical Functions
- [ ] Login/Logout
- [ ] Upload images
- [ ] Create threads
- [ ] Admin panel access
- [ ] Image viewing
- [ ] Comments

## Database Migration (Optional)

If you want to migrate from FlatFile to SQLite or MySQL:

### Migrate to SQLite

#### Create Admin Tool (add to admin panel or create migrate.php):

```php
<?php
// migrate_to_sqlite.php
require_once 'config/config.php';
require_once 'includes/database.php';

// Create new SQLite database
$newDb = new SQLiteDB(DATA_DIR . '/database.sqlite');

// Get all collections
$collections = [
    'users', 'images', 'tags', 'comments', 'sessions',
    'ratings', 'favorites', 'forum_topics', 'forum_replies',
    'channels', 'extensions', 'blog_posts', 'blog_comments',
    'wiki_pages', 'wiki_revisions', 'notifications',
    'moderation_queue', 'user_hides', 'boards',
    'board_threads', 'board_posts', 'tgp_posts', 'tgp_likes'
];

// Migrate each collection
$oldDb = new FlatFileDB(DATA_DIR);

foreach ($collections as $collection) {
    echo "Migrating $collection...\n";
    $items = $oldDb->getAll($collection);
    
    foreach ($items as $item) {
        $id = $item['id'];
        unset($item['id']);
        $newDb->save($collection, $id, $item);
    }
    
    echo "  Migrated " . count($items) . " items\n";
}

// Update configuration
$dbConfig = [
    'type' => 'sqlite',
    'path' => DATA_DIR . '/database.sqlite'
];

file_put_contents(DATA_DIR . '/db_config.json', json_encode($dbConfig, JSON_PRETTY_PRINT));

echo "Migration complete! Update your index.php to use DatabaseFactory.\n";
```

### Migrate to MySQL

#### Step 1: Create MySQL Database
```sql
CREATE DATABASE pxlboard CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'pxluser'@'localhost' IDENTIFIED BY 'your_password';
GRANT ALL PRIVILEGES ON pxlboard.* TO 'pxluser'@'localhost';
FLUSH PRIVILEGES;
```

#### Step 2: Configure Database
Create `/data/db_config.json`:
```json
{
    "type": "mysql",
    "host": "localhost",
    "dbname": "pxlboard",
    "username": "pxluser",
    "password": "your_password",
    "prefix": "pxl_"
}
```

#### Step 3: Run Migration Script
(Similar to SQLite migration above, but use MySQLDB instead)

## Troubleshooting

### Error: "Call to undefined function..."
**Solution**: Make sure all files were uploaded correctly. Re-upload if necessary.

### Error: "htmlspecialchars(): Passing null..."
**Solution**: This was the main bug in v12g. Make sure you're running v12h files.

### Database Connection Errors
**Solution**: 
1. Check `db_config.json` credentials
2. Ensure MySQL/SQLite PHP extensions are installed
3. Test database connection manually

### Permissions Errors
**Solution**:
```bash
chmod 755 -R /path/to/pxlboard
chmod 777 /path/to/pxlboard/data
chmod 777 /path/to/pxlboard/uploads
```

### Site Shows Blank Page
**Solution**:
1. Enable error reporting in config.php
2. Check PHP error logs
3. Verify all files uploaded correctly

### Old Data Not Showing
**Solution**:
1. Verify `data/` directory was preserved
2. Check file permissions
3. Ensure database configuration is correct

## Rollback Procedure

If something goes wrong:

```bash
# Stop web server
sudo systemctl stop apache2  # or nginx

# Restore backup
cd /path/to
rm -rf pxlboard
mv pxlboard_v12g_backup pxlboard

# Restore data if needed
cd pxlboard
rm -rf data uploads
mv ../data_backup_YYYYMMDD data
mv ../uploads_backup_YYYYMMDD uploads

# Start web server
sudo systemctl start apache2  # or nginx
```

## PHP Version Specific Notes

### PHP 8.3
- All known compatibility issues fixed in v12h
- Deprecated warnings eliminated
- Performance improvements active

### PHP 8.4
- Fully tested and compatible
- Uses modern PHP features where applicable
- JIT compiler benefits available

### PHP 7.4 (EOL)
- Still supported but not recommended
- Consider upgrading to PHP 8.3+
- Some performance features unavailable

## Performance Tips After Upgrade

### 1. Enable OPcache
Add to php.ini:
```ini
opcache.enable=1
opcache.memory_consumption=128
opcache.max_accelerated_files=10000
opcache.revalidate_freq=2
```

### 2. Consider Database Upgrade
- FlatFile: Good for <1000 images
- SQLite: Good for <10,000 images
- MySQL: Best for >10,000 images

### 3. Enable Gzip Compression
Add to .htaccess:
```apache
<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/html text/plain text/xml text/css text/javascript application/javascript
</IfModule>
```

## Getting Help

If you encounter issues:

1. Check the [TROUBLESHOOTING.md](TROUBLESHOOTING.md) guide
2. Review PHP error logs
3. Verify file permissions
4. Check database connectivity
5. Ask on the PXLBoard community forums

## Next Steps

After successful upgrade:

1. Review new features in [CHANGELOG_v12h.md](CHANGELOG_v12h.md)
2. Consider migrating to SQLite or MySQL for better performance
3. Customize themes using new CSS variables
4. Configure image grabber in admin panel (when available)
5. Set up scheduled backups

## Important Notes

- **Backward Compatible**: v12h works with all v12g data
- **No Data Loss**: Your existing content is preserved
- **Easy Rollback**: Keep backups for safety
- **Performance**: Consider database upgrade for larger sites
- **Testing**: Test thoroughly before going live

---

**Upgrade Time Estimate**:
- Small site (<100 images): 5-10 minutes
- Medium site (100-1000 images): 10-20 minutes  
- Large site (>1000 images): 20-30 minutes
- Plus optional database migration: 10-60 minutes

**Support**: For assistance, please visit the PXLBoard forums or open an issue on GitHub.
