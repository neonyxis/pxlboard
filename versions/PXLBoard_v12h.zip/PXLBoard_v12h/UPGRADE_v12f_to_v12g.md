# PXLBoard v12f to v12g Upgrade Guide

## Overview

This guide will walk you through upgrading from PXLBoard v12f to v12g. The upgrade includes critical bug fixes, enhanced notification system, SMTP email support, and a new image grabber feature.

## Pre-Upgrade Checklist

- [ ] Backup your entire PXLBoard directory
- [ ] Backup your database
- [ ] Verify PHP version (7.4 or higher required)
- [ ] Verify PHP cURL extension is installed
- [ ] Note your current configuration settings
- [ ] Test in development environment first

## What's New in v12g

### Critical Bug Fixes ✅
1. ✅ Fixed missing `gallery_card.php` template error
2. ✅ Fixed board shortname undefined array key errors
3. ✅ Fixed PHP 8.1+ htmlspecialchars null parameter deprecation
4. ✅ Fixed community portal threads not updating properly
5. ✅ Fixed dark mode inconsistencies across all site elements

### New Features 🚀
1. 🚀 Extensive notification system with 13+ notification types
2. 🚀 SMTP email notifications with template support
3. 🚀 Image grabber system for Danbooru, Gelbooru, RSS feeds
4. 🚀 Admin dashboard for image grabber management
5. 🚀 Enhanced dark mode with 40+ new style rules

## Upgrade Steps

### Step 1: Backup Everything

```bash
# Backup files
cp -r /path/to/PXLBoard_v12f /path/to/PXLBoard_v12f_backup_$(date +%Y%m%d)

# Backup database (if using MySQL)
mysqldump -u username -p database_name > pxlboard_backup_$(date +%Y%m%d).sql

# Verify backups
ls -lh /path/to/backups/
```

### Step 2: Download and Extract v12g

```bash
# Download the v12g package
# Extract to temporary location
unzip PXLBoard_v12g.zip -d /tmp/PXLBoard_v12g

# Verify extraction
ls -la /tmp/PXLBoard_v12g/
```

### Step 3: Preserve Your Configuration

```bash
# Copy your config file to safe location
cp /path/to/PXLBoard_v12f/config/config.php ~/config_backup.php

# Copy your uploads directory
cp -r /path/to/PXLBoard_v12f/uploads /tmp/uploads_backup
```

### Step 4: Update Files

```bash
# Method 1: Replace entire directory (recommended for clean install)
cd /path/to/webroot
rm -rf PXLBoard_v12f
mv /tmp/PXLBoard_v12g ./PXLBoard_v12g
ln -s PXLBoard_v12g PXLBoard  # Symbolic link for easy switching

# Method 2: Selective update (if you have customizations)
# Copy only changed files - see "Changed Files" section below
```

### Step 5: Restore and Update Configuration

```bash
# Copy back your config
cp ~/config_backup.php /path/to/PXLBoard_v12g/config/config.php

# Edit config to add new settings
nano /path/to/PXLBoard_v12g/config/config.php
```

Add these new configuration options to your `config.php`:

```php
// ============================================
// SMTP Email Configuration (New in v12g)
// ============================================
define('SMTP_ENABLED', false);  // Set to true to enable
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'your-email@gmail.com');
define('SMTP_PASSWORD', 'your-app-password');
define('SMTP_FROM', 'noreply@yoursite.com');
define('SMTP_USE_TLS', true);

// ============================================
// Image Grabber Configuration (New in v12g)
// ============================================
define('GRABBER_ENABLED', false);  // Set to true to enable
define('GRABBER_AUTO_RUN', false);
define('GRABBER_MAX_IMAGES', 50);
```

### Step 6: Restore Data

```bash
# Restore uploads
cp -r /tmp/uploads_backup/* /path/to/PXLBoard_v12g/uploads/

# Verify uploads are accessible
ls -la /path/to/PXLBoard_v12g/uploads/
```

### Step 7: Set Permissions

```bash
cd /path/to/PXLBoard_v12g

# Set directory permissions
chmod 755 uploads
chmod 755 data
chmod 755 data/notifications
chmod 755 config

# Set file permissions
chmod 644 config/config.php
chmod 644 includes/*.php
chmod 644 pages/*.php
```

### Step 8: Verify Installation

1. **Check homepage**: Visit your site and verify it loads
2. **Check admin panel**: Login as admin and access admin panel
3. **Test dark mode**: Switch to dark theme and check styling
4. **Test boards**: Navigate to boards and check for errors
5. **Test community portal**: Verify threads display correctly
6. **Test gallery**: Check that gallery cards display properly

### Step 9: Configure New Features (Optional)

#### Enable SMTP Emails

1. Get SMTP credentials from your email provider
2. Update `config.php` with SMTP settings
3. Set `SMTP_ENABLED` to `true`
4. Test by triggering a notification

**Gmail Setup**:
```php
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'youremail@gmail.com');
define('SMTP_PASSWORD', 'your-16-char-app-password');  // NOT your regular password!
define('SMTP_USE_TLS', true);
```

To get Gmail App Password:
1. Go to Google Account settings
2. Security → 2-Step Verification
3. App passwords → Generate
4. Use the 16-character password

#### Enable Image Grabber

1. Set `GRABBER_ENABLED` to `true` in config
2. Navigate to Admin → Image Grabber (`?page=admin_grabber`)
3. Add your first source (start with Safebooru for testing)
4. Click "Grab Now" to test
5. Enable auto-import if desired

### Step 10: Update .htaccess (If Applicable)

If you use custom URL routing, ensure your `.htaccess` is compatible:

```apache
# No changes needed for v12g
# But verify your existing .htaccess works
```

## Changed Files Reference

### New Files in v12g
```
/includes/smtp_mailer.php              [NEW]
/includes/image_grabber.php            [NEW]
/pages/admin_grabber.php               [NEW]
/templates/gallery_card.php            [NEW]
/CHANGELOG_v12g.md                     [NEW]
/UPGRADE_v12f_to_v12g.md              [NEW]
/README_v12g.md                        [NEW]
```

### Modified Files in v12g
```
/includes/functions.php                [MODIFIED - escape() function]
/includes/notifications.php            [MODIFIED - new notification types]
/pages/boards.php                      [MODIFIED - null handling]
/pages/community_portal.php            [MODIFIED - thread sorting]
/themes/dark/style.css                 [MODIFIED - extensive additions]
```

### Files to Preserve (Your Data)
```
/config/config.php                     [PRESERVE]
/uploads/*                             [PRESERVE]
/data/*                                [PRESERVE]
/.htaccess                             [PRESERVE IF CUSTOMIZED]
```

## Database Migration

**Good News**: No database schema changes are required for v12g!

All new features use the existing flexible JSON-based storage system. However, you may want to verify data integrity:

```php
// Run this from admin panel or create a migration script
$db->getAll('notifications');  // Should work
$db->getAll('grabber_sources');  // Will be empty initially (expected)
```

## Troubleshooting

### Issue: "Class 'SMTPMailer' not found"

**Solution**: Make sure `/includes/smtp_mailer.php` was uploaded correctly.

```bash
ls -l /path/to/PXLBoard_v12g/includes/smtp_mailer.php
```

### Issue: "Class 'ImageGrabber' not found"

**Solution**: Ensure `/includes/image_grabber.php` exists.

```bash
ls -l /path/to/PXLBoard_v12g/includes/image_grabber.php
```

### Issue: Gallery card template errors

**Solution**: Verify the template file exists and is readable.

```bash
ls -l /path/to/PXLBoard_v12g/templates/gallery_card.php
chmod 644 /path/to/PXLBoard_v12g/templates/gallery_card.php
```

### Issue: Dark mode still looks inconsistent

**Solution**: Clear browser cache and verify you're using the correct theme CSS.

```bash
# Verify dark theme CSS was updated
ls -l /path/to/PXLBoard_v12g/themes/dark/style.css

# Check file size (should be larger than v12f)
du -h /path/to/PXLBoard_v12g/themes/dark/style.css
```

### Issue: SMTP emails not sending

**Checklist**:
1. ✅ `SMTP_ENABLED` is `true`
2. ✅ SMTP credentials are correct
3. ✅ Port 587 (or 465) is not blocked by firewall
4. ✅ Using app password for Gmail (not regular password)
5. ✅ Check PHP error logs for specific SMTP errors

```bash
# Test SMTP connection
telnet smtp.gmail.com 587
# Should connect (Ctrl+C to exit)

# Check PHP error log
tail -f /var/log/php_errors.log
```

### Issue: Image grabber not downloading images

**Checklist**:
1. ✅ PHP cURL extension is installed
2. ✅ `uploads` directory is writable
3. ✅ Firewall allows outbound HTTPS connections
4. ✅ API endpoints are accessible

```bash
# Check cURL
php -m | grep curl

# Test manual download
curl -I https://danbooru.donmai.us/posts.json
# Should return 200 OK

# Check uploads directory permissions
ls -ld uploads
# Should be: drwxr-xr-x
```

## Rollback Procedure

If you encounter critical issues and need to rollback:

```bash
# Stop web server (if possible)
sudo systemctl stop apache2  # or nginx

# Restore files
rm -rf /path/to/PXLBoard_v12g
mv /path/to/PXLBoard_v12f_backup /path/to/PXLBoard_v12f

# Restore database (if you made changes)
mysql -u username -p database_name < pxlboard_backup_YYYYMMDD.sql

# Restart web server
sudo systemctl start apache2
```

## Post-Upgrade Tasks

### 1. Test Critical Functionality
- [ ] User login/registration
- [ ] Image upload
- [ ] Board posting
- [ ] Comments
- [ ] Admin panel access

### 2. Configure New Features
- [ ] Set up SMTP (if desired)
- [ ] Configure image grabber sources (if desired)
- [ ] Test notifications

### 3. Monitor for Issues
- [ ] Check error logs daily for first week
- [ ] Monitor email sending (if enabled)
- [ ] Check image grabber imports (if enabled)

### 4. Optimize Performance
- [ ] Clear old notifications periodically
- [ ] Monitor grabber import frequency
- [ ] Adjust email batch sizes if needed

## Performance Considerations

### Image Grabber
- Start with small limits (10-20 images per grab)
- Use cron jobs instead of web-triggered grabs for large imports
- Monitor disk space if auto-importing

### Email Notifications
- Enable email notifications gradually
- Consider email batching for high-traffic sites
- Monitor SMTP rate limits

## Support

If you encounter issues:

1. **Check Logs**: Review PHP error logs and server logs
2. **Documentation**: Read `/docs` directory files
3. **Verify Environment**: Ensure PHP 7.4+, cURL extension
4. **Test Individually**: Test each new feature separately
5. **Rollback If Needed**: Use backup to restore previous version

## Recommended Next Steps

1. **Test thoroughly** in staging before production
2. **Configure SMTP** for better user engagement
3. **Set up image grabber** sources for automated content
4. **Review dark mode** improvements on all pages
5. **Update documentation** for your users about new features

---

**Upgrade completed!** You're now running PXLBoard v12g with enhanced notifications, SMTP support, and image grabber capabilities.

For detailed feature documentation, see `CHANGELOG_v12g.md` and `README_v12g.md`.
