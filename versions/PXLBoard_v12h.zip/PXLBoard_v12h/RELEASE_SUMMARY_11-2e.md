# PXLBoard v11-2e - Release Summary

**Release Date**: January 31, 2026  
**Package Name**: PXLBoard_v11-2e.zip  
**Package Size**: ~232 KB

## What's Included

This release contains both new debugging features AND critical bug fixes from version 11-2d.

### 🆕 New Features

#### Admin Debug Panel
A comprehensive system diagnostics and information panel accessible from Admin Panel → Debug tab:

**7 Major Sections:**

1. **System Version** - PXLBoard version, PHP version, server software, installation date
2. **Path Configuration** - All directory paths with writable status indicators
3. **PHP Configuration** - Upload limits, memory, execution time, enabled extensions
4. **Database Statistics** - Record counts across 11 data collections
5. **Recent PHP Errors** - Last 20 error log entries with scrollable view
6. **Quick Diagnostics** - Automated checks for common issues
7. **Maintenance Tools** - Quick actions (diagnostics, refresh, copy version)

#### Version Indicators
- Admin navbar badge (visible only to admins)
- Footer display (visible to all users)
- One-click version copying

### 🐛 Critical Bug Fixes

#### Database Issues
**Fixed**: User profile corruption bug
- **Problem**: Profile updates saved to `null.json` instead of actual user file
- **Cause**: `db->get()` didn't return the `id` field
- **Impact**: Users couldn't update profiles, got PHP warnings
- **Fix**: Inject `id` in `database.php` + null guard in `profile.php`

#### Routing Issues
**Fixed**: Public profile 404 errors
- **Problem**: `/user/username` URLs gave 404 in subdirectory deployments
- **Cause**: `buildUrl()` generated root-relative paths, `.htaccess` had wrong `RewriteBase`
- **Impact**: All pretty URLs broken in subdirectory installations
- **Fix**: Auto-detect subdirectory from `SITE_URL`, auto-patch `.htaccess` during install

## Installation

### New Installations
1. Extract to web directory
2. Visit `/install.php`
3. Complete installation form
4. System auto-configures paths

### Upgrades from 11-2d
1. Backup `data/` directory
2. Extract over existing installation (keep `data/` folder)
3. Remove `data/users/null.json` if it exists
4. Visit site and verify version in footer

**Detailed instructions**: See `UPGRADE_GUIDE_11-2e.md`

## File Changes

### Modified Core Files (9 files)
- `config/config.php` - Version constant
- `includes/database.php` - ID injection
- `includes/functions.php` - URL prefix handling
- `pages/profile.php` - Null safety
- `pages/install.php` - .htaccess patching
- `pages/admin.php` - Debug tab
- `templates/header.php` - Version badge
- `.htaccess` - Documentation
- `CHANGELOG.md` - Version history
- `README.md` - Updated info

### New Files (2 files)
- `VERSION_NOTES_11-2e.md` - Complete release notes
- `UPGRADE_GUIDE_11-2e.md` - Installation/upgrade instructions

### Unchanged
- All `data/` directory contents
- All `uploads/` directory contents
- User settings and configuration
- All other system files

## Requirements

### Server Requirements
- PHP 7.4 or higher
- Apache with mod_rewrite (or nginx with rewrite rules)
- GD Library for image processing
- JSON extension
- Writable directories: `data/`, `uploads/`

### Recommended
- PHP 8.0+ for better performance
- 128MB+ PHP memory limit
- 10MB+ upload limit

## Testing Checklist

After installation/upgrade:

- [ ] Can log in as admin
- [ ] Version shows "11-2e" in footer
- [ ] Version badge appears in navbar (admins)
- [ ] Admin Panel → Debug tab loads
- [ ] Debug panel shows all 7 sections
- [ ] User profile pages load without errors
- [ ] Can update profile information
- [ ] Pretty URLs work (e.g., `/user/username`)
- [ ] Image upload still works
- [ ] All existing data intact

## Known Issues

**None reported** as of release date.

If you find issues, check:
1. Debug panel for diagnostics
2. PHP error logs
3. File permissions (755 for directories, 644 for files)
4. `.htaccess` RewriteBase matches your path

## Documentation Files

📄 **VERSION_NOTES_11-2e.md** - Complete technical documentation  
📄 **UPGRADE_GUIDE_11-2e.md** - Step-by-step upgrade instructions  
📄 **CHANGELOG.md** - Full version history  
📄 **README.md** - Project overview and features  

## Security Notes

- Debug panel is admin-only (proper authorization checks)
- Error log viewing requires file read permissions
- No sensitive data exposed to non-admin users
- Version info display is safe (no exploitable information)

## Support

For issues:
1. Check Debug panel in Admin section
2. Review error logs
3. Verify file permissions
4. Check `.htaccess` configuration

## Credits

**PXLBoard** - Flat-file PHP imageboard system  
Inspired by Derpibooru and Philomena

---

**Enjoy the improved debugging tools and bug-free experience!** 🎉
