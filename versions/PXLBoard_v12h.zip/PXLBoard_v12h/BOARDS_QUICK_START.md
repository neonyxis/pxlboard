# Quick Implementation Guide

## Installation (5 minutes)

### Step 1: Backup Current Files
```bash
# Backup your current boards.php
cp pages/boards.php pages/boards_original_backup.php
```

### Step 2: Deploy Improved Files

#### Option A: Replace Existing (Recommended)
```bash
# Copy the improved version over the old one
cp pages/boards_improved.php pages/boards.php
```

#### Option B: Side-by-side Testing
```bash
# Keep both versions
# Access via: ?page=boards_improved
mv pages/boards_improved.php pages/boards_improved.php
# Original remains at ?page=boards
```

### Step 3: Add JavaScript Enhancement

1. Create `js` directory if it doesn't exist:
```bash
mkdir -p js
```

2. Copy the JavaScript file:
```bash
cp js/boards-enhanced.js js/
```

3. Update `templates/header.php`:

Add this before the closing `</head>` tag:
```php
<?php if (isset($_GET['page']) && $_GET['page'] === 'boards'): ?>
    <script src="js/boards-enhanced.js"></script>
<?php endif; ?>
```

Or if you want it globally:
```php
<script src="js/boards-enhanced.js"></script>
```

### Step 4: Test

Visit your boards page:
```
http://yoursite.com/index.php?page=boards
```

**What to check:**
- ✅ Boards load and display
- ✅ Search works (type in search box)
- ✅ Sort dropdown changes order
- ✅ Grid/List view toggle works
- ✅ Statistics display correctly
- ✅ Keyboard shortcuts work (press 's')

## Quick Fixes

### If JavaScript doesn't work:

1. **Check console** (F12 in browser):
   - Look for 404 errors on js file
   - Check for JavaScript errors

2. **Verify path**:
   ```html
   <!-- Should be relative to index.php -->
   <script src="js/boards-enhanced.js"></script>
   ```

3. **Clear browser cache**:
   - Chrome: Ctrl+Shift+R (hard reload)
   - Firefox: Ctrl+F5

### If caching causes issues:

Temporarily disable cache:
```php
// In boards.php (or boards_improved.php)
// Line ~18, change:
$use_cache = false; // Was: true
```

### If boards don't display:

Check your database structure:
```php
// Boards should have these fields:
- id
- shortcode
- name  
- description
- category
- nsfw
- featured
- user_created
- thread_count
- post_count
```

## Configuration

### 1. Adjust Cache Time

In `pages/boards.php` line ~18:
```php
$cache_time = 300;  // 5 minutes (default)
$cache_time = 600;  // 10 minutes
$cache_time = 60;   // 1 minute
$cache_time = 0;    // Disable cache
```

### 2. Change Default View

In `pages/boards.php` line ~68:
```php
$view_mode = $_GET['view'] ?? 'grid';  // Default: grid
$view_mode = $_GET['view'] ?? 'list';  // Default: list
```

### 3. Change Default Sort

In `pages/boards.php` line ~69:
```php
$sort_by = $_GET['sort'] ?? 'activity';  // Default: activity
$sort_by = $_GET['sort'] ?? 'name';      // Default: alphabetical
$sort_by = $_GET['sort'] ?? 'threads';   // Default: most threads
```

### 4. Disable Keyboard Shortcuts

In `js/boards-enhanced.js`, comment out line ~250:
```javascript
// KeyboardNav.init();  // Disabled
```

### 5. Disable Animations

In `js/boards-enhanced.js`, comment out line ~247:
```javascript
// AnimationEffects.init();  // Disabled
```

## Feature Flags

Create a config section at the top of `pages/boards.php`:

```php
// Feature flags
$config = [
    'enable_cache' => true,
    'cache_duration' => 300,
    'enable_search' => true,
    'enable_nsfw_filter' => true,
    'default_view' => 'grid',
    'default_sort' => 'activity',
    'show_stats_summary' => true,
    'show_recent_activity' => true
];
```

## Keyboard Shortcuts Reference

Print this or share with users:

| Shortcut | Action |
|----------|--------|
| `s` | Focus search box |
| `ESC` | Clear search / unfocus |
| `c` | Create new board (if logged in) |
| `g` | Toggle Grid/List view |

## Customization Examples

### 1. Change Color Scheme

In `pages/boards.php` CSS section:
```css
.board-header {
    /* Change gradient colors */
    background: linear-gradient(135deg, #YOUR_COLOR1 0%, #YOUR_COLOR2 100%);
}
```

### 2. Modify Grid Columns

```css
.board-grid {
    /* Change number of columns */
    grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); /* Smaller cards */
    grid-template-columns: repeat(auto-fill, minmax(350px, 1fr)); /* Larger cards */
}
```

### 3. Add Custom Sort Option

In `pages/boards.php`, find the sort switch (~line 115):
```php
case 'custom':
    // Your custom sorting logic
    return $a['your_field'] - $b['your_field'];
```

Then add to the select dropdown (~line 450):
```html
<option value="custom">Custom Sort</option>
```

## Integration with Existing Features

### If you have custom board fields:

Update the board card template (~line 500):
```php
<?php if (isset($board['your_custom_field'])): ?>
    <div class="custom-field">
        <?php echo htmlspecialchars($board['your_custom_field']); ?>
    </div>
<?php endif; ?>
```

### If you have board permissions:

Add permission checks:
```php
<?php if ($auth->canViewBoard($board)): ?>
    <!-- Show board -->
<?php endif; ?>
```

## Performance Tuning

### For Large Installations (1000+ boards):

1. **Enable Redis caching**:
```php
// Replace session cache with Redis
$redis = new Redis();
$redis->connect('127.0.0.1', 6379);

if ($redis->exists($cache_key)) {
    $boards = json_decode($redis->get($cache_key), true);
} else {
    // ... fetch boards
    $redis->setex($cache_key, $cache_time, json_encode($boards));
}
```

2. **Paginate results**:
```php
$per_page = 50;
$page = $_GET['p'] ?? 1;
$boards = array_slice($boards, ($page - 1) * $per_page, $per_page);
```

3. **Lazy load images** (if you add board thumbnails):
```html
<img loading="lazy" src="...">
```

## Rollback Instructions

If you need to revert to the original:

```bash
# Restore backup
cp pages/boards_original_backup.php pages/boards.php

# Remove JavaScript (optional)
rm js/boards-enhanced.js

# Remove JavaScript include from header.php
# (edit and remove the script tag added in Step 3)
```

## Testing Checklist

- [ ] Boards load without errors
- [ ] Search functionality works
- [ ] Sort dropdown changes order
- [ ] Grid/List toggle works
- [ ] SFW/NSFW filter works
- [ ] Statistics display correctly
- [ ] Board cards are clickable
- [ ] Admin delete button works (if admin)
- [ ] Create board button appears (if logged in)
- [ ] Mobile layout is responsive
- [ ] Keyboard shortcuts work
- [ ] Animations are smooth
- [ ] No JavaScript errors in console

## Common Issues

### Issue: "Boards not loading"
**Solution**: Check database connection and table structure

### Issue: "Search doesn't work"
**Solution**: Verify JavaScript file is loaded (check Network tab in DevTools)

### Issue: "Cache shows old data"
**Solution**: Clear cache manually or reduce cache_time

### Issue: "Page is slow"
**Solution**: Enable caching, optimize database queries

### Issue: "Mobile view broken"
**Solution**: Check responsive CSS is not overridden by custom styles

## Support

If you encounter issues:

1. Check `BOARDS_IMPROVEMENTS.md` for detailed documentation
2. Look in browser console for JavaScript errors
3. Verify file paths are correct
4. Test with cache disabled
5. Check database has required fields

## Next Steps

After successful installation:

1. **Monitor performance**: Check page load times
2. **Gather feedback**: Ask users what they think
3. **Customize**: Adjust colors, layout to match your site
4. **Optimize**: Enable Redis cache for production
5. **Extend**: Add new features from "Future Enhancements" section

## Additional Resources

- Full documentation: `BOARDS_IMPROVEMENTS.md`
- Original boards.php: `pages/boards_original_backup.php`
- JavaScript source: `js/boards-enhanced.js`

---

**Estimated setup time**: 5-10 minutes
**Difficulty**: Easy to Moderate
**Breaking changes**: None (fully backward compatible)
