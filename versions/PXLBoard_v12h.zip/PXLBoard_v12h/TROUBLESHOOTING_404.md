# PXLBoard 404 Error Troubleshooting Guide

## Common Causes and Solutions

### 1. .htaccess Not Being Read

**Symptoms:**
- Accessing `/` or `/home` shows 404
- Only `index.php?page=home` works

**Solutions:**

a) **Enable mod_rewrite in Apache:**
```bash
sudo a2enmod rewrite
sudo systemctl restart apache2
```

b) **Allow .htaccess in Apache configuration:**
Edit your Apache config (usually `/etc/apache2/sites-available/000-default.conf` or your virtual host):

```apache
<Directory /var/www/html>
    AllowOverride All
    Require all granted
</Directory>
```

Then restart Apache:
```bash
sudo systemctl restart apache2
```

c) **Check if .htaccess file exists:**
```bash
ls -la | grep .htaccess
```

If missing, the .htaccess file might not have been extracted from the zip properly (hidden files issue).

### 2. Data Directory Missing or Not Writable

**Symptoms:**
- Redirects to installation page repeatedly
- Database errors
- Cannot save uploaded images

**Solutions:**

```bash
# Create data directory
mkdir data
chmod 777 data

# Create uploads directory  
mkdir uploads
chmod 777 uploads
```

### 3. Installation Not Completed

**Symptoms:**
- Always redirects to `index.php?page=install`
- 404 after clicking links

**Solution:**
Complete the installation by visiting `index.php?page=install` in your browser and following the setup wizard.

### 4. Missing PHP Extensions

**Symptoms:**
- Blank pages
- 500 Internal Server Error
- Class not found errors

**Solution:**
Ensure required PHP extensions are installed:

```bash
# For Ubuntu/Debian
sudo apt-get install php-gd php-mbstring php-xml

# Restart Apache
sudo systemctl restart apache2
```

### 5. Wrong Document Root

**Symptoms:**
- CSS/JS not loading
- Images not displaying
- 404 on all pages

**Solution:**
Ensure PXLBoard files are in your web server's document root:
- **Apache default:** `/var/www/html/`
- **XAMPP:** `C:\xampp\htdocs\`
- **WAMP:** `C:\wamp\www\`

### 6. Permissions Issues

**Symptoms:**
- Cannot upload images
- Cannot create users
- "Permission denied" errors

**Solution:**

```bash
# Set proper ownership (replace www-data with your web server user)
sudo chown -R www-data:www-data /path/to/pxlboard

# Set proper permissions
chmod -R 755 /path/to/pxlboard
chmod -R 777 /path/to/pxlboard/data
chmod -R 777 /path/to/pxlboard/uploads
```

## Quick Diagnostic Steps

1. **Access diagnostic.php:**
   Visit `http://yoursite.com/diagnostic.php` to see detailed system information

2. **Test direct access:**
   Try accessing `http://yoursite.com/index.php?page=home`
   - If this works, the issue is with .htaccess/mod_rewrite
   - If this doesn't work, the issue is with PHP/installation

3. **Check Apache error log:**
   ```bash
   sudo tail -f /var/log/apache2/error.log
   ```

4. **Check PHP error log:**
   Look in your PHP error log location (check phpinfo() for location)

5. **Test mod_rewrite:**
   Visit `http://yoursite.com/home`
   - If it works, mod_rewrite is working
   - If 404, mod_rewrite is not enabled or .htaccess not being read

## Specific Error Messages

### "The page you're looking for doesn't exist"
This is PXLBoard's 404 page, meaning:
- PHP is working
- PXLBoard is installed
- But the requested page parameter is invalid

**Check:** The URL might have a typo or the page doesn't exist in the router (index.php)

### "404 Not Found" (Apache default)
This is Apache's 404, meaning:
- The file literally doesn't exist
- Mod_rewrite is not working
- .htaccess is not being read

**Solution:** Enable mod_rewrite and AllowOverride All

### "500 Internal Server Error"
This means PHP encountered a fatal error.

**Solutions:**
1. Check Apache error log
2. Enable PHP error display (temporarily):
   Add to top of index.php:
   ```php
   error_reporting(E_ALL);
   ini_set('display_errors', 1);
   ```

## Testing Checklist

- [ ] Apache mod_rewrite is enabled
- [ ] AllowOverride All is set in Apache config
- [ ] .htaccess file exists and is readable
- [ ] data/ directory exists and is writable (chmod 777)
- [ ] uploads/ directory exists and is writable (chmod 777)
- [ ] Installation completed (installed.lock exists in data/)
- [ ] PHP version >= 7.4
- [ ] Required PHP extensions installed

## Still Having Issues?

1. Run diagnostic.php and review all sections
2. Check Apache and PHP error logs
3. Try accessing index.php?page=home directly
4. Verify file permissions and ownership
5. Ensure all files extracted properly from ZIP

## Clean Installation Steps

If all else fails, try a clean installation:

```bash
# 1. Extract ZIP
unzip PXLBoard_Merged_Complete.zip
cd merged/

# 2. Create required directories
mkdir -p data uploads
chmod 777 data uploads

# 3. Set ownership
sudo chown -R www-data:www-data .

# 4. Enable mod_rewrite
sudo a2enmod rewrite
sudo systemctl restart apache2

# 5. Configure Apache (add to your vhost)
# AllowOverride All in your Directory block

# 6. Access installation
# http://yoursite.com/index.php?page=install
```

The installation wizard will create the necessary database files and configuration.
