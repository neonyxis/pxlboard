<?php
/**
 * Diagnostic Page - Debug 404 Issues
 */
?>
<!DOCTYPE html>
<html>
<head>
    <title>PXLBoard Diagnostic</title>
    <style>
        body { font-family: monospace; padding: 20px; background: #f5f5f5; }
        .section { background: white; padding: 15px; margin: 10px 0; border-radius: 5px; }
        .ok { color: green; }
        .error { color: red; }
        .warning { color: orange; }
        h2 { border-bottom: 2px solid #333; padding-bottom: 5px; }
        table { width: 100%; border-collapse: collapse; }
        td, th { padding: 8px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background: #f0f0f0; }
    </style>
</head>
<body>
    <h1>PXLBoard Installation Diagnostic</h1>
    
    <div class="section">
        <h2>1. File Structure</h2>
        <table>
            <tr>
                <th>File/Directory</th>
                <th>Status</th>
                <th>Path</th>
            </tr>
            <?php
            $checks = [
                'index.php' => __DIR__ . '/index.php',
                '.htaccess' => __DIR__ . '/.htaccess',
                'config/config.php' => __DIR__ . '/config/config.php',
                'pages/home.php' => __DIR__ . '/pages/home.php',
                'pages/404.php' => __DIR__ . '/pages/404.php',
                'includes/database.php' => __DIR__ . '/includes/database.php',
                'data/' => __DIR__ . '/data',
                'uploads/' => __DIR__ . '/uploads',
                'templates/header.php' => __DIR__ . '/templates/header.php',
            ];
            
            foreach ($checks as $name => $path) {
                $exists = file_exists($path);
                $readable = $exists && is_readable($path);
                $status = $exists ? ($readable ? 'OK' : 'Not Readable') : 'Missing';
                $class = $exists ? ($readable ? 'ok' : 'warning') : 'error';
                echo "<tr><td>$name</td><td class='$class'>$status</td><td>$path</td></tr>\n";
            }
            ?>
        </table>
    </div>

    <div class="section">
        <h2>2. PHP Configuration</h2>
        <table>
            <tr>
                <th>Setting</th>
                <th>Value</th>
                <th>Status</th>
            </tr>
            <?php
            $phpChecks = [
                'PHP Version' => ['value' => PHP_VERSION, 'required' => '7.4', 'check' => version_compare(PHP_VERSION, '7.4', '>=')],
                'upload_max_filesize' => ['value' => ini_get('upload_max_filesize'), 'required' => '20M', 'check' => true],
                'post_max_size' => ['value' => ini_get('post_max_size'), 'required' => '25M', 'check' => true],
                'memory_limit' => ['value' => ini_get('memory_limit'), 'required' => '128M', 'check' => true],
                'file_uploads' => ['value' => ini_get('file_uploads') ? 'On' : 'Off', 'required' => 'On', 'check' => ini_get('file_uploads')],
            ];
            
            foreach ($phpChecks as $name => $info) {
                $status = $info['check'] ? 'OK' : 'Warning';
                $class = $info['check'] ? 'ok' : 'warning';
                echo "<tr><td>$name</td><td>{$info['value']}</td><td class='$class'>$status (Required: {$info['required']})</td></tr>\n";
            }
            ?>
        </table>
    </div>

    <div class="section">
        <h2>3. REQUEST Information</h2>
        <table>
            <tr><th>Variable</th><th>Value</th></tr>
            <tr><td>REQUEST_URI</td><td><?php echo htmlspecialchars($_SERVER['REQUEST_URI'] ?? 'N/A'); ?></td></tr>
            <tr><td>SCRIPT_NAME</td><td><?php echo htmlspecialchars($_SERVER['SCRIPT_NAME'] ?? 'N/A'); ?></td></tr>
            <tr><td>PHP_SELF</td><td><?php echo htmlspecialchars($_SERVER['PHP_SELF'] ?? 'N/A'); ?></td></tr>
            <tr><td>DOCUMENT_ROOT</td><td><?php echo htmlspecialchars($_SERVER['DOCUMENT_ROOT'] ?? 'N/A'); ?></td></tr>
            <tr><td>HTTP_HOST</td><td><?php echo htmlspecialchars($_SERVER['HTTP_HOST'] ?? 'N/A'); ?></td></tr>
            <tr><td>SERVER_SOFTWARE</td><td><?php echo htmlspecialchars($_SERVER['SERVER_SOFTWARE'] ?? 'N/A'); ?></td></tr>
        </table>
    </div>

    <div class="section">
        <h2>4. $_GET Parameters</h2>
        <table>
            <tr><th>Key</th><th>Value</th></tr>
            <?php
            if (empty($_GET)) {
                echo "<tr><td colspan='2' class='warning'>No GET parameters set</td></tr>";
            } else {
                foreach ($_GET as $key => $value) {
                    echo "<tr><td>" . htmlspecialchars($key) . "</td><td>" . htmlspecialchars($value) . "</td></tr>";
                }
            }
            ?>
        </table>
    </div>

    <div class="section">
        <h2>5. Mod Rewrite Test</h2>
        <?php
        if (function_exists('apache_get_modules')) {
            $modules = apache_get_modules();
            $hasRewrite = in_array('mod_rewrite', $modules);
            echo "<p class='" . ($hasRewrite ? 'ok' : 'error') . "'>mod_rewrite: " . ($hasRewrite ? 'Enabled ✓' : 'Disabled ✗') . "</p>";
        } else {
            echo "<p class='warning'>Cannot detect mod_rewrite (function apache_get_modules not available)</p>";
        }
        
        echo "<p>Access this page as: <a href='test-rewrite'>test-rewrite</a> to test URL rewriting</p>";
        ?>
    </div>

    <div class="section">
        <h2>6. Installation Status</h2>
        <?php
        $dataDir = __DIR__ . '/data';
        $lockFile = $dataDir . '/installed.lock';
        $hasDataDir = is_dir($dataDir);
        $isWritable = $hasDataDir && is_writable($dataDir);
        $isInstalled = file_exists($lockFile);
        
        echo "<table>";
        echo "<tr><td>Data Directory Exists</td><td class='" . ($hasDataDir ? 'ok' : 'error') . "'>" . ($hasDataDir ? 'Yes ✓' : 'No ✗') . "</td></tr>";
        echo "<tr><td>Data Directory Writable</td><td class='" . ($isWritable ? 'ok' : 'error') . "'>" . ($isWritable ? 'Yes ✓' : 'No ✗') . "</td></tr>";
        echo "<tr><td>Installation Lock File</td><td class='" . ($isInstalled ? 'ok' : 'warning') . "'>" . ($isInstalled ? 'Installed ✓' : 'Not Installed') . "</td></tr>";
        echo "</table>";
        
        if (!$hasDataDir) {
            echo "<p class='error'>ERROR: Data directory does not exist. Create it with: mkdir data && chmod 777 data</p>";
        }
        
        if (!$isInstalled) {
            echo "<p class='warning'>System not installed. Go to <a href='index.php?page=install'>Installation Page</a></p>";
        }
        ?>
    </div>

    <div class="section">
        <h2>7. Quick Links</h2>
        <ul>
            <li><a href="index.php">index.php (direct)</a></li>
            <li><a href="index.php?page=home">index.php?page=home</a></li>
            <li><a href="./">Root / (tests .htaccess)</a></li>
            <li><a href="home">home (tests .htaccess rewrite)</a></li>
            <li><a href="index.php?page=install">Installation Page</a></li>
        </ul>
    </div>
</body>
</html>
