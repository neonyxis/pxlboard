# PXLBoard v11-2 - Version Notes

## What's New in v11-2

### 🎯 Primary Changes

1. **Simplified Directory Structure**
   - All files moved from `PXLBoard_Enhanced/` subfolder to root directory
   - Cleaner, more straightforward deployment
   - Easier to upload and install on shared hosting

2. **New Admin Content Management Panel**
   - Dedicated page for managing blogs and wiki content
   - Centralized interface for all content administration
   - Access via: `?page=admin_content`

### 📋 New Features

#### Admin Content Dashboard
- **Statistics Overview Cards**
  - Total blogs and wiki pages
  - Published vs draft content counts
  - Featured blog posts count
  - Locked wiki pages count

#### Blog Management Interface
- **View All Blogs** in a sortable, filterable table
- **Quick Actions**:
  - 👁️ View blog post
  - ✏️ Edit blog post
  - 🔒/👁️ Toggle publish/unpublish
  - ⭐/☆ Feature/unfeature posts
  - 🗑️ Delete with confirmation
- **Status Indicators**: Published, Draft, Featured badges
- **Metrics**: View counts, author, creation date
- **Empty State**: Helpful message for new installations

#### Wiki Management Interface
- **View All Wiki Pages** in a comprehensive table
- **Quick Actions**:
  - 👁️ View wiki page
  - ✏️ Edit wiki page
  - 🔒/👁️ Toggle publish/unpublish
  - 🔓/🔒 Lock/unlock pages (prevent editing)
  - 📋 View revision history
  - ↩️ Revert to previous versions
  - 🗑️ Delete with confirmation
- **Status Indicators**: Published, Draft, Locked badges
- **Revision Tracking**: 
  - Number of revisions displayed
  - Expandable revision history viewer
  - Revert to any previous version with one click
- **Last Modified**: Shows who made the last change and when
- **Empty State**: Helpful message for new installations

### 🎨 UI/UX Improvements

1. **Tab-Based Navigation**
   - Switch between Blog and Wiki management
   - Clean, intuitive interface
   - Active tab highlighting

2. **Responsive Design**
   - Mobile-friendly tables
   - Touch-friendly action buttons
   - Adapts to all screen sizes

3. **Visual Feedback**
   - Color-coded status badges
   - Hover effects on rows and buttons
   - Confirmation dialogs for destructive actions
   - Success/error alerts

4. **Organized Layout**
   - Emoji-based icons for quick recognition
   - Compact action buttons
   - Professional spacing and typography
   - Clear column headers

### 🔧 Technical Details

#### New File
- `pages/admin_content.php` - Complete admin content management interface

#### Features Implementation
- **Publish/Unpublish Toggle**: Instantly change content visibility
- **Featured Flag**: Mark important blog posts for homepage display
- **Wiki Locking**: Prevent accidental edits to important pages
- **Revision System**: Built-in version control for wiki pages
- **Batch Processing**: Multiple actions without page reloads

### 📦 File Structure Changes

**Before (v11-1)**:
```
PXLBoard_v11-1.zip
└── PXLBoard_Enhanced/
    ├── config/
    ├── includes/
    ├── pages/
    └── ...
```

**After (v11-2)**:
```
PXLBoard_v11-2.zip
├── config/
├── includes/
├── pages/
│   └── admin_content.php (NEW)
├── CHANGELOG.md (NEW)
└── ...
```

### 🚀 Upgrade Instructions

1. **Backup Your Data**
   - Backup your `data/` directory
   - Backup your `uploads/` directory

2. **Extract Files**
   - Extract v11-2 ZIP directly to your web root
   - Files are now at root level (no PXLBoard_Enhanced folder)

3. **Restore Data**
   - Copy your backed up `data/` folder
   - Copy your backed up `uploads/` folder

4. **Access New Panel**
   - Log in as admin
   - Navigate to `?page=admin_content`
   - Start managing your content!

### ✅ Compatibility

- **Backward Compatible**: All existing data structures work without changes
- **No Database Changes**: No migration scripts needed
- **All Features Retained**: Everything from v11-1 is still available
- **PHP Version**: Requires PHP 7.4 or higher (same as before)

### 💡 Usage Tips

1. **Managing Blogs**
   - Use the Feature toggle (⭐) to highlight important posts
   - Draft posts are shown with reduced opacity
   - Sort by creation date by default (newest first)

2. **Managing Wiki**
   - Lock important pages to prevent accidental edits
   - View revision history to track changes over time
   - Revert to any previous version if needed
   - Unpublish draft pages while working on them

3. **Quick Workflow**
   - Create content in draft mode
   - Review and edit
   - Publish when ready
   - Monitor from admin panel

### 🐛 Bug Fixes

- None in this release (new feature addition)

### 🔜 Future Plans

- Bulk actions (select multiple items)
- Content scheduling (publish at specific time)
- Advanced filtering and search
- Export content to different formats
- Category management for blogs
- Wiki namespace support

### 📚 Documentation

- **CHANGELOG.md** - Complete version history
- **README.md** - Updated with v11-2 information
- **This file** - Detailed release notes

### 🙏 Credits

Built on the solid foundation of PXLBoard Enhanced with community feedback incorporated into the design.

---

**Installation Date**: Extract and check file modification dates  
**Version**: 11-2  
**Release Date**: January 31, 2026  
**Compatibility**: PHP 7.4+
