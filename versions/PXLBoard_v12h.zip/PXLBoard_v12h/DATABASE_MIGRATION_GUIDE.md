# Database Migration Guide

## Overview
PXLBoard v12h supports three database backends. This guide helps you choose the right one and migrate between them.

## Database Comparison

| Feature | FlatFile (JSON) | SQLite | MySQL/MariaDB |
|---------|-----------------|---------|---------------|
| **Setup Complexity** | None | Very Low | Medium |
| **Performance (small)** | ★★★★★ | ★★★★★ | ★★★☆☆ |
| **Performance (large)** | ★★☆☆☆ | ★★★★☆ | ★★★★★ |
| **Scalability** | Low | Medium | High |
| **Hosting Requirements** | None | PDO SQLite | MySQL Server |
| **Backup Complexity** | Copy files | Copy file | Dump database |
| **Concurrent Users** | Low | Medium | High |
| **Max Recommended Images** | <1,000 | <10,000 | Unlimited |
| **RAM Usage** | Low | Medium | Variable |
| **Disk I/O** | High | Medium | Low |

## When to Use Each Database

### FlatFile (JSON)
**Best For:**
- New installations
- Personal projects
- Low-traffic sites
- <1,000 images
- Shared hosting without database access
- Quick testing/development

**Pros:**
- Zero configuration
- Easy backups (just copy data folder)
- No external dependencies
- Simple debugging
- Portable

**Cons:**
- Slower with large datasets
- High disk I/O
- Limited concurrent user support
- No complex queries

### SQLite
**Best For:**
- Small to medium sites
- 1,000-10,000 images
- Sites with moderate traffic
- When you want SQL without server overhead
- VPS/dedicated hosting

**Pros:**
- Better performance than FlatFile
- SQL query capabilities
- Single file database
- ACID compliance
- Good concurrency
- Easy backups

**Cons:**
- Still file-based (some I/O overhead)
- Limited to ~10,000 concurrent connections
- Not ideal for distributed systems
- No built-in replication

### MySQL/MariaDB
**Best For:**
- Large sites (>10,000 images)
- High-traffic installations
- Multiple web servers
- Enterprise deployments
- Sites expecting growth

**Pros:**
- Excellent performance at scale
- High concurrency support
- Replication and clustering
- Advanced optimization options
- Industry standard
- Well-documented

**Cons:**
- Requires database server
- More complex setup
- Higher hosting requirements
- Needs regular maintenance
- More complex backups

## Migration Paths

### FlatFile → SQLite

#### Prerequisites
```bash
# Check if SQLite is available
php -m | grep sqlite
# Should show: pdo_sqlite
```

#### Method 1: Using Admin Panel (Recommended - Coming in v12i)
1. Login as admin
2. Go to Admin → Database → Migration
3. Select "Migrate to SQLite"
4. Click "Start Migration"
5. Wait for completion
6. Verify data integrity

#### Method 2: Manual Migration Script

Create `migrate_to_sqlite.php` in your PXLBoard root:

```php
<?php
/**
 * Migrate FlatFile to SQLite
 * Run from command line: php migrate_to_sqlite.php
 */

require_once 'config/config.php';
require_once 'includes/database.php';

echo "PXLBoard Database Migration: FlatFile → SQLite\n";
echo "============================================\n\n";

// Initialize old database
$oldDb = new FlatFileDB(DATA_DIR);

// Create new database
$sqlitePath = DATA_DIR . '/database.sqlite';
if (file_exists($sqlitePath)) {
    echo "WARNING: SQLite database already exists!\n";
    echo "Backup path: $sqlitePath.backup\n";
    copy($sqlitePath, $sqlitePath . '.backup');
}

$newDb = new SQLiteDB($sqlitePath);

// Collections to migrate
$collections = [
    'users', 'images', 'tags', 'comments', 'sessions',
    'ratings', 'favorites', 'forum_topics', 'forum_replies',
    'channels', 'extensions', 'blog_posts', 'blog_comments',
    'wiki_pages', 'wiki_revisions', 'notifications',
    'moderation_queue', 'user_hides', 'boards',
    'board_threads', 'board_posts', 'tgp_posts', 'tgp_likes'
];

$totalItems = 0;
$totalCollections = 0;

foreach ($collections as $collection) {
    echo "Migrating: $collection ... ";
    
    $items = $oldDb->getAll($collection);
    $count = count($items);
    
    if ($count === 0) {
        echo "EMPTY\n";
        continue;
    }
    
    $migrated = 0;
    foreach ($items as $item) {
        $id = $item['id'];
        unset($item['id']); // Remove ID from data
        
        if ($newDb->save($collection, $id, $item)) {
            $migrated++;
        }
    }
    
    echo "$migrated/$count items\n";
    $totalItems += $migrated;
    $totalCollections++;
}

// Update configuration
$dbConfig = [
    'type' => 'sqlite',
    'path' => $sqlitePath
];

file_put_contents(DATA_DIR . '/db_config.json', json_encode($dbConfig, JSON_PRETTY_PRINT));

echo "\n============================================\n";
echo "Migration Complete!\n";
echo "Total Collections: $totalCollections\n";
echo "Total Items: $totalItems\n";
echo "Database: $sqlitePath\n";
echo "\nNext Steps:\n";
echo "1. Test your site thoroughly\n";
echo "2. Keep FlatFile backup until verified\n";
echo "3. Update any custom scripts\n";
echo "4. Optimize database: php optimize_db.php\n";
?>
```

Run migration:
```bash
cd /path/to/pxlboard
php migrate_to_sqlite.php
```

### FlatFile → MySQL

#### Prerequisites
```bash
# Check MySQL extension
php -m | grep mysql
# Should show: pdo_mysql

# Create database
mysql -u root -p
```

```sql
CREATE DATABASE pxlboard CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'pxluser'@'localhost' IDENTIFIED BY 'SecurePassword123!';
GRANT ALL PRIVILEGES ON pxlboard.* TO 'pxluser'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

#### Migration Script

Create `migrate_to_mysql.php`:

```php
<?php
/**
 * Migrate FlatFile to MySQL
 * Run from command line: php migrate_to_mysql.php
 */

require_once 'config/config.php';
require_once 'includes/database.php';

echo "PXLBoard Database Migration: FlatFile → MySQL\n";
echo "============================================\n\n";

// MySQL Configuration
$mysqlConfig = [
    'type' => 'mysql',
    'host' => 'localhost',
    'dbname' => 'pxlboard',
    'username' => 'pxluser',
    'password' => 'SecurePassword123!',
    'prefix' => 'pxl_'
];

// Test connection
echo "Testing MySQL connection...\n";
try {
    $newDb = new MySQLDB(
        $mysqlConfig['host'],
        $mysqlConfig['dbname'],
        $mysqlConfig['username'],
        $mysqlConfig['password'],
        $mysqlConfig['prefix']
    );
    echo "✓ Connection successful\n\n";
} catch (PDOException $e) {
    die("✗ Connection failed: " . $e->getMessage() . "\n");
}

// Initialize old database
$oldDb = new FlatFileDB(DATA_DIR);

// Collections to migrate
$collections = [
    'users', 'images', 'tags', 'comments', 'sessions',
    'ratings', 'favorites', 'forum_topics', 'forum_replies',
    'channels', 'extensions', 'blog_posts', 'blog_comments',
    'wiki_pages', 'wiki_revisions', 'notifications',
    'moderation_queue', 'user_hides', 'boards',
    'board_threads', 'board_posts', 'tgp_posts', 'tgp_likes'
];

$totalItems = 0;
$totalCollections = 0;

foreach ($collections as $collection) {
    echo "Migrating: $collection ... ";
    
    $items = $oldDb->getAll($collection);
    $count = count($items);
    
    if ($count === 0) {
        echo "EMPTY\n";
        continue;
    }
    
    $migrated = 0;
    foreach ($items as $item) {
        $id = $item['id'];
        unset($item['id']);
        
        if ($newDb->save($collection, $id, $item)) {
            $migrated++;
        }
    }
    
    echo "$migrated/$count items\n";
    $totalItems += $migrated;
    $totalCollections++;
}

// Update configuration
file_put_contents(DATA_DIR . '/db_config.json', json_encode($mysqlConfig, JSON_PRETTY_PRINT));

echo "\n============================================\n";
echo "Migration Complete!\n";
echo "Total Collections: $totalCollections\n";
echo "Total Items: $totalItems\n";
echo "Database: {$mysqlConfig['dbname']}\n";
echo "\nNext Steps:\n";
echo "1. Test your site thoroughly\n";
echo "2. Keep FlatFile backup until verified\n";
echo "3. Set up database backups\n";
echo "4. Consider adding database indexes\n";
?>
```

Run migration:
```bash
cd /path/to/pxlboard
php migrate_to_mysql.php
```

### SQLite → MySQL

#### Migration Script

Create `migrate_sqlite_to_mysql.php`:

```php
<?php
require_once 'config/config.php';
require_once 'includes/database.php';

// Load current SQLite database
$sqliteConfig = json_decode(file_get_contents(DATA_DIR . '/db_config.json'), true);
$oldDb = new SQLiteDB($sqliteConfig['path']);

// MySQL configuration
$mysqlConfig = [
    'type' => 'mysql',
    'host' => 'localhost',
    'dbname' => 'pxlboard',
    'username' => 'pxluser',
    'password' => 'SecurePassword123!',
    'prefix' => 'pxl_'
];

// Create MySQL database
$newDb = new MySQLDB(
    $mysqlConfig['host'],
    $mysqlConfig['dbname'],
    $mysqlConfig['username'],
    $mysqlConfig['password'],
    $mysqlConfig['prefix']
);

// Collections to migrate
$collections = [
    'users', 'images', 'tags', 'comments', 'sessions',
    'ratings', 'favorites', 'forum_topics', 'forum_replies',
    'channels', 'extensions', 'blog_posts', 'blog_comments',
    'wiki_pages', 'wiki_revisions', 'notifications',
    'moderation_queue', 'user_hides', 'boards',
    'board_threads', 'board_posts', 'tgp_posts', 'tgp_likes'
];

foreach ($collections as $collection) {
    echo "Migrating: $collection ... ";
    $items = $oldDb->getAll($collection);
    
    foreach ($items as $item) {
        $id = $item['id'];
        unset($item['id']);
        $newDb->save($collection, $id, $item);
    }
    
    echo count($items) . " items\n";
}

// Update configuration
file_put_contents(DATA_DIR . '/db_config.json', json_encode($mysqlConfig, JSON_PRETTY_PRINT));

echo "Migration complete!\n";
?>
```

## Post-Migration Tasks

### 1. Verify Data Integrity

```php
// verify_migration.php
<?php
require_once 'config/config.php';
require_once 'includes/database.php';

$dbConfig = json_decode(file_get_contents(DATA_DIR . '/db_config.json'), true);
$db = DatabaseFactory::create($dbConfig);

$collections = ['users', 'images', 'boards', 'board_threads'];

foreach ($collections as $collection) {
    $count = $db->count($collection);
    echo "$collection: $count items\n";
}
?>
```

### 2. Optimize Database

#### For SQLite:
```bash
sqlite3 data/database.sqlite "VACUUM;"
sqlite3 data/database.sqlite "ANALYZE;"
```

#### For MySQL:
```sql
USE pxlboard;
OPTIMIZE TABLE pxl_data;
ANALYZE TABLE pxl_data;
```

### 3. Set Up Backups

#### FlatFile:
```bash
# Cron job: Daily backup
0 2 * * * tar -czf /backups/pxlboard_$(date +\%Y\%m\%d).tar.gz /path/to/pxlboard/data
```

#### SQLite:
```bash
# Cron job: Daily backup
0 2 * * * cp /path/to/pxlboard/data/database.sqlite /backups/database_$(date +\%Y\%m\%d).sqlite
```

#### MySQL:
```bash
# Cron job: Daily backup
0 2 * * * mysqldump -u pxluser -pSecurePassword123! pxlboard > /backups/pxlboard_$(date +\%Y\%m\%d).sql
```

### 4. Performance Tuning

#### MySQL Optimization:
```sql
-- Add indexes for better performance
ALTER TABLE pxl_data ADD INDEX idx_collection_updated (collection, updated_at DESC);
ALTER TABLE pxl_data ADD INDEX idx_id_lookup (collection, id);

-- Optimize InnoDB settings (my.cnf)
innodb_buffer_pool_size = 256M
innodb_log_file_size = 64M
innodb_flush_log_at_trx_commit = 2
```

## Troubleshooting

### Migration Fails Midway
**Solution**: The migration script can be run multiple times safely. It will skip or update existing records.

### Out of Memory Error
**Solution**: Migrate in batches:
```php
// Add to migration script:
$batchSize = 100;
for ($i = 0; $i < count($items); $i += $batchSize) {
    $batch = array_slice($items, $i, $batchSize);
    foreach ($batch as $item) {
        // migrate...
    }
    unset($batch);
    gc_collect_cycles();
}
```

### Connection Timeouts
**Solution**: Increase timeout in db_config.json or php.ini:
```php
ini_set('max_execution_time', 300);
```

### Data Corruption
**Solution**: Always keep backups! Restore from backup and try again.

## Performance Benchmarks

### Image Listing (1000 images):
- FlatFile: ~500ms
- SQLite: ~50ms (10x faster)
- MySQL: ~20ms (25x faster)

### Search Operation:
- FlatFile: ~1000ms
- SQLite: ~100ms (10x faster)
- MySQL: ~30ms (33x faster)

### Concurrent Users (100 simultaneous):
- FlatFile: Struggles, high disk I/O
- SQLite: Good performance
- MySQL: Excellent performance

## Best Practices

1. **Always backup before migration**
2. **Test on development first**
3. **Migrate during low-traffic periods**
4. **Monitor disk space during migration**
5. **Keep old database until verified**
6. **Set up automated backups immediately**
7. **Document your configuration**
8. **Test rollback procedure**

## Getting Help

If migration fails:
1. Check PHP error logs
2. Verify database credentials
3. Ensure sufficient disk space
4. Review migration script output
5. Check database server logs
6. Try migration in smaller batches

---

**Note**: This guide assumes you have shell access to your server. For shared hosting, contact your hosting provider for database migration assistance.
