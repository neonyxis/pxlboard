# PXLBoard Changelog

## Version 11-2e (January 31, 2026) - Debug & Diagnostics Update

### 🔧 System Information & Debugging Tools

#### New Debug Panel (Admin Only)
- **Comprehensive System Information**: Version, installation date, PHP version, server details
- **Path Configuration Viewer**: All directory paths with writable status indicators
- **PHP Configuration Display**: Upload limits, memory, execution time, extensions
- **Database Statistics**: Record counts for all 11 data collections
- **Error Log Viewer**: Recent PHP errors (last 20 entries)
- **Quick Diagnostics**: Automated checks for .htaccess, mod_rewrite, sessions, directories
- **Maintenance Tools**: Direct links to diagnostics, refresh, version copying

#### Version Indicators
- **Admin Navbar Badge**: Version badge visible to admins in navigation bar
- **Footer Display**: Version shown on all pages (already present)
- **Quick Copy**: One-click version copying in debug panel

### 🐛 Critical Bug Fixes

#### Database & Profile Issues
- **Fixed Database ID Injection**: `db->get()` now properly returns `id` field in all records
  - **Impact**: Prevented profile updates from creating `null.json` corruption
  - **Location**: `includes/database.php`
- **Profile Null Guard**: Added safety check when user record is missing
  - **Impact**: Prevents crashes with "array offset on null" warnings
  - **Location**: `pages/profile.php`

#### URL & Routing Fixes (Subdirectory Deployments)
- **Fixed buildUrl() Prefix Detection**: URLs now include subdirectory path
  - **New Function**: `getBasePrefix()` extracts path from `SITE_URL`
  - **Impact**: Fixes all pretty URLs in subdirectory installations
  - **Location**: `includes/functions.php`
- **.htaccess Auto-Configuration**: Installer now auto-patches `RewriteBase`
  - **Impact**: Zero-configuration subdirectory deployment
  - **Location**: `pages/install.php`
- **Fixed Public Profile 404s**: User profiles now accessible via pretty URLs
  - **Impact**: `/user/username` routes now work correctly

### 📝 Technical Changes

#### Modified Files
- `config/config.php` - VERSION updated to '11-2e'
- `includes/database.php` - ID injection fix
- `includes/functions.php` - URL prefix handling
- `pages/profile.php` - Null guard
- `pages/install.php` - htaccess patching
- `pages/admin.php` - Debug tab added
- `templates/header.php` - Version badge
- `.htaccess` - Documentation updates

#### New Files
- `VERSION_NOTES_11-2e.md` - Release notes

### 🔄 Upgrade Instructions

**From 11-2d:**
1. Replace all files
2. Check `data/users/` for `null.json` and delete if exists
3. If in subdirectory: Re-run installer OR manually set `RewriteBase` in `.htaccess`

**No database migration required**

---

## Version 11-2d (January 31, 2025) - Tier 1 Integration

### 🎯 Major Update: Tier 1 Features
Integrated six high-impact features from the Tier 1 update package:

#### 1. Image Hiding System (High Impact)
- **User Hide Preferences**: Users can hide images they don't want to see
- **Personal Filtering**: Hidden images automatically filtered from gallery views
- **Management Interface**: New page at Profile Settings → Hidden Images
- **Files Added**: `includes/hiding.php`, `pages/manage_hides.php`
- **Directory Added**: `data/user_hides/`

#### 2. Image Source Tracking (Medium Impact)
- **Source URLs**: Track where images originated with URL references
- **Edit History**: Full revision history for source attribution
- **Upload Integration**: Add sources during upload or edit later
- **Display**: Source information shown on image pages
- **Files Added**: `pages/edit_source.php`

#### 3. Tag Aliases (High Impact)
- **Canonical Tags**: Redirect alternate tag names to standardized versions
- **Admin Interface**: New admin panel for managing tag aliases
- **Automatic Normalization**: Tags automatically converted during upload
- **Search Improvement**: Better tag consistency and organization
- **Access**: Admin Panel → Tag Aliases
- **Files Added**: `includes/tag_aliases.php`, `pages/admin_tags.php`
- **Config Added**: `data/tag_aliases.json`

#### 4. Comment Editing (Medium Impact)
- **Edit Your Comments**: Users can edit their own comments after posting
- **Revision History**: Full edit history tracking
- **History Viewer**: View complete edit history for any comment
- **Edit Markers**: Edited comments marked with timestamp
- **Files Added**: `pages/edit_comment.php`, `pages/comment_history.php`

#### 5. Anonymous Uploads (Medium Impact)
- **Privacy Option**: Upload images without displaying username publicly
- **Upload Form**: Optional "Upload Anonymously" checkbox
- **Moderation Tracking**: User identity still logged internally
- **Public Display**: Appears as "Anonymous" to other users
- **Implementation**: Enhanced `pages/upload.php`

#### 6. Enhanced Avatar Management (Medium Impact)
- **Profile Settings Page**: Dedicated interface for user preferences
- **Improved Upload**: Better avatar management interface
- **Integrated Preferences**: Combined with other user settings
- **Files Added**: `pages/profile_settings.php`

### 📦 Files Modified
- `pages/upload.php` - Added source URL field and anonymous upload option
- `pages/image.php` - Added hide button, source display, and comment editing
- `pages/gallery.php` - Added hidden image filtering
- `includes/database.php` - Updated to support new features

### 🔧 Technical Details
- **Version Number**: Updated to 11-2d
- **Backward Compatibility**: 100% compatible with 11-2b data
- **No Migrations**: Uses existing file-based data system
- **Requirements**: PHP 7.4+, JSON extension, GD extension

### 📚 Documentation Added
- `VERSION_NOTES_11-2d.md` - Complete release notes
- `TIER1_IMPLEMENTATION_GUIDE.md` - Feature implementation guide
- `TIER1_README.md` - Tier 1 overview and usage

### 🎨 User Experience
- Cleaner gallery views with hide functionality
- Better image attribution with source tracking
- More consistent tagging with aliases
- Editable comments for fixing mistakes
- Privacy-focused anonymous uploads
- Streamlined profile management

### 🔐 Security
- Anonymous uploads still tracked internally for moderation
- Comment edit history prevents abuse
- Source URLs validated against XSS
- User-specific hide preferences

---

## Version 11-2 (January 31, 2026) - Updated

### 🎯 Major Changes
- **Restructured Directory**: Moved all content from `PXLBoard_Enhanced/` folder to root of ZIP file for cleaner deployment
- **New Admin Content Panel**: Added dedicated admin panel for managing blogs and wiki pages

### 🐛 Bug Fixes (Latest Update)
- **Fixed Wiki History 404**: Created `wiki_history.php` page to display revision history
- **Added Admin UI Routes**: Registered `admin_content` and `wiki_history` routes in `index.php`
- **Added Navigation Links**: 
  - Added "Content Management" link to admin dropdown menu in header
  - Added "Content Management" tab to main admin panel
  - Added quick links to manage blogs/wiki from admin statistics

### ✨ New Features

#### Wiki History Page (`wiki_history.php`)
- View complete revision history for any wiki page
- See all previous versions with timestamps and authors
- Preview old content in modal dialogs
- Revert to previous versions (admin only)
- Breadcrumb navigation
- Page info sidebar showing creation date, views, and status

#### Admin Content Management (`admin_content.php`)
- **Unified Content Dashboard**: Single interface for managing both blogs and wiki pages
- **Statistics Overview**: Real-time statistics showing:
  - Total blogs/wiki pages
  - Published vs draft content
  - Featured blogs
  - Locked wiki pages
  
#### Blog Management
- View all blog posts in a sortable table
- Quick actions:
  - View blog post
  - Edit blog post
  - Toggle publish/unpublish status
  - Feature/unfeature posts
  - Delete posts (with confirmation)
- Status indicators for published/draft/featured posts
- View count tracking
- Author and creation date display

#### Wiki Management
- View all wiki pages in a sortable table
- Quick actions:
  - View wiki page
  - Edit wiki page
  - Toggle publish/unpublish status
  - Lock/unlock pages (prevent editing)
  - View revision history
  - Revert to previous versions
  - Delete pages (with confirmation)
- Status indicators for published/draft/locked pages
- Revision tracking with version numbers
- Last modified information with author
- Expandable revision history viewer

### 🔧 Technical Improvements
- Tab-based navigation between blog and wiki management
- Responsive table design for mobile compatibility
- Consistent emoji-based UI for better visual recognition
- Inline revision viewer for wiki pages
- Confirmation dialogs for destructive actions
- Empty state messages for new installations

### 🎨 UI/UX Enhancements
- Clean, modern interface with card-based statistics
- Color-coded badges for different content states
- Hover effects for better interactivity
- Compact action buttons with tooltips
- Organized table layout with clear column headers
- Professional spacing and typography

### 📝 Additional Notes
- All previous features from PXLBoard Enhanced are retained
- Backward compatible with existing data structures
- No database schema changes required
- Ready for production deployment

### 🔗 Quick Access
- Navigate to admin panel: `?page=admin_content`
- Default tab: Blog management
- Switch tabs: `?page=admin_content&tab=wiki`

---

## Previous Versions

### Version 11-1 (PXLBoard Enhanced)
- Enhanced admin panel with additional features
- Improved moderation tools
- Extended RBAC (Role-Based Access Control)
- Avatar system improvements
- Notification system enhancements
- Multiple upload fix implementations
- Profile system updates
- Channel management features
- Theme system (dark/default)
- Extension support
- Comprehensive documentation suite

### Core Features (All Versions)
- User authentication and authorization
- Image gallery with channel support
- Blog system
- Wiki with revision control
- Forum system
- Search functionality
- Tag management
- User rankings and profiles
- Moderation tools
- Responsive design
- Multiple themes support
