# QUICK FIX REFERENCE - PXLBoard v11-2e

## 🔴 CRITICAL BUGS FIXED

### Bug #1: 404 Page Redirect Loop ✅ FIXED
**File Changed:** `pages/404.php` (line 14)
**Before:** `<a href="index.php?page=home">`
**After:** `<a href="index.php">`

### Bug #2: Upload Directory Not Writable ⚠️ REQUIRES SETUP
**Solution:** Run the setup script OR use manual commands below

---

## 🚀 QUICK SETUP (Choose One)

### OPTION A: Automatic Setup (Recommended)
```bash
cd /path/to/pxlboard
chmod +x setup_uploads.sh
./setup_uploads.sh
```

### OPTION B: Manual Setup (3 commands)
```bash
mkdir -p uploads/thumbs data/images
chmod -R 755 uploads/ data/
sudo chown -R www-data:www-data uploads/ data/
```

### OPTION C: Quick & Dirty (Development Only)
```bash
mkdir -p uploads/thumbs && chmod -R 777 uploads/
```

---

## ✅ VERIFICATION

### Test 404 Fix:
1. Go to: `yoursite.com/index.php?page=nonexistent`
2. Click "Go Home" button
3. Should land on home page ✓

### Test Upload Fix:
1. Go to: `yoursite.com/index.php?page=upload&debug=1`
2. Upload an image
3. Should see success message ✓

---

## 🔧 COMMON WEB SERVER USERS

| Platform | User |
|----------|------|
| Ubuntu/Debian | www-data |
| CentOS/RHEL | apache |
| macOS | _www |
| XAMPP | daemon or current user |

Check yours: `ps aux | grep -E 'apache|nginx' | grep -v grep`

---

## 📋 PERMISSION GUIDE

| Directory | Permissions | Owner | Purpose |
|-----------|-------------|-------|---------|
| uploads/ | 755 | www-data | Upload storage |
| uploads/thumbs/ | 755 | www-data | Thumbnail storage |
| data/ | 755 | www-data | Database files |
| data/images/ | 755 | www-data | Image metadata |

**For production:** Use 755  
**For development:** Can use 777 (less secure)

---

## ⚡ EMERGENCY COMMANDS

### Upload fails?
```bash
chmod -R 777 uploads/ && sudo chown -R www-data:www-data uploads/
```

### Still not working?
```bash
sudo apt-get install php-gd && sudo systemctl restart apache2
```

### Check logs:
```bash
tail -f /var/log/apache2/error.log
```

---

## 📝 FILES MODIFIED

1. **pages/404.php** - Fixed redirect loop
2. **setup_uploads.sh** - NEW: Automated setup script
3. **BUGFIX_GUIDE.md** - Complete documentation
4. **QUICK_FIX_REFERENCE.md** - This file

---

## 🎯 SUCCESS CHECKLIST

Upload fix complete when:
- [ ] `uploads/` directory exists
- [ ] `uploads/thumbs/` directory exists  
- [ ] Directories owned by web server user
- [ ] Permissions set to 755 or 777
- [ ] Can upload image successfully
- [ ] Thumbnail appears in gallery
- [ ] Database entry created

404 fix complete when:
- [ ] 404 page shows on invalid URL
- [ ] "Go Home" button works
- [ ] No redirect loop occurs

---

**Fixed:** January 31, 2026  
**Version:** PXLBoard v11-2e  
**Severity:** Critical  
