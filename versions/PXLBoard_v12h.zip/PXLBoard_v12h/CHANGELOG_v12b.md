# PXLBoard v12b - Update Notes

**Version:** 12b  
**Date:** January 31, 2026  
**Type:** Feature update

## Changes

### Board Moderators
- Board creators are automatic top-level moderators
- Top-level mods can add/remove other moderators
- Moderator panel on board pages
- Two moderator levels: regular and top-level

### Voting System
- Upvote/downvote threads and posts
- Vote scores displayed
- Board karma leaderboard in Rankings
- Karma integrated with user profiles

### Threaded Comments
- Reply-to functionality for posts
- Nested comment display (up to 5 levels)
- Visual threading with indentation

### Template Compliance
- All board pages use header/footer templates
- Consistent styling across pages

## Upgrade

Extract v12b over v11-2e or v12a. No data migration needed.

## New Files

- `includes/board_moderators.php` - Moderator system
- `includes/board_voting.php` - Voting system

## Modified Files

- `pages/board.php` - Added moderator panel, voting
- `pages/board_thread.php` - Threaded comments, voting
- `pages/rankings.php` - Karma leaderboard
- `config/config.php` - Version 12b
