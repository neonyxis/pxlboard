# PXLBoard Tier 1 Features Implementation Guide

## Overview
This document outlines the implementation of 6 Tier 1 "Quick Wins" features for PXLBoard, a simple flat file image board. All features are designed to work with the existing flat-file database system and shared hosting environment.

---

## Features Implemented

### 1. ✅ Image Hiding System
**Status**: Complete  
**Impact**: High | **Effort**: Low

#### Files Created:
- `includes/hiding.php` - Core hiding system functionality
- `pages/manage_hides.php` - User interface to manage hidden images

#### Files Modified:
- `pages/image.php` - Added hide/unhide buttons
- `pages/gallery.php` - Filters out hidden images from display
- `includes/database.php` - Added `user_hides` directory

#### How It Works:
1. Each user has a hide data file: `data/user_hides/{user_id}.json`
2. Contains array of hidden image IDs
3. Gallery automatically filters out hidden images for logged-in users
4. Users can view and manage their hidden images at `/manage_hides`

#### Usage:
```php
// Hide an image
$hiding = getHidingSystem();
$hiding->hideImage('img_123');

// Check if hidden
if (isImageHidden('img_123')) {
    // Image is hidden
}

// Filter images array
$visibleImages = filterHiddenImages($allImages);
```

#### User Interface:
- Hide button on image pages
- "Manage Hidden Images" page shows all hidden images
- Option to unhide individual images or clear all

---

### 2. ✅ Image Source Tracking
**Status**: Complete  
**Impact**: Medium | **Effort**: Low

#### Files Created:
- `pages/edit_source.php` - Edit source URL page

#### Files Modified:
- `pages/upload.php` - Added source URL field to upload form
- `pages/image.php` - Display source URL with edit link

#### Data Structure:
```json
{
  "id": "img_123",
  "source_url": "https://example.com/art.jpg",
  "source_history": [
    {
      "url": "https://old-source.com",
      "updated_at": 1640995200,
      "updated_by": "admin"
    }
  ]
}
```

#### Features:
- Add source URL during upload
- Edit source URL after upload (uploader/admin only)
- Full history of source URL changes
- Display source with external link icon

---

### 3. ✅ Tag Aliases
**Status**: Complete  
**Impact**: High | **Effort**: Medium

#### Files Created:
- `includes/tag_aliases.php` - Tag alias system
- `pages/admin_tags.php` - Admin interface for managing aliases

#### Files Modified:
- `pages/upload.php` - Automatically resolves tag aliases on upload

#### Data Structure:
```json
{
  "pony": "mlp",
  "pegasus": "pegasi",
  "rarity": "rarity_(mlp)"
}
```

#### How It Works:
1. Aliases stored in `data/tag_aliases.json`
2. When tags are entered, they're automatically resolved to canonical forms
3. Supports alias chains (up to 10 levels)
4. Admin interface for managing aliases
5. Bulk migration tool to update existing images

#### Usage:
```php
// Resolve a single tag
$canonical = resolveTag('pony'); // Returns 'mlp'

// Resolve multiple tags
$tags = resolveTags(['pony', 'pegasus']); // Returns ['mlp', 'pegasi']

// Add alias
$system = getTagAliasSystem();
$system->addAlias('ponies', 'mlp');

// Migrate existing images
$updated = $system->migrateTag('old_tag', 'new_tag');
```

#### Admin Interface:
- View all aliases
- Add new aliases with autocomplete
- Remove aliases
- Bulk tag migration tool
- Statistics dashboard

---

### 4. ✅ Comment Editing with History
**Status**: Complete  
**Impact**: Medium | **Effort**: Easy

#### Files Created:
- `pages/edit_comment.php` - Edit comment interface
- `pages/comment_history.php` - View edit history

#### Files Modified:
- `pages/image.php` - Added edit buttons to comments, shows "edited" indicator

#### Data Structure:
```json
{
  "id": "123",
  "comment": "Current content",
  "edited_at": 1640995200,
  "last_editor": "username",
  "edit_history": [
    {
      "content": "Original content",
      "edited_at": 1640995100,
      "edited_by": "username",
      "reason": "Fixed typo"
    }
  ]
}
```

#### Features:
- Edit button on comments (owner/admin only)
- Optional edit reason field
- Full edit history preservation
- "Edited" indicator with link to history
- View all previous versions with timestamps

---

### 5. ✅ Anonymous Uploads
**Status**: Complete  
**Impact**: Medium | **Effort**: Easy

#### Files Modified:
- `pages/upload.php` - Added anonymous checkbox
- `pages/image.php` - Display "Anonymous" instead of username

#### How It Works:
1. Checkbox on upload form: "Upload anonymously"
2. Sets `anonymous: true` flag in image data
3. Uploader ID still stored (for admin/moderation)
4. Public display shows "Anonymous" instead of username

#### Privacy Features:
- Username hidden from public view
- User can still manage their own anonymous uploads
- Admins can still see actual uploader for moderation
- User ID preserved for attribution/deletion rights

---

### 6. ✅ User Avatars
**Status**: Complete (Already Implemented)  
**Impact**: Medium | **Effort**: Low

#### Files Already Present:
- `includes/avatar.php` - Full avatar management system

#### Files Created:
- `pages/profile_settings.php` - Avatar upload interface

#### Files Modified:
- `pages/image.php` - Display avatars in comments

#### Features:
- Upload custom avatar (JPG, PNG, GIF, WebP)
- Automatic resize to multiple sizes (small, medium, large)
- Center-crop to square
- Gravatar fallback support
- Delete avatar option
- 2MB file size limit
- Displayed in comments, profiles, forum posts

#### Usage:
```php
// Get avatar manager
$avatarManager = new AvatarManager($db);

// Upload avatar
$result = $avatarManager->uploadAvatar($_FILES['avatar'], $userId);

// Get avatar URL
$url = $avatarManager->getAvatarUrl($userId, 'medium');

// Get avatar HTML
echo $avatarManager->getAvatarHtml($userId, 'small', 'custom-class');
```

---

## Installation Instructions

### 1. Upload New Files
Upload all new files to your PXLBoard installation:
```
includes/hiding.php
includes/tag_aliases.php
pages/manage_hides.php
pages/admin_tags.php
pages/edit_source.php
pages/edit_comment.php
pages/comment_history.php
pages/profile_settings.php
```

### 2. Replace Modified Files
Replace the following files with the updated versions:
```
includes/database.php
pages/upload.php
pages/image.php
pages/gallery.php
```

### 3. Set Permissions
Ensure the data directory is writable:
```bash
chmod 755 data/
chmod 644 data/*.json
```

### 4. Initialize Directories
The system will auto-create these directories on first use:
- `data/user_hides/` - User hide preferences
- `uploads/avatars/` - Avatar storage (already created by avatar system)

### 5. Create Tag Aliases File
Create an empty tag aliases file:
```bash
echo '{}' > data/tag_aliases.json
chmod 644 data/tag_aliases.json
```

---

## User Guide

### For Regular Users:

#### Hiding Images
1. Go to any image page
2. Click "Hide Image" button in the Actions panel
3. Manage hidden images at `/manage_hides` or Settings menu
4. Hidden images won't appear in your gallery view

#### Uploading Anonymously
1. Go to upload page
2. Check "Upload anonymously" checkbox
3. Your username won't be shown publicly (admins can still see it)

#### Setting Your Avatar
1. Go to Profile Settings
2. Upload a profile picture (max 2MB)
3. Square images work best (will be auto-cropped)
4. Avatar appears in your comments and profile

#### Editing Comments
1. Find your comment on an image
2. Click the edit button (pencil icon)
3. Make changes and optionally add edit reason
4. View full edit history by clicking "edited" timestamp

---

### For Admins:

#### Managing Tag Aliases
1. Go to Admin → Tag Aliases
2. Add new aliases to redirect old tags to canonical ones
3. Use bulk migration to update existing images
4. View statistics on alias usage

Example aliases:
- `pony` → `mlp`
- `pegasus` → `pegasi`
- `rarity` → `rarity_(mlp)`

#### Managing Image Sources
- Users can add source URLs during upload
- Admins can edit any image's source URL
- Full source history is preserved

---

## Technical Details

### Database Structure
All features use the existing flat-file JSON database:

**User Hides**: `data/user_hides/{user_id}.json`
```json
{
  "user_id": "user_1",
  "hidden_images": ["img_123", "img_456"],
  "hidden_count": 2,
  "created_at": 1640995200,
  "updated_at": 1640995300
}
```

**Tag Aliases**: `data/tag_aliases.json`
```json
{
  "alias1": "canonical1",
  "alias2": "canonical2"
}
```

**Image with Source**: `data/images/img_123.json`
```json
{
  "id": "img_123",
  "source_url": "https://example.com",
  "source_history": [...],
  "anonymous": false
}
```

**Comment with History**: `data/comments/123.json`
```json
{
  "id": "123",
  "comment": "Current text",
  "edited_at": 1640995200,
  "edit_history": [...]
}
```

### Performance Considerations

1. **Hidden Images**: Filtering happens in memory, minimal performance impact
2. **Tag Aliases**: Resolved during upload/tag processing only
3. **Avatars**: Multiple sizes pre-generated, CDN-friendly
4. **Comment History**: Only loaded when viewing history page

### Shared Hosting Compatibility

All features are designed for shared hosting:
- ✅ No database server required
- ✅ No special PHP extensions needed
- ✅ File-based storage only
- ✅ Minimal memory usage
- ✅ No cron jobs required
- ✅ Works with basic PHP 7.4+

---

## API Reference

### Hiding System

```php
// Get hiding system for current user
$hiding = getHidingSystem();

// Hide an image
$hiding->hideImage($imageId);

// Unhide an image
$hiding->unhideImage($imageId);

// Check if hidden
$isHidden = $hiding->isImageHidden($imageId);

// Get all hidden images
$hiddenIds = $hiding->getHiddenImages();

// Filter array of images
$visible = $hiding->filterHiddenImages($images);

// Clear all hides
$hiding->clearAllHides();
```

### Tag Aliases

```php
// Get tag alias system
$system = getTagAliasSystem();

// Add alias
$system->addAlias('old_tag', 'new_tag');

// Remove alias
$system->removeAlias('old_tag');

// Resolve single tag
$canonical = $system->resolveTag('tag');

// Resolve multiple tags
$resolved = $system->resolveTags(['tag1', 'tag2']);

// Get canonical tag
$canonical = $system->getCanonical('alias');

// Get all aliases for a canonical tag
$aliases = $system->getAliasesFor('canonical');

// Migrate tag in all images
$updated = $system->migrateTag('old', 'new');

// Get statistics
$stats = $system->getStats();
```

### Avatar Manager

```php
// Create avatar manager
$avatarManager = new AvatarManager($db);

// Upload avatar
$result = $avatarManager->uploadAvatar($_FILES['avatar'], $userId);

// Delete avatar
$avatarManager->deleteAvatar($userId);

// Get avatar URL
$url = $avatarManager->getAvatarUrl($userId, 'medium');

// Get avatar HTML
$html = $avatarManager->getAvatarHtml($userId, 'small', 'css-class');
```

---

## Troubleshooting

### Hidden Images Not Working
- Check that `data/user_hides/` directory exists and is writable
- Verify user is logged in
- Clear browser cache

### Tag Aliases Not Resolving
- Verify `data/tag_aliases.json` exists
- Check file permissions (should be 644)
- Test with simple alias first

### Avatars Not Uploading
- Check `uploads/avatars/` directory exists and is writable
- Verify file size is under 2MB
- Ensure GD library is enabled in PHP

### Comment Editing Not Saving
- Verify `data/comments/` directory is writable
- Check that user owns the comment or is admin
- Look for JavaScript errors in browser console

---

## Future Enhancements

Potential improvements for these features:

1. **Hiding System**:
   - Bulk hide by tag/uploader
   - Temporary hides (expire after time)
   - Hide reasons/notes

2. **Tag Aliases**:
   - Import/export aliases
   - Tag suggestions based on aliases
   - Merge duplicate tags automatically

3. **Comment Editing**:
   - Diff view between versions
   - Restore previous version
   - Moderator edit tracking

4. **Anonymous Uploads**:
   - Anonymous mode toggle
   - Random pseudonyms
   - Anonymous comments

5. **Avatars**:
   - Avatar galleries/collections
   - Animated avatar support
   - Avatar borders/frames

---

## Changelog

### Version 1.1 (2025-01-31)
- ✅ Added image hiding system
- ✅ Added image source tracking with history
- ✅ Added tag aliases system
- ✅ Added comment editing with history
- ✅ Added anonymous upload option
- ✅ Enhanced avatar system with profile settings page

---

## Support

For issues or questions:
1. Check this implementation guide
2. Review the troubleshooting section
3. Check file permissions and error logs
4. Verify PHP version compatibility (7.4+)

---

## License

These features are part of PXLBoard and inherit its license.
