#!/bin/bash

# PXLBoard v12f Setup Script
# This script creates necessary directories and sets permissions

echo "==================================="
echo "PXLBoard v12f Setup"
echo "==================================="
echo ""

# Check if running with appropriate permissions
if [ ! -w . ]; then
    echo "Error: Cannot write to current directory"
    echo "Please ensure you have write permissions or run with appropriate user"
    exit 1
fi

# Create upload directories
echo "Creating upload directories..."
mkdir -p uploads/images
mkdir -p uploads/thumbs
mkdir -p uploads/avatars
mkdir -p uploads/board_thumbs
mkdir -p uploads/board_thumbs/thumbs

# Create data directories
echo "Creating data directories..."
mkdir -p data/users
mkdir -p data/images
mkdir -p data/tags
mkdir -p data/comments
mkdir -p data/sessions
mkdir -p data/cache
mkdir -p data/ratings
mkdir -p data/favorites
mkdir -p data/forum_topics
mkdir -p data/forum_replies
mkdir -p data/channels
mkdir -p data/extensions
mkdir -p data/blog_posts
mkdir -p data/blog_comments
mkdir -p data/wiki_pages
mkdir -p data/wiki_revisions
mkdir -p data/notifications
mkdir -p data/moderation_queue
mkdir -p data/user_hides
mkdir -p data/boards
mkdir -p data/board_threads
mkdir -p data/board_posts
mkdir -p data/tgp_posts
mkdir -p data/tgp_likes

# Set permissions
echo "Setting permissions..."
chmod 755 uploads
chmod 755 uploads/images
chmod 755 uploads/thumbs
chmod 755 uploads/avatars
chmod 755 uploads/board_thumbs
chmod 755 uploads/board_thumbs/thumbs

chmod 755 data
chmod 755 data/*

# Create .htaccess for data directory
echo "Creating security files..."
cat > data/.htaccess << 'EOF'
# Deny all access to data directory
Deny from all
EOF

# Create placeholder index files
echo "Creating placeholder files..."
touch uploads/index.html
touch data/index.html

echo ""
echo "==================================="
echo "Setup Complete!"
echo "==================================="
echo ""
echo "Next steps:"
echo "1. Visit http://yoursite.com/index.php?page=install"
echo "2. Complete the installation wizard"
echo "3. Create your admin account"
echo "4. Start using PXLBoard!"
echo ""
echo "For help, see README_v12f.md or ENHANCEMENT_GUIDE_v12f.md"
echo ""
