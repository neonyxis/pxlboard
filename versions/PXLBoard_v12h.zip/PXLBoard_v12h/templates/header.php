<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo escape(SITE_NAME); ?></title>
    <meta name="description" content="<?php echo escape(SITE_DESCRIPTION); ?>">
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    
    <!-- Custom Theme CSS -->
    <link rel="stylesheet" href="themes/<?php echo getTheme(); ?>/style.css">
    
    <!-- Board Enhancements JavaScript (v12c) -->
    <?php if (isset($_GET['page']) && $_GET['page'] === 'boards'): ?>
        <script src="js/boards-enhanced.js" defer></script>
    <?php endif; ?>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container-fluid">
            <a class="navbar-brand" href="index.php?page=home">
                <strong><?php echo escape(SITE_NAME); ?></strong>
                <?php if ($auth->isAdmin()): ?>
                    <span class="badge bg-secondary ms-2" style="font-size: 0.6rem; vertical-align: middle;">v<?php echo VERSION; ?></span>
                <?php endif; ?>
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php?page=home">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="index.php?page=community_portal">
                            <i class="bi bi-compass"></i> Portal
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="index.php?page=gallery_enhanced">Gallery</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="index.php?page=tgp">
                            <i class="bi bi-grid-3x3-gap"></i> Collections
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="index.php?page=boards_enhanced">Boards</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="index.php?page=forums">Forums</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            More
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="index.php?page=channel">Channels</a></li>
                            <li><a class="dropdown-item" href="index.php?page=tags">Tags</a></li>
                            <li><a class="dropdown-item" href="index.php?page=wiki">Wiki</a></li>
                            <li><a class="dropdown-item" href="index.php?page=blogs">Blogs</a></li>
                        </ul>
                    </li>
                    <?php if ($auth->isLoggedIn()): ?>
                        <li class="nav-item">
                            <a class="nav-link btn btn-outline-light btn-sm ms-2" href="index.php?page=upload">
                                <i class="bi bi-cloud-upload"></i> Upload
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
                
                <form class="d-flex me-3" method="GET" action="index.php">
                    <input type="hidden" name="page" value="search">
                    <input class="form-control me-2" type="search" name="q" placeholder="Search..." style="width: 250px;">
                    <button class="btn btn-outline-light" type="submit">Search</button>
                </form>
                
                <ul class="navbar-nav">
                    <?php if ($auth->isLoggedIn()): ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown">
                                <?php echo escape($_SESSION['username']); ?>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li><a class="dropdown-item" href="index.php?page=profile">My Profile</a></li>
                                <li><a class="dropdown-item" href="<?php echo buildUrl('user', $_SESSION['username']); ?>">Public Profile</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <?php if ($auth->isAdmin()): ?>
                                    <li><a class="dropdown-item" href="index.php?page=admin">Admin Panel</a></li>
                                    <li><a class="dropdown-item" href="index.php?page=admin_content">Content Management</a></li>
                                    <li><a class="dropdown-item" href="index.php?page=admin_forums">Forum Management</a></li>
                                    <li><a class="dropdown-item" href="index.php?page=extensions">Extensions</a></li>
                                    <li><hr class="dropdown-divider"></li>
                                <?php endif; ?>
                                <li>
                                    <form method="GET" action="index.php" class="px-3 py-2">
                                        <input type="hidden" name="page" value="home">
                                        <label class="form-label small">Theme</label>
                                        <select name="theme" class="form-select form-select-sm" onchange="document.cookie='theme='+this.value+';path=/;max-age=31536000'; location.reload();">
                                            <?php foreach (getAvailableThemes() as $theme): ?>
                                                <option value="<?php echo escape($theme['name']); ?>" 
                                                        <?php echo getTheme() === $theme['name'] ? 'selected' : ''; ?>>
                                                    <?php echo escape($theme['display_name']); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </form>
                                </li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="index.php?page=logout">Logout</a></li>
                            </ul>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="index.php?page=login">Login</a>
                        </li>
                        <?php if (REGISTRATION_ENABLED): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="index.php?page=register">Register</a>
                            </li>
                        <?php endif; ?>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
    
    <main>
