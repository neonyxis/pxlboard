# PXLBoard v12c Enhanced - Quick Start Guide

## What's New?

PXLBoard v12c Enhanced includes major UI improvements with **two new themes**, **advanced tagging**, and **enhanced viewing**. This guide will get you started quickly.

---

## 🎨 Using the New Themes

### Switching Themes

1. Click your **username** in the top-right navbar
2. Look for the **Theme** dropdown in the menu
3. Select your preferred theme:
   - **DPBooru** - Modern, colorful (recommended for daytime)
   - **Vichan** - Dark, classic (recommended for nighttime)
   - **Default** - Original PXLBoard theme
   - **Dark** - Original dark theme

4. Page will reload with new theme

### Theme Features

**DPBooru Theme:**
- Bright, colorful design
- Color-coded tags (purple = artist, green = character, etc.)
- Smooth animations
- Best for: Daytime browsing, visual users

**Vichan Theme:**
- Dark background (#0e0e0e)
- Muted colors
- Classic imageboard look
- Best for: Nighttime browsing, reduced eye strain

---

## 📋 Using Enhanced Boards

### Quick Actions

**Search Boards:**
- Press `S` to focus search box
- Type to filter boards instantly
- Press `ESC` to clear

**Change View:**
- Press `G` for grid view (cards)
- Press `L` for list view (table)
- Or click view toggle buttons

**Sort Boards:**
- Click "Sort By" dropdown
- Choose: Most Active, Recent, Name, Threads, or Posts

**Filter Content:**
- Click "SFW Only" for family-friendly
- Click "NSFW Only" for adult content
- Click "All Boards" to show everything

### Understanding Activity Indicators

- 🟢 **Green pulse** = High activity (10+ threads today)
- 🟡 **Yellow dot** = Medium activity (3-10 threads today)
- ⚪ **Gray dot** = Low activity (0-2 threads today)

---

## 🖼️ Using Enhanced Image View

### Zoom Controls

**Keyboard:**
- `+` or `=` - Zoom in
- `-` - Zoom out
- `0` - Reset zoom
- `F` - Fullscreen mode

**Mouse:**
- Hover over image to see zoom buttons (bottom-right)
- Click buttons to zoom in/out/reset
- Click fullscreen button (top-right)

### Quick Actions

Top-right buttons:
- **Fullscreen** - Immersive view
- **Download** - Save image
- **Favorite** - Add to your favorites (star icon)

Right sidebar:
- **Share** - Get shareable link
- **Report** - Flag inappropriate content
- **Edit** - Modify details (if you own it)
- **Delete** - Remove image (if you own it)

---

## 🏷️ Using the Tag System

### Understanding Tag Types

Tags are now **color-coded** by type:

| Color | Type | Example | When to Use |
|-------|------|---------|-------------|
| 🟣 Purple | Artist | `artist:john_doe` | Creator attribution |
| 🟢 Green | Character | `character:sparkle` | Character names |
| 🔴 Red | Species | `species:dragon` | Creature types |
| 🔵 Blue | General | `fluffy`, `cute` | General descriptions |
| 🟡 Yellow | Meta | `oc`, `commission` | Image metadata |
| 🔴 Red | Rating | `safe`, `nsfw` | Content rating |
| 🔵 Cyan | Content | `wallpaper` | Content type |

### How to Tag Images

**Basic tagging:**
```
fluffy, cute, sunset, landscape
```

**With type prefixes (recommended):**
```
artist:john_doe, character:rainbow, species:unicorn, safe, fluffy
```

**Mixed approach:**
```
artist:john, fluffy, cute, oc, safe
```

The system will automatically detect common patterns:
- `drawn_by_john` → Artist tag
- `oc` → Meta tag  
- `safe` → Rating tag

### Tag Autocomplete

When adding tags:
1. Start typing a tag name
2. Suggestions appear below
3. Click a suggestion to add it
4. See usage count for each tag

---

## ⌨️ Keyboard Shortcuts Cheat Sheet

### Boards Page
| Key | Action |
|-----|--------|
| `S` | Focus search |
| `ESC` | Clear search |
| `G` | Grid view |
| `L` | List view |

### Image View
| Key | Action |
|-----|--------|
| `F` | Fullscreen |
| `+` | Zoom in |
| `-` | Zoom out |
| `0` | Reset zoom |
| `ESC` | Exit fullscreen |

---

## 💡 Tips & Tricks

### For Browsing

1. **Use keyboard shortcuts** - Much faster than clicking
2. **Try both view modes** - Grid for visual, List for details
3. **Filter by rating** - Keep content appropriate for your setting
4. **Watch activity indicators** - Find active communities quickly

### For Tagging

1. **Use type prefixes** - Better organization and searchability
2. **Check suggestions** - Discover related tags
3. **Be consistent** - Use existing tags when possible
4. **Don't over-tag** - 5-15 tags is usually enough

### For Image Viewing

1. **Use fullscreen** - Better for detailed viewing
2. **Zoom in** - See fine details
3. **Check related images** - Discover similar content
4. **Read tags** - Learn proper tagging from good examples

---

## 🔧 Troubleshooting

### Themes Not Showing?

1. **Clear browser cache** (Ctrl+Shift+Delete)
2. **Hard refresh** (Ctrl+F5)
3. **Check another browser**
4. **Contact admin** if problem persists

### Search Not Working?

1. **Check JavaScript is enabled**
2. **Clear browser cache**
3. **Try different browser**
4. **Check browser console** (F12) for errors

### Zoom Not Responding?

1. **Enable JavaScript**
2. **Try keyboard shortcuts** (`+`, `-`, `0`)
3. **Hard refresh page** (Ctrl+F5)
4. **Update browser** to latest version

### Tags Not Color-Coded?

1. **Use type prefixes**: `artist:name` not just `name`
2. **Check tag format** - Common patterns auto-detect
3. **Wait for page reload** - Changes may require refresh

---

## 📱 Mobile Usage

The enhanced UI is **fully responsive**:

- **Touch-friendly** - Larger tap targets
- **Mobile menus** - Collapsible navigation
- **Optimized layouts** - Adapts to screen size
- **Zoom support** - Pinch to zoom on images
- **Portrait/Landscape** - Works both ways

**Mobile-specific tips:**
- Tap and hold for context menus
- Swipe to scroll through images
- Use browser fullscreen for best view
- Two-finger pinch to zoom images

---

## 🎯 Common Tasks

### Finding Active Boards
1. Go to Boards page
2. Sort by "Most Active"
3. Look for green activity indicators

### Discovering Similar Images
1. Open any image
2. Scroll to "Related Images" section (right sidebar)
3. Click thumbnails to explore

### Searching by Tags
1. Click any tag on an image
2. OR use search bar: type tag name
3. Multiple tags = AND search (all must match)

### Managing Favorites
1. Click star icon on any image
2. View favorites: Profile → My Profile
3. Remove: Click star again

---

## 📚 Learn More

- **Full Documentation**: `UI_ENHANCEMENTS.md`
- **All Changes**: `CHANGELOG_v12c_ENHANCED.md`
- **Main README**: `README.md`

---

## 🆘 Getting Help

**If something doesn't work:**

1. Check this guide
2. Read `UI_ENHANCEMENTS.md` for details
3. Clear browser cache and try again
4. Check browser console (F12) for errors
5. Contact site admin with:
   - What you tried
   - What happened
   - Browser and version
   - Screenshots if possible

---

## ✨ Pro Tips

### Power User Shortcuts

**Fastest board browsing:**
1. Press `S` to search
2. Type board name
3. Press Enter to visit first result

**Best tagging workflow:**
1. Start with type prefix: `artist:john`
2. Add general tags: `fluffy, cute`
3. Add meta tags: `oc, commission`
4. Add rating: `safe`

**Efficient image browsing:**
1. Use keyboard for zoom (`+`, `-`, `0`)
2. Fullscreen mode (`F`) for focus
3. Check related images for more
4. Use tags to find similar content

### Customization

**For Admins:**
- Set default theme in `config.php`
- Customize tag colors in theme CSS
- Add custom tag types in `enhanced_tags.php`

**For Users:**
- Bookmark favorite board searches
- Learn keyboard shortcuts
- Try both themes to see preference

---

**Enjoy the enhanced PXLBoard experience!**

For complete documentation, see `UI_ENHANCEMENTS.md`
