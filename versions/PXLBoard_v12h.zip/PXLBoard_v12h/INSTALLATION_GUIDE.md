# PXLBoard - Quick Installation Guide

## What is PXLBoard?

PXLBoard is a lightweight, flat-file PHP imageboard system inspired by Philomena. It's designed specifically for shared hosting environments and requires no database - all data is stored in JSON files.

## Key Features

✅ **Flat-File Storage** - No MySQL/PostgreSQL required
✅ **User Registration & Login** - Complete authentication system
✅ **Image Upload System** - Support for JPG, PNG, GIF, WebP
✅ **Tagging & Search** - Organize and find images easily
✅ **Comments** - Users can discuss images
✅ **SMTP Support** - Email notifications (optional)
✅ **Multiple Themes** - Dark mode included
✅ **Admin Panel** - Manage everything from the web interface
✅ **Shared Hosting Ready** - Works on most PHP hosting

## Installation Steps

### 1. Upload Files

Extract the ZIP file and upload all files to your web hosting via FTP or cPanel File Manager.

### 2. Set Permissions (Important!)

If on Linux/Unix hosting, set these permissions:

```bash
chmod 755 -R pxlboard/
chmod 777 -R pxlboard/data/
chmod 777 -R pxlboard/uploads/
```

In cPanel File Manager:
- Right-click the `data` folder → Change Permissions → Set to 777
- Right-click the `uploads` folder → Change Permissions → Set to 777

### 3. Access Installation Wizard

Open your browser and go to:
```
http://yourdomain.com/pxlboard/
```

The installation wizard will automatically start.

### 4. Complete Installation Form

Fill in:
- **Site Name**: Your imageboard name (e.g., "My ImageBoard")
- **Site Description**: Brief description
- **Site URL**: Your full site URL
- **Admin Username**: Choose a username
- **Admin Email**: Your email address
- **Admin Password**: Strong password (min 8 characters)

Click "Install PXLBoard"

### 5. Login

After installation completes, you'll be redirected to the login page. Use your admin credentials to log in.

## Post-Installation Configuration

### Enable SMTP (Optional)

For email notifications:

1. Login as admin
2. Go to **Admin Panel** (from user menu)
3. Click **Settings** tab
4. Scroll to **SMTP Settings**
5. Enable SMTP and enter your email server details

**Example for Gmail:**
- Host: `smtp.gmail.com`
- Port: `587`
- Username: `youremail@gmail.com`
- Password: Your Gmail password or [app-specific password](https://support.google.com/accounts/answer/185833)
- From Email: `youremail@gmail.com`

### Adjust Upload Limits

In Admin Panel → Settings:
- Change **Max Upload Size** (default: 10MB)
- Modify PHP limits in `.htaccess` if needed

### Choose Default Theme

In Admin Panel → Settings:
- Select **Default Theme** (Default or Dark mode)

## Troubleshooting

### Can't upload images

**Solution 1:** Check directory permissions
```bash
chmod 777 data/
chmod 777 uploads/
```

**Solution 2:** Increase PHP upload limit
Edit `.htaccess`:
```
php_value upload_max_filesize 20M
php_value post_max_size 20M
```

### Installation wizard not appearing

**Check:** Make sure you deleted any existing `data/installed.lock` file

### Blank page / Errors

**Check:** Ensure PHP 7.4+ is installed
**Check:** GD library is enabled: `php -m | grep gd`
**Check:** Error logs in cPanel or server logs

### Permission denied errors

All directories need proper permissions:
```bash
chmod 755 index.php config/ includes/ pages/ templates/ themes/
chmod 777 data/ uploads/
```

## Requirements

- **PHP:** 7.4 or higher
- **GD Library:** For image processing (usually pre-installed)
- **Apache:** With mod_rewrite enabled (most shared hosting)
- **Disk Space:** Depends on your image storage needs

## Security Tips

1. **Use HTTPS** - Enable SSL certificate (free with Let's Encrypt)
2. **Strong Passwords** - Enforce for all admin accounts
3. **Regular Backups** - Backup the `data/` directory regularly
4. **Update PHP** - Keep your PHP version updated
5. **Disable Registration** - If you want a private board (Admin Panel → Settings)

## Customization

### Creating Custom Themes

1. Create folder: `themes/mytheme/`
2. Add `style.css` with your custom CSS
3. Create `theme.json`:
```json
{
    "name": "mytheme",
    "display_name": "My Theme",
    "description": "My custom theme",
    "author": "Your Name",
    "version": "1.0.0"
}
```

Theme will appear in the theme selector automatically!

## Support & Documentation

- **README.md** - Full documentation included
- **Admin Panel** - Built-in settings and controls
- Issues? Check file permissions and PHP error logs

## System Overview

### Directory Structure
```
pxlboard/
├── config/          → Configuration files
├── data/            → Database (JSON files)
├── includes/        → Core PHP classes
├── pages/           → Page controllers
├── templates/       → Header/footer templates
├── themes/          → Theme files (CSS)
├── uploads/         → User uploaded images
└── index.php        → Main entry point
```

### Default Admin Credentials

**After installation:**
- Username: As you specified during install
- Password: As you specified during install

**Change these immediately after first login!**

## What's Next?

1. **Login** with your admin account
2. **Upload** your first image
3. **Create tags** to organize content
4. **Customize settings** in Admin Panel
5. **Choose a theme** or create your own
6. **Enable registration** to let others join
7. **Configure SMTP** for email features

## Feature Highlights

### User Features
- Upload images with descriptions
- Tag images for organization
- Search by tags, title, or description
- Comment on images
- User profiles
- Theme customization

### Admin Features
- Complete settings control
- User management
- Image moderation
- SMTP configuration
- Upload limits
- Registration control

## Need Help?

Check the included **README.md** for detailed information on:
- Advanced configuration
- Theme development
- Security best practices
- Troubleshooting common issues

---

**Enjoy your new imageboard!**

PXLBoard v1.0.0 - A lightweight PHP imageboard for shared hosting
