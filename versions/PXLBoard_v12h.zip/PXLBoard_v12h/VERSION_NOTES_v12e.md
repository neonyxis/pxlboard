# PXLBoard v12e - Release Notes

## Major Update: Enhanced Forum System
**Release Date:** January 31, 2026

### 🎉 New Features

#### Forum Moderation & Administration
- **Complete Admin Panel** for forum management (`admin_forums.php`)
  - Overview dashboard with statistics
  - Category management with customization
  - Content moderation tools
  - Comprehensive settings panel

#### Customizable Categories
- Full category CRUD operations
- Custom icons (Bootstrap Icons support)
- Custom colors for each category
- Category descriptions
- Enable/disable categories
- Order management

#### Image & File Uploads
- Support for image uploads in topics and replies
- Configurable max images per post
- File attachment support
- Configurable file size limits
- Allowed file extensions management
- Visual attachment gallery display
- Click to enlarge images
- Download buttons for non-image files

#### Advanced Voting System  
- Reddit-style upvote/downvote on topics
- Upvote/downvote on individual replies
- Vote score calculation
- Visual vote indicators (colors for positive/negative)
- "Hot" sorting based on votes and time decay
- "Top" sorting by vote score

#### Modern Moderation Tools
- Lock/unlock topics
- Pin/unpin topics
- Delete topics and replies (with cascade delete of attachments)
- Move topics between categories
- Flag/report system for content
- Bulk moderation actions
- Moderation log and history

#### Enhanced User Experience
- Best Answer marking system
- "Solved" status for topics
- View tracking (per session)
- Content length validation
- Edit time limits
- Auto-lock inactive topics
- Anonymous posting option
- Post approval system

### ⚙️ Configuration Options

#### Forum Settings (via Admin Panel)
- **Media Settings:**
  - Allow/disable image uploads
  - Max images per post (1-20)
  - Allow/disable file attachments
  - Max file size (MB)
  - Allowed file extensions

- **Posting Settings:**
  - Minimum post length
  - Maximum post length
  - Allow user editing
  - Edit time limit
  - Posts per page

- **Feature Toggles:**
  - Voting system on/off
  - Best answer marking on/off
  - Anonymous posting on/off
  - Require approval for new topics
  - Auto-lock after X days

### 📁 New Files

```
pages/
├── admin_forums.php          # Admin panel for forum management
├── forums.php                # Enhanced forum system (replaced)
└── forums_backup.php         # Backup of previous version

data/
├── forum_categories.json     # Customizable category configuration
└── forum_settings.json       # Forum feature settings

uploads/
└── forum/                    # Forum attachments directory
```

### 🔧 Technical Improvements

- **Database Structure Updates:**
  - Added `attachments` field to topics and replies
  - Added `flags` field for reporting
  - Added `approved` field for moderation queue
  - Added `votes` and `score` fields

- **File Upload Handling:**
  - Secure file upload with sanitization
  - File type validation
  - Size limit enforcement
  - Unique filename generation
  - Automatic directory creation

- **Performance:**
  - Efficient vote calculation
  - Session-based view tracking
  - Smart sorting algorithms

### 🎨 UI/UX Enhancements

- Modern card-based topic layout
- Attachment gallery grid
- Improved mobile responsiveness
- Better visual hierarchy
- Loading states and transitions
- Modal dialogs for moderation actions
- Color-coded categories
- Badge system for topic status

### 🛡️ Security Improvements

- File upload validation
- Content length limits
- XSS protection in user content
- Admin-only moderation features
- Permission checks throughout
- Secure file handling
- Input sanitization

### 📋 Moderation Features

1. **Topic Management:**
   - Pin/unpin topics
   - Lock/unlock discussions
   - Move to different categories
   - Delete with cascading cleanup
   - Approve/reject pending topics

2. **Content Monitoring:**
   - Flag/report system
   - Flagged content dashboard
   - Bulk actions
   - Filter by status (pinned, locked, flagged)

3. **Category Control:**
   - Add/edit/delete categories
   - Enable/disable categories
   - Custom styling per category
   - Usage tracking

### 🔄 Migration from v12d

No database migration required. New features will:
- Auto-create configuration files
- Initialize with sensible defaults
- Preserve existing forum data
- Add new fields transparently

### 📝 Usage Notes

1. **Access Admin Panel:**
   - Navigate to Admin → Forum Management
   - Or visit: `index.php?page=admin_forums`

2. **Configure Categories:**
   - Go to Forum Management → Categories tab
   - Add, edit, or remove categories
   - Customize icons, colors, and descriptions

3. **Adjust Settings:**
   - Forum Management → Settings tab
   - Configure upload limits
   - Toggle features on/off
   - Set content restrictions

4. **Moderate Content:**
   - Forum Management → Moderation tab
   - View all topics or filter by status
   - Use quick actions for moderation
   - Review flagged content

### ⚠️ Breaking Changes

None. This is a backward-compatible update.

### 🐛 Bug Fixes from v12d

- Fixed undefined variable errors in boards pages
- Added missing header/footer templates
- Corrected theme CSS loading
- Fixed vote state persistence

### 📚 Documentation

- See `admin_forums.php` for moderation panel
- Category configuration in `/data/forum_categories.json`
- Settings configuration in `/data/forum_settings.json`
- File uploads stored in `/uploads/forum/`

### 🚀 Future Enhancements

Planned for future releases:
- Rich text editor integration
- Emoji reactions
- Thread subscriptions
- Email notifications
- User reputation system
- Advanced search with filters
- Export/import categories
- Moderation activity log

---

## Installation

1. Replace PXLBoard_v12d with PXLBoard_v12e
2. Ensure `uploads/forum/` directory is writable
3. Access admin panel to configure forum settings
4. Customize categories as needed

## Upgrade Path

```bash
# Backup your data directory
cp -r data data_backup

# Extract v12e
unzip PXLBoard_v12e.zip

# Your forum data will be preserved
# New config files will be auto-created
```

---

**Version:** 12e  
**Codename:** Forum Master  
**Build Date:** 2026-01-31
