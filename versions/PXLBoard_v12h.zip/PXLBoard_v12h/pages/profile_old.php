<?php
/**
 * Profile Page
 */

if (!$auth->isLoggedIn()) {
    redirect('index.php?page=login');
}

$user = $auth->getCurrentUser();
$userImages = array_filter($db->getAll('images'), function($img) use ($user) {
    return $img['uploader_id'] === $user['id'];
});

require 'templates/header.php';
?>

<div class="container mt-4">
    <h2>Profile: <?php echo escape($user['username']); ?></h2>
    
    <div class="card mb-4">
        <div class="card-body">
            <p><strong>Email:</strong> <?php echo escape($user['email']); ?></p>
            <p><strong>Role:</strong> <span class="badge <?php echo $user['role'] === 'admin' ? 'bg-danger' : 'bg-secondary'; ?>"><?php echo escape($user['role']); ?></span></p>
            <p><strong>Member since:</strong> <?php echo date('F j, Y', $user['created_at']); ?></p>
            <p><strong>Uploaded images:</strong> <?php echo count($userImages); ?></p>
        </div>
    </div>
    
    <h3>Your Uploads</h3>
    
    <div class="row">
        <?php if (empty($userImages)): ?>
            <div class="col-12 text-center py-5">
                <p class="text-muted">You haven't uploaded any images yet</p>
                <a href="index.php?page=upload" class="btn btn-primary">Upload Now</a>
            </div>
        <?php else: ?>
            <?php foreach ($userImages as $image): ?>
                <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                    <div class="card image-card">
                        <a href="index.php?page=image&id=<?php echo escape($image['id']); ?>">
                            <img src="uploads/thumbs/<?php echo escape($image['filename']); ?>" 
                                 class="card-img-top" 
                                 alt="<?php echo escape($image['title']); ?>">
                        </a>
                        <div class="card-body">
                            <h6 class="card-title"><?php echo escape($image['title']); ?></h6>
                            <p class="card-text small text-muted"><?php echo timeAgo($image['uploaded_at']); ?></p>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<?php require 'templates/footer.php'; ?>
