<?php
/**
 * Individual Board Page - Shows threads within a board
 */

require_once 'includes/board_moderators.php';
require_once 'includes/board_voting.php';

$boardMods = new BoardModerators($db);
$voting = new BoardVoting($db);

$boardId = $_GET['id'] ?? '';
if (empty($boardId)) {
    header('Location: index.php?page=boards');
    exit;
}

$board = $db->get('boards', $boardId);
if (!$board) {
    header('Location: index.php?page=boards');
    exit;
}

$user = $auth->getCurrentUser();
$isModerator = $user && $boardMods->isModerator($boardId, $user['id']);
$isTopLevelMod = $user && $boardMods->isTopLevelMod($boardId, $user['id']);
$isAdmin = $auth->isAdmin();

// Handle moderator actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $isTopLevelMod) {
    if (isset($_POST['add_moderator'])) {
        $username = trim($_POST['mod_username'] ?? '');
        $users = $db->getAll('users');
        foreach ($users as $u) {
            if ($u['username'] === $username) {
                $topLevel = isset($_POST['top_level']);
                if ($boardMods->addModerator($boardId, $u['id'], $u['username'], $topLevel)) {
                    $_SESSION['success'] = "Moderator added";
                }
                break;
            }
        }
        header('Location: index.php?page=board&id=' . $boardId);
        exit;
    }
    
    if (isset($_POST['remove_moderator'])) {
        $modUserId = $_POST['mod_user_id'];
        if ($boardMods->removeModerator($boardId, $modUserId)) {
            $_SESSION['success'] = "Moderator removed";
        }
        header('Location: index.php?page=board&id=' . $boardId);
        exit;
    }
}

// Handle thread creation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_thread']) && $auth->isLoggedIn()) {
    $title = trim($_POST['title'] ?? '');
    $content = trim($_POST['content'] ?? '');
    $anonymous = isset($_POST['anonymous']);
    
    if (!empty($title) && !empty($content)) {
        $threadId = 'thread_' . time() . '_' . rand(1000, 9999);
        
        $imagePath = null;
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $uploadDir = 'uploads/board_images/';
            if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
            
            $extension = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
            if (in_array($extension, ['jpg', 'jpeg', 'png', 'gif', 'webp'])) {
                $filename = $threadId . '_' . time() . '.' . $extension;
                $targetPath = $uploadDir . $filename;
                if (move_uploaded_file($_FILES['image']['tmp_name'], $targetPath)) {
                    $imagePath = $targetPath;
                }
            }
        }
        
        $threadData = [
            'board_id' => $boardId,
            'title' => $title,
            'content' => $content,
            'author_id' => $anonymous ? null : $user['id'],
            'author_name' => $anonymous ? 'Anonymous' : $user['username'],
            'image' => $imagePath,
            'created_at' => time(),
            'updated_at' => time(),
            'reply_count' => 0,
            'pinned' => false,
            'locked' => false,
            'votes' => [],
            'vote_score' => 0
        ];
        
        if ($db->save('board_threads', $threadId, $threadData)) {
            $board['thread_count'] = ($board['thread_count'] ?? 0) + 1;
            $board['post_count'] = ($board['post_count'] ?? 0) + 1;
            $db->save('boards', $boardId, $board);
            
            $_SESSION['success'] = "Thread created successfully!";
            header('Location: index.php?page=board_thread&id=' . $threadId);
            exit;
        }
    }
}

// Handle thread actions (mod/admin)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($isModerator || $isAdmin)) {
    $threadId = $_POST['thread_id'] ?? '';
    $thread = $db->get('board_threads', $threadId);
    
    if ($thread && $thread['board_id'] === $boardId) {
        if (isset($_POST['pin_thread'])) {
            $thread['pinned'] = !($thread['pinned'] ?? false);
            $db->save('board_threads', $threadId, $thread);
        } elseif (isset($_POST['lock_thread'])) {
            $thread['locked'] = !($thread['locked'] ?? false);
            $db->save('board_threads', $threadId, $thread);
        } elseif (isset($_POST['delete_thread'])) {
            if (!empty($thread['image']) && file_exists($thread['image'])) {
                unlink($thread['image']);
            }
            
            $posts = $db->getAll('board_posts');
            foreach ($posts as $post) {
                if ($post['thread_id'] === $threadId) {
                    if (!empty($post['image']) && file_exists($post['image'])) {
                        unlink($post['image']);
                    }
                    $db->delete('board_posts', $post['id']);
                }
            }
            
            $db->delete('board_threads', $threadId);
            $board['thread_count'] = max(0, ($board['thread_count'] ?? 1) - 1);
            $board['post_count'] = max(0, ($board['post_count'] ?? 1) - ($thread['reply_count'] ?? 0) - 1);
            $db->save('boards', $boardId, $board);
            
            $_SESSION['success'] = "Thread deleted";
        }
    }
    header('Location: index.php?page=board&id=' . $boardId);
    exit;
}

// Get threads
$allThreads = $db->getAll('board_threads');
$threads = array_filter($allThreads, function($thread) use ($boardId) {
    return $thread['board_id'] === $boardId;
});

usort($threads, function($a, $b) {
    if (($a['pinned'] ?? false) && !($b['pinned'] ?? false)) return -1;
    if (!($a['pinned'] ?? false) && ($b['pinned'] ?? false)) return 1;
    return ($b['updated_at'] ?? 0) - ($a['updated_at'] ?? 0);
});

$page_num = isset($_GET['p']) ? max(1, intval($_GET['p'])) : 1;
$perPage = 20;
$offset = ($page_num - 1) * $perPage;
$totalThreads = count($threads);
$totalPages = ceil($totalThreads / $perPage);
$threads = array_slice($threads, $offset, $perPage);

$pageTitle = $board['name'] . ' - ' . SITE_NAME;
include 'templates/header.php';
?>

<style>
.board-container { max-width: 1200px; margin: 0 auto; }
.board-banner { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; border-radius: 10px; margin-bottom: 20px; }
.board-banner h1 { margin: 0; font-size: 2.5em; }
.board-stats { display: flex; gap: 20px; margin-top: 15px; font-size: 0.9em; }
.thread-create-box { background: white; border: 2px solid #667eea; border-radius: 8px; padding: 20px; margin-bottom: 20px; }
.thread-list { background: white; border-radius: 8px; overflow: hidden; }
.thread-item { padding: 15px 20px; border-bottom: 1px solid #e0e0e0; transition: background 0.2s; display: flex; gap: 15px; align-items: start; }
.thread-item:hover { background: #f9f9f9; }
.thread-thumbnail { width: 60px; height: 60px; border-radius: 5px; object-fit: cover; }
.thread-info { flex: 1; }
.thread-title { font-size: 1.1em; font-weight: bold; margin-bottom: 5px; }
.thread-title a { color: #333; text-decoration: none; }
.thread-title a:hover { color: #667eea; }
.thread-meta { font-size: 0.85em; color: #888; }
.thread-stats { display: flex; gap: 15px; margin-top: 5px; font-size: 0.85em; color: #666; }
.thread-actions { display: flex; flex-direction: column; gap: 5px; }
.pinned-badge { background: #ffd700; color: #333; padding: 2px 8px; border-radius: 3px; font-size: 0.75em; font-weight: bold; }
.locked-badge { background: #999; color: white; padding: 2px 8px; border-radius: 3px; font-size: 0.75em; font-weight: bold; }
.mod-panel { background: #f0f4ff; border: 2px solid #667eea; border-radius: 8px; padding: 20px; margin-bottom: 20px; }
.mod-list { list-style: none; padding: 0; }
.mod-list li { padding: 8px; background: white; margin: 5px 0; border-radius: 5px; display: flex; justify-content: space-between; align-items: center; }
</style>

<div class="container board-container">
    <div class="board-banner">
        <h1>
            <span style="font-family: monospace; opacity: 0.9;">/<?php echo htmlspecialchars($board['shortcode']); ?>/</span>
            - <?php echo htmlspecialchars($board['name']); ?>
        </h1>
        <?php if (!empty($board['description'])): ?>
            <div style="margin-top: 10px; opacity: 0.9;">
                <?php echo htmlspecialchars($board['description']); ?>
            </div>
        <?php endif; ?>
        <div class="board-stats">
            <span>💬 <?php echo number_format($board['thread_count'] ?? 0); ?> threads</span>
            <span>📝 <?php echo number_format($board['post_count'] ?? 0); ?> posts</span>
            <?php if ($board['nsfw'] ?? false): ?>
                <span style="background: #ff4444; padding: 2px 8px; border-radius: 3px;">NSFW</span>
            <?php endif; ?>
            <?php if ($isModerator): ?>
                <span style="background: #4CAF50; padding: 2px 8px; border-radius: 3px;">⚡ MODERATOR</span>
            <?php endif; ?>
        </div>
    </div>

    <div style="margin-bottom: 20px;">
        <a href="index.php?page=boards" class="btn btn-secondary">← Back to Boards</a>
    </div>

    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success">
            <?php echo htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?>
        </div>
    <?php endif; ?>

    <?php if ($isTopLevelMod): ?>
        <div class="mod-panel">
            <h4>⚡ Moderator Panel</h4>
            <div class="row">
                <div class="col-md-6">
                    <h5>Add Moderator</h5>
                    <form method="post">
                        <div class="input-group mb-2">
                            <input type="text" name="mod_username" class="form-control" placeholder="Username" required>
                            <button type="submit" name="add_moderator" class="btn btn-primary">Add</button>
                        </div>
                        <div class="form-check">
                            <input type="checkbox" name="top_level" class="form-check-input" id="top_level">
                            <label class="form-check-label" for="top_level">Top-level (can add mods)</label>
                        </div>
                    </form>
                </div>
                <div class="col-md-6">
                    <h5>Current Moderators</h5>
                    <ul class="mod-list">
                        <?php foreach ($boardMods->getModerators($boardId) as $mod): ?>
                            <li>
                                <span>
                                    <?php echo htmlspecialchars($mod['username']); ?>
                                    <?php if ($mod['is_creator'] ?? false): ?>
                                        <span class="badge bg-warning">Creator</span>
                                    <?php elseif ($mod['top_level'] ?? false): ?>
                                        <span class="badge bg-success">Top-level</span>
                                    <?php endif; ?>
                                </span>
                                <?php if (!($mod['is_creator'] ?? false)): ?>
                                    <form method="post" style="margin: 0;">
                                        <input type="hidden" name="mod_user_id" value="<?php echo $mod['user_id']; ?>">
                                        <button type="submit" name="remove_moderator" class="btn btn-sm btn-danger">Remove</button>
                                    </form>
                                <?php endif; ?>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <?php if ($auth->isLoggedIn()): ?>
        <div class="thread-create-box">
            <h4>Start a New Thread</h4>
            <form method="post" enctype="multipart/form-data">
                <div class="mb-3">
                    <input type="text" name="title" class="form-control" placeholder="Thread title..." required maxlength="200">
                </div>
                <div class="mb-3">
                    <textarea name="content" class="form-control" rows="4" placeholder="Your message..." required></textarea>
                </div>
                <div class="mb-3">
                    <label class="form-label">Attach Image (optional)</label>
                    <input type="file" name="image" class="form-control" accept="image/*">
                </div>
                <div class="mb-3 form-check">
                    <input type="checkbox" name="anonymous" class="form-check-input" id="anonymous">
                    <label class="form-check-label" for="anonymous">Post anonymously</label>
                </div>
                <button type="submit" name="create_thread" class="btn btn-primary">Create Thread</button>
            </form>
        </div>
    <?php else: ?>
        <div class="alert alert-info">
            <a href="index.php?page=login">Log in</a> to create threads
        </div>
    <?php endif; ?>

    <?php if (empty($threads)): ?>
        <div class="alert alert-secondary text-center">
            <h5>No threads yet</h5>
            <p>Be the first to start a discussion!</p>
        </div>
    <?php else: ?>
        <div class="thread-list">
            <?php foreach ($threads as $thread): ?>
                <div class="thread-item">
                    <?php if (!empty($thread['image'])): ?>
                        <img src="<?php echo htmlspecialchars($thread['image']); ?>" class="thread-thumbnail" alt="Thread image">
                    <?php endif; ?>
                    
                    <div class="thread-info">
                        <div class="thread-title">
                            <?php if ($thread['pinned'] ?? false): ?>
                                <span class="pinned-badge">📌 PINNED</span>
                            <?php endif; ?>
                            <?php if ($thread['locked'] ?? false): ?>
                                <span class="locked-badge">🔒 LOCKED</span>
                            <?php endif; ?>
                            <a href="index.php?page=board_thread&id=<?php echo $thread['id']; ?>">
                                <?php echo htmlspecialchars($thread['title']); ?>
                            </a>
                        </div>
                        <div class="thread-meta">
                            by <strong><?php echo htmlspecialchars($thread['author_name'] ?? 'Anonymous'); ?></strong>
                            • <?php echo date('M j, Y g:i A', $thread['created_at']); ?>
                        </div>
                        <div class="thread-stats">
                            <span>💬 <?php echo number_format($thread['reply_count'] ?? 0); ?> replies</span>
                            <span>⬆ <?php echo $thread['vote_score'] ?? 0; ?> points</span>
                        </div>
                    </div>

                    <div class="thread-actions">
                        <?php if ($isModerator || $isAdmin): ?>
                            <form method="post" style="margin: 0;">
                                <input type="hidden" name="thread_id" value="<?php echo $thread['id']; ?>">
                                <button type="submit" name="pin_thread" class="btn btn-sm btn-warning">
                                    <?php echo ($thread['pinned'] ?? false) ? 'Unpin' : 'Pin'; ?>
                                </button>
                                <button type="submit" name="lock_thread" class="btn btn-sm btn-secondary">
                                    <?php echo ($thread['locked'] ?? false) ? 'Unlock' : 'Lock'; ?>
                                </button>
                                <button type="submit" name="delete_thread" class="btn btn-sm btn-danger" 
                                        onclick="return confirm('Delete this thread?');">Delete</button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <?php if ($totalPages > 1): ?>
            <nav class="mt-3">
                <ul class="pagination justify-content-center">
                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <li class="page-item <?php echo $i === $page_num ? 'active' : ''; ?>">
                            <a class="page-link" href="?page=board&id=<?php echo $boardId; ?>&p=<?php echo $i; ?>">
                                <?php echo $i; ?>
                            </a>
                        </li>
                    <?php endfor; ?>
                </ul>
            </nav>
        <?php endif; ?>
    <?php endif; ?>
</div>

<?php include 'templates/footer.php'; ?>
