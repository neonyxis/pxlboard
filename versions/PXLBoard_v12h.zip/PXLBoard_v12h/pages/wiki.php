<?php
/**
 * Wiki System
 * View and browse wiki pages
 */

$action = $_GET['action'] ?? 'browse';
$pageSlug = $_GET['slug'] ?? 'main_page';

if ($action === 'view') {
    // View specific wiki page
    $wikiPages = $db->getAll('wiki_pages');
    $page = null;
    
    foreach ($wikiPages as $wp) {
        if ($wp['slug'] === $pageSlug) {
            $page = $wp;
            break;
        }
    }
    
    if (!$page) {
        // Page doesn't exist, show create prompt
        require 'templates/header.php';
        ?>
        <div class="container mt-4">
            <div class="alert alert-info">
                <h4>This wiki page doesn't exist yet</h4>
                <p>The page "<strong><?php echo escape($pageSlug); ?></strong>" hasn't been created.</p>
                <?php if ($auth->isLoggedIn()): ?>
                    <a href="index.php?page=wiki_edit&slug=<?php echo urlencode($pageSlug); ?>" 
                       class="btn btn-primary">Create This Page</a>
                <?php else: ?>
                    <p>Please <a href="index.php?page=login">log in</a> to create this page.</p>
                <?php endif; ?>
                <a href="index.php?page=wiki" class="btn btn-secondary">Back to Wiki</a>
            </div>
        </div>
        <?php
        require 'templates/footer.php';
        exit;
    }
    
    // Increment view count
    $page['views'] = ($page['views'] ?? 0) + 1;
    $db->save('wiki_pages', $page['id'], $page);
    
    require 'templates/header.php';
    ?>
    
    <div class="container mt-4">
        <div class="row">
            <div class="col-lg-9">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start mb-3">
                            <h1><?php echo escape($page['title']); ?></h1>
                            <div class="btn-group">
                                <?php if ($auth->isLoggedIn()): ?>
                                    <a href="index.php?page=wiki_edit&slug=<?php echo urlencode($page['slug']); ?>" 
                                       class="btn btn-sm btn-outline-primary">
                                        <i class="bi bi-pencil"></i> Edit
                                    </a>
                                <?php endif; ?>
                                <a href="index.php?page=wiki_history&slug=<?php echo urlencode($page['slug']); ?>" 
                                   class="btn btn-sm btn-outline-secondary">
                                    <i class="bi bi-clock-history"></i> History
                                </a>
                            </div>
                        </div>
                        
                        <div class="wiki-content">
                            <?php echo nl2br(escape($page['content'])); ?>
                        </div>
                        
                        <hr>
                        
                        <div class="small text-muted">
                            <div class="row">
                                <div class="col-md-6">
                                    Created by <?php echo escape($page['created_by_username'] ?? 'Unknown'); ?> 
                                    on <?php echo date('F j, Y', $page['created_at']); ?>
                                </div>
                                <div class="col-md-6 text-end">
                                    <?php if (isset($page['last_edited_at'])): ?>
                                        Last edited by <?php echo escape($page['last_edited_by_username'] ?? 'Unknown'); ?> 
                                        on <?php echo date('F j, Y', $page['last_edited_at']); ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="mt-2">
                                <i class="bi bi-eye"></i> <?php echo number_format($page['views'] ?? 0); ?> views •
                                <i class="bi bi-clock-history"></i> <?php echo number_format($page['revision_count'] ?? 1); ?> revisions
                                <?php if (!empty($page['category'])): ?>
                                    • <i class="bi bi-folder"></i> <?php echo escape($page['category']); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-3">
                <div class="card mb-3">
                    <div class="card-header">
                        <strong>Wiki Navigation</strong>
                    </div>
                    <div class="list-group list-group-flush">
                        <a href="index.php?page=wiki&action=view&slug=main_page" 
                           class="list-group-item list-group-item-action">
                            <i class="bi bi-house"></i> Main Page
                        </a>
                        <a href="index.php?page=wiki" 
                           class="list-group-item list-group-item-action">
                            <i class="bi bi-list"></i> All Pages
                        </a>
                        <a href="index.php?page=wiki&action=categories" 
                           class="list-group-item list-group-item-action">
                            <i class="bi bi-folder"></i> Categories
                        </a>
                        <a href="index.php?page=wiki&action=recent" 
                           class="list-group-item list-group-item-action">
                            <i class="bi bi-clock"></i> Recent Changes
                        </a>
                    </div>
                </div>
                
                <?php if (!empty($page['related_pages'])): ?>
                <div class="card">
                    <div class="card-header">
                        <strong>Related Pages</strong>
                    </div>
                    <div class="list-group list-group-flush">
                        <?php foreach ($page['related_pages'] as $relatedSlug): 
                            $relatedPage = null;
                            foreach ($wikiPages as $wp) {
                                if ($wp['slug'] === $relatedSlug) {
                                    $relatedPage = $wp;
                                    break;
                                }
                            }
                            if ($relatedPage):
                        ?>
                            <a href="index.php?page=wiki&action=view&slug=<?php echo urlencode($relatedSlug); ?>" 
                               class="list-group-item list-group-item-action">
                                <?php echo escape($relatedPage['title']); ?>
                            </a>
                        <?php endif; endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <?php
    require 'templates/footer.php';
    exit;
}

// Browse all pages
$wikiPages = $db->getAll('wiki_pages');
$categories = [];

// Group by category
foreach ($wikiPages as $page) {
    $category = $page['category'] ?? 'Uncategorized';
    if (!isset($categories[$category])) {
        $categories[$category] = [];
    }
    $categories[$category][] = $page;
}

// Sort pages within categories alphabetically
foreach ($categories as &$pages) {
    usort($pages, function($a, $b) {
        return strcmp($a['title'], $b['title']);
    });
}

ksort($categories);

require 'templates/header.php';
?>

<div class="container mt-4">
    <div class="row mb-4">
        <div class="col-md-8">
            <h1><i class="bi bi-book"></i> Wiki</h1>
            <p class="text-muted">Community knowledge base</p>
        </div>
        <div class="col-md-4 text-end">
            <?php if ($auth->isLoggedIn()): ?>
                <a href="index.php?page=wiki_edit" class="btn btn-primary">
                    <i class="bi bi-plus-circle"></i> New Page
                </a>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Search Box -->
    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" action="index.php">
                <input type="hidden" name="page" value="wiki">
                <input type="hidden" name="action" value="search">
                <div class="input-group">
                    <input type="text" name="q" class="form-control" 
                           placeholder="Search wiki pages..." 
                           value="<?php echo escape($_GET['q'] ?? ''); ?>">
                    <button class="btn btn-primary" type="submit">
                        <i class="bi bi-search"></i> Search
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Statistics -->
    <div class="row mb-4">
        <div class="col-md-4">
            <div class="card text-center">
                <div class="card-body">
                    <h3><?php echo number_format(count($wikiPages)); ?></h3>
                    <p class="text-muted mb-0">Total Pages</p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card text-center">
                <div class="card-body">
                    <h3><?php echo number_format(count($categories)); ?></h3>
                    <p class="text-muted mb-0">Categories</p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card text-center">
                <div class="card-body">
                    <?php
                    $totalEdits = 0;
                    foreach ($wikiPages as $page) {
                        $totalEdits += $page['revision_count'] ?? 1;
                    }
                    ?>
                    <h3><?php echo number_format($totalEdits); ?></h3>
                    <p class="text-muted mb-0">Total Edits</p>
                </div>
            </div>
        </div>
    </div>
    
    <?php if (empty($wikiPages)): ?>
        <div class="alert alert-info text-center py-5">
            <h4>No wiki pages yet</h4>
            <p>Be the first to create a wiki page!</p>
            <?php if ($auth->isLoggedIn()): ?>
                <a href="index.php?page=wiki_edit" class="btn btn-primary">Create First Page</a>
            <?php else: ?>
                <a href="index.php?page=login" class="btn btn-primary">Log In to Create Pages</a>
            <?php endif; ?>
        </div>
    <?php else: ?>
        <!-- Pages by Category -->
        <?php foreach ($categories as $categoryName => $pages): ?>
            <div class="card mb-3">
                <div class="card-header">
                    <h5 class="mb-0">
                        <i class="bi bi-folder"></i> <?php echo escape($categoryName); ?>
                        <span class="badge bg-secondary"><?php echo count($pages); ?></span>
                    </h5>
                </div>
                <div class="list-group list-group-flush">
                    <?php foreach ($pages as $page): ?>
                        <div class="list-group-item">
                            <div class="d-flex justify-content-between align-items-start">
                                <div>
                                    <h6 class="mb-1">
                                        <a href="index.php?page=wiki&action=view&slug=<?php echo urlencode($page['slug']); ?>" 
                                           class="text-decoration-none">
                                            <?php echo escape($page['title']); ?>
                                        </a>
                                    </h6>
                                    <p class="mb-1 small text-muted">
                                        <?php echo escape(mb_substr($page['summary'] ?? '', 0, 100)); ?>
                                        <?php if (strlen($page['summary'] ?? '') > 100) echo '...'; ?>
                                    </p>
                                    <small class="text-muted">
                                        <i class="bi bi-eye"></i> <?php echo number_format($page['views'] ?? 0); ?> views •
                                        <i class="bi bi-clock-history"></i> <?php echo number_format($page['revision_count'] ?? 1); ?> revisions •
                                        Updated <?php echo timeAgo($page['last_edited_at'] ?? $page['created_at']); ?>
                                    </small>
                                </div>
                                <div class="text-end">
                                    <?php if ($auth->isLoggedIn()): ?>
                                        <a href="index.php?page=wiki_edit&slug=<?php echo urlencode($page['slug']); ?>" 
                                           class="btn btn-sm btn-outline-primary">
                                            <i class="bi bi-pencil"></i> Edit
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<?php require 'templates/footer.php'; ?>
