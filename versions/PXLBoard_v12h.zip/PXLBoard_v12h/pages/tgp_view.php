<?php
/**
 * TGP View Page - Display Individual Gallery Collection
 */

require_once 'includes/tgp_manager.php';

$tgpManager = new TGPManager($db);

$postId = $_GET['id'] ?? '';
$post = $tgpManager->getPost($postId);

if (!$post) {
    redirect('index.php?page=tgp');
}

// Increment view count
$tgpManager->incrementViews($postId);

// Check if user has liked
$hasLiked = false;
if ($auth->isLoggedIn()) {
    $hasLiked = $tgpManager->hasLiked($postId, $auth->getCurrentUser()['id']);
}

// Get images
$images = [];
foreach ($post['images'] as $imageId) {
    $image = $db->get('images', $imageId);
    if ($image) {
        $images[] = $image;
    }
}

// Check if current user is the author or admin
$canEdit = false;
if ($auth->isLoggedIn()) {
    $user = $auth->getCurrentUser();
    $canEdit = $post['author_id'] === $user['id'] || $user['role'] === 'admin';
}

require 'templates/header.php';
?>

<div class="tgp-view">
    <!-- Header -->
    <div class="tgp-header py-4" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white;">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mb-2" style="background: transparent;">
                            <li class="breadcrumb-item">
                                <a href="index.php?page=tgp" class="text-white">Collections</a>
                            </li>
                            <li class="breadcrumb-item active text-white" aria-current="page">
                                <?php echo escape($post['title']); ?>
                            </li>
                        </ol>
                    </nav>
                    <h1 class="display-5 mb-0"><?php echo escape($post['title']); ?></h1>
                </div>
                <div class="col-md-4 text-md-end mt-3 mt-md-0">
                    <?php if ($canEdit): ?>
                        <a href="index.php?page=tgp_edit&id=<?php echo $postId; ?>" class="btn btn-light me-2">
                            <i class="bi bi-pencil"></i> Edit
                        </a>
                    <?php endif; ?>
                    <a href="index.php?page=tgp" class="btn btn-outline-light">
                        <i class="bi bi-arrow-left"></i> Back
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="container my-5">
        <div class="row">
            <!-- Main Content -->
            <div class="col-lg-9">
                <!-- Collection Info -->
                <div class="card mb-4 shadow-sm">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start mb-3">
                            <div class="flex-grow-1">
                                <div class="d-flex align-items-center mb-2">
                                    <img src="<?php 
                                        $author = $db->search('users', 'id', $post['author_id'])[0] ?? null;
                                        if ($author && !empty($author['avatar'])) {
                                            echo 'uploads/avatars/' . escape($author['avatar']);
                                        } else {
                                            echo 'assets/images/default-avatar.png';
                                        }
                                    ?>" 
                                         alt="<?php echo escape($post['author']); ?>"
                                         class="rounded-circle me-2"
                                         style="width: 40px; height: 40px; object-fit: cover;">
                                    <div>
                                        <strong><?php echo escape($post['author']); ?></strong>
                                        <div class="text-muted small">
                                            <?php echo date('F j, Y', $post['created_at']); ?>
                                        </div>
                                    </div>
                                </div>
                                
                                <?php if (!empty($post['description'])): ?>
                                    <p class="mb-0"><?php echo nl2br(escape($post['description'])); ?></p>
                                <?php endif; ?>
                            </div>
                            
                            <div class="ms-3">
                                <span class="badge bg-primary"><?php echo ucfirst($post['category']); ?></span>
                                <?php if ($post['is_featured'] ?? false): ?>
                                    <span class="badge bg-warning">
                                        <i class="bi bi-star-fill"></i> Featured
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <!-- Tags -->
                        <?php if (!empty($post['tags'])): ?>
                            <div class="mb-3">
                                <i class="bi bi-tags me-2"></i>
                                <?php foreach ($post['tags'] as $tag): ?>
                                    <a href="index.php?page=tgp&tag=<?php echo urlencode($tag); ?>" class="badge bg-secondary me-1">
                                        <?php echo escape($tag); ?>
                                    </a>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                        
                        <!-- Stats and Actions -->
                        <div class="d-flex justify-content-between align-items-center border-top pt-3">
                            <div class="text-muted small">
                                <i class="bi bi-eye"></i> <?php echo number_format($post['views']); ?> views
                                <i class="bi bi-images ms-3"></i> <?php echo count($images); ?> images
                            </div>
                            
                            <div>
                                <?php if ($auth->isLoggedIn()): ?>
                                    <button class="btn btn-sm <?php echo $hasLiked ? 'btn-danger' : 'btn-outline-danger'; ?>" 
                                            onclick="toggleLike('<?php echo $postId; ?>')">
                                        <i class="bi bi-heart<?php echo $hasLiked ? '-fill' : ''; ?>"></i>
                                        <span id="likeCount"><?php echo number_format($post['likes'] ?? 0); ?></span>
                                    </button>
                                <?php else: ?>
                                    <span class="text-muted">
                                        <i class="bi bi-heart"></i> <?php echo number_format($post['likes'] ?? 0); ?>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Image Gallery -->
                <div class="card shadow-sm">
                    <div class="card-header bg-dark text-white">
                        <h5 class="mb-0">
                            <i class="bi bi-images"></i> Collection Images
                            <span class="badge bg-light text-dark"><?php echo count($images); ?></span>
                        </h5>
                    </div>
                    <div class="card-body p-0">
                        <?php if (empty($images)): ?>
                            <div class="text-center py-5">
                                <i class="bi bi-inbox text-muted" style="font-size: 3rem;"></i>
                                <p class="text-muted mt-3">No images in this collection</p>
                            </div>
                        <?php else: ?>
                            <div class="row g-0" id="imageGallery">
                                <?php foreach ($images as $index => $image): ?>
                                    <div class="col-lg-4 col-md-6 col-sm-6">
                                        <div class="gallery-image-item">
                                            <a href="index.php?page=image&id=<?php echo $image['id']; ?>" 
                                               data-lightbox="collection"
                                               data-title="<?php echo escape($image['title']); ?>">
                                                <img src="uploads/thumbs/<?php echo escape($image['filename']); ?>" 
                                                     alt="<?php echo escape($image['title']); ?>"
                                                     class="img-fluid">
                                                <div class="image-hover-overlay">
                                                    <div class="overlay-content">
                                                        <h6><?php echo escape($image['title'] ?? 'Untitled'); ?></h6>
                                                        <p class="small mb-0">
                                                            <i class="bi bi-eye"></i> <?php echo number_format($image['views'] ?? 0); ?>
                                                            <i class="bi bi-heart ms-2"></i> <?php echo number_format($image['favorites'] ?? 0); ?>
                                                        </p>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Sidebar -->
            <div class="col-lg-3">
                <!-- Author Info -->
                <div class="card mb-3 shadow-sm">
                    <div class="card-header bg-primary text-white">
                        <h6 class="mb-0"><i class="bi bi-person"></i> About Author</h6>
                    </div>
                    <div class="card-body text-center">
                        <img src="<?php 
                            if ($author && !empty($author['avatar'])) {
                                echo 'uploads/avatars/' . escape($author['avatar']);
                            } else {
                                echo 'assets/images/default-avatar.png';
                            }
                        ?>" 
                             alt="<?php echo escape($post['author']); ?>"
                             class="rounded-circle mb-2"
                             style="width: 80px; height: 80px; object-fit: cover;">
                        <h6><?php echo escape($post['author']); ?></h6>
                        <?php if ($author): ?>
                            <p class="text-muted small mb-2">
                                <?php echo escape($author['bio'] ?? 'No bio available'); ?>
                            </p>
                            <a href="index.php?page=user&id=<?php echo $post['author_id']; ?>" class="btn btn-sm btn-outline-primary w-100">
                                View Profile
                            </a>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- More from Author -->
                <div class="card mb-3 shadow-sm">
                    <div class="card-header bg-secondary text-white">
                        <h6 class="mb-0"><i class="bi bi-grid-3x3"></i> More Collections</h6>
                    </div>
                    <div class="list-group list-group-flush">
                        <?php
                        $authorPosts = $tgpManager->getPosts([
                            'author_id' => $post['author_id'],
                            'status' => 'published'
                        ]);
                        $otherPosts = array_filter($authorPosts, function($p) use ($postId) {
                            return $p['id'] !== $postId;
                        });
                        $otherPosts = array_slice($otherPosts, 0, 5);
                        ?>
                        
                        <?php if (empty($otherPosts)): ?>
                            <div class="list-group-item text-muted small">
                                No other collections
                            </div>
                        <?php else: ?>
                            <?php foreach ($otherPosts as $otherPost): ?>
                                <a href="index.php?page=tgp_view&id=<?php echo $otherPost['id']; ?>" 
                                   class="list-group-item list-group-item-action">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <span class="small"><?php echo escape($otherPost['title']); ?></span>
                                        <span class="badge bg-light text-dark">
                                            <?php echo count($otherPost['images']); ?>
                                        </span>
                                    </div>
                                </a>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Share -->
                <div class="card shadow-sm">
                    <div class="card-header bg-info text-white">
                        <h6 class="mb-0"><i class="bi bi-share"></i> Share</h6>
                    </div>
                    <div class="card-body">
                        <div class="d-grid gap-2">
                            <button class="btn btn-sm btn-outline-primary" onclick="copyLink()">
                                <i class="bi bi-link-45deg"></i> Copy Link
                            </button>
                            <a href="https://twitter.com/intent/tweet?text=<?php echo urlencode('Check out this collection: ' . $post['title']); ?>&url=<?php echo urlencode($_SERVER['REQUEST_URI']); ?>" 
                               target="_blank" class="btn btn-sm btn-outline-info">
                                <i class="bi bi-twitter"></i> Tweet
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.gallery-image-item {
    position: relative;
    overflow: hidden;
    background: #000;
}

.gallery-image-item img {
    display: block;
    width: 100%;
    height: 250px;
    object-fit: cover;
    transition: transform 0.3s ease, opacity 0.3s ease;
}

.gallery-image-item:hover img {
    transform: scale(1.1);
    opacity: 0.8;
}

.image-hover-overlay {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    background: linear-gradient(to top, rgba(0,0,0,0.9), transparent);
    padding: 15px;
    transform: translateY(100%);
    transition: transform 0.3s ease;
    color: white;
}

.gallery-image-item:hover .image-hover-overlay {
    transform: translateY(0);
}

.overlay-content h6 {
    color: white;
    margin-bottom: 5px;
    font-size: 0.9rem;
}
</style>

<script>
function toggleLike(postId) {
    fetch('index.php?page=api&action=tgp_like&post_id=' + postId, {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'}
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            const button = event.target.closest('button');
            const icon = button.querySelector('i');
            const count = document.getElementById('likeCount');
            
            if (data.liked) {
                button.classList.remove('btn-outline-danger');
                button.classList.add('btn-danger');
                icon.classList.remove('bi-heart');
                icon.classList.add('bi-heart-fill');
            } else {
                button.classList.remove('btn-danger');
                button.classList.add('btn-outline-danger');
                icon.classList.remove('bi-heart-fill');
                icon.classList.add('bi-heart');
            }
            
            count.textContent = data.likes;
        }
    })
    .catch(error => console.error('Error:', error));
}

function copyLink() {
    const url = window.location.href;
    navigator.clipboard.writeText(url).then(() => {
        alert('Link copied to clipboard!');
    });
}
</script>

<?php require 'templates/footer.php'; ?>
