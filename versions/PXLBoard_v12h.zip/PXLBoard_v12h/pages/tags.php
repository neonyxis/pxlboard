<?php
/**
 * Tags Page
 */

$allTags = $db->getAll('tags');

// Sort by count descending
usort($allTags, function($a, $b) {
    return $b['count'] - $a['count'];
});

require 'templates/header.php';
?>

<div class="container mt-4">
    <h2>All Tags</h2>
    
    <?php if (empty($allTags)): ?>
        <p class="text-muted">No tags yet</p>
    <?php else: ?>
        <div class="tag-cloud mt-4">
            <?php foreach ($allTags as $tag): ?>
                <a href="index.php?page=search&q=<?php echo urlencode($tag['name']); ?>" 
                   class="badge bg-primary me-2 mb-2" 
                   style="font-size: <?php echo min(2, 0.8 + ($tag['count'] / 10)); ?>rem;">
                    <?php echo escape($tag['name']); ?>
                    <span class="badge bg-secondary"><?php echo $tag['count']; ?></span>
                </a>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<?php require 'templates/footer.php'; ?>
