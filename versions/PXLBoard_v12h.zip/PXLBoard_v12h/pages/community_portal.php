<?php
/**
 * Community Portal - Central hub for all community activities
 * Integrates activity stream, wiki, blog, forums, boards, and gallery
 */

require_once 'includes/functions.php';

// Get recent activity from various sources
$recentImages = array_slice($db->getAll('images'), 0, 6);
$recentBlogPosts = array_slice($db->getAll('blog_posts'), 0, 5);
$recentWikiPages = array_slice($db->getAll('wiki_pages'), 0, 5);

// Get board threads sorted by last activity
$allBoardThreads = $db->getAll('board_threads') ?? [];
usort($allBoardThreads, function($a, $b) {
    $timeA = $a['last_post_time'] ?? $a['updated_at'] ?? $a['created_at'] ?? 0;
    $timeB = $b['last_post_time'] ?? $b['updated_at'] ?? $b['created_at'] ?? 0;
    return $timeB - $timeA;
});
$recentBoardThreads = array_slice($allBoardThreads, 0, 8);

$recentComments = array_slice($db->getAll('comments'), 0, 10);

// Combine and sort all activities
$activities = [];

foreach ($recentImages as $image) {
    $activities[] = [
        'type' => 'image',
        'timestamp' => $image['uploaded_at'] ?? 0,
        'title' => $image['title'] ?? 'Untitled',
        'user' => $image['uploader'] ?? 'Anonymous',
        'url' => 'index.php?page=image&id=' . $image['id'],
        'icon' => 'bi-image',
        'data' => $image
    ];
}

foreach ($recentBlogPosts as $post) {
    $activities[] = [
        'type' => 'blog',
        'timestamp' => $post['created_at'] ?? 0,
        'title' => $post['title'] ?? 'Untitled',
        'user' => $post['author'] ?? 'Anonymous',
        'url' => 'index.php?page=blogs&id=' . $post['id'],
        'icon' => 'bi-newspaper',
        'data' => $post
    ];
}

foreach ($recentWikiPages as $page) {
    $activities[] = [
        'type' => 'wiki',
        'timestamp' => $page['updated_at'] ?? $page['created_at'] ?? 0,
        'title' => $page['title'] ?? 'Untitled',
        'user' => $page['last_editor'] ?? $page['author'] ?? 'Anonymous',
        'url' => 'index.php?page=wiki&title=' . urlencode($page['title']),
        'icon' => 'bi-book',
        'data' => $page
    ];
}

foreach ($recentBoardThreads as $thread) {
    $timestamp = $thread['last_post_time'] ?? $thread['updated_at'] ?? $thread['created_at'] ?? 0;
    $activities[] = [
        'type' => 'thread',
        'timestamp' => $timestamp,
        'title' => $thread['subject'] ?? 'Untitled',
        'user' => $thread['author'] ?? 'Anonymous',
        'url' => 'index.php?page=board_thread&board=' . ($thread['board_id'] ?? '') . '&id=' . $thread['id'],
        'icon' => 'bi-chat-dots',
        'data' => $thread
    ];
}

// Sort by timestamp
usort($activities, function($a, $b) {
    return $b['timestamp'] - $a['timestamp'];
});

$activities = array_slice($activities, 0, 20);

// Get statistics
$stats = [
    'total_users' => $db->count('users'),
    'total_images' => $db->count('images'),
    'total_boards' => $db->count('boards'),
    'total_threads' => $db->count('board_threads'),
    'total_wiki_pages' => $db->count('wiki_pages'),
    'total_blog_posts' => $db->count('blog_posts')
];

require 'templates/header.php';
?>

<div class="container-fluid px-4 py-4">
    <!-- Portal Header -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="portal-header text-center py-5" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 15px; color: white;">
                <h1 class="display-3 fw-bold mb-3">
                    <i class="bi bi-compass"></i> Community Portal
                </h1>
                <p class="lead mb-0">Your central hub for all community activities and content</p>
            </div>
        </div>
    </div>

    <!-- Statistics Dashboard -->
    <div class="row mb-4 g-3">
        <div class="col-md-2 col-sm-4 col-6">
            <div class="stat-card text-center p-3 h-100 border rounded shadow-sm bg-light">
                <i class="bi bi-people-fill text-primary fs-1"></i>
                <div class="fs-3 fw-bold mt-2"><?php echo number_format($stats['total_users']); ?></div>
                <div class="text-muted small">Members</div>
            </div>
        </div>
        <div class="col-md-2 col-sm-4 col-6">
            <div class="stat-card text-center p-3 h-100 border rounded shadow-sm bg-light">
                <i class="bi bi-image-fill text-success fs-1"></i>
                <div class="fs-3 fw-bold mt-2"><?php echo number_format($stats['total_images']); ?></div>
                <div class="text-muted small">Images</div>
            </div>
        </div>
        <div class="col-md-2 col-sm-4 col-6">
            <div class="stat-card text-center p-3 h-100 border rounded shadow-sm bg-light">
                <i class="bi bi-grid-3x3 text-info fs-1"></i>
                <div class="fs-3 fw-bold mt-2"><?php echo number_format($stats['total_boards']); ?></div>
                <div class="text-muted small">Boards</div>
            </div>
        </div>
        <div class="col-md-2 col-sm-4 col-6">
            <div class="stat-card text-center p-3 h-100 border rounded shadow-sm bg-light">
                <i class="bi bi-chat-dots-fill text-warning fs-1"></i>
                <div class="fs-3 fw-bold mt-2"><?php echo number_format($stats['total_threads']); ?></div>
                <div class="text-muted small">Threads</div>
            </div>
        </div>
        <div class="col-md-2 col-sm-4 col-6">
            <div class="stat-card text-center p-3 h-100 border rounded shadow-sm bg-light">
                <i class="bi bi-book-fill text-danger fs-1"></i>
                <div class="fs-3 fw-bold mt-2"><?php echo number_format($stats['total_wiki_pages']); ?></div>
                <div class="text-muted small">Wiki Pages</div>
            </div>
        </div>
        <div class="col-md-2 col-sm-4 col-6">
            <div class="stat-card text-center p-3 h-100 border rounded shadow-sm bg-light">
                <i class="bi bi-newspaper text-secondary fs-1"></i>
                <div class="fs-3 fw-bold mt-2"><?php echo number_format($stats['total_blog_posts']); ?></div>
                <div class="text-muted small">Blog Posts</div>
            </div>
        </div>
    </div>

    <!-- Quick Navigation -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0"><i class="bi bi-signpost-split"></i> Quick Navigation</h5>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-4 col-sm-6">
                            <a href="index.php?page=gallery" class="nav-card d-block p-3 border rounded text-decoration-none hover-shadow">
                                <div class="d-flex align-items-center">
                                    <div class="icon-circle bg-success bg-opacity-10 p-3 rounded-circle me-3">
                                        <i class="bi bi-images text-success fs-3"></i>
                                    </div>
                                    <div>
                                        <h6 class="mb-1 fw-bold">Gallery</h6>
                                        <small class="text-muted">Browse image collection</small>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-4 col-sm-6">
                            <a href="index.php?page=boards" class="nav-card d-block p-3 border rounded text-decoration-none hover-shadow">
                                <div class="d-flex align-items-center">
                                    <div class="icon-circle bg-info bg-opacity-10 p-3 rounded-circle me-3">
                                        <i class="bi bi-collection text-info fs-3"></i>
                                    </div>
                                    <div>
                                        <h6 class="mb-1 fw-bold">Discussion Boards</h6>
                                        <small class="text-muted">Join conversations</small>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-4 col-sm-6">
                            <a href="index.php?page=forums" class="nav-card d-block p-3 border rounded text-decoration-none hover-shadow">
                                <div class="d-flex align-items-center">
                                    <div class="icon-circle bg-primary bg-opacity-10 p-3 rounded-circle me-3">
                                        <i class="bi bi-chat-square-text text-primary fs-3"></i>
                                    </div>
                                    <div>
                                        <h6 class="mb-1 fw-bold">Forums</h6>
                                        <small class="text-muted">Discuss topics</small>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-4 col-sm-6">
                            <a href="index.php?page=wiki" class="nav-card d-block p-3 border rounded text-decoration-none hover-shadow">
                                <div class="d-flex align-items-center">
                                    <div class="icon-circle bg-danger bg-opacity-10 p-3 rounded-circle me-3">
                                        <i class="bi bi-book text-danger fs-3"></i>
                                    </div>
                                    <div>
                                        <h6 class="mb-1 fw-bold">Community Wiki</h6>
                                        <small class="text-muted">Knowledge base</small>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-4 col-sm-6">
                            <a href="index.php?page=blogs" class="nav-card d-block p-3 border rounded text-decoration-none hover-shadow">
                                <div class="d-flex align-items-center">
                                    <div class="icon-circle bg-warning bg-opacity-10 p-3 rounded-circle me-3">
                                        <i class="bi bi-newspaper text-warning fs-3"></i>
                                    </div>
                                    <div>
                                        <h6 class="mb-1 fw-bold">Community Blogs</h6>
                                        <small class="text-muted">Read & write posts</small>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-4 col-sm-6">
                            <a href="index.php?page=rankings" class="nav-card d-block p-3 border rounded text-decoration-none hover-shadow">
                                <div class="d-flex align-items-center">
                                    <div class="icon-circle bg-secondary bg-opacity-10 p-3 rounded-circle me-3">
                                        <i class="bi bi-trophy text-secondary fs-3"></i>
                                    </div>
                                    <div>
                                        <h6 class="mb-1 fw-bold">Rankings</h6>
                                        <small class="text-muted">Top contributors</small>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Activity Stream -->
        <div class="col-lg-8 mb-4">
            <div class="card shadow-sm h-100">
                <div class="card-header bg-secondary text-white d-flex justify-content-between align-items-center">
                    <h5 class="mb-0"><i class="bi bi-activity"></i> Recent Activity</h5>
                    <div class="btn-group btn-group-sm" role="group">
                        <button type="button" class="btn btn-outline-light active" onclick="filterActivity('all')">All</button>
                        <button type="button" class="btn btn-outline-light" onclick="filterActivity('image')">Images</button>
                        <button type="button" class="btn btn-outline-light" onclick="filterActivity('blog')">Blogs</button>
                        <button type="button" class="btn btn-outline-light" onclick="filterActivity('thread')">Threads</button>
                    </div>
                </div>
                <div class="card-body activity-stream" style="max-height: 600px; overflow-y: auto;">
                    <?php if (empty($activities)): ?>
                        <div class="text-center py-5 text-muted">
                            <i class="bi bi-inbox fs-1"></i>
                            <p class="mt-3">No recent activity</p>
                        </div>
                    <?php else: ?>
                        <div class="list-group list-group-flush">
                            <?php foreach ($activities as $activity): ?>
                                <div class="list-group-item activity-item border-0 border-bottom" data-type="<?php echo $activity['type']; ?>">
                                    <div class="d-flex align-items-start">
                                        <div class="activity-icon me-3">
                                            <i class="<?php echo $activity['icon']; ?> fs-4 text-primary"></i>
                                        </div>
                                        <div class="flex-grow-1">
                                            <div class="d-flex justify-content-between">
                                                <h6 class="mb-1">
                                                    <a href="<?php echo $activity['url']; ?>" class="text-decoration-none">
                                                        <?php echo escape($activity['title']); ?>
                                                    </a>
                                                </h6>
                                                <small class="text-muted"><?php echo timeAgo($activity['timestamp']); ?></small>
                                            </div>
                                            <p class="mb-1 small text-muted">
                                                <i class="bi bi-person-circle"></i> <?php echo escape($activity['user']); ?>
                                                <span class="badge bg-light text-dark ms-2"><?php echo ucfirst($activity['type']); ?></span>
                                            </p>
                                            <?php if ($activity['type'] === 'image' && !empty($activity['data']['filename'])): ?>
                                                <div class="mt-2">
                                                    <img src="uploads/thumbs/<?php echo escape($activity['data']['filename']); ?>" 
                                                         alt="<?php echo escape($activity['title']); ?>"
                                                         class="img-thumbnail"
                                                         style="max-width: 120px; max-height: 80px; object-fit: cover;">
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Sidebar -->
        <div class="col-lg-4 mb-4">
            <!-- Featured Content -->
            <div class="card shadow-sm mb-3">
                <div class="card-header bg-info text-white">
                    <h6 class="mb-0"><i class="bi bi-star-fill"></i> Featured Images</h6>
                </div>
                <div class="card-body p-2">
                    <div class="row g-1">
                        <?php foreach (array_slice($recentImages, 0, 4) as $image): ?>
                            <div class="col-6">
                                <a href="index.php?page=image&id=<?php echo $image['id']; ?>" class="d-block">
                                    <img src="uploads/thumbs/<?php echo escape($image['filename']); ?>" 
                                         alt="<?php echo escape($image['title']); ?>"
                                         class="img-fluid rounded hover-shadow"
                                         style="height: 100px; width: 100%; object-fit: cover;">
                                </a>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <!-- Popular Boards -->
            <div class="card shadow-sm mb-3">
                <div class="card-header bg-success text-white">
                    <h6 class="mb-0"><i class="bi bi-fire"></i> Popular Boards</h6>
                </div>
                <div class="list-group list-group-flush">
                    <?php
                    $boards = $db->getAll('boards');
                    usort($boards, function($a, $b) {
                        return ($b['thread_count'] ?? 0) - ($a['thread_count'] ?? 0);
                    });
                    $popularBoards = array_slice($boards, 0, 5);
                    ?>
                    <?php if (empty($popularBoards)): ?>
                        <div class="list-group-item text-muted small">No boards yet</div>
                    <?php else: ?>
                        <?php foreach ($popularBoards as $board): ?>
                            <a href="index.php?page=board&id=<?php echo $board['id']; ?>" 
                               class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                                <span><?php echo escape($board['name'] ?? 'Untitled'); ?></span>
                                <span class="badge bg-primary rounded-pill"><?php echo $board['thread_count'] ?? 0; ?></span>
                            </a>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Recent Wiki Pages -->
            <div class="card shadow-sm mb-3">
                <div class="card-header bg-warning text-dark">
                    <h6 class="mb-0"><i class="bi bi-journal-text"></i> Recent Wiki Updates</h6>
                </div>
                <div class="list-group list-group-flush">
                    <?php if (empty($recentWikiPages)): ?>
                        <div class="list-group-item text-muted small">No wiki pages yet</div>
                    <?php else: ?>
                        <?php foreach (array_slice($recentWikiPages, 0, 5) as $wikiPage): ?>
                            <a href="index.php?page=wiki&title=<?php echo urlencode($wikiPage['title']); ?>" 
                               class="list-group-item list-group-item-action">
                                <div class="d-flex justify-content-between">
                                    <span class="small"><?php echo escape($wikiPage['title']); ?></span>
                                    <small class="text-muted"><?php echo timeAgo($wikiPage['updated_at'] ?? 0); ?></small>
                                </div>
                            </a>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Online Users (if you implement this feature) -->
            <div class="card shadow-sm">
                <div class="card-header bg-dark text-white">
                    <h6 class="mb-0"><i class="bi bi-person-check"></i> Community Status</h6>
                </div>
                <div class="card-body">
                    <div class="d-flex justify-content-between mb-2">
                        <span class="small">Total Members:</span>
                        <strong><?php echo number_format($stats['total_users']); ?></strong>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span class="small">Active Today:</span>
                        <strong class="text-success">
                            <i class="bi bi-circle-fill" style="font-size: 8px;"></i>
                            <?php echo rand(10, 50); ?>
                        </strong>
                    </div>
                    <div class="d-flex justify-content-between">
                        <span class="small">Newest Member:</span>
                        <strong>
                            <?php
                            $allUsers = $db->getAll('users');
                            if (!empty($allUsers)) {
                                usort($allUsers, function($a, $b) {
                                    return ($b['created_at'] ?? 0) - ($a['created_at'] ?? 0);
                                });
                                echo escape($allUsers[0]['username'] ?? 'N/A');
                            } else {
                                echo 'N/A';
                            }
                            ?>
                        </strong>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.hover-shadow {
    transition: all 0.3s ease;
}

.hover-shadow:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.15) !important;
}

.nav-card {
    transition: all 0.3s ease;
}

.nav-card:hover {
    background-color: #f8f9fa;
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}

.activity-stream {
    scrollbar-width: thin;
}

.activity-stream::-webkit-scrollbar {
    width: 8px;
}

.activity-stream::-webkit-scrollbar-thumb {
    background: #888;
    border-radius: 4px;
}

.activity-item {
    transition: background-color 0.2s ease;
}

.activity-item:hover {
    background-color: #f8f9fa;
}

.icon-circle {
    display: inline-flex;
    align-items: center;
    justify-content: center;
}

.stat-card {
    transition: all 0.3s ease;
}

.stat-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 6px 20px rgba(0,0,0,0.15) !important;
}
</style>

<script>
function filterActivity(type) {
    const items = document.querySelectorAll('.activity-item');
    const buttons = document.querySelectorAll('.btn-group button');
    
    buttons.forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
    
    items.forEach(item => {
        if (type === 'all' || item.dataset.type === type) {
            item.style.display = '';
        } else {
            item.style.display = 'none';
        }
    });
}
</script>

<?php require 'templates/footer.php'; ?>
