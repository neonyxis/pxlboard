<?php
/**
 * Public User Profile Page
 */

// Support both /user/username (from SEO URLs) and ?page=user&id=user_123
$username = $_GET['username'] ?? '';
$userId = $_GET['id'] ?? '';

// If username provided, find the user by username
if (!empty($username)) {
    $allUsers = $db->getAll('users');
    $user = null;
    foreach ($allUsers as $u) {
        if ($u['username'] === $username) {
            $user = $u;
            $userId = $u['id'];
            break;
        }
    }
} else if (!empty($userId)) {
    // Direct ID lookup
    $user = $db->get('users', $userId);
} else {
    $user = null;
}

if (!$user) {
    require 'pages/404.php';
    exit;
}

// Get user's images
$allImages = $db->getAll('images');
$userImages = array_filter($allImages, function($img) use ($userId) {
    return $img['uploader_id'] === $userId;
});

// Get user's favorites
$allFavorites = $db->getAll('favorites');
$userFavorites = array_filter($allFavorites, function($fav) use ($userId) {
    return $fav['user_id'] === $userId;
});

$favoriteImageIds = array_column($userFavorites, 'image_id');
$favoriteImages = array_filter($allImages, function($img) use ($favoriteImageIds) {
    return in_array($img['id'], $favoriteImageIds);
});

// Get statistics
$totalUploads = count($userImages);
$totalViews = array_sum(array_column($userImages, 'views'));
$totalFavorites = array_sum(array_column($userImages, 'favorites'));

$tab = $_GET['tab'] ?? 'uploads';

require 'templates/header.php';
?>

<div class="container mt-4">
    <div class="card mb-4">
        <div class="card-body">
            <div class="row">
                <div class="col-md-2 text-center">
                    <div class="avatar-placeholder bg-primary text-white rounded-circle d-inline-flex align-items-center justify-content-center" 
                         style="width: 100px; height: 100px; font-size: 3rem;">
                        <?php echo strtoupper(substr($user['username'], 0, 1)); ?>
                    </div>
                </div>
                <div class="col-md-10">
                    <h2>
                        <?php echo escape($user['username']); ?>
                        <?php if ($user['role'] === 'admin'): ?>
                            <span class="badge bg-danger">Admin</span>
                        <?php endif; ?>
                    </h2>
                    <p class="text-muted mb-2">
                        Member since <?php echo date('F j, Y', $user['created_at']); ?>
                    </p>
                    
                    <div class="row mt-3">
                        <div class="col-md-3">
                            <strong><?php echo number_format($totalUploads); ?></strong>
                            <div class="text-muted small">Uploads</div>
                        </div>
                        <div class="col-md-3">
                            <strong><?php echo number_format($totalViews); ?></strong>
                            <div class="text-muted small">Total Views</div>
                        </div>
                        <div class="col-md-3">
                            <strong><?php echo number_format($totalFavorites); ?></strong>
                            <div class="text-muted small">Favorites Received</div>
                        </div>
                        <div class="col-md-3">
                            <strong><?php echo number_format(count($favoriteImages)); ?></strong>
                            <div class="text-muted small">Images Favorited</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <ul class="nav nav-tabs mb-4">
        <li class="nav-item">
            <a class="nav-link <?php echo $tab === 'uploads' ? 'active' : ''; ?>" 
               href="<?php echo buildUrl('user', $user['username']); ?>?tab=uploads">
                Uploads (<?php echo count($userImages); ?>)
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo $tab === 'favorites' ? 'active' : ''; ?>" 
               href="<?php echo buildUrl('user', $user['username']); ?>?tab=favorites">
                Favorites (<?php echo count($favoriteImages); ?>)
            </a>
        </li>
    </ul>
    
    <div class="tab-content">
        <?php if ($tab === 'uploads'): ?>
            <div class="row">
                <?php if (empty($userImages)): ?>
                    <div class="col-12 text-center py-5">
                        <h3>No uploads yet</h3>
                    </div>
                <?php else: ?>
                    <?php foreach ($userImages as $image): ?>
                        <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                            <div class="card image-card">
                                <a href="index.php?page=image&id=<?php echo escape($image['id']); ?>">
                                    <img src="uploads/thumbs/<?php echo escape($image['filename']); ?>" 
                                         class="card-img-top" 
                                         alt="<?php echo escape($image['title']); ?>">
                                </a>
                                <div class="card-body">
                                    <h6 class="card-title"><?php echo escape($image['title']); ?></h6>
                                    <p class="card-text small text-muted">
                                        <?php echo timeAgo($image['uploaded_at']); ?> • 
                                        <?php echo number_format($image['views']); ?> views
                                    </p>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        <?php elseif ($tab === 'favorites'): ?>
            <div class="row">
                <?php if (empty($favoriteImages)): ?>
                    <div class="col-12 text-center py-5">
                        <h3>No favorites yet</h3>
                    </div>
                <?php else: ?>
                    <?php foreach ($favoriteImages as $image): ?>
                        <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                            <div class="card image-card">
                                <a href="index.php?page=image&id=<?php echo escape($image['id']); ?>">
                                    <img src="uploads/thumbs/<?php echo escape($image['filename']); ?>" 
                                         class="card-img-top" 
                                         alt="<?php echo escape($image['title']); ?>">
                                </a>
                                <div class="card-body">
                                    <h6 class="card-title"><?php echo escape($image['title']); ?></h6>
                                    <p class="card-text small text-muted">
                                        by <?php echo escape($image['uploader']); ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require 'templates/footer.php'; ?>
