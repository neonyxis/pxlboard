<?php
/**
 * Profile Settings Page
 */

if (!$auth->isLoggedIn()) {
    redirect('index.php?page=login');
}

require_once 'includes/avatar.php';

$message = '';
$error = '';
$avatarManager = new AvatarManager($db);

// Handle avatar upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['upload_avatar'])) {
    if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
        $result = $avatarManager->uploadAvatar($_FILES['avatar'], $_SESSION['user_id']);
        
        if ($result['success']) {
            $message = 'Avatar uploaded successfully!';
        } else {
            $error = $result['error'];
        }
    } else {
        $error = 'No file uploaded or upload error occurred';
    }
}

// Handle avatar deletion
if (isset($_GET['action']) && $_GET['action'] === 'delete_avatar') {
    if ($avatarManager->deleteAvatar($_SESSION['user_id'])) {
        $message = 'Avatar deleted successfully';
    } else {
        $error = 'Failed to delete avatar';
    }
    redirect('index.php?page=profile_settings');
}

// Get user data
$user = $db->get('users', $_SESSION['user_id']);

require 'templates/header.php';
?>

<div class="container mt-4">
    <div class="row">
        <div class="col-md-3">
            <div class="list-group">
                <a href="index.php?page=profile_settings" class="list-group-item list-group-item-action active">
                    <i class="bi bi-person-circle"></i> Profile Settings
                </a>
                <a href="index.php?page=manage_hides" class="list-group-item list-group-item-action">
                    <i class="bi bi-eye-slash"></i> Hidden Images
                </a>
                <a href="index.php?page=profile&user=<?php echo htmlspecialchars($_SESSION['username']); ?>" 
                   class="list-group-item list-group-item-action">
                    <i class="bi bi-person"></i> View Profile
                </a>
            </div>
        </div>
        
        <div class="col-md-9">
            <div class="card">
                <div class="card-header">
                    <h4><i class="bi bi-person-circle"></i> Profile Settings</h4>
                </div>
                <div class="card-body">
                    <?php if ($message): ?>
                        <div class="alert alert-success alert-dismissible fade show">
                            <i class="bi bi-check-circle"></i> <?php echo htmlspecialchars($message); ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($error): ?>
                        <div class="alert alert-danger alert-dismissible fade show">
                            <i class="bi bi-exclamation-triangle"></i> <?php echo htmlspecialchars($error); ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>
                    
                    <!-- Avatar Section -->
                    <div class="mb-4">
                        <h5>Profile Picture</h5>
                        <div class="row">
                            <div class="col-md-4 text-center">
                                <div class="mb-3">
                                    <?php echo $avatarManager->getAvatarHtml($_SESSION['user_id'], 'large'); ?>
                                </div>
                                
                                <?php if (isset($user['avatar'])): ?>
                                    <a href="index.php?page=profile_settings&action=delete_avatar" 
                                       class="btn btn-sm btn-danger"
                                       onclick="return confirm('Delete your avatar?')">
                                        <i class="bi bi-trash"></i> Delete Avatar
                                    </a>
                                <?php endif; ?>
                            </div>
                            
                            <div class="col-md-8">
                                <form method="POST" enctype="multipart/form-data">
                                    <div class="mb-3">
                                        <label class="form-label">Upload New Avatar</label>
                                        <input type="file" name="avatar" class="form-control" 
                                               accept="image/jpeg,image/jpg,image/png,image/gif,image/webp" required>
                                        <small class="text-muted">
                                            Max size: 2MB | Formats: JPG, PNG, GIF, WebP
                                        </small>
                                    </div>
                                    
                                    <button type="submit" name="upload_avatar" class="btn btn-primary">
                                        <i class="bi bi-upload"></i> Upload Avatar
                                    </button>
                                </form>
                                
                                <div class="alert alert-info mt-3 mb-0">
                                    <small>
                                        <strong>Tips:</strong>
                                        <ul class="mb-0 mt-1">
                                            <li>Square images work best</li>
                                            <li>Images will be automatically cropped and resized</li>
                                            <li>Use a clear, recognizable image</li>
                                        </ul>
                                    </small>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <hr>
                    
                    <!-- Account Info Section -->
                    <div class="mb-4">
                        <h5>Account Information</h5>
                        <div class="row">
                            <div class="col-md-6">
                                <p><strong>Username:</strong> <?php echo htmlspecialchars($user['username']); ?></p>
                            </div>
                            <div class="col-md-6">
                                <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
                            </div>
                            <div class="col-md-6">
                                <p><strong>Member Since:</strong> <?php echo date('Y-m-d', $user['created_at']); ?></p>
                            </div>
                            <div class="col-md-6">
                                <p><strong>Role:</strong> <?php echo htmlspecialchars($user['role'] ?? 'user'); ?></p>
                            </div>
                        </div>
                    </div>
                    
                    <hr>
                    
                    <!-- Statistics Section -->
                    <div class="mb-4">
                        <h5>Your Statistics</h5>
                        <?php
                        $allImages = $db->getAll('images');
                        $userImages = array_filter($allImages, function($img) {
                            return $img['uploader_id'] === $_SESSION['user_id'];
                        });
                        
                        $allComments = $db->getAll('comments');
                        $userComments = array_filter($allComments, function($c) {
                            return $c['user_id'] === $_SESSION['user_id'];
                        });
                        ?>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="card text-center">
                                    <div class="card-body">
                                        <h3 class="text-primary"><?php echo count($userImages); ?></h3>
                                        <p class="mb-0">Images Uploaded</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card text-center">
                                    <div class="card-body">
                                        <h3 class="text-success"><?php echo count($userComments); ?></h3>
                                        <p class="mb-0">Comments Posted</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card text-center">
                                    <div class="card-body">
                                        <?php
                                        $totalViews = array_sum(array_column($userImages, 'views'));
                                        ?>
                                        <h3 class="text-info"><?php echo number_format($totalViews); ?></h3>
                                        <p class="mb-0">Total Views</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require 'templates/footer.php'; ?>
