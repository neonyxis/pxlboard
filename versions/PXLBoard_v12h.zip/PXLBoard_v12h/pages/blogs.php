<?php
/**
 * User Blogs
 * Browse and read blog posts
 */

$action = $_GET['action'] ?? 'browse';
$postId = $_GET['id'] ?? '';
$username = $_GET['user'] ?? '';

if ($action === 'view' && !empty($postId)) {
    // View specific blog post
    $post = $db->get('blog_posts', $postId);
    
    if (!$post) {
        require 'pages/404.php';
        exit;
    }
    
    // Increment view count
    $post['views'] = ($post['views'] ?? 0) + 1;
    $db->save('blog_posts', $postId, $post);
    
    // Get author info
    $author = $db->get('users', $post['author_id']);
    
    // Get comments
    $allComments = $db->getAll('blog_comments');
    $comments = array_filter($allComments, function($c) use ($postId) {
        return $c['post_id'] === $postId;
    });
    usort($comments, function($a, $b) {
        return $b['created_at'] - $a['created_at'];
    });
    
    // Handle new comment
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_comment']) && $auth->isLoggedIn()) {
        $commentContent = trim($_POST['comment'] ?? '');
        if (!empty($commentContent)) {
            $commentId = $db->getNextId('blog_comments');
            $commentData = [
                'post_id' => $postId,
                'user_id' => $_SESSION['user_id'],
                'username' => $_SESSION['username'],
                'content' => $commentContent,
                'created_at' => time()
            ];
            $db->save('blog_comments', $commentId, $commentData);
            
            $post['comment_count'] = ($post['comment_count'] ?? 0) + 1;
            $db->save('blog_posts', $postId, $post);
            
            redirect('index.php?page=blogs&action=view&id=' . $postId . '#comments');
        }
    }
    
    require 'templates/header.php';
    ?>
    
    <div class="container mt-4">
        <div class="row">
            <div class="col-lg-8 offset-lg-2">
                <article class="card mb-4">
                    <div class="card-body">
                        <div class="mb-3">
                            <a href="index.php?page=blogs&user=<?php echo urlencode($post['author_username']); ?>" 
                               class="text-decoration-none">
                                <small class="text-muted">
                                    <?php echo escape($post['author_username']); ?>'s Blog
                                </small>
                            </a>
                        </div>
                        
                        <h1 class="mb-3"><?php echo escape($post['title']); ?></h1>
                        
                        <div class="d-flex align-items-center mb-4 text-muted small">
                            <span class="me-3">
                                <i class="bi bi-calendar"></i> 
                                <?php echo date('F j, Y', $post['created_at']); ?>
                            </span>
                            <span class="me-3">
                                <i class="bi bi-eye"></i> 
                                <?php echo number_format($post['views'] ?? 0); ?> views
                            </span>
                            <span class="me-3">
                                <i class="bi bi-chat"></i> 
                                <?php echo number_format($post['comment_count'] ?? 0); ?> comments
                            </span>
                            <?php if (!empty($post['category'])): ?>
                            <span class="badge bg-primary"><?php echo escape($post['category']); ?></span>
                            <?php endif; ?>
                        </div>
                        
                        <?php if ($auth->isLoggedIn() && $_SESSION['user_id'] === $post['author_id']): ?>
                        <div class="mb-3">
                            <a href="index.php?page=blog_edit&id=<?php echo $postId; ?>" 
                               class="btn btn-sm btn-outline-primary">
                                <i class="bi bi-pencil"></i> Edit Post
                            </a>
                        </div>
                        <?php endif; ?>
                        
                        <div class="blog-content">
                            <?php echo nl2br(escape($post['content'])); ?>
                        </div>
                        
                        <?php if (!empty($post['tags'])): ?>
                        <hr>
                        <div class="mb-0">
                            <strong class="me-2">Tags:</strong>
                            <?php foreach ($post['tags'] as $tag): ?>
                                <a href="index.php?page=blogs&tag=<?php echo urlencode($tag); ?>" 
                                   class="badge bg-secondary text-decoration-none me-1">
                                    <?php echo escape($tag); ?>
                                </a>
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </article>
                
                <!-- Comments Section -->
                <div class="card" id="comments">
                    <div class="card-header">
                        <strong><i class="bi bi-chat"></i> Comments (<?php echo count($comments); ?>)</strong>
                    </div>
                    <div class="card-body">
                        <?php if ($auth->isLoggedIn()): ?>
                        <form method="POST" class="mb-4">
                            <div class="mb-3">
                                <label class="form-label"><strong>Add a comment</strong></label>
                                <textarea name="comment" class="form-control" rows="3" 
                                          placeholder="Share your thoughts..." required></textarea>
                            </div>
                            <button type="submit" name="add_comment" class="btn btn-primary">
                                <i class="bi bi-send"></i> Post Comment
                            </button>
                        </form>
                        <?php else: ?>
                        <p class="text-muted">
                            <a href="index.php?page=login">Log in</a> to leave a comment.
                        </p>
                        <?php endif; ?>
                        
                        <?php if (empty($comments)): ?>
                            <p class="text-muted text-center py-4">No comments yet. Be the first to comment!</p>
                        <?php else: ?>
                            <?php foreach ($comments as $comment): ?>
                            <div class="border-bottom pb-3 mb-3">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div>
                                        <strong><?php echo escape($comment['username']); ?></strong>
                                        <small class="text-muted ms-2">
                                            <?php echo timeAgo($comment['created_at']); ?>
                                        </small>
                                    </div>
                                </div>
                                <p class="mt-2 mb-0"><?php echo nl2br(escape($comment['content'])); ?></p>
                            </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php
    require 'templates/footer.php';
    exit;
}

// Browse blogs
$allPosts = $db->getAll('blog_posts');

// Filter by user if specified
if (!empty($username)) {
    $allPosts = array_filter($allPosts, function($post) use ($username) {
        return strtolower($post['author_username'] ?? '') === strtolower($username);
    });
}

// Filter by tag if specified
if (!empty($_GET['tag'])) {
    $filterTag = $_GET['tag'];
    $allPosts = array_filter($allPosts, function($post) use ($filterTag) {
        return in_array($filterTag, $post['tags'] ?? []);
    });
}

// Filter by category if specified
if (!empty($_GET['category'])) {
    $filterCategory = $_GET['category'];
    $allPosts = array_filter($allPosts, function($post) use ($filterCategory) {
        return ($post['category'] ?? '') === $filterCategory;
    });
}

// Filter published only (hide drafts from other users)
$allPosts = array_filter($allPosts, function($post) use ($auth) {
    if ($post['status'] === 'published') {
        return true;
    }
    if ($auth->isLoggedIn() && $post['author_id'] === $_SESSION['user_id']) {
        return true;
    }
    return false;
});

// Sort by date
usort($allPosts, function($a, $b) {
    return $b['created_at'] - $a['created_at'];
});

require 'templates/header.php';
?>

<div class="container mt-4">
    <div class="row mb-4">
        <div class="col-md-8">
            <h1><i class="bi bi-journal-text"></i> 
                <?php if (!empty($username)): ?>
                    <?php echo escape($username); ?>'s Blog
                <?php else: ?>
                    Blogs
                <?php endif; ?>
            </h1>
            <p class="text-muted">
                <?php if (!empty($username)): ?>
                    Personal blog posts
                <?php else: ?>
                    Community blog posts and articles
                <?php endif; ?>
            </p>
        </div>
        <div class="col-md-4 text-end">
            <?php if ($auth->isLoggedIn()): ?>
                <a href="index.php?page=blog_edit" class="btn btn-primary">
                    <i class="bi bi-plus-circle"></i> New Post
                </a>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="row">
        <div class="col-lg-8">
            <?php if (empty($allPosts)): ?>
                <div class="alert alert-info text-center py-5">
                    <h4>No blog posts yet</h4>
                    <?php if ($auth->isLoggedIn()): ?>
                        <p>Start sharing your thoughts by creating your first blog post!</p>
                        <a href="index.php?page=blog_edit" class="btn btn-primary">Create First Post</a>
                    <?php else: ?>
                        <p>Check back later for community blog posts.</p>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <?php foreach ($allPosts as $post): ?>
                <article class="card mb-4">
                    <div class="card-body">
                        <div class="mb-2">
                            <a href="index.php?page=blogs&user=<?php echo urlencode($post['author_username']); ?>" 
                               class="text-decoration-none">
                                <small class="text-muted">
                                    <?php echo escape($post['author_username']); ?>
                                </small>
                            </a>
                            <?php if ($post['status'] === 'draft'): ?>
                                <span class="badge bg-warning text-dark">Draft</span>
                            <?php endif; ?>
                        </div>
                        
                        <h3 class="card-title">
                            <a href="index.php?page=blogs&action=view&id=<?php echo $post['id']; ?>" 
                               class="text-decoration-none">
                                <?php echo escape($post['title']); ?>
                            </a>
                        </h3>
                        
                        <p class="card-text text-muted">
                            <?php echo escape(mb_substr($post['excerpt'] ?? $post['content'], 0, 200)); ?>...
                        </p>
                        
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="small text-muted">
                                <span class="me-3">
                                    <i class="bi bi-calendar"></i> 
                                    <?php echo date('M j, Y', $post['created_at']); ?>
                                </span>
                                <span class="me-3">
                                    <i class="bi bi-eye"></i> 
                                    <?php echo number_format($post['views'] ?? 0); ?>
                                </span>
                                <span>
                                    <i class="bi bi-chat"></i> 
                                    <?php echo number_format($post['comment_count'] ?? 0); ?>
                                </span>
                            </div>
                            <a href="index.php?page=blogs&action=view&id=<?php echo $post['id']; ?>" 
                               class="btn btn-sm btn-outline-primary">
                                Read More <i class="bi bi-arrow-right"></i>
                            </a>
                        </div>
                    </div>
                </article>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        
        <div class="col-lg-4">
            <!-- Categories -->
            <div class="card mb-3">
                <div class="card-header">
                    <strong>Categories</strong>
                </div>
                <div class="list-group list-group-flush">
                    <a href="index.php?page=blogs" 
                       class="list-group-item list-group-item-action">
                        All Posts
                    </a>
                    <?php
                    $categories = [];
                    foreach ($db->getAll('blog_posts') as $p) {
                        if (!empty($p['category']) && $p['status'] === 'published') {
                            $categories[$p['category']] = ($categories[$p['category']] ?? 0) + 1;
                        }
                    }
                    arsort($categories);
                    foreach ($categories as $cat => $count):
                    ?>
                    <a href="index.php?page=blogs&category=<?php echo urlencode($cat); ?>" 
                       class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                        <?php echo escape($cat); ?>
                        <span class="badge bg-primary"><?php echo $count; ?></span>
                    </a>
                    <?php endforeach; ?>
                </div>
            </div>
            
            <!-- Popular Tags -->
            <div class="card mb-3">
                <div class="card-header">
                    <strong>Popular Tags</strong>
                </div>
                <div class="card-body">
                    <?php
                    $tags = [];
                    foreach ($db->getAll('blog_posts') as $p) {
                        if ($p['status'] === 'published') {
                            foreach ($p['tags'] ?? [] as $tag) {
                                $tags[$tag] = ($tags[$tag] ?? 0) + 1;
                            }
                        }
                    }
                    arsort($tags);
                    $topTags = array_slice($tags, 0, 20);
                    
                    if (empty($topTags)):
                    ?>
                        <p class="text-muted small mb-0">No tags yet</p>
                    <?php else: ?>
                        <?php foreach ($topTags as $tag => $count): ?>
                            <a href="index.php?page=blogs&tag=<?php echo urlencode($tag); ?>" 
                               class="badge bg-secondary text-decoration-none me-1 mb-1">
                                <?php echo escape($tag); ?> (<?php echo $count; ?>)
                            </a>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Recent Posts -->
            <div class="card">
                <div class="card-header">
                    <strong>Recent Posts</strong>
                </div>
                <div class="list-group list-group-flush">
                    <?php
                    $recentPosts = array_filter($db->getAll('blog_posts'), function($p) {
                        return $p['status'] === 'published';
                    });
                    usort($recentPosts, function($a, $b) {
                        return $b['created_at'] - $a['created_at'];
                    });
                    $recentPosts = array_slice($recentPosts, 0, 5);
                    
                    if (empty($recentPosts)):
                    ?>
                        <div class="list-group-item text-muted small">No posts yet</div>
                    <?php else: ?>
                        <?php foreach ($recentPosts as $rp): ?>
                        <a href="index.php?page=blogs&action=view&id=<?php echo $rp['id']; ?>" 
                           class="list-group-item list-group-item-action">
                            <div class="small">
                                <strong><?php echo escape(mb_substr($rp['title'], 0, 40)); ?></strong><br>
                                <span class="text-muted">
                                    by <?php echo escape($rp['author_username']); ?> • 
                                    <?php echo timeAgo($rp['created_at']); ?>
                                </span>
                            </div>
                        </a>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require 'templates/footer.php'; ?>
