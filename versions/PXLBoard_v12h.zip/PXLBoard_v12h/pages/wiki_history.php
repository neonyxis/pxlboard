<?php
/**
 * Wiki History Page
 * View revision history for wiki pages
 */

$pageSlug = $_GET['slug'] ?? '';

if (empty($pageSlug)) {
    redirect('index.php?page=wiki');
}

// Get wiki page
$wikiPages = $db->getAll('wiki');
$page = null;

foreach ($wikiPages as $id => $wp) {
    if (($wp['slug'] ?? $id) === $pageSlug) {
        $page = $wp;
        $page['id'] = $id;
        break;
    }
}

if (!$page) {
    redirect('index.php?page=wiki');
}

require 'templates/header.php';
?>

<div class="container mt-4">
    <div class="row">
        <div class="col-lg-9">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php?page=wiki">Wiki</a></li>
                    <li class="breadcrumb-item">
                        <a href="index.php?page=wiki&action=view&slug=<?php echo urlencode($pageSlug); ?>">
                            <?php echo escape($page['title'] ?? 'Untitled'); ?>
                        </a>
                    </li>
                    <li class="breadcrumb-item active">History</li>
                </ol>
            </nav>
            
            <div class="card">
                <div class="card-header">
                    <h2 class="mb-0">
                        <i class="bi bi-clock-history"></i> Revision History
                    </h2>
                    <div class="text-muted">
                        <?php echo escape($page['title'] ?? 'Untitled'); ?>
                    </div>
                </div>
                <div class="card-body">
                    <?php
                    $revisions = $page['revisions'] ?? [];
                    
                    if (empty($revisions)):
                    ?>
                        <div class="alert alert-info">
                            <p class="mb-0">This page has no revision history yet. The current version is the original.</p>
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Version</th>
                                        <th>Date & Time</th>
                                        <th>Author</th>
                                        <th>Summary</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <!-- Current Version -->
                                    <tr class="table-success">
                                        <td>
                                            <strong>Current</strong>
                                            <span class="badge bg-success ms-2">Latest</span>
                                        </td>
                                        <td>
                                            <?php 
                                            $timestamp = $page['last_modified'] ?? $page['created_at'] ?? time();
                                            echo date('M j, Y g:i A', $timestamp);
                                            ?>
                                        </td>
                                        <td>
                                            <?php 
                                            $author = $page['last_modified_by'] ?? $page['author'] ?? 'Unknown';
                                            echo escape($author);
                                            ?>
                                        </td>
                                        <td>
                                            <em>Current version</em>
                                        </td>
                                        <td>
                                            <a href="index.php?page=wiki&action=view&slug=<?php echo urlencode($pageSlug); ?>" 
                                               class="btn btn-sm btn-primary">
                                                <i class="bi bi-eye"></i> View
                                            </a>
                                        </td>
                                    </tr>
                                    
                                    <!-- Previous Revisions -->
                                    <?php 
                                    // Sort revisions by timestamp (newest first)
                                    $sortedRevisions = $revisions;
                                    usort($sortedRevisions, function($a, $b) {
                                        return ($b['timestamp'] ?? 0) - ($a['timestamp'] ?? 0);
                                    });
                                    
                                    foreach ($sortedRevisions as $index => $revision): 
                                        $revisionNumber = count($revisions) - $index;
                                    ?>
                                        <tr>
                                            <td>
                                                <strong>#<?php echo $revisionNumber; ?></strong>
                                            </td>
                                            <td>
                                                <?php echo date('M j, Y g:i A', $revision['timestamp'] ?? time()); ?>
                                                <small class="text-muted d-block">
                                                    (<?php echo timeAgo($revision['timestamp'] ?? time()); ?>)
                                                </small>
                                            </td>
                                            <td>
                                                <?php echo escape($revision['author'] ?? 'Unknown'); ?>
                                            </td>
                                            <td>
                                                <?php 
                                                if (!empty($revision['summary'])) {
                                                    echo escape($revision['summary']);
                                                } else {
                                                    echo '<em class="text-muted">No summary provided</em>';
                                                }
                                                ?>
                                            </td>
                                            <td>
                                                <div class="btn-group btn-group-sm">
                                                    <button type="button" 
                                                            class="btn btn-outline-secondary" 
                                                            data-bs-toggle="modal" 
                                                            data-bs-target="#viewModal<?php echo $index; ?>">
                                                        <i class="bi bi-eye"></i> View
                                                    </button>
                                                    <?php if ($auth->isAdmin()): ?>
                                                        <a href="index.php?page=wiki_edit&slug=<?php echo urlencode($pageSlug); ?>&revert=<?php echo $index; ?>" 
                                                           class="btn btn-outline-warning"
                                                           onclick="return confirm('Revert to this version? This will create a new revision.')">
                                                            <i class="bi bi-arrow-counterclockwise"></i> Revert
                                                        </a>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                        </tr>
                                        
                                        <!-- View Content Modal -->
                                        <div class="modal fade" id="viewModal<?php echo $index; ?>" tabindex="-1">
                                            <div class="modal-dialog modal-lg">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">
                                                            Revision #<?php echo $revisionNumber; ?> - 
                                                            <?php echo date('M j, Y g:i A', $revision['timestamp'] ?? time()); ?>
                                                        </h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="mb-3">
                                                            <strong>Author:</strong> <?php echo escape($revision['author'] ?? 'Unknown'); ?>
                                                        </div>
                                                        <?php if (!empty($revision['summary'])): ?>
                                                            <div class="mb-3">
                                                                <strong>Summary:</strong> <?php echo escape($revision['summary']); ?>
                                                            </div>
                                                        <?php endif; ?>
                                                        <hr>
                                                        <div class="wiki-content">
                                                            <?php echo nl2br(escape($revision['content'] ?? '')); ?>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                        <?php if ($auth->isAdmin()): ?>
                                                            <a href="index.php?page=wiki_edit&slug=<?php echo urlencode($pageSlug); ?>&revert=<?php echo $index; ?>" 
                                                               class="btn btn-warning"
                                                               onclick="return confirm('Revert to this version?')">
                                                                <i class="bi bi-arrow-counterclockwise"></i> Revert to This Version
                                                            </a>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="mt-3">
                <a href="index.php?page=wiki&action=view&slug=<?php echo urlencode($pageSlug); ?>" 
                   class="btn btn-secondary">
                    <i class="bi bi-arrow-left"></i> Back to Page
                </a>
                <?php if ($auth->isLoggedIn()): ?>
                    <a href="index.php?page=wiki_edit&slug=<?php echo urlencode($pageSlug); ?>" 
                       class="btn btn-primary">
                        <i class="bi bi-pencil"></i> Edit Page
                    </a>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="col-lg-3">
            <div class="card">
                <div class="card-header">
                    <strong>Page Info</strong>
                </div>
                <div class="card-body">
                    <p><strong>Title:</strong><br><?php echo escape($page['title'] ?? 'Untitled'); ?></p>
                    <p><strong>Slug:</strong><br><code><?php echo escape($pageSlug); ?></code></p>
                    <p><strong>Created:</strong><br>
                        <?php echo date('M j, Y', $page['created_at'] ?? time()); ?><br>
                        <small class="text-muted">by <?php echo escape($page['author'] ?? 'Unknown'); ?></small>
                    </p>
                    <?php if (isset($page['last_modified'])): ?>
                        <p><strong>Last Modified:</strong><br>
                            <?php echo date('M j, Y', $page['last_modified']); ?><br>
                            <small class="text-muted">by <?php echo escape($page['last_modified_by'] ?? 'Unknown'); ?></small>
                        </p>
                    <?php endif; ?>
                    <p><strong>Total Revisions:</strong><br>
                        <?php echo count($revisions); ?>
                    </p>
                    <p><strong>Total Views:</strong><br>
                        <?php echo number_format($page['views'] ?? 0); ?>
                    </p>
                    <?php if ($page['locked'] ?? false): ?>
                        <div class="alert alert-warning p-2 small">
                            <i class="bi bi-lock"></i> This page is locked
                        </div>
                    <?php endif; ?>
                    <?php if (!($page['published'] ?? true)): ?>
                        <div class="alert alert-info p-2 small">
                            <i class="bi bi-eye-slash"></i> This page is unpublished
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.wiki-content {
    padding: 15px;
    background: #f8f9fa;
    border-radius: 4px;
    max-height: 400px;
    overflow-y: auto;
}

.table-success {
    background-color: rgba(25, 135, 84, 0.1);
}
</style>

<?php require 'templates/footer.php'; ?>
