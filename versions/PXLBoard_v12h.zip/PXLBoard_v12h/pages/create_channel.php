<?php
/**
 * Create Channel Page
 * Allows users to create and manage their own channels
 */

if (!$auth->isLoggedIn()) {
    redirect('index.php?page=login');
}

$message = '';
$error = '';

// Handle channel creation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_channel'])) {
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $isPublic = isset($_POST['is_public']);
    $allowSubmissions = isset($_POST['allow_submissions']);
    
    if (empty($name)) {
        $error = 'Channel name is required';
    } elseif (strlen($name) < 3) {
        $error = 'Channel name must be at least 3 characters';
    } elseif (strlen($name) > 50) {
        $error = 'Channel name must be less than 50 characters';
    } else {
        // Check if channel name already exists
        $existingChannels = $db->getAll('channels');
        $nameExists = false;
        foreach ($existingChannels as $ch) {
            if (strtolower($ch['name']) === strtolower($name)) {
                $nameExists = true;
                break;
            }
        }
        
        if ($nameExists) {
            $error = 'A channel with this name already exists';
        } else {
            // Create channel
            $channelId = 'chan_' . uniqid();
            $channelData = [
                'name' => $name,
                'description' => $description,
                'owner_id' => $_SESSION['user_id'],
                'owner' => $_SESSION['username'],
                'created_at' => time(),
                'subscribers' => 0,
                'image_count' => 0,
                'is_public' => $isPublic,
                'allow_submissions' => $allowSubmissions,
                'moderators' => [$_SESSION['user_id']]
            ];
            
            if ($db->save('channels', $channelId, $channelData)) {
                $message = 'Channel created successfully!';
                redirect('index.php?page=channel&id=' . $channelId);
            } else {
                $error = 'Failed to create channel';
            }
        }
    }
}

// Handle channel editing
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_channel'])) {
    $channelId = $_POST['channel_id'] ?? '';
    $channel = $db->get('channels', $channelId);
    
    if ($channel && $channel['owner_id'] === $_SESSION['user_id']) {
        $channel['description'] = trim($_POST['description'] ?? '');
        $channel['is_public'] = isset($_POST['is_public']);
        $channel['allow_submissions'] = isset($_POST['allow_submissions']);
        
        if ($db->save('channels', $channelId, $channel)) {
            $message = 'Channel updated successfully!';
        } else {
            $error = 'Failed to update channel';
        }
    } else {
        $error = 'You do not have permission to edit this channel';
    }
}

// Handle channel deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_channel'])) {
    $channelId = $_POST['channel_id'] ?? '';
    $channel = $db->get('channels', $channelId);
    
    if ($channel && $channel['owner_id'] === $_SESSION['user_id']) {
        if ($db->delete('channels', $channelId)) {
            $message = 'Channel deleted successfully!';
        } else {
            $error = 'Failed to delete channel';
        }
    } else {
        $error = 'You do not have permission to delete this channel';
    }
}

// Get user's channels
$allChannels = $db->getAll('channels');
$userChannels = array_filter($allChannels, function($ch) {
    return $ch['owner_id'] === $_SESSION['user_id'];
});

require 'templates/header.php';
?>

<div class="container mt-4">
    <h2><i class="bi bi-folder-plus"></i> My Channels</h2>
    <p class="text-muted">Create and manage your own channels</p>
    
    <?php if ($message): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?php echo htmlspecialchars($message); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <?php echo htmlspecialchars($error); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <div class="row">
        <div class="col-lg-4">
            <div class="card">
                <div class="card-header">
                    <strong>Create New Channel</strong>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Channel Name *</label>
                            <input type="text" name="name" class="form-control" required 
                                   minlength="3" maxlength="50" placeholder="Enter channel name">
                            <small class="text-muted">3-50 characters, unique name</small>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Description</label>
                            <textarea name="description" class="form-control" rows="3" 
                                      placeholder="Describe what this channel is about"></textarea>
                        </div>
                        
                        <div class="mb-3 form-check">
                            <input type="checkbox" name="is_public" class="form-check-input" 
                                   id="isPublic" checked>
                            <label class="form-check-label" for="isPublic">
                                Public channel (visible to everyone)
                            </label>
                        </div>
                        
                        <div class="mb-3 form-check">
                            <input type="checkbox" name="allow_submissions" class="form-check-input" 
                                   id="allowSubmissions" checked>
                            <label class="form-check-label" for="allowSubmissions">
                                Allow others to submit images
                            </label>
                        </div>
                        
                        <button type="submit" name="create_channel" class="btn btn-primary w-100">
                            <i class="bi bi-plus-circle"></i> Create Channel
                        </button>
                    </form>
                </div>
            </div>
            
            <div class="card mt-3">
                <div class="card-header">
                    <strong>Channel Guidelines</strong>
                </div>
                <div class="card-body">
                    <ul class="small mb-0">
                        <li>Choose a clear, descriptive name</li>
                        <li>Provide a helpful description</li>
                        <li>Set appropriate permissions</li>
                        <li>Moderate your channel actively</li>
                        <li>Follow community guidelines</li>
                    </ul>
                </div>
            </div>
        </div>
        
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header">
                    <strong>Your Channels (<?php echo count($userChannels); ?>)</strong>
                </div>
                <div class="card-body">
                    <?php if (empty($userChannels)): ?>
                        <p class="text-muted text-center py-5">
                            You haven't created any channels yet.<br>
                            Create your first channel using the form on the left!
                        </p>
                    <?php else: ?>
                        <div class="list-group">
                            <?php foreach ($userChannels as $channel): ?>
                                <?php
                                // Count images in channel
                                $allImages = $db->getAll('images');
                                $imageCount = 0;
                                foreach ($allImages as $img) {
                                    if (($img['channel'] ?? '') === $channel['id']) {
                                        $imageCount++;
                                    }
                                }
                                ?>
                                <div class="list-group-item">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <div class="flex-grow-1">
                                            <h5 class="mb-1">
                                                <a href="index.php?page=channel&id=<?php echo $channel['id']; ?>" 
                                                   class="text-decoration-none">
                                                    <?php echo escape($channel['name']); ?>
                                                </a>
                                            </h5>
                                            <p class="mb-2 text-muted">
                                                <?php echo escape($channel['description']); ?>
                                            </p>
                                            <small class="text-muted">
                                                <i class="bi bi-images"></i> <?php echo $imageCount; ?> images • 
                                                <i class="bi bi-people"></i> <?php echo $channel['subscribers'] ?? 0; ?> subscribers • 
                                                Created <?php echo timeAgo($channel['created_at']); ?>
                                            </small>
                                            <br>
                                            <small>
                                                <?php if ($channel['is_public']): ?>
                                                    <span class="badge bg-success">Public</span>
                                                <?php else: ?>
                                                    <span class="badge bg-secondary">Private</span>
                                                <?php endif; ?>
                                                
                                                <?php if ($channel['allow_submissions']): ?>
                                                    <span class="badge bg-info">Open Submissions</span>
                                                <?php endif; ?>
                                            </small>
                                        </div>
                                        <div class="btn-group-vertical ms-3">
                                            <button class="btn btn-sm btn-outline-primary" 
                                                    data-bs-toggle="modal" 
                                                    data-bs-target="#editModal<?php echo $channel['id']; ?>">
                                                <i class="bi bi-pencil"></i> Edit
                                            </button>
                                            <a href="index.php?page=upload&channel=<?php echo $channel['id']; ?>" 
                                               class="btn btn-sm btn-outline-success">
                                                <i class="bi bi-upload"></i> Upload
                                            </a>
                                            <button class="btn btn-sm btn-outline-danger" 
                                                    data-bs-toggle="modal" 
                                                    data-bs-target="#deleteModal<?php echo $channel['id']; ?>">
                                                <i class="bi bi-trash"></i> Delete
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Edit Modal -->
                                <div class="modal fade" id="editModal<?php echo $channel['id']; ?>" tabindex="-1">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <form method="POST">
                                                <div class="modal-header">
                                                    <h5 class="modal-title">Edit Channel</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <input type="hidden" name="channel_id" value="<?php echo $channel['id']; ?>">
                                                    
                                                    <div class="mb-3">
                                                        <label class="form-label">Description</label>
                                                        <textarea name="description" class="form-control" rows="3"><?php echo escape($channel['description']); ?></textarea>
                                                    </div>
                                                    
                                                    <div class="mb-3 form-check">
                                                        <input type="checkbox" name="is_public" class="form-check-input" 
                                                               id="isPublicEdit<?php echo $channel['id']; ?>" 
                                                               <?php echo $channel['is_public'] ? 'checked' : ''; ?>>
                                                        <label class="form-check-label" for="isPublicEdit<?php echo $channel['id']; ?>">
                                                            Public channel
                                                        </label>
                                                    </div>
                                                    
                                                    <div class="mb-3 form-check">
                                                        <input type="checkbox" name="allow_submissions" class="form-check-input" 
                                                               id="allowSubmissionsEdit<?php echo $channel['id']; ?>" 
                                                               <?php echo $channel['allow_submissions'] ? 'checked' : ''; ?>>
                                                        <label class="form-check-label" for="allowSubmissionsEdit<?php echo $channel['id']; ?>">
                                                            Allow others to submit images
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                    <button type="submit" name="edit_channel" class="btn btn-primary">Save Changes</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Delete Modal -->
                                <div class="modal fade" id="deleteModal<?php echo $channel['id']; ?>" tabindex="-1">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <form method="POST">
                                                <div class="modal-header">
                                                    <h5 class="modal-title">Delete Channel</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <input type="hidden" name="channel_id" value="<?php echo $channel['id']; ?>">
                                                    <p>Are you sure you want to delete the channel "<strong><?php echo escape($channel['name']); ?></strong>"?</p>
                                                    <p class="text-danger"><strong>Warning:</strong> This action cannot be undone. Images in this channel will not be deleted, but will become uncategorized.</p>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                    <button type="submit" name="delete_channel" class="btn btn-danger">Delete Channel</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require 'templates/footer.php'; ?>
