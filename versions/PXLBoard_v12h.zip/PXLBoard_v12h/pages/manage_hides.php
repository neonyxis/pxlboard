<?php
/**
 * Manage Hidden Images Page
 */

if (!$auth->isLoggedIn()) {
    redirect('index.php?page=login');
}

require_once 'includes/hiding.php';

$hiding = getHidingSystem();
$message = '';

// Handle unhide action
if (isset($_GET['action']) && $_GET['action'] === 'unhide' && isset($_GET['image_id'])) {
    if ($hiding->unhideImage($_GET['image_id'])) {
        $message = 'Image unhidden successfully';
    }
    redirect('index.php?page=manage_hides');
}

// Handle clear all
if (isset($_POST['clear_all'])) {
    if ($hiding->clearAllHides()) {
        $message = 'All hidden images have been cleared';
    }
    redirect('index.php?page=manage_hides');
}

// Get all hidden images
$hiddenImageIds = $hiding->getHiddenImages();
$hiddenImages = [];

foreach ($hiddenImageIds as $imageId) {
    $image = $db->get('images', $imageId);
    if ($image) {
        $image['id'] = $imageId;
        $hiddenImages[] = $image;
    }
}

require 'templates/header.php';
?>

<div class="container mt-4">
    <h2><i class="bi bi-eye-slash"></i> Manage Hidden Images</h2>
    <p class="text-muted">Images you've hidden from your gallery view</p>
    
    <?php if ($message): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?php echo htmlspecialchars($message); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <div class="card mb-4">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <strong>Hidden Images:</strong> <?php echo count($hiddenImages); ?>
                </div>
                <?php if (!empty($hiddenImages)): ?>
                    <form method="POST" class="d-inline">
                        <button type="submit" name="clear_all" class="btn btn-sm btn-danger"
                                onclick="return confirm('Are you sure you want to unhide all images?')">
                            <i class="bi bi-trash"></i> Clear All
                        </button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <?php if (empty($hiddenImages)): ?>
        <div class="alert alert-info">
            <i class="bi bi-info-circle"></i> You haven't hidden any images yet.
            When browsing images, click the "Hide" button to hide images you don't want to see.
        </div>
    <?php else: ?>
        <div class="row">
            <?php foreach ($hiddenImages as $image): ?>
                <div class="col-md-3 mb-4">
                    <div class="card h-100">
                        <a href="index.php?page=image&id=<?php echo htmlspecialchars($image['id']); ?>">
                            <img src="uploads/thumbs/<?php echo htmlspecialchars($image['filename']); ?>" 
                                 class="card-img-top" 
                                 alt="<?php echo htmlspecialchars($image['title']); ?>"
                                 style="object-fit: cover; height: 200px;">
                        </a>
                        <div class="card-body">
                            <h6 class="card-title text-truncate">
                                <?php echo htmlspecialchars($image['title']); ?>
                            </h6>
                            <small class="text-muted">
                                by <?php echo htmlspecialchars($image['uploader']); ?>
                            </small>
                        </div>
                        <div class="card-footer">
                            <a href="index.php?page=manage_hides&action=unhide&image_id=<?php echo htmlspecialchars($image['id']); ?>" 
                               class="btn btn-sm btn-success w-100">
                                <i class="bi bi-eye"></i> Unhide
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<?php require 'templates/footer.php'; ?>
