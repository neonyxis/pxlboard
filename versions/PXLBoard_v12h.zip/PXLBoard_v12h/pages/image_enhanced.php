<!-- Enhanced Image View - Inspired by DPBooru, Vichan, and Shimmie2 -->

<div class="container-fluid py-4">
    <div class="row">
        <!-- Main Image Column -->
        <div class="col-lg-8">
            <!-- Image Container - DPBooru style -->
            <div class="card mb-4 border-0 shadow-sm">
                <div class="card-header bg-gradient d-flex justify-content-between align-items-center" 
                     style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white;">
                    <h5 class="mb-0">
                        <i class="bi bi-image"></i>
                        <?php echo escape($image['title'] ?? 'Untitled'); ?>
                    </h5>
                    <div class="image-actions">
                        <button class="btn btn-sm btn-light" onclick="toggleFullscreen()" title="Fullscreen">
                            <i class="bi bi-arrows-fullscreen"></i>
                        </button>
                        <a href="<?php echo $image['file_path']; ?>" download class="btn btn-sm btn-light" title="Download">
                            <i class="bi bi-download"></i>
                        </a>
                        <?php if ($auth->isLoggedIn()): ?>
                            <button class="btn btn-sm btn-light" onclick="toggleFavorite()" title="Favorite">
                                <i class="bi bi-star" id="favoriteIcon"></i>
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="card-body p-0 bg-dark position-relative" id="imageContainer">
                    <!-- Rating Badge -->
                    <?php if (isset($image['rating'])): ?>
                        <div class="rating-badge rating-<?php echo strtolower($image['rating']); ?>">
                            <?php echo strtoupper($image['rating']); ?>
                        </div>
                    <?php endif; ?>
                    
                    <!-- Main Image -->
                    <img src="<?php echo escape($image['file_path']); ?>" 
                         alt="<?php echo escape($image['title'] ?? ''); ?>"
                         class="img-fluid w-100"
                         id="mainImage"
                         style="cursor: zoom-in; max-height: 80vh; object-fit: contain; margin: 0 auto; display: block;">
                    
                    <!-- Image Controls Overlay -->
                    <div class="image-controls-overlay">
                        <button class="btn btn-sm btn-dark" onclick="zoomIn()">
                            <i class="bi bi-zoom-in"></i>
                        </button>
                        <button class="btn btn-sm btn-dark" onclick="zoomOut()">
                            <i class="bi bi-zoom-out"></i>
                        </button>
                        <button class="btn btn-sm btn-dark" onclick="resetZoom()">
                            <i class="bi bi-arrow-counterclockwise"></i>
                        </button>
                    </div>
                </div>
                
                <!-- Image Stats Bar - Vichan inspired -->
                <div class="card-footer bg-light">
                    <div class="row text-center">
                        <div class="col">
                            <i class="bi bi-eye text-primary"></i>
                            <strong><?php echo number_format($image['views'] ?? 0); ?></strong>
                            <small class="text-muted d-block">Views</small>
                        </div>
                        <div class="col">
                            <i class="bi bi-star-fill text-warning"></i>
                            <strong><?php echo number_format($image['favorites'] ?? 0); ?></strong>
                            <small class="text-muted d-block">Favorites</small>
                        </div>
                        <div class="col">
                            <i class="bi bi-chat-dots text-success"></i>
                            <strong><?php echo number_format($image['comments'] ?? 0); ?></strong>
                            <small class="text-muted d-block">Comments</small>
                        </div>
                        <div class="col">
                            <i class="bi bi-hand-thumbs-up text-info"></i>
                            <strong><?php echo number_format($image['upvotes'] ?? 0); ?></strong>
                            <small class="text-muted d-block">Upvotes</small>
                        </div>
                        <div class="col">
                            <i class="bi bi-calendar text-secondary"></i>
                            <strong><?php echo date('M d, Y', $image['uploaded_at'] ?? time()); ?></strong>
                            <small class="text-muted d-block">Uploaded</small>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Description -->
            <?php if (!empty($image['description'])): ?>
                <div class="card mb-4 shadow-sm">
                    <div class="card-header">
                        <h6 class="mb-0"><i class="bi bi-file-text"></i> Description</h6>
                    </div>
                    <div class="card-body">
                        <?php echo nl2br(escape($image['description'])); ?>
                    </div>
                </div>
            <?php endif; ?>
            
            <!-- Comments Section -->
            <div class="card shadow-sm">
                <div class="card-header">
                    <h6 class="mb-0">
                        <i class="bi bi-chat-left-text"></i> 
                        Comments (<?php echo count($comments ?? []); ?>)
                    </h6>
                </div>
                <div class="card-body">
                    <?php if ($auth->isLoggedIn()): ?>
                        <!-- Comment Form -->
                        <form method="POST" class="mb-4">
                            <div class="mb-3">
                                <textarea name="comment" class="form-control" rows="3" 
                                          placeholder="Write a comment..." required></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary">
                                <i class="bi bi-send"></i> Post Comment
                            </button>
                        </form>
                    <?php endif; ?>
                    
                    <!-- Comments List -->
                    <div id="commentsList">
                        <?php foreach ($comments ?? [] as $comment): ?>
                            <div class="comment mb-3" id="comment-<?php echo $comment['id']; ?>">
                                <div class="comment-header">
                                    <div class="d-flex align-items-center">
                                        <img src="<?php echo getUserAvatar($comment['user_id']); ?>" 
                                             class="rounded-circle me-2" 
                                             width="32" height="32"
                                             alt="Avatar">
                                        <strong class="comment-author">
                                            <?php echo escape($comment['username']); ?>
                                        </strong>
                                        <small class="comment-date ms-2">
                                            <?php echo timeAgo($comment['created_at']); ?>
                                        </small>
                                    </div>
                                    <?php if ($auth->isLoggedIn() && 
                                             ($auth->getUsername() === $comment['username'] || 
                                              $auth->isAdmin())): ?>
                                        <div class="dropdown">
                                            <button class="btn btn-sm btn-link text-muted" 
                                                    data-bs-toggle="dropdown">
                                                <i class="bi bi-three-dots-vertical"></i>
                                            </button>
                                            <ul class="dropdown-menu">
                                                <li>
                                                    <a class="dropdown-item" href="#" 
                                                       onclick="editComment(<?php echo $comment['id']; ?>)">
                                                        <i class="bi bi-pencil"></i> Edit
                                                    </a>
                                                </li>
                                                <li>
                                                    <a class="dropdown-item text-danger" href="#"
                                                       onclick="deleteComment(<?php echo $comment['id']; ?>)">
                                                        <i class="bi bi-trash"></i> Delete
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="comment-body">
                                    <?php echo nl2br(escape($comment['text'])); ?>
                                </div>
                                <?php if ($auth->isLoggedIn()): ?>
                                    <div class="comment-actions mt-2">
                                        <button class="btn btn-sm btn-link text-muted" 
                                                onclick="replyToComment(<?php echo $comment['id']; ?>)">
                                            <i class="bi bi-reply"></i> Reply
                                        </button>
                                        <button class="btn btn-sm btn-link text-muted" 
                                                onclick="voteComment(<?php echo $comment['id']; ?>, 1)">
                                            <i class="bi bi-hand-thumbs-up"></i>
                                            <span id="upvotes-<?php echo $comment['id']; ?>">
                                                <?php echo $comment['upvotes'] ?? 0; ?>
                                            </span>
                                        </button>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Sidebar -->
        <div class="col-lg-4">
            <!-- Image Information - Shimmie2 inspired -->
            <div class="card mb-3 shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h6 class="mb-0"><i class="bi bi-info-circle"></i> Information</h6>
                </div>
                <div class="card-body">
                    <table class="table table-sm table-borderless mb-0">
                        <tr>
                            <td class="text-muted" width="40%"><i class="bi bi-person"></i> Uploader</td>
                            <td>
                                <a href="<?php echo buildUrl('user', $image['username']); ?>">
                                    <?php echo escape($image['username'] ?? 'Anonymous'); ?>
                                </a>
                            </td>
                        </tr>
                        <tr>
                            <td class="text-muted"><i class="bi bi-calendar"></i> Date</td>
                            <td><?php echo date('F j, Y g:i A', $image['uploaded_at'] ?? time()); ?></td>
                        </tr>
                        <tr>
                            <td class="text-muted"><i class="bi bi-file-earmark"></i> Size</td>
                            <td><?php echo formatFileSize($image['file_size'] ?? 0); ?></td>
                        </tr>
                        <tr>
                            <td class="text-muted"><i class="bi bi-aspect-ratio"></i> Dimensions</td>
                            <td><?php echo ($image['width'] ?? 0) . ' × ' . ($image['height'] ?? 0); ?></td>
                        </tr>
                        <tr>
                            <td class="text-muted"><i class="bi bi-file-code"></i> Format</td>
                            <td><?php echo strtoupper($image['extension'] ?? 'unknown'); ?></td>
                        </tr>
                        <?php if (!empty($image['source'])): ?>
                            <tr>
                                <td class="text-muted"><i class="bi bi-link-45deg"></i> Source</td>
                                <td>
                                    <a href="<?php echo escape($image['source']); ?>" 
                                       target="_blank" rel="noopener">
                                        View Source <i class="bi bi-box-arrow-up-right"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </table>
                </div>
            </div>
            
            <!-- Tags - DPBooru style -->
            <div class="card mb-3 shadow-sm">
                <div class="card-header bg-success text-white">
                    <h6 class="mb-0"><i class="bi bi-tags"></i> Tags</h6>
                </div>
                <div class="card-body">
                    <?php if (!empty($image['tag_data'])): ?>
                        <div class="tags-container">
                            <?php 
                            // Group tags by type
                            $tagsByType = [];
                            foreach ($image['tag_data'] as $tag) {
                                $type = $tag['type'] ?? 'general';
                                if (!isset($tagsByType[$type])) {
                                    $tagsByType[$type] = [];
                                }
                                $tagsByType[$type][] = $tag;
                            }
                            
                            // Display tags grouped by type
                            $typeLabels = [
                                'artist' => 'Artists',
                                'character' => 'Characters',
                                'species' => 'Species',
                                'rating' => 'Rating',
                                'meta' => 'Meta',
                                'content' => 'Content',
                                'general' => 'General'
                            ];
                            
                            foreach ($typeLabels as $type => $label):
                                if (isset($tagsByType[$type]) && count($tagsByType[$type]) > 0):
                            ?>
                                <div class="tag-group mb-3">
                                    <div class="tag-group-label text-muted small mb-1">
                                        <i class="bi bi-<?php echo $tagsByType[$type][0]['icon'] ?? 'tag'; ?>"></i>
                                        <?php echo $label; ?>
                                    </div>
                                    <div class="tags">
                                        <?php foreach ($tagsByType[$type] as $tag): ?>
                                            <a href="index.php?page=search&q=<?php echo urlencode($tag['name']); ?>" 
                                               class="badge tag-<?php echo $tag['type']; ?> me-1 mb-1"
                                               style="background-color: <?php echo $tag['color']; ?>;">
                                                <?php echo escape(str_replace('_', ' ', $tag['name'])); ?>
                                            </a>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            <?php 
                                endif;
                            endforeach; 
                            ?>
                        </div>
                    <?php else: ?>
                        <p class="text-muted mb-0">No tags</p>
                    <?php endif; ?>
                    
                    <?php if ($auth->isLoggedIn()): ?>
                        <button class="btn btn-sm btn-outline-primary mt-2" 
                                onclick="showTagEditor()">
                            <i class="bi bi-pencil"></i> Edit Tags
                        </button>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Actions -->
            <?php if ($auth->isLoggedIn()): ?>
                <div class="card mb-3 shadow-sm">
                    <div class="card-header bg-warning">
                        <h6 class="mb-0"><i class="bi bi-gear"></i> Actions</h6>
                    </div>
                    <div class="card-body">
                        <div class="d-grid gap-2">
                            <button class="btn btn-outline-primary" onclick="shareImage()">
                                <i class="bi bi-share"></i> Share
                            </button>
                            <button class="btn btn-outline-info" onclick="reportImage()">
                                <i class="bi bi-flag"></i> Report
                            </button>
                            <?php if ($auth->getUsername() === $image['username'] || $auth->isAdmin()): ?>
                                <a href="index.php?page=edit_image&id=<?php echo $image['id']; ?>" 
                                   class="btn btn-outline-secondary">
                                    <i class="bi bi-pencil"></i> Edit
                                </a>
                                <button class="btn btn-outline-danger" 
                                        onclick="deleteImage(<?php echo $image['id']; ?>)">
                                    <i class="bi bi-trash"></i> Delete
                                </button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            
            <!-- Related Images -->
            <div class="card shadow-sm">
                <div class="card-header bg-info text-white">
                    <h6 class="mb-0"><i class="bi bi-images"></i> Related Images</h6>
                </div>
                <div class="card-body p-2">
                    <div class="row g-2">
                        <?php foreach ($relatedImages ?? [] as $related): ?>
                            <div class="col-6">
                                <a href="<?php echo buildUrl('image', $related['id']); ?>">
                                    <img src="<?php echo escape($related['thumbnail'] ?? $related['file_path']); ?>" 
                                         class="img-fluid rounded" 
                                         alt="<?php echo escape($related['title'] ?? ''); ?>"
                                         style="height: 120px; width: 100%; object-fit: cover;">
                                </a>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Tag Editor Modal -->
<div class="modal fade" id="tagEditorModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit Tags</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form method="POST" id="tagEditForm">
                    <div class="mb-3">
                        <label class="form-label">Tags (comma-separated)</label>
                        <input type="text" name="tags" class="form-control" 
                               id="tagInput"
                               placeholder="artist:name, character:name, general_tag"
                               value="<?php echo implode(', ', array_column($image['tag_data'] ?? [], 'name')); ?>">
                        <small class="text-muted">
                            Prefix with type: artist:, character:, species:, meta:, rating:
                        </small>
                    </div>
                    <div id="tagSuggestions" class="border rounded p-2 mb-3" style="max-height: 200px; overflow-y: auto;">
                        <!-- Autocomplete suggestions will appear here -->
                    </div>
                    <button type="submit" class="btn btn-primary">Save Tags</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
// Image zoom functionality
let zoomLevel = 1;
const mainImage = document.getElementById('mainImage');

function zoomIn() {
    zoomLevel = Math.min(zoomLevel + 0.2, 3);
    mainImage.style.transform = `scale(${zoomLevel})`;
}

function zoomOut() {
    zoomLevel = Math.max(zoomLevel - 0.2, 0.5);
    mainImage.style.transform = `scale(${zoomLevel})`;
}

function resetZoom() {
    zoomLevel = 1;
    mainImage.style.transform = 'scale(1)';
}

function toggleFullscreen() {
    const container = document.getElementById('imageContainer');
    if (!document.fullscreenElement) {
        container.requestFullscreen();
    } else {
        document.exitFullscreen();
    }
}

// Tag editor
function showTagEditor() {
    const modal = new bootstrap.Modal(document.getElementById('tagEditorModal'));
    modal.show();
    
    // Setup autocomplete
    setupTagAutocomplete();
}

function setupTagAutocomplete() {
    const input = document.getElementById('tagInput');
    const suggestions = document.getElementById('tagSuggestions');
    
    input.addEventListener('input', debounce(async function() {
        const query = this.value.split(',').pop().trim();
        if (query.length < 2) {
            suggestions.innerHTML = '';
            return;
        }
        
        // Fetch suggestions (implement AJAX call)
        const results = await fetchTagSuggestions(query);
        displayTagSuggestions(results);
    }, 300));
}

function displayTagSuggestions(tags) {
    const container = document.getElementById('tagSuggestions');
    container.innerHTML = tags.map(tag => 
        `<button type="button" class="btn btn-sm badge tag-${tag.type} me-1 mb-1" 
                 onclick="addTag('${tag.name}')">
            ${tag.name} (${tag.count})
         </button>`
    ).join('');
}

function addTag(tagName) {
    const input = document.getElementById('tagInput');
    const tags = input.value.split(',').map(t => t.trim());
    tags[tags.length - 1] = tagName;
    input.value = tags.join(', ') + ', ';
    input.focus();
}

// Helper function
function debounce(func, wait) {
    let timeout;
    return function(...args) {
        clearTimeout(timeout);
        timeout = setTimeout(() => func.apply(this, args), wait);
    };
}

// Keyboard shortcuts
document.addEventListener('keydown', function(e) {
    if (e.key === 'f' && !e.ctrlKey && !e.metaKey) {
        if (document.activeElement.tagName !== 'INPUT' && 
            document.activeElement.tagName !== 'TEXTAREA') {
            e.preventDefault();
            toggleFullscreen();
        }
    } else if (e.key === '+' || e.key === '=') {
        e.preventDefault();
        zoomIn();
    } else if (e.key === '-') {
        e.preventDefault();
        zoomOut();
    } else if (e.key === '0') {
        e.preventDefault();
        resetZoom();
    }
});
</script>

<style>
.image-controls-overlay {
    position: absolute;
    bottom: 1rem;
    right: 1rem;
    display: flex;
    gap: 0.5rem;
    opacity: 0;
    transition: opacity 0.3s;
}

#imageContainer:hover .image-controls-overlay {
    opacity: 1;
}

.tag-group-label {
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.comment {
    transition: background-color 0.2s;
}

.comment:hover {
    background-color: rgba(0,0,0,0.02);
}
</style>
