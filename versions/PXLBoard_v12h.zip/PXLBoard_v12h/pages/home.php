<?php
/**
 * Home Page - Image Gallery with Upload and Filters
 */

$page_num = isset($_GET['p']) ? max(1, intval($_GET['p'])) : 1;
$offset = ($page_num - 1) * ITEMS_PER_PAGE;
$view = $_GET['view'] ?? 'grid'; // grid or list
$sort = $_GET['sort'] ?? 'newest'; // newest, popular, rating

// Advanced filter parameters
$filterUploader = $_GET['uploader'] ?? '';
$filterChannel = $_GET['channel'] ?? '';
$filterTag = $_GET['tag'] ?? '';
$filterRating = $_GET['min_rating'] ?? '';
$filterDateFrom = $_GET['date_from'] ?? '';
$filterDateTo = $_GET['date_to'] ?? '';

$images = $db->getAll('images');

// Apply filters
if (!empty($filterUploader)) {
    $images = array_filter($images, function($img) use ($filterUploader) {
        return stripos($img['uploader'] ?? '', $filterUploader) !== false;
    });
}

if (!empty($filterChannel)) {
    $images = array_filter($images, function($img) use ($filterChannel) {
        return ($img['channel'] ?? '') === $filterChannel;
    });
}

if (!empty($filterTag)) {
    $images = array_filter($images, function($img) use ($filterTag) {
        $tags = $img['tags'] ?? [];
        foreach ($tags as $tag) {
            if (stripos($tag, $filterTag) !== false) {
                return true;
            }
        }
        return false;
    });
}

if (!empty($filterRating) && is_numeric($filterRating)) {
    $minRating = floatval($filterRating);
    $images = array_filter($images, function($img) use ($minRating) {
        return ($img['rating'] ?? 0) >= $minRating;
    });
}

if (!empty($filterDateFrom)) {
    $dateFrom = strtotime($filterDateFrom);
    if ($dateFrom !== false) {
        $images = array_filter($images, function($img) use ($dateFrom) {
            return ($img['uploaded_at'] ?? 0) >= $dateFrom;
        });
    }
}

if (!empty($filterDateTo)) {
    $dateTo = strtotime($filterDateTo . ' 23:59:59');
    if ($dateTo !== false) {
        $images = array_filter($images, function($img) use ($dateTo) {
            return ($img['uploaded_at'] ?? 0) <= $dateTo;
        });
    }
}

// Apply sorting
switch ($sort) {
    case 'popular':
        usort($images, function($a, $b) {
            return ($b['views'] ?? 0) - ($a['views'] ?? 0);
        });
        break;
    case 'rating':
        usort($images, function($a, $b) {
            return ($b['rating'] ?? 0) - ($a['rating'] ?? 0);
        });
        break;
    case 'favorites':
        usort($images, function($a, $b) {
            return ($b['favorites'] ?? 0) - ($a['favorites'] ?? 0);
        });
        break;
    case 'newest':
    default:
        usort($images, function($a, $b) {
            return ($b['uploaded_at'] ?? 0) - ($a['uploaded_at'] ?? 0);
        });
        break;
}

$totalImages = count($images);
$images = array_slice($images, $offset, ITEMS_PER_PAGE);
$totalPages = ceil($totalImages / ITEMS_PER_PAGE);

// Get all channels for filter dropdown
$channels = $db->getAll('channels');

require 'templates/header.php';
?>

<div class="container mt-4">
    <!-- Header Section -->
    <div class="row mb-4">
        <div class="col-md-8">
            <h1><?php echo escape(SITE_NAME); ?></h1>
            <p class="text-muted"><?php echo escape(SITE_DESCRIPTION); ?></p>
        </div>
        <div class="col-md-4 text-end">
            <div class="btn-group" role="group">
                <a href="?page=home&view=grid<?php echo !empty($sort) ? '&sort=' . $sort : ''; ?>" 
                   class="btn btn-outline-secondary <?php echo $view === 'grid' ? 'active' : ''; ?>">
                    <i class="bi bi-grid-3x3-gap"></i> Grid
                </a>
                <a href="?page=home&view=list<?php echo !empty($sort) ? '&sort=' . $sort : ''; ?>" 
                   class="btn btn-outline-secondary <?php echo $view === 'list' ? 'active' : ''; ?>">
                    <i class="bi bi-list"></i> List
                </a>
            </div>
        </div>
    </div>
    
    <!-- Upload Box (for logged-in users) -->
    <?php if ($auth->isLoggedIn()): ?>
        <div class="card mb-4 border-primary">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h5 class="mb-0">
                            <i class="bi bi-cloud-upload"></i> Upload New Image
                        </h5>
                        <p class="text-muted small mb-0">Share your images with the community</p>
                    </div>
                    <div class="col-md-4 text-end">
                        <a href="index.php?page=upload" class="btn btn-primary">
                            <i class="bi bi-plus-circle"></i> Upload Image
                        </a>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
    
    <!-- Community Portal Link -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card border-primary shadow-lg" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
                <div class="card-body text-white p-4">
                    <div class="row align-items-center">
                        <div class="col-md-8">
                            <h3 class="card-title mb-3">
                                <i class="bi bi-compass"></i> Community Portal
                            </h3>
                            <p class="card-text mb-0">
                                Your central hub for all community activities! Access the activity stream, wiki, blogs, forums, discussion boards, and gallery - all in one place.
                            </p>
                        </div>
                        <div class="col-md-4 text-md-end mt-3 mt-md-0">
                            <a href="index.php?page=community_portal" class="btn btn-light btn-lg shadow">
                                <i class="bi bi-arrow-right-circle"></i> Explore Portal
                            </a>
                        </div>
                    </div>
                    <div class="row mt-4">
                        <div class="col-6 col-md-3 text-center">
                            <i class="bi bi-activity fs-2 mb-2"></i>
                            <div class="small">Activity Feed</div>
                        </div>
                        <div class="col-6 col-md-3 text-center">
                            <i class="bi bi-book fs-2 mb-2"></i>
                            <div class="small">Wiki</div>
                        </div>
                        <div class="col-6 col-md-3 text-center">
                            <i class="bi bi-newspaper fs-2 mb-2"></i>
                            <div class="small">Blogs</div>
                        </div>
                        <div class="col-6 col-md-3 text-center">
                            <i class="bi bi-collection fs-2 mb-2"></i>
                            <div class="small">Boards</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Photo Rotator -->
    <?php
    require_once 'includes/photo_rotator.php';
    $rotator = new PhotoRotator($db);
    ?>
    <div class="row mb-4">
        <div class="col-12">
            <div class="card shadow">
                <div class="card-header bg-dark text-white">
                    <h5 class="mb-0"><i class="bi bi-star-fill"></i> Featured Images</h5>
                </div>
                <div class="card-body p-0">
                    <?php echo $rotator->render([
                        'count' => 8,
                        'criteria' => 'top_rated',
                        'height' => '400px',
                        'autoplay' => true,
                        'interval' => 5000
                    ]); ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Collapsible Filters -->
    <div class="card mb-4">
        <div class="card-header">
            <button class="btn btn-link text-decoration-none w-100 text-start p-0" 
                    type="button" 
                    data-bs-toggle="collapse" 
                    data-bs-target="#filterCollapse">
                <div class="d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">
                        <i class="bi bi-funnel"></i> Filters & Sort
                    </h5>
                    <i class="bi bi-chevron-down"></i>
                </div>
            </button>
        </div>
        <div class="collapse <?php echo (!empty($filterUploader) || !empty($filterChannel) || !empty($filterTag) || !empty($filterRating) || !empty($filterDateFrom) || !empty($filterDateTo)) ? 'show' : ''; ?>" 
             id="filterCollapse">
            <div class="card-body">
                <form method="GET" action="index.php" class="row g-3">
                    <input type="hidden" name="page" value="home">
                    <input type="hidden" name="view" value="<?php echo escape($view); ?>">
                    
                    <!-- Sort -->
                    <div class="col-md-3">
                        <label class="form-label">Sort By</label>
                        <select name="sort" class="form-select">
                            <option value="newest" <?php echo $sort === 'newest' ? 'selected' : ''; ?>>Newest First</option>
                            <option value="popular" <?php echo $sort === 'popular' ? 'selected' : ''; ?>>Most Popular</option>
                            <option value="rating" <?php echo $sort === 'rating' ? 'selected' : ''; ?>>Highest Rated</option>
                            <option value="favorites" <?php echo $sort === 'favorites' ? 'selected' : ''; ?>>Most Favorited</option>
                        </select>
                    </div>
                    
                    <!-- Uploader -->
                    <div class="col-md-3">
                        <label class="form-label">Uploader</label>
                        <input type="text" name="uploader" class="form-control" 
                               placeholder="Username..." 
                               value="<?php echo escape($filterUploader); ?>">
                    </div>
                    
                    <!-- Channel -->
                    <div class="col-md-3">
                        <label class="form-label">Channel</label>
                        <select name="channel" class="form-select">
                            <option value="">All Channels</option>
                            <?php foreach ($channels as $channel): ?>
                                <option value="<?php echo escape($channel['id']); ?>" 
                                        <?php echo $filterChannel === $channel['id'] ? 'selected' : ''; ?>>
                                    <?php echo escape($channel['name'] ?? $channel['id']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <!-- Tag -->
                    <div class="col-md-3">
                        <label class="form-label">Tag</label>
                        <input type="text" name="tag" class="form-control" 
                               placeholder="Search by tag..." 
                               value="<?php echo escape($filterTag); ?>">
                    </div>
                    
                    <!-- Min Rating -->
                    <div class="col-md-2">
                        <label class="form-label">Min Rating</label>
                        <select name="min_rating" class="form-select">
                            <option value="">Any</option>
                            <option value="1" <?php echo $filterRating === '1' ? 'selected' : ''; ?>>1+ Stars</option>
                            <option value="2" <?php echo $filterRating === '2' ? 'selected' : ''; ?>>2+ Stars</option>
                            <option value="3" <?php echo $filterRating === '3' ? 'selected' : ''; ?>>3+ Stars</option>
                            <option value="4" <?php echo $filterRating === '4' ? 'selected' : ''; ?>>4+ Stars</option>
                            <option value="5" <?php echo $filterRating === '5' ? 'selected' : ''; ?>>5 Stars</option>
                        </select>
                    </div>
                    
                    <!-- Date From -->
                    <div class="col-md-2">
                        <label class="form-label">Date From</label>
                        <input type="date" name="date_from" class="form-control" 
                               value="<?php echo escape($filterDateFrom); ?>">
                    </div>
                    
                    <!-- Date To -->
                    <div class="col-md-2">
                        <label class="form-label">Date To</label>
                        <input type="date" name="date_to" class="form-control" 
                               value="<?php echo escape($filterDateTo); ?>">
                    </div>
                    
                    <!-- Buttons -->
                    <div class="col-md-6">
                        <label class="form-label d-block">&nbsp;</label>
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-search"></i> Apply Filters
                        </button>
                        <a href="index.php?page=home&view=<?php echo escape($view); ?>" class="btn btn-secondary">
                            <i class="bi bi-x-circle"></i> Clear
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Results Info -->
    <div class="d-flex justify-content-between align-items-center mb-3">
        <p class="text-muted mb-0">
            Showing <?php echo number_format($totalImages); ?> image<?php echo $totalImages !== 1 ? 's' : ''; ?>
        </p>
    </div>
    
    <!-- Gallery Grid or List View -->
    <?php if ($view === 'grid'): ?>
        <div class="row">
            <?php if (empty($images)): ?>
                <div class="col-12 text-center py-5">
                    <h3>No images found</h3>
                    <p class="text-muted">Try adjusting your filters or be the first to upload!</p>
                    <?php if ($auth->isLoggedIn()): ?>
                        <a href="index.php?page=upload" class="btn btn-primary">Upload Image</a>
                    <?php else: ?>
                        <a href="index.php?page=login" class="btn btn-primary">Login to Upload</a>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <?php foreach ($images as $image): ?>
                    <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                        <div class="card image-card h-100">
                            <a href="index.php?page=image&id=<?php echo escape($image['id']); ?>">
                                <img src="uploads/thumbs/<?php echo escape($image['filename']); ?>" 
                                     class="card-img-top" 
                                     alt="<?php echo escape($image['title']); ?>"
                                     loading="lazy">
                            </a>
                            <div class="card-body">
                                <h6 class="card-title">
                                    <a href="index.php?page=image&id=<?php echo escape($image['id']); ?>" class="text-decoration-none">
                                        <?php echo escape($image['title'] ?? 'Untitled'); ?>
                                    </a>
                                </h6>
                                <p class="card-text small text-muted">
                                    <?php echo escape($image['uploader']); ?> • 
                                    <?php echo timeAgo($image['uploaded_at']); ?>
                                </p>
                                <div class="d-flex justify-content-between small text-muted mb-2">
                                    <span><i class="bi bi-eye"></i> <?php echo number_format($image['views'] ?? 0); ?></span>
                                    <span><i class="bi bi-star-fill"></i> <?php echo $image['rating'] ?? 'N/A'; ?></span>
                                    <span><i class="bi bi-heart"></i> <?php echo number_format($image['favorites'] ?? 0); ?></span>
                                </div>
                                <div class="tags">
                                    <?php if (!empty($image['tags'])): ?>
                                        <?php foreach (array_slice($image['tags'], 0, 3) as $tag): ?>
                                            <a href="index.php?page=home&tag=<?php echo urlencode($tag); ?>" class="badge bg-secondary">
                                                <?php echo escape($tag); ?>
                                            </a>
                                        <?php endforeach; ?>
                                        <?php if (count($image['tags']) > 3): ?>
                                            <span class="badge bg-light text-dark">+<?php echo count($image['tags']) - 3; ?></span>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    <?php else: ?>
        <!-- List View -->
        <div class="row">
            <?php if (empty($images)): ?>
                <div class="col-12 text-center py-5">
                    <h3>No images found</h3>
                    <p class="text-muted">Try adjusting your filters or be the first to upload!</p>
                    <?php if ($auth->isLoggedIn()): ?>
                        <a href="index.php?page=upload" class="btn btn-primary">Upload Image</a>
                    <?php else: ?>
                        <a href="index.php?page=login" class="btn btn-primary">Login to Upload</a>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <?php foreach ($images as $image): ?>
                    <div class="col-12 mb-3">
                        <div class="card">
                            <div class="row g-0">
                                <div class="col-md-3">
                                    <a href="index.php?page=image&id=<?php echo escape($image['id']); ?>">
                                        <img src="uploads/thumbs/<?php echo escape($image['filename']); ?>" 
                                             class="img-fluid rounded-start" 
                                             alt="<?php echo escape($image['title']); ?>"
                                             style="height: 200px; width: 100%; object-fit: cover;">
                                    </a>
                                </div>
                                <div class="col-md-9">
                                    <div class="card-body">
                                        <h5 class="card-title">
                                            <a href="index.php?page=image&id=<?php echo escape($image['id']); ?>" class="text-decoration-none">
                                                <?php echo escape($image['title'] ?? 'Untitled'); ?>
                                            </a>
                                        </h5>
                                        <?php if (!empty($image['description'])): ?>
                                            <p class="card-text"><?php echo escape(substr($image['description'], 0, 200)); ?><?php echo strlen($image['description']) > 200 ? '...' : ''; ?></p>
                                        <?php endif; ?>
                                        <p class="card-text">
                                            <small class="text-muted">
                                                By <?php echo escape($image['uploader']); ?> • 
                                                <?php echo timeAgo($image['uploaded_at']); ?> • 
                                                <i class="bi bi-eye"></i> <?php echo number_format($image['views'] ?? 0); ?> views • 
                                                <i class="bi bi-star-fill"></i> <?php echo $image['rating'] ?? 'N/A'; ?> • 
                                                <i class="bi bi-heart"></i> <?php echo number_format($image['favorites'] ?? 0); ?> favorites
                                            </small>
                                        </p>
                                        <div class="tags">
                                            <?php if (!empty($image['tags'])): ?>
                                                <?php foreach ($image['tags'] as $tag): ?>
                                                    <a href="index.php?page=home&tag=<?php echo urlencode($tag); ?>" class="badge bg-secondary">
                                                        <?php echo escape($tag); ?>
                                                    </a>
                                                <?php endforeach; ?>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    <?php endif; ?>
    
    <!-- Pagination -->
    <?php if ($totalPages > 1): ?>
        <nav aria-label="Page navigation">
            <ul class="pagination justify-content-center">
                <?php if ($page_num > 1): ?>
                    <li class="page-item">
                        <a class="page-link" href="<?php echo buildQueryString(['p' => $page_num - 1]); ?>">Previous</a>
                    </li>
                <?php endif; ?>
                
                <?php for ($i = max(1, $page_num - 2); $i <= min($totalPages, $page_num + 2); $i++): ?>
                    <li class="page-item <?php echo $i === $page_num ? 'active' : ''; ?>">
                        <a class="page-link" href="<?php echo buildQueryString(['p' => $i]); ?>"><?php echo $i; ?></a>
                    </li>
                <?php endfor; ?>
                
                <?php if ($page_num < $totalPages): ?>
                    <li class="page-item">
                        <a class="page-link" href="<?php echo buildQueryString(['p' => $page_num + 1]); ?>">Next</a>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>
    <?php endif; ?>
</div>

<style>
.image-card {
    transition: transform 0.2s, box-shadow 0.2s;
}

.image-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 4px 15px rgba(0,0,0,0.2);
}

.image-card img {
    height: 200px;
    object-fit: cover;
}

.collapse.show ~ .card-header i.bi-chevron-down {
    transform: rotate(180deg);
}

.card-header .btn-link {
    color: inherit;
}

.card-header .btn-link:hover {
    color: inherit;
}
</style>

<?php require 'templates/footer.php'; ?>
