<?php
/**
 * Moderation Panel
 * Admin page for managing bans, reports, and moderation
 */

if (!$auth->isAdmin()) {
    header('Location: index.php');
    exit;
}

require_once __DIR__ . '/../includes/moderation.php';
$mod = new Moderation($db);

$action = $_GET['action'] ?? 'reports';
$message = '';
$error = '';

// Handle POST actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['ban_user'])) {
        $userId = $_POST['user_id'];
        $reason = $_POST['reason'];
        $duration = (int)$_POST['duration'];
        $ipBan = isset($_POST['ip_ban']);
        
        $result = $mod->banUser($userId, $reason, $_SESSION['user_id'], $duration, $ipBan);
        if ($result['success']) {
            $message = 'User banned successfully';
        } else {
            $error = $result['error'];
        }
    }
    
    if (isset($_POST['unban_user'])) {
        $userId = $_POST['user_id'];
        $result = $mod->unbanUser($userId, $_SESSION['user_id']);
        if ($result['success']) {
            $message = 'User unbanned successfully';
        } else {
            $error = $result['error'];
        }
    }
    
    if (isset($_POST['process_report'])) {
        $reportId = $_POST['report_id'];
        $reportAction = $_POST['report_action'];
        $notes = $_POST['notes'] ?? '';
        
        $result = $mod->processReport($reportId, $reportAction, $_SESSION['user_id'], $notes);
        if ($result['success']) {
            $message = 'Report processed successfully';
        } else {
            $error = $result['error'];
        }
    }
}

// Get data based on active tab
$pendingReports = $mod->getPendingReports();
$activeBans = $mod->getActiveBans();
$modLogs = $mod->getModLogs(50);
$stats = $mod->getStats();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Moderation Panel - <?php echo htmlspecialchars(SITE_NAME); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        .stat-card {
            border-left: 4px solid;
            transition: transform 0.2s;
        }
        .stat-card:hover {
            transform: translateY(-2px);
        }
        .stat-card.danger { border-left-color: #dc3545; }
        .stat-card.warning { border-left-color: #ffc107; }
        .stat-card.info { border-left-color: #0dcaf0; }
        .stat-card.success { border-left-color: #198754; }
        
        .report-card {
            border-left: 3px solid #ffc107;
            transition: all 0.2s;
        }
        .report-card:hover {
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        
        .ban-badge {
            font-size: 0.75rem;
            padding: 0.25rem 0.5rem;
        }
        
        .mod-log-entry {
            border-left: 2px solid #dee2e6;
            padding-left: 1rem;
            margin-bottom: 0.5rem;
        }
        
        .content-preview {
            max-height: 100px;
            overflow: hidden;
            position: relative;
        }
        .content-preview::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            height: 30px;
            background: linear-gradient(transparent, white);
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
        <div class="container-fluid">
            <a class="navbar-brand" href="index.php">
                <i class="bi bi-shield-check"></i> Moderation Panel
            </a>
            <div class="ms-auto">
                <a href="index.php?page=admin" class="btn btn-outline-light btn-sm">
                    <i class="bi bi-arrow-left"></i> Back to Admin
                </a>
            </div>
        </div>
    </nav>

    <div class="container-fluid">
        <?php if ($message): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle"></i> <?php echo htmlspecialchars($message); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="bi bi-exclamation-triangle"></i> <?php echo htmlspecialchars($error); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- Statistics Cards -->
        <div class="row mb-4">
            <div class="col-md-3 mb-3">
                <div class="card stat-card warning">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">Pending Reports</h6>
                                <h3 class="mb-0"><?php echo $stats['pending_reports']; ?></h3>
                            </div>
                            <div class="text-warning">
                                <i class="bi bi-flag fs-1"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3 mb-3">
                <div class="card stat-card danger">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">Active Bans</h6>
                                <h3 class="mb-0"><?php echo $stats['active_bans']; ?></h3>
                            </div>
                            <div class="text-danger">
                                <i class="bi bi-ban fs-1"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3 mb-3">
                <div class="card stat-card info">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">Total Reports</h6>
                                <h3 class="mb-0"><?php echo $stats['total_reports']; ?></h3>
                            </div>
                            <div class="text-info">
                                <i class="bi bi-clipboard-data fs-1"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3 mb-3">
                <div class="card stat-card success">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">Total Mutes</h6>
                                <h3 class="mb-0"><?php echo $stats['total_mutes']; ?></h3>
                            </div>
                            <div class="text-success">
                                <i class="bi bi-volume-mute fs-1"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Tabs -->
        <ul class="nav nav-tabs mb-4" role="tablist">
            <li class="nav-item">
                <a class="nav-link <?php echo $action === 'reports' ? 'active' : ''; ?>" 
                   href="?page=moderation&action=reports">
                    <i class="bi bi-flag"></i> Reports 
                    <?php if ($stats['pending_reports'] > 0): ?>
                        <span class="badge bg-warning text-dark"><?php echo $stats['pending_reports']; ?></span>
                    <?php endif; ?>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo $action === 'bans' ? 'active' : ''; ?>" 
                   href="?page=moderation&action=bans">
                    <i class="bi bi-ban"></i> Bans
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo $action === 'logs' ? 'active' : ''; ?>" 
                   href="?page=moderation&action=logs">
                    <i class="bi bi-clock-history"></i> Mod Logs
                </a>
            </li>
        </ul>

        <!-- Tab Content -->
        <?php if ($action === 'reports'): ?>
            <!-- Reports Tab -->
            <div class="row">
                <div class="col-12">
                    <h4 class="mb-3">Pending Reports (<?php echo count($pendingReports); ?>)</h4>
                    
                    <?php if (empty($pendingReports)): ?>
                        <div class="alert alert-info">
                            <i class="bi bi-info-circle"></i> No pending reports. Great job!
                        </div>
                    <?php else: ?>
                        <?php foreach ($pendingReports as $report): ?>
                            <div class="card report-card mb-3">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-8">
                                            <div class="d-flex align-items-start mb-2">
                                                <span class="badge bg-<?php 
                                                    echo match($report['category']) {
                                                        'spam' => 'secondary',
                                                        'offensive' => 'danger',
                                                        'copyright' => 'warning',
                                                        'illegal' => 'dark',
                                                        default => 'info'
                                                    };
                                                ?> me-2">
                                                    <?php echo htmlspecialchars(ucfirst($report['category'])); ?>
                                                </span>
                                                <span class="badge bg-primary me-2">
                                                    <?php echo htmlspecialchars(ucfirst($report['type'])); ?>
                                                </span>
                                                <small class="text-muted">
                                                    <?php echo date('M d, Y H:i', $report['created_at']); ?>
                                                </small>
                                            </div>
                                            
                                            <h6 class="mb-2">Report Reason:</h6>
                                            <p class="mb-2"><?php echo htmlspecialchars($report['reason']); ?></p>
                                            
                                            <?php if ($report['content_info']): ?>
                                                <div class="content-preview bg-light p-2 rounded mb-2">
                                                    <small class="text-muted"><strong>Content Preview:</strong></small><br>
                                                    <?php if ($report['type'] === 'image' && isset($report['content_info']['title'])): ?>
                                                        <strong><?php echo htmlspecialchars($report['content_info']['title']); ?></strong><br>
                                                        <small><?php echo htmlspecialchars($report['content_info']['description'] ?? 'No description'); ?></small>
                                                    <?php elseif ($report['type'] === 'comment' && isset($report['content_info']['content'])): ?>
                                                        <?php echo htmlspecialchars(substr($report['content_info']['content'], 0, 200)); ?>
                                                    <?php elseif ($report['type'] === 'user' && isset($report['content_info']['username'])): ?>
                                                        User: <strong><?php echo htmlspecialchars($report['content_info']['username']); ?></strong>
                                                    <?php endif; ?>
                                                </div>
                                            <?php endif; ?>
                                            
                                            <small class="text-muted">
                                                <i class="bi bi-person"></i> Reported by: 
                                                <?php 
                                                    $reporter = $db->get('users', $report['reported_by']);
                                                    echo $reporter ? htmlspecialchars($reporter['username']) : 'Unknown';
                                                ?>
                                            </small>
                                        </div>
                                        
                                        <div class="col-md-4">
                                            <form method="POST" class="d-grid gap-2">
                                                <input type="hidden" name="report_id" value="<?php echo $report['id']; ?>">
                                                
                                                <label class="form-label"><strong>Action:</strong></label>
                                                <select name="report_action" class="form-select form-select-sm mb-2" required>
                                                    <option value="">Choose action...</option>
                                                    <option value="dismiss">Dismiss (No action)</option>
                                                    <option value="delete_content">Delete Content</option>
                                                    <option value="warn_user">Warn User</option>
                                                    <option value="ban_user">Ban User (7 days)</option>
                                                </select>
                                                
                                                <textarea name="notes" class="form-control form-control-sm mb-2" 
                                                          rows="2" placeholder="Moderator notes..."></textarea>
                                                
                                                <button type="submit" name="process_report" class="btn btn-primary btn-sm">
                                                    <i class="bi bi-check-lg"></i> Process Report
                                                </button>
                                                
                                                <a href="?page=<?php echo $report['type']; ?>&id=<?php echo $report['content_id']; ?>" 
                                                   class="btn btn-outline-secondary btn-sm" target="_blank">
                                                    <i class="bi bi-box-arrow-up-right"></i> View Content
                                                </a>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
            
        <?php elseif ($action === 'bans'): ?>
            <!-- Bans Tab -->
            <div class="row">
                <div class="col-md-8">
                    <h4 class="mb-3">Active Bans (<?php echo count($activeBans); ?>)</h4>
                    
                    <?php if (empty($activeBans)): ?>
                        <div class="alert alert-info">
                            <i class="bi bi-info-circle"></i> No active bans.
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>User</th>
                                        <th>Reason</th>
                                        <th>Type</th>
                                        <th>Banned</th>
                                        <th>Expires</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($activeBans as $ban): ?>
                                        <tr>
                                            <td>
                                                <strong><?php echo htmlspecialchars($ban['username']); ?></strong>
                                                <?php if ($ban['is_ip_ban']): ?>
                                                    <br><small class="text-muted">IP: <?php echo htmlspecialchars($ban['ip_address']); ?></small>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo htmlspecialchars(substr($ban['reason'], 0, 50)); ?></td>
                                            <td>
                                                <?php if ($ban['is_permanent']): ?>
                                                    <span class="badge bg-danger ban-badge">Permanent</span>
                                                <?php else: ?>
                                                    <span class="badge bg-warning text-dark ban-badge">Temporary</span>
                                                <?php endif; ?>
                                                <?php if ($ban['is_ip_ban']): ?>
                                                    <span class="badge bg-dark ban-badge">IP Ban</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <small><?php echo date('M d, Y', $ban['created_at']); ?></small>
                                            </td>
                                            <td>
                                                <?php if ($ban['is_permanent']): ?>
                                                    <small class="text-muted">Never</small>
                                                <?php else: ?>
                                                    <small><?php echo date('M d, Y', $ban['expires_at']); ?></small>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <form method="POST" style="display: inline;">
                                                    <input type="hidden" name="user_id" value="<?php echo $ban['user_id']; ?>">
                                                    <button type="submit" name="unban_user" class="btn btn-success btn-sm"
                                                            onclick="return confirm('Unban this user?')">
                                                        <i class="bi bi-unlock"></i> Unban
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
                
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-header bg-dark text-white">
                            <i class="bi bi-plus-circle"></i> Ban User
                        </div>
                        <div class="card-body">
                            <form method="POST">
                                <div class="mb-3">
                                    <label class="form-label">User ID</label>
                                    <input type="text" name="user_id" class="form-control" required 
                                           placeholder="user_xxx">
                                    <small class="text-muted">Find user ID in user management</small>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">Reason</label>
                                    <textarea name="reason" class="form-control" rows="3" required
                                              placeholder="Explain why this user is being banned..."></textarea>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">Duration</label>
                                    <select name="duration" class="form-select" required>
                                        <option value="0">Permanent</option>
                                        <option value="3600">1 Hour</option>
                                        <option value="86400">1 Day</option>
                                        <option value="604800">7 Days</option>
                                        <option value="2592000">30 Days</option>
                                    </select>
                                </div>
                                
                                <div class="mb-3 form-check">
                                    <input type="checkbox" name="ip_ban" class="form-check-input" id="ipBanCheck">
                                    <label class="form-check-label" for="ipBanCheck">
                                        Also ban IP address
                                    </label>
                                </div>
                                
                                <button type="submit" name="ban_user" class="btn btn-danger w-100">
                                    <i class="bi bi-ban"></i> Ban User
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            
        <?php elseif ($action === 'logs'): ?>
            <!-- Logs Tab -->
            <div class="row">
                <div class="col-12">
                    <h4 class="mb-3">Moderation Logs (Last 50)</h4>
                    
                    <?php if (empty($modLogs)): ?>
                        <div class="alert alert-info">
                            <i class="bi bi-info-circle"></i> No moderation logs yet.
                        </div>
                    <?php else: ?>
                        <div class="card">
                            <div class="card-body">
                                <?php foreach ($modLogs as $log): ?>
                                    <div class="mod-log-entry">
                                        <div class="d-flex justify-content-between align-items-start">
                                            <div>
                                                <span class="badge bg-<?php 
                                                    echo match($log['action']) {
                                                        'ban_user' => 'danger',
                                                        'unban_user' => 'success',
                                                        'process_report' => 'warning',
                                                        default => 'secondary'
                                                    };
                                                ?>">
                                                    <?php echo htmlspecialchars(str_replace('_', ' ', ucfirst($log['action']))); ?>
                                                </span>
                                                <small class="text-muted ms-2">
                                                    <?php 
                                                        $moderator = $db->get('users', $log['moderator_id']);
                                                        echo $moderator ? htmlspecialchars($moderator['username']) : 'System';
                                                    ?>
                                                </small>
                                                <p class="mb-0 mt-1">
                                                    <small><?php echo htmlspecialchars($log['reason']); ?></small>
                                                </p>
                                            </div>
                                            <small class="text-muted text-nowrap">
                                                <?php echo date('M d, Y H:i:s', $log['timestamp']); ?>
                                            </small>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
