<?php
/**
 * Admin Tag Aliases Management
 */

if (!$auth->isLoggedIn() || !$auth->isAdmin()) {
    redirect('index.php?page=login');
}

require_once 'includes/tag_aliases.php';

$aliasSystem = getTagAliasSystem();
$message = '';
$error = '';

// Handle add alias
if (isset($_POST['add_alias'])) {
    $alias = trim($_POST['alias'] ?? '');
    $canonical = trim($_POST['canonical'] ?? '');
    
    if (empty($alias) || empty($canonical)) {
        $error = 'Both alias and canonical tag are required';
    } elseif ($alias === $canonical) {
        $error = 'Alias and canonical tag cannot be the same';
    } else {
        if ($aliasSystem->addAlias($alias, $canonical)) {
            $message = "Alias added: '$alias' → '$canonical'";
        } else {
            $error = 'Failed to add alias (possible circular reference)';
        }
    }
}

// Handle remove alias
if (isset($_GET['action']) && $_GET['action'] === 'remove' && isset($_GET['alias'])) {
    if ($aliasSystem->removeAlias($_GET['alias'])) {
        $message = 'Alias removed successfully';
    } else {
        $error = 'Failed to remove alias';
    }
    redirect('index.php?page=admin_tags');
}

// Handle migrate tag
if (isset($_POST['migrate_tag'])) {
    $oldTag = trim($_POST['old_tag'] ?? '');
    $newTag = trim($_POST['new_tag'] ?? '');
    
    if (empty($oldTag) || empty($newTag)) {
        $error = 'Both old and new tags are required';
    } else {
        $updated = $aliasSystem->migrateTag($oldTag, $newTag);
        $message = "Migrated $updated images from '$oldTag' to '$newTag'";
    }
}

$stats = $aliasSystem->getStats();
$aliases = $stats['aliases'];

// Get all unique tags from images for autocomplete
$allImages = $db->getAll('images');
$allTags = [];
foreach ($allImages as $image) {
    if (isset($image['tags']) && is_array($image['tags'])) {
        $allTags = array_merge($allTags, $image['tags']);
    }
}
$allTags = array_unique($allTags);
sort($allTags);

require 'templates/header.php';
?>

<style>
.alias-entry {
    padding: 10px;
    border-bottom: 1px solid #dee2e6;
}
.alias-entry:hover {
    background-color: #f8f9fa;
}
</style>

<div class="container mt-4">
    <h2><i class="bi bi-tags"></i> Tag Aliases Management</h2>
    <p class="text-muted">Redirect old or alternate tag names to canonical tags</p>
    
    <?php if ($message): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="bi bi-check-circle"></i> <?php echo htmlspecialchars($message); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <i class="bi bi-exclamation-triangle"></i> <?php echo htmlspecialchars($error); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <div class="row">
        <div class="col-md-8">
            <div class="card mb-4">
                <div class="card-header">
                    <strong>Tag Aliases (<?php echo count($aliases); ?>)</strong>
                </div>
                <div class="card-body p-0">
                    <?php if (empty($aliases)): ?>
                        <div class="p-3 text-muted">
                            No tag aliases defined yet. Add one using the form on the right.
                        </div>
                    <?php else: ?>
                        <div style="max-height: 600px; overflow-y: auto;">
                            <?php foreach ($aliases as $alias => $canonical): ?>
                                <div class="alias-entry d-flex justify-content-between align-items-center">
                                    <div>
                                        <code class="text-primary"><?php echo htmlspecialchars($alias); ?></code>
                                        <i class="bi bi-arrow-right mx-2"></i>
                                        <strong><?php echo htmlspecialchars($canonical); ?></strong>
                                    </div>
                                    <a href="index.php?page=admin_tags&action=remove&alias=<?php echo urlencode($alias); ?>" 
                                       class="btn btn-sm btn-danger"
                                       onclick="return confirm('Remove this alias?')">
                                        <i class="bi bi-trash"></i>
                                    </a>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <strong>Statistics</strong>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <strong>Total Aliases:</strong> <?php echo $stats['total_aliases']; ?>
                        </div>
                        <div class="col-md-6">
                            <strong>Canonical Tags:</strong> <?php echo $stats['canonical_tags']; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="card mb-3">
                <div class="card-header">
                    <strong>Add Tag Alias</strong>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Alias Tag</label>
                            <input type="text" name="alias" class="form-control" 
                                   placeholder="pony" required list="existingTags">
                            <small class="text-muted">The tag to redirect from</small>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Canonical Tag</label>
                            <input type="text" name="canonical" class="form-control" 
                                   placeholder="mlp" required list="existingTags">
                            <small class="text-muted">The tag to redirect to</small>
                        </div>
                        
                        <button type="submit" name="add_alias" class="btn btn-primary w-100">
                            <i class="bi bi-plus-circle"></i> Add Alias
                        </button>
                    </form>
                    
                    <datalist id="existingTags">
                        <?php foreach ($allTags as $tag): ?>
                            <option value="<?php echo htmlspecialchars($tag); ?>">
                        <?php endforeach; ?>
                    </datalist>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <strong>Bulk Tag Migration</strong>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Old Tag</label>
                            <input type="text" name="old_tag" class="form-control" 
                                   placeholder="old_name" required list="existingTags">
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">New Tag</label>
                            <input type="text" name="new_tag" class="form-control" 
                                   placeholder="new_name" required list="existingTags">
                        </div>
                        
                        <button type="submit" name="migrate_tag" class="btn btn-warning w-100"
                                onclick="return confirm('This will update all images using the old tag. Continue?')">
                            <i class="bi bi-arrow-repeat"></i> Migrate Tag
                        </button>
                        
                        <small class="text-muted d-block mt-2">
                            Updates all images using the old tag to use the new tag
                        </small>
                    </form>
                </div>
            </div>
            
            <div class="card mt-3">
                <div class="card-header">
                    <strong>How It Works</strong>
                </div>
                <div class="card-body">
                    <ul class="small mb-0">
                        <li>Tag aliases redirect old tags to new ones</li>
                        <li>When users search for an alias, they see results for the canonical tag</li>
                        <li>Aliases are resolved automatically when images are tagged</li>
                        <li>Use bulk migration to update existing images</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require 'templates/footer.php'; ?>
