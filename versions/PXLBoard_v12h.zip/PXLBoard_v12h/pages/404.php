<?php
/**
 * 404 Page
 */

require 'templates/header.php';
?>

<div class="container mt-5">
    <div class="text-center">
        <h1 class="display-1">404</h1>
        <h2>Page Not Found</h2>
        <p class="text-muted">The page you're looking for doesn't exist.</p>
        <a href="index.php" class="btn btn-primary">Go Home</a>
    </div>
</div>

<?php require 'templates/footer.php'; ?>
