<?php
/**
 * TGP (Thumbnail Gallery Post) Browse Page
 */

require_once 'includes/tgp_manager.php';

$tgpManager = new TGPManager($db);

$page_num = isset($_GET['p']) ? max(1, intval($_GET['p'])) : 1;
$perPage = 12;
$offset = ($page_num - 1) * $perPage;

$filters = [
    'category' => $_GET['category'] ?? '',
    'sort' => $_GET['sort'] ?? 'newest',
    'status' => 'published'
];

$allPosts = $tgpManager->getPosts($filters);
$totalPosts = count($allPosts);
$posts = array_slice($allPosts, $offset, $perPage);
$totalPages = ceil($totalPosts / $perPage);

// Get featured posts
$featuredPosts = $tgpManager->getFeaturedPosts(3);

// Get categories
$categories = [
    'general' => 'General',
    'art' => 'Art',
    'photography' => 'Photography',
    'design' => 'Design',
    'nature' => 'Nature',
    'urban' => 'Urban',
    'abstract' => 'Abstract',
    'portraits' => 'Portraits'
];

require 'templates/header.php';
?>

<div class="tgp-browse">
    <!-- Header -->
    <div class="tgp-header py-5" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white;">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h1 class="display-4 mb-2">
                        <i class="bi bi-grid-3x3-gap"></i> Gallery Collections
                    </h1>
                    <p class="lead mb-0">Curated collections of images by community members</p>
                </div>
                <div class="col-md-4 text-md-end mt-3 mt-md-0">
                    <?php if ($auth->isLoggedIn()): ?>
                        <a href="index.php?page=tgp_create" class="btn btn-light btn-lg">
                            <i class="bi bi-plus-circle"></i> Create Collection
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="container my-5">
        <!-- Featured Collections -->
        <?php if (!empty($featuredPosts)): ?>
            <div class="featured-section mb-5">
                <h2 class="mb-4">
                    <i class="bi bi-star-fill text-warning"></i> Featured Collections
                </h2>
                <div class="row g-4">
                    <?php foreach ($featuredPosts as $featured): ?>
                        <div class="col-md-4">
                            <div class="card featured-card h-100 shadow">
                                <div class="position-relative">
                                    <?php if (!empty($featured['images'])): ?>
                                        <?php $firstImage = $db->get('images', $featured['images'][0]); ?>
                                        <?php if ($firstImage): ?>
                                            <img src="uploads/thumbs/<?php echo escape($firstImage['filename']); ?>" 
                                                 class="card-img-top" 
                                                 alt="<?php echo escape($featured['title']); ?>"
                                                 style="height: 250px; object-fit: cover;">
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    <div class="featured-badge">
                                        <span class="badge bg-warning">
                                            <i class="bi bi-star-fill"></i> Featured
                                        </span>
                                    </div>
                                    <div class="image-count-badge">
                                        <span class="badge bg-dark">
                                            <i class="bi bi-images"></i> <?php echo count($featured['images']); ?> images
                                        </span>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <h5 class="card-title">
                                        <a href="index.php?page=tgp_view&id=<?php echo $featured['id']; ?>" class="text-decoration-none">
                                            <?php echo escape($featured['title']); ?>
                                        </a>
                                    </h5>
                                    <p class="card-text text-muted small">
                                        <?php echo escape(substr($featured['description'], 0, 100)); ?>...
                                    </p>
                                    <div class="d-flex justify-content-between align-items-center small text-muted">
                                        <span>
                                            <i class="bi bi-person"></i> <?php echo escape($featured['author']); ?>
                                        </span>
                                        <span>
                                            <i class="bi bi-eye"></i> <?php echo number_format($featured['views']); ?>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>

        <!-- Filters -->
        <div class="row mb-4">
            <div class="col-md-8">
                <div class="btn-group" role="group">
                    <a href="?page=tgp" class="btn btn-outline-primary <?php echo empty($filters['category']) ? 'active' : ''; ?>">
                        All
                    </a>
                    <?php foreach ($categories as $catKey => $catName): ?>
                        <a href="?page=tgp&category=<?php echo $catKey; ?>" 
                           class="btn btn-outline-primary <?php echo $filters['category'] === $catKey ? 'active' : ''; ?>">
                            <?php echo $catName; ?>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>
            <div class="col-md-4 text-md-end mt-3 mt-md-0">
                <select class="form-select" onchange="window.location.href='?page=tgp&category=<?php echo $filters['category']; ?>&sort='+this.value">
                    <option value="newest" <?php echo $filters['sort'] === 'newest' ? 'selected' : ''; ?>>Newest First</option>
                    <option value="popular" <?php echo $filters['sort'] === 'popular' ? 'selected' : ''; ?>>Most Viewed</option>
                    <option value="likes" <?php echo $filters['sort'] === 'likes' ? 'selected' : ''; ?>>Most Liked</option>
                    <option value="oldest" <?php echo $filters['sort'] === 'oldest' ? 'selected' : ''; ?>>Oldest First</option>
                </select>
            </div>
        </div>

        <!-- Collections Grid -->
        <?php if (empty($posts)): ?>
            <div class="text-center py-5">
                <i class="bi bi-inbox text-muted" style="font-size: 5rem;"></i>
                <h3 class="mt-3">No collections found</h3>
                <p class="text-muted">Be the first to create a collection!</p>
                <?php if ($auth->isLoggedIn()): ?>
                    <a href="index.php?page=tgp_create" class="btn btn-primary">
                        <i class="bi bi-plus-circle"></i> Create Collection
                    </a>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <div class="row g-4">
                <?php foreach ($posts as $post): ?>
                    <div class="col-lg-3 col-md-4 col-sm-6">
                        <div class="card tgp-card h-100 shadow-sm">
                            <div class="position-relative">
                                <?php if (!empty($post['images'])): ?>
                                    <?php $firstImage = $db->get('images', $post['images'][0]); ?>
                                    <?php if ($firstImage): ?>
                                        <a href="index.php?page=tgp_view&id=<?php echo $post['id']; ?>">
                                            <img src="uploads/thumbs/<?php echo escape($firstImage['filename']); ?>" 
                                                 class="card-img-top" 
                                                 alt="<?php echo escape($post['title']); ?>"
                                                 style="height: 200px; object-fit: cover;">
                                        </a>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <div class="image-count-badge">
                                    <span class="badge bg-dark bg-opacity-75">
                                        <i class="bi bi-images"></i> <?php echo count($post['images']); ?>
                                    </span>
                                </div>
                                <?php if ($post['is_featured'] ?? false): ?>
                                    <div class="featured-badge">
                                        <span class="badge bg-warning">
                                            <i class="bi bi-star-fill"></i>
                                        </span>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="card-body">
                                <h6 class="card-title">
                                    <a href="index.php?page=tgp_view&id=<?php echo $post['id']; ?>" class="text-decoration-none">
                                        <?php echo escape($post['title']); ?>
                                    </a>
                                </h6>
                                <?php if (!empty($post['description'])): ?>
                                    <p class="card-text small text-muted">
                                        <?php echo escape(substr($post['description'], 0, 60)); ?>...
                                    </p>
                                <?php endif; ?>
                                <div class="d-flex justify-content-between align-items-center">
                                    <small class="text-muted">
                                        <i class="bi bi-person"></i> <?php echo escape($post['author']); ?>
                                    </small>
                                    <div class="small text-muted">
                                        <i class="bi bi-eye"></i> <?php echo number_format($post['views']); ?>
                                        <i class="bi bi-heart ms-2"></i> <?php echo number_format($post['likes'] ?? 0); ?>
                                    </div>
                                </div>
                                <?php if (!empty($post['tags'])): ?>
                                    <div class="mt-2">
                                        <?php foreach (array_slice($post['tags'], 0, 3) as $tag): ?>
                                            <span class="badge bg-secondary"><?php echo escape($tag); ?></span>
                                        <?php endforeach; ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- Pagination -->
            <?php if ($totalPages > 1): ?>
                <nav class="mt-5" aria-label="Collection pagination">
                    <ul class="pagination justify-content-center">
                        <?php if ($page_num > 1): ?>
                            <li class="page-item">
                                <a class="page-link" href="?page=tgp&category=<?php echo $filters['category']; ?>&sort=<?php echo $filters['sort']; ?>&p=<?php echo $page_num - 1; ?>">
                                    Previous
                                </a>
                            </li>
                        <?php endif; ?>
                        
                        <?php for ($i = max(1, $page_num - 2); $i <= min($totalPages, $page_num + 2); $i++): ?>
                            <li class="page-item <?php echo $i === $page_num ? 'active' : ''; ?>">
                                <a class="page-link" href="?page=tgp&category=<?php echo $filters['category']; ?>&sort=<?php echo $filters['sort']; ?>&p=<?php echo $i; ?>">
                                    <?php echo $i; ?>
                                </a>
                            </li>
                        <?php endfor; ?>
                        
                        <?php if ($page_num < $totalPages): ?>
                            <li class="page-item">
                                <a class="page-link" href="?page=tgp&category=<?php echo $filters['category']; ?>&sort=<?php echo $filters['sort']; ?>&p=<?php echo $page_num + 1; ?>">
                                    Next
                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </nav>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>

<style>
.tgp-card {
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.tgp-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(0,0,0,0.2) !important;
}

.featured-card {
    border: 2px solid #ffc107;
}

.image-count-badge {
    position: absolute;
    top: 10px;
    right: 10px;
}

.featured-badge {
    position: absolute;
    top: 10px;
    left: 10px;
}

.card-img-top {
    transition: transform 0.3s ease;
}

.tgp-card:hover .card-img-top {
    transform: scale(1.05);
}

.card {
    overflow: hidden;
}
</style>

<?php require 'templates/footer.php'; ?>
