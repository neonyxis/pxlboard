<?php
/**
 * TGP Create Page - Create Thumbnail Gallery Posts
 */

if (!$auth->isLoggedIn()) {
    redirect('index.php?page=login');
}

require_once 'includes/tgp_manager.php';

$tgpManager = new TGPManager($db);
$user = $auth->getCurrentUser();

$message = '';
$error = '';

// Get user's images for selection
$userImages = array_filter($db->getAll('images'), function($img) use ($user) {
    return isset($img['uploader_id']) && $img['uploader_id'] === $user['id'];
});

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_tgp'])) {
    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $selectedImages = $_POST['images'] ?? [];
    $tags = array_filter(array_map('trim', explode(',', $_POST['tags'] ?? '')));
    $category = $_POST['category'] ?? 'general';
    $status = $_POST['status'] ?? 'published';
    
    // Validation
    if (empty($title)) {
        $error = 'Title is required';
    } elseif (empty($selectedImages)) {
        $error = 'Please select at least one image';
    } else {
        $result = $tgpManager->createPost([
            'title' => $title,
            'description' => $description,
            'images' => $selectedImages,
            'tags' => $tags,
            'category' => $category,
            'author' => $user['username'],
            'status' => $status
        ], $user['id']);
        
        if ($result['success']) {
            $message = 'Collection created successfully!';
            // Redirect to view page
            header('Location: index.php?page=tgp_view&id=' . $result['post_id']);
            exit;
        } else {
            $error = $result['error'];
        }
    }
}

// Categories
$categories = [
    'general' => 'General',
    'art' => 'Art',
    'photography' => 'Photography',
    'design' => 'Design',
    'nature' => 'Nature',
    'urban' => 'Urban',
    'abstract' => 'Abstract',
    'portraits' => 'Portraits',
    'landscapes' => 'Landscapes',
    'animals' => 'Animals',
    'technology' => 'Technology',
    'food' => 'Food & Drink',
    'fashion' => 'Fashion',
    'sports' => 'Sports',
    'other' => 'Other'
];

require 'templates/header.php';
?>

<div class="container my-5">
    <div class="row">
        <div class="col-lg-8 offset-lg-2">
            <div class="card shadow-lg">
                <div class="card-header bg-primary text-white">
                    <h3 class="mb-0">
                        <i class="bi bi-plus-circle"></i> Create Gallery Collection
                    </h3>
                </div>
                <div class="card-body">
                    <?php if ($message): ?>
                        <div class="alert alert-success alert-dismissible fade show">
                            <i class="bi bi-check-circle"></i> <?php echo htmlspecialchars($message); ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($error): ?>
                        <div class="alert alert-danger alert-dismissible fade show">
                            <i class="bi bi-exclamation-triangle"></i> <?php echo htmlspecialchars($error); ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>
                    
                    <form method="POST" action="">
                        <!-- Title -->
                        <div class="mb-4">
                            <label for="title" class="form-label fw-bold">
                                Collection Title <span class="text-danger">*</span>
                            </label>
                            <input type="text" class="form-control form-control-lg" id="title" name="title" 
                                   placeholder="Enter a descriptive title for your collection" required>
                            <div class="form-text">Give your collection a catchy, descriptive title</div>
                        </div>
                        
                        <!-- Description -->
                        <div class="mb-4">
                            <label for="description" class="form-label fw-bold">Description</label>
                            <textarea class="form-control" id="description" name="description" rows="4" 
                                      placeholder="Describe your collection, its theme, or inspiration..."></textarea>
                            <div class="form-text">Optional: Tell viewers about your collection</div>
                        </div>
                        
                        <!-- Category -->
                        <div class="mb-4">
                            <label for="category" class="form-label fw-bold">Category</label>
                            <select class="form-select" id="category" name="category">
                                <?php foreach ($categories as $key => $name): ?>
                                    <option value="<?php echo $key; ?>"><?php echo $name; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <!-- Tags -->
                        <div class="mb-4">
                            <label for="tags" class="form-label fw-bold">Tags</label>
                            <input type="text" class="form-control" id="tags" name="tags" 
                                   placeholder="landscape, nature, sunset">
                            <div class="form-text">Separate tags with commas to help others find your collection</div>
                        </div>
                        
                        <!-- Image Selection -->
                        <div class="mb-4">
                            <label class="form-label fw-bold">
                                Select Images <span class="text-danger">*</span>
                                <span class="badge bg-secondary" id="selectedCount">0 selected</span>
                            </label>
                            
                            <?php if (empty($userImages)): ?>
                                <div class="alert alert-warning">
                                    <i class="bi bi-exclamation-triangle"></i> You don't have any uploaded images yet.
                                    <a href="index.php?page=upload" class="alert-link">Upload some images first</a>.
                                </div>
                            <?php else: ?>
                                <div class="row g-2 image-selector" id="imageSelector">
                                    <?php foreach ($userImages as $image): ?>
                                        <div class="col-lg-3 col-md-4 col-sm-6">
                                            <div class="image-select-item">
                                                <input type="checkbox" name="images[]" value="<?php echo $image['id']; ?>" 
                                                       id="img-<?php echo $image['id']; ?>" class="image-checkbox">
                                                <label for="img-<?php echo $image['id']; ?>" class="image-label">
                                                    <img src="uploads/thumbs/<?php echo escape($image['filename']); ?>" 
                                                         alt="<?php echo escape($image['title']); ?>"
                                                         class="img-fluid">
                                                    <div class="image-overlay">
                                                        <i class="bi bi-check-circle-fill"></i>
                                                    </div>
                                                    <div class="image-info">
                                                        <small><?php echo escape($image['title'] ?? 'Untitled'); ?></small>
                                                    </div>
                                                </label>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                                
                                <div class="form-text mt-3">
                                    Click on images to select them for your collection. Selected images will have a checkmark.
                                </div>
                            <?php endif; ?>
                        </div>
                        
                        <!-- Status -->
                        <div class="mb-4">
                            <label class="form-label fw-bold">Status</label>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="status" id="statusPublished" 
                                       value="published" checked>
                                <label class="form-check-label" for="statusPublished">
                                    <strong>Published</strong> - Visible to everyone
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="status" id="statusDraft" 
                                       value="draft">
                                <label class="form-check-label" for="statusDraft">
                                    <strong>Draft</strong> - Only visible to you
                                </label>
                            </div>
                        </div>
                        
                        <!-- Submit Buttons -->
                        <div class="d-flex justify-content-between">
                            <a href="index.php?page=tgp" class="btn btn-outline-secondary">
                                <i class="bi bi-x-circle"></i> Cancel
                            </a>
                            <button type="submit" name="create_tgp" class="btn btn-primary btn-lg">
                                <i class="bi bi-check-circle"></i> Create Collection
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Tips Card -->
            <div class="card mt-4 border-info">
                <div class="card-header bg-info text-white">
                    <h5 class="mb-0"><i class="bi bi-lightbulb"></i> Tips for Great Collections</h5>
                </div>
                <div class="card-body">
                    <ul class="mb-0">
                        <li>Choose images that share a common theme or style</li>
                        <li>Add a descriptive title that tells viewers what to expect</li>
                        <li>Use relevant tags to help others discover your collection</li>
                        <li>Include 5-15 images for the best viewing experience</li>
                        <li>Write a description to give context or tell a story</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.image-selector {
    max-height: 500px;
    overflow-y: auto;
    padding: 10px;
    border: 1px solid #dee2e6;
    border-radius: 8px;
    background: #f8f9fa;
}

.image-select-item {
    position: relative;
    border-radius: 8px;
    overflow: hidden;
}

.image-checkbox {
    display: none;
}

.image-label {
    display: block;
    position: relative;
    cursor: pointer;
    margin-bottom: 0;
    border: 3px solid transparent;
    border-radius: 8px;
    overflow: hidden;
    transition: all 0.3s ease;
}

.image-label img {
    display: block;
    width: 100%;
    height: 150px;
    object-fit: cover;
}

.image-overlay {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 123, 255, 0.7);
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    transition: opacity 0.3s ease;
}

.image-overlay i {
    font-size: 3rem;
    color: white;
}

.image-checkbox:checked + .image-label {
    border-color: #007bff;
    box-shadow: 0 0 10px rgba(0, 123, 255, 0.5);
}

.image-checkbox:checked + .image-label .image-overlay {
    opacity: 1;
}

.image-label:hover {
    transform: scale(1.02);
}

.image-info {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    background: linear-gradient(to top, rgba(0,0,0,0.8), transparent);
    padding: 8px;
    color: white;
}

.image-info small {
    display: block;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const checkboxes = document.querySelectorAll('.image-checkbox');
    const countBadge = document.getElementById('selectedCount');
    
    function updateCount() {
        const checked = document.querySelectorAll('.image-checkbox:checked').length;
        countBadge.textContent = checked + ' selected';
        countBadge.className = 'badge ' + (checked > 0 ? 'bg-primary' : 'bg-secondary');
    }
    
    checkboxes.forEach(checkbox => {
        checkbox.addEventListener('change', updateCount);
    });
    
    updateCount();
});
</script>

<?php require 'templates/footer.php'; ?>
