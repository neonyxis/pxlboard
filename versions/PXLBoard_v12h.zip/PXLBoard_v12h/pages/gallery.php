<?php
/**
 * Gallery View Page
 */

require_once 'includes/hiding.php';

$page_num = isset($_GET['p']) ? max(1, intval($_GET['p'])) : 1;
$offset = ($page_num - 1) * ITEMS_PER_PAGE;
$view = $_GET['view'] ?? 'grid'; // grid or list
$sort = $_GET['sort'] ?? 'newest'; // newest, popular, rating

// Advanced filter parameters
$filterUploader = $_GET['uploader'] ?? '';
$filterChannel = $_GET['channel'] ?? '';
$filterTag = $_GET['tag'] ?? '';
$filterRating = $_GET['min_rating'] ?? '';
$filterDateFrom = $_GET['date_from'] ?? '';
$filterDateTo = $_GET['date_to'] ?? '';

$images = $db->getAll('images');

// Filter out hidden images for logged-in users
if ($auth->isLoggedIn()) {
    $images = filterHiddenImages($images);
}

// Apply filters
if (!empty($filterUploader)) {
    $images = array_filter($images, function($img) use ($filterUploader) {
        return stripos($img['uploader'] ?? '', $filterUploader) !== false;
    });
}

if (!empty($filterChannel)) {
    $images = array_filter($images, function($img) use ($filterChannel) {
        return ($img['channel'] ?? '') === $filterChannel;
    });
}

if (!empty($filterTag)) {
    $images = array_filter($images, function($img) use ($filterTag) {
        $tags = $img['tags'] ?? [];
        foreach ($tags as $tag) {
            if (stripos($tag, $filterTag) !== false) {
                return true;
            }
        }
        return false;
    });
}

if (!empty($filterRating) && is_numeric($filterRating)) {
    $minRating = floatval($filterRating);
    $images = array_filter($images, function($img) use ($minRating) {
        return ($img['rating'] ?? 0) >= $minRating;
    });
}

if (!empty($filterDateFrom)) {
    $dateFrom = strtotime($filterDateFrom);
    if ($dateFrom !== false) {
        $images = array_filter($images, function($img) use ($dateFrom) {
            return ($img['uploaded_at'] ?? 0) >= $dateFrom;
        });
    }
}

if (!empty($filterDateTo)) {
    $dateTo = strtotime($filterDateTo . ' 23:59:59');
    if ($dateTo !== false) {
        $images = array_filter($images, function($img) use ($dateTo) {
            return ($img['uploaded_at'] ?? 0) <= $dateTo;
        });
    }
}

// Apply sorting
switch ($sort) {
    case 'popular':
        usort($images, function($a, $b) {
            return ($b['views'] ?? 0) - ($a['views'] ?? 0);
        });
        break;
    case 'rating':
        usort($images, function($a, $b) {
            return ($b['rating'] ?? 0) - ($a['rating'] ?? 0);
        });
        break;
    case 'favorites':
        usort($images, function($a, $b) {
            return ($b['favorites'] ?? 0) - ($a['favorites'] ?? 0);
        });
        break;
    case 'newest':
    default:
        usort($images, function($a, $b) {
            return ($b['uploaded_at'] ?? 0) - ($a['uploaded_at'] ?? 0);
        });
        break;
}

$totalImages = count($images);
$images = array_slice($images, $offset, ITEMS_PER_PAGE);
$totalPages = ceil($totalImages / ITEMS_PER_PAGE);

require 'templates/header.php';
?>

<div class="container-fluid mt-4">
    <div class="row">
        <!-- Filters Sidebar -->
        <div class="col-lg-3 mb-4">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <strong><i class="bi bi-funnel"></i> Filters</strong>
                    <?php if (!empty($filterUploader) || !empty($filterChannel) || !empty($filterTag) || !empty($filterRating) || !empty($filterDateFrom) || !empty($filterDateTo)): ?>
                        <a href="?page=gallery&view=<?php echo $view; ?>&sort=<?php echo $sort; ?>" 
                           class="btn btn-sm btn-outline-secondary">Clear All</a>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <form method="GET" action="index.php">
                        <input type="hidden" name="page" value="gallery">
                        <input type="hidden" name="view" value="<?php echo $view; ?>">
                        <input type="hidden" name="sort" value="<?php echo $sort; ?>">
                        
                        <!-- Uploader Filter -->
                        <div class="mb-3">
                            <label class="form-label small"><strong>Uploader</strong></label>
                            <input type="text" name="uploader" class="form-control form-control-sm" 
                                   placeholder="Username" value="<?php echo escape($filterUploader); ?>">
                        </div>
                        
                        <!-- Channel Filter -->
                        <div class="mb-3">
                            <label class="form-label small"><strong>Channel</strong></label>
                            <select name="channel" class="form-select form-select-sm">
                                <option value="">All Channels</option>
                                <?php
                                $channels = $db->getAll('channels');
                                foreach ($channels as $ch):
                                ?>
                                    <option value="<?php echo $ch['id']; ?>" 
                                            <?php echo $filterChannel === $ch['id'] ? 'selected' : ''; ?>>
                                        <?php echo escape($ch['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <!-- Tag Filter -->
                        <div class="mb-3">
                            <label class="form-label small"><strong>Tag</strong></label>
                            <input type="text" name="tag" class="form-control form-control-sm" 
                                   placeholder="Tag name" value="<?php echo escape($filterTag); ?>">
                        </div>
                        
                        <!-- Rating Filter -->
                        <div class="mb-3">
                            <label class="form-label small"><strong>Minimum Rating</strong></label>
                            <select name="min_rating" class="form-select form-select-sm">
                                <option value="">Any Rating</option>
                                <option value="1" <?php echo $filterRating === '1' ? 'selected' : ''; ?>>1+ Stars</option>
                                <option value="2" <?php echo $filterRating === '2' ? 'selected' : ''; ?>>2+ Stars</option>
                                <option value="3" <?php echo $filterRating === '3' ? 'selected' : ''; ?>>3+ Stars</option>
                                <option value="4" <?php echo $filterRating === '4' ? 'selected' : ''; ?>>4+ Stars</option>
                                <option value="5" <?php echo $filterRating === '5' ? 'selected' : ''; ?>>5 Stars</option>
                            </select>
                        </div>
                        
                        <!-- Date Range Filter -->
                        <div class="mb-3">
                            <label class="form-label small"><strong>Date Range</strong></label>
                            <input type="date" name="date_from" class="form-control form-control-sm mb-2" 
                                   placeholder="From" value="<?php echo escape($filterDateFrom); ?>">
                            <input type="date" name="date_to" class="form-control form-control-sm" 
                                   placeholder="To" value="<?php echo escape($filterDateTo); ?>">
                        </div>
                        
                        <button type="submit" class="btn btn-primary btn-sm w-100">
                            <i class="bi bi-search"></i> Apply Filters
                        </button>
                    </form>
                    
                    <!-- Active Filters Display -->
                    <?php if (!empty($filterUploader) || !empty($filterChannel) || !empty($filterTag) || !empty($filterRating) || !empty($filterDateFrom) || !empty($filterDateTo)): ?>
                        <hr>
                        <div class="small">
                            <strong>Active Filters:</strong>
                            <div class="mt-2">
                                <?php if (!empty($filterUploader)): ?>
                                    <span class="badge bg-primary mb-1">
                                        Uploader: <?php echo escape($filterUploader); ?>
                                        <a href="?page=gallery&view=<?php echo $view; ?>&sort=<?php echo $sort; ?>&channel=<?php echo $filterChannel; ?>&tag=<?php echo $filterTag; ?>&min_rating=<?php echo $filterRating; ?>&date_from=<?php echo $filterDateFrom; ?>&date_to=<?php echo $filterDateTo; ?>" 
                                           class="text-white ms-1">×</a>
                                    </span>
                                <?php endif; ?>
                                <?php if (!empty($filterChannel)): 
                                    $ch = $db->get('channels', $filterChannel);
                                ?>
                                    <span class="badge bg-primary mb-1">
                                        Channel: <?php echo escape($ch['name'] ?? 'Unknown'); ?>
                                        <a href="?page=gallery&view=<?php echo $view; ?>&sort=<?php echo $sort; ?>&uploader=<?php echo $filterUploader; ?>&tag=<?php echo $filterTag; ?>&min_rating=<?php echo $filterRating; ?>&date_from=<?php echo $filterDateFrom; ?>&date_to=<?php echo $filterDateTo; ?>" 
                                           class="text-white ms-1">×</a>
                                    </span>
                                <?php endif; ?>
                                <?php if (!empty($filterTag)): ?>
                                    <span class="badge bg-primary mb-1">
                                        Tag: <?php echo escape($filterTag); ?>
                                        <a href="?page=gallery&view=<?php echo $view; ?>&sort=<?php echo $sort; ?>&uploader=<?php echo $filterUploader; ?>&channel=<?php echo $filterChannel; ?>&min_rating=<?php echo $filterRating; ?>&date_from=<?php echo $filterDateFrom; ?>&date_to=<?php echo $filterDateTo; ?>" 
                                           class="text-white ms-1">×</a>
                                    </span>
                                <?php endif; ?>
                                <?php if (!empty($filterRating)): ?>
                                    <span class="badge bg-primary mb-1">
                                        Rating: <?php echo $filterRating; ?>+ stars
                                        <a href="?page=gallery&view=<?php echo $view; ?>&sort=<?php echo $sort; ?>&uploader=<?php echo $filterUploader; ?>&channel=<?php echo $filterChannel; ?>&tag=<?php echo $filterTag; ?>&date_from=<?php echo $filterDateFrom; ?>&date_to=<?php echo $filterDateTo; ?>" 
                                           class="text-white ms-1">×</a>
                                    </span>
                                <?php endif; ?>
                                <?php if (!empty($filterDateFrom) || !empty($filterDateTo)): ?>
                                    <span class="badge bg-primary mb-1">
                                        Date: <?php echo $filterDateFrom ?: 'Any'; ?> - <?php echo $filterDateTo ?: 'Any'; ?>
                                        <a href="?page=gallery&view=<?php echo $view; ?>&sort=<?php echo $sort; ?>&uploader=<?php echo $filterUploader; ?>&channel=<?php echo $filterChannel; ?>&tag=<?php echo $filterTag; ?>&min_rating=<?php echo $filterRating; ?>" 
                                           class="text-white ms-1">×</a>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- Gallery Content -->
        <div class="col-lg-9">
    <div class="row mb-4">
        <div class="col-md-6">
            <h1>Gallery</h1>
            <p class="text-muted"><?php echo number_format($totalImages); ?> images</p>
        </div>
        <div class="col-md-6">
            <div class="d-flex justify-content-end gap-2">
                <div class="btn-group" role="group">
                    <a href="?page=gallery&view=grid&sort=<?php echo $sort; ?>" 
                       class="btn btn-<?php echo $view === 'grid' ? 'primary' : 'outline-primary'; ?>">
                        Grid View
                    </a>
                    <a href="?page=gallery&view=list&sort=<?php echo $sort; ?>" 
                       class="btn btn-<?php echo $view === 'list' ? 'primary' : 'outline-primary'; ?>">
                        List View
                    </a>
                </div>
                
                <select class="form-select" style="width: auto;" onchange="location.href='?page=gallery&view=<?php echo $view; ?>&sort='+this.value">
                    <option value="newest" <?php echo $sort === 'newest' ? 'selected' : ''; ?>>Newest</option>
                    <option value="popular" <?php echo $sort === 'popular' ? 'selected' : ''; ?>>Most Viewed</option>
                    <option value="rating" <?php echo $sort === 'rating' ? 'selected' : ''; ?>>Highest Rated</option>
                    <option value="favorites" <?php echo $sort === 'favorites' ? 'selected' : ''; ?>>Most Favorited</option>
                </select>
            </div>
        </div>
    </div>
    
    <?php if ($view === 'grid'): ?>
        <!-- Grid View - Squared Thumbnails (2 col mobile, 3 col desktop) -->
        <style>
            .gallery-grid {
                display: grid;
                grid-template-columns: repeat(2, 1fr);
                gap: 15px;
            }
            
            @media (min-width: 768px) {
                .gallery-grid {
                    grid-template-columns: repeat(3, 1fr);
                }
            }
            
            .gallery-item {
                background: #fff;
                border: 1px solid #dee2e6;
                border-radius: 8px;
                overflow: hidden;
                transition: all 0.3s ease;
                box-shadow: 0 2px 4px rgba(0,0,0,0.05);
            }
            
            .gallery-item:hover {
                transform: translateY(-4px);
                box-shadow: 0 6px 12px rgba(0,0,0,0.15);
                border-color: #0d6efd;
            }
            
            .gallery-item-image {
                position: relative;
                width: 100%;
                padding-bottom: 100%; /* 1:1 Aspect Ratio (Square) */
                background: #f8f9fa;
                overflow: hidden;
            }
            
            .gallery-item-image img {
                position: absolute;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                width: 100%;
                height: 100%;
                object-fit: cover;
            }
            
            .gallery-item-overlay {
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: rgba(0,0,0,0.6);
                opacity: 0;
                transition: opacity 0.3s ease;
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 10px;
            }
            
            .gallery-item:hover .gallery-item-overlay {
                opacity: 1;
            }
            
            .gallery-item-info {
                padding: 10px;
                background: #fff;
            }
            
            .gallery-actions {
                display: flex;
                justify-content: space-around;
                padding: 8px 10px;
                border-top: 1px solid #dee2e6;
                background: #f8f9fa;
            }
            
            .gallery-action-btn {
                background: none;
                border: none;
                color: #6c757d;
                font-size: 0.85rem;
                cursor: pointer;
                transition: all 0.2s;
                display: flex;
                align-items: center;
                gap: 4px;
                padding: 4px 8px;
                border-radius: 4px;
            }
            
            .gallery-action-btn:hover {
                background: #e9ecef;
                color: #0d6efd;
            }
            
            .gallery-action-btn.active {
                color: #dc3545;
            }
            
            .gallery-action-btn i {
                font-size: 1rem;
            }
        </style>
        
        <div class="gallery-grid">
            <?php foreach ($images as $image): 
                $hasLiked = false;
                $hasFavorited = false;
                
                if ($auth->isLoggedIn()) {
                    // Check if user has liked/favorited
                    $currentUserId = $_SESSION['user_id'];
                    $ratings = $db->getAll('ratings');
                    foreach ($ratings as $rating) {
                        if ($rating['image_id'] === $image['id'] && $rating['user_id'] === $currentUserId) {
                            $hasLiked = true;
                            break;
                        }
                    }
                    
                    $favorites = $db->getAll('favorites');
                    foreach ($favorites as $fav) {
                        if ($fav['image_id'] === $image['id'] && $fav['user_id'] === $currentUserId) {
                            $hasFavorited = true;
                            break;
                        }
                    }
                }
            ?>
                <div class="gallery-item">
                    <a href="index.php?page=image&id=<?php echo escape($image['id']); ?>" class="gallery-item-image">
                        <img src="uploads/thumbs/<?php echo escape($image['filename']); ?>" 
                             alt="<?php echo escape($image['title'] ?? 'Untitled'); ?>"
                             loading="lazy">
                        <div class="gallery-item-overlay">
                            <span class="badge bg-light text-dark">
                                <i class="bi bi-eye"></i> <?php echo number_format($image['views'] ?? 0); ?>
                            </span>
                        </div>
                    </a>
                    
                    <div class="gallery-item-info">
                        <h6 class="mb-1" style="font-size: 0.9rem; line-height: 1.3;">
                            <a href="index.php?page=image&id=<?php echo escape($image['id']); ?>" 
                               class="text-decoration-none text-dark">
                                <?php echo escape(mb_substr($image['title'] ?? 'Untitled', 0, 40)); ?>
                            </a>
                        </h6>
                        <small class="text-muted d-block" style="font-size: 0.75rem;">
                            by <?php echo escape($image['uploader'] ?? 'Unknown'); ?>
                        </small>
                    </div>
                    
                    <div class="gallery-actions">
                        <?php if ($auth->isLoggedIn()): ?>
                            <button class="gallery-action-btn <?php echo $hasLiked ? 'active' : ''; ?>" 
                                    onclick="likeImage('<?php echo $image['id']; ?>', this)"
                                    title="Like">
                                <i class="bi bi-heart<?php echo $hasLiked ? '-fill' : ''; ?>"></i>
                                <span><?php echo number_format($image['likes'] ?? 0); ?></span>
                            </button>
                            
                            <button class="gallery-action-btn" 
                                    onclick="location.href='index.php?page=image&id=<?php echo $image['id']; ?>#comments'"
                                    title="Comments">
                                <i class="bi bi-chat"></i>
                                <span><?php echo number_format($image['comments_count'] ?? 0); ?></span>
                            </button>
                            
                            <button class="gallery-action-btn <?php echo $hasFavorited ? 'active' : ''; ?>" 
                                    onclick="favoriteImage('<?php echo $image['id']; ?>', this)"
                                    title="Favorite">
                                <i class="bi bi-star<?php echo $hasFavorited ? '-fill' : ''; ?>"></i>
                                <span><?php echo number_format($image['favorites'] ?? 0); ?></span>
                            </button>
                        <?php else: ?>
                            <span class="gallery-action-btn" title="Likes">
                                <i class="bi bi-heart"></i>
                                <span><?php echo number_format($image['likes'] ?? 0); ?></span>
                            </span>
                            
                            <span class="gallery-action-btn" title="Comments">
                                <i class="bi bi-chat"></i>
                                <span><?php echo number_format($image['comments_count'] ?? 0); ?></span>
                            </span>
                            
                            <span class="gallery-action-btn" title="Favorites">
                                <i class="bi bi-star"></i>
                                <span><?php echo number_format($image['favorites'] ?? 0); ?></span>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        
        <script>
        function likeImage(imageId, button) {
            fetch('index.php?page=api&action=like', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'image_id=' + imageId
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const icon = button.querySelector('i');
                    const count = button.querySelector('span');
                    
                    if (data.liked) {
                        button.classList.add('active');
                        icon.classList.remove('bi-heart');
                        icon.classList.add('bi-heart-fill');
                        count.textContent = parseInt(count.textContent) + 1;
                    } else {
                        button.classList.remove('active');
                        icon.classList.remove('bi-heart-fill');
                        icon.classList.add('bi-heart');
                        count.textContent = Math.max(0, parseInt(count.textContent) - 1);
                    }
                }
            });
        }
        
        function favoriteImage(imageId, button) {
            fetch('index.php?page=api&action=favorite', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'image_id=' + imageId
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const icon = button.querySelector('i');
                    const count = button.querySelector('span');
                    
                    if (data.favorited) {
                        button.classList.add('active');
                        icon.classList.remove('bi-star');
                        icon.classList.add('bi-star-fill');
                        count.textContent = parseInt(count.textContent) + 1;
                    } else {
                        button.classList.remove('active');
                        icon.classList.remove('bi-star-fill');
                        icon.classList.add('bi-star');
                        count.textContent = Math.max(0, parseInt(count.textContent) - 1);
                    }
                }
            });
        }
        </script>
    <?php else: ?>
        <!-- List View -->
        <div class="list-group">
            <?php foreach ($images as $image): ?>
                <div class="list-group-item list-group-item-action">
                    <div class="row align-items-center">
                        <div class="col-md-2">
                            <a href="index.php?page=image&id=<?php echo escape($image['id']); ?>">
                                <img src="uploads/thumbs/<?php echo escape($image['filename']); ?>" 
                                     class="img-fluid rounded" 
                                     alt="<?php echo escape($image['title']); ?>"
                                     style="max-height: 100px;">
                            </a>
                        </div>
                        <div class="col-md-6">
                            <h5 class="mb-1">
                                <a href="index.php?page=image&id=<?php echo escape($image['id']); ?>" class="text-decoration-none">
                                    <?php echo escape($image['title'] ?? 'Untitled'); ?>
                                </a>
                            </h5>
                            <p class="mb-1 text-muted">
                                <?php echo escape(mb_substr($image['description'] ?? '', 0, 100)); ?>
                            </p>
                            <small class="text-muted">
                                by <?php echo escape($image['uploader']); ?> • 
                                <?php echo timeAgo($image['uploaded_at']); ?>
                            </small>
                        </div>
                        <div class="col-md-2">
                            <div class="tags">
                                <?php if (!empty($image['tags'])): ?>
                                    <?php foreach (array_slice($image['tags'], 0, 3) as $tag): ?>
                                        <a href="index.php?page=search&q=<?php echo urlencode($tag); ?>" class="badge bg-secondary">
                                            <?php echo escape($tag); ?>
                                        </a>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-2 text-end">
                            <div class="small text-muted">
                                <div>👁 <?php echo number_format($image['views']); ?> views</div>
                                <div>★ <?php echo number_format($image['favorites'] ?? 0); ?> favorites</div>
                                <div>💬 <?php echo number_format($image['comments_count'] ?? 0); ?> comments</div>
                                <?php if (isset($image['rating'])): ?>
                                    <div>⭐ <?php echo $image['rating']; ?>/5</div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    
    <?php if ($totalPages > 1): ?>
        <nav class="mt-4">
            <ul class="pagination justify-content-center">
                <?php if ($page_num > 1): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=gallery&view=<?php echo $view; ?>&sort=<?php echo $sort; ?>&p=<?php echo $page_num - 1; ?>">Previous</a>
                    </li>
                <?php endif; ?>
                
                <?php for ($i = max(1, $page_num - 2); $i <= min($totalPages, $page_num + 2); $i++): ?>
                    <li class="page-item <?php echo $i === $page_num ? 'active' : ''; ?>">
                        <a class="page-link" href="?page=gallery&view=<?php echo $view; ?>&sort=<?php echo $sort; ?>&p=<?php echo $i; ?>"><?php echo $i; ?></a>
                    </li>
                <?php endfor; ?>
                
                <?php if ($page_num < $totalPages): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=gallery&view=<?php echo $view; ?>&sort=<?php echo $sort; ?>&p=<?php echo $page_num + 1; ?>">Next</a>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>
    <?php endif; ?>
        </div><!-- End Gallery Content col-lg-9 -->
    </div><!-- End row with sidebar -->
</div><!-- End container-fluid -->

<?php require 'templates/footer.php'; ?>
