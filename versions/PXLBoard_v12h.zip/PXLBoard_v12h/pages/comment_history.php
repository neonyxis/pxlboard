<?php
/**
 * Comment Edit History Page
 */

$commentId = $_GET['id'] ?? '';
$comment = $db->get('comments', $commentId);

if (!$comment) {
    require 'pages/404.php';
    exit;
}

$image = $db->get('images', $comment['image_id']);

require 'templates/header.php';
?>

<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">
                    <h4><i class="bi bi-clock-history"></i> Comment Edit History</h4>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <a href="index.php?page=image&id=<?php echo htmlspecialchars($comment['image_id']); ?>" 
                           class="btn btn-sm btn-outline-primary">
                            <i class="bi bi-arrow-left"></i> Back to Image
                        </a>
                    </div>
                    
                    <div class="alert alert-info">
                        <strong>Comment by:</strong> <?php echo htmlspecialchars($comment['username']); ?>
                        <?php if ($image): ?>
                            on <a href="index.php?page=image&id=<?php echo htmlspecialchars($comment['image_id']); ?>">
                                <?php echo htmlspecialchars($image['title']); ?>
                            </a>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Current Version -->
                    <div class="card mb-3 border-primary">
                        <div class="card-header bg-primary text-white">
                            <strong>Current Version</strong>
                            <?php if (isset($comment['edited_at'])): ?>
                                <span class="float-end">
                                    Last edited <?php echo timeAgo($comment['edited_at']); ?>
                                    <?php if (isset($comment['last_editor'])): ?>
                                        by <?php echo htmlspecialchars($comment['last_editor']); ?>
                                    <?php endif; ?>
                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="card-body">
                            <p class="mb-0"><?php echo nl2br(htmlspecialchars($comment['comment'])); ?></p>
                        </div>
                    </div>
                    
                    <?php if (!empty($comment['edit_history'])): ?>
                        <h5 class="mt-4 mb-3">Previous Versions</h5>
                        <?php foreach (array_reverse($comment['edit_history']) as $index => $edit): ?>
                            <div class="card mb-3">
                                <div class="card-header">
                                    <strong>Version #<?php echo count($comment['edit_history']) - $index; ?></strong>
                                    <span class="text-muted float-end">
                                        <?php echo date('Y-m-d H:i', $edit['edited_at']); ?>
                                        by <?php echo htmlspecialchars($edit['edited_by']); ?>
                                    </span>
                                </div>
                                <div class="card-body">
                                    <?php if (!empty($edit['reason'])): ?>
                                        <div class="alert alert-secondary py-1 px-2 mb-2">
                                            <small><strong>Reason:</strong> <?php echo htmlspecialchars($edit['reason']); ?></small>
                                        </div>
                                    <?php endif; ?>
                                    <p class="mb-0"><?php echo nl2br(htmlspecialchars($edit['content'])); ?></p>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="alert alert-info">
                            <i class="bi bi-info-circle"></i> This comment has not been edited yet.
                        </div>
                    <?php endif; ?>
                    
                    <!-- Original Version -->
                    <div class="card border-secondary">
                        <div class="card-header bg-secondary text-white">
                            <strong>Original Version</strong>
                            <span class="float-end">
                                Posted <?php echo timeAgo($comment['created_at']); ?>
                            </span>
                        </div>
                        <div class="card-body">
                            <?php if (!empty($comment['edit_history'])): ?>
                                <p class="mb-0">
                                    <?php 
                                    $originalContent = end($comment['edit_history'])['content'];
                                    echo nl2br(htmlspecialchars($originalContent)); 
                                    ?>
                                </p>
                            <?php else: ?>
                                <p class="mb-0 text-muted">(Same as current version)</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require 'templates/footer.php'; ?>
