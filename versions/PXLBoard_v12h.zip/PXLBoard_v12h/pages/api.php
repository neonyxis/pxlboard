<?php
/**
 * API Endpoint
 * Handles AJAX requests for likes, favorites, reports, etc.
 */

header('Content-Type: application/json');

if (!$auth->isLoggedIn()) {
    echo json_encode(['success' => false, 'error' => 'Not authenticated']);
    exit;
}

$action = $_GET['action'] ?? $_POST['action'] ?? '';
$userId = $_SESSION['user_id'];

switch ($action) {
    case 'like':
        $imageId = $_POST['image_id'] ?? '';
        if (empty($imageId)) {
            echo json_encode(['success' => false, 'error' => 'Image ID required']);
            exit;
        }
        
        $image = $db->get('images', $imageId);
        if (!$image) {
            echo json_encode(['success' => false, 'error' => 'Image not found']);
            exit;
        }
        
        // Check if already liked
        $likeId = $userId . '_' . $imageId;
        $existingLike = $db->get('ratings', $likeId);
        
        if ($existingLike) {
            // Unlike
            $db->delete('ratings', $likeId);
            $image['likes'] = max(0, ($image['likes'] ?? 0) - 1);
            $db->save('images', $imageId, $image);
            echo json_encode(['success' => true, 'liked' => false, 'count' => $image['likes']]);
        } else {
            // Like
            $likeData = [
                'user_id' => $userId,
                'image_id' => $imageId,
                'created_at' => time()
            ];
            $db->save('ratings', $likeId, $likeData);
            $image['likes'] = ($image['likes'] ?? 0) + 1;
            $db->save('images', $imageId, $image);
            echo json_encode(['success' => true, 'liked' => true, 'count' => $image['likes']]);
        }
        break;
        
    case 'favorite':
        $imageId = $_POST['image_id'] ?? '';
        if (empty($imageId)) {
            echo json_encode(['success' => false, 'error' => 'Image ID required']);
            exit;
        }
        
        $image = $db->get('images', $imageId);
        if (!$image) {
            echo json_encode(['success' => false, 'error' => 'Image not found']);
            exit;
        }
        
        // Check if already favorited
        $favoriteId = $userId . '_' . $imageId;
        $existingFavorite = $db->get('favorites', $favoriteId);
        
        if ($existingFavorite) {
            // Unfavorite
            $db->delete('favorites', $favoriteId);
            $image['favorites'] = max(0, ($image['favorites'] ?? 0) - 1);
            $db->save('images', $imageId, $image);
            echo json_encode(['success' => true, 'favorited' => false, 'count' => $image['favorites']]);
        } else {
            // Favorite
            $favoriteData = [
                'user_id' => $userId,
                'image_id' => $imageId,
                'created_at' => time()
            ];
            $db->save('favorites', $favoriteId, $favoriteData);
            $image['favorites'] = ($image['favorites'] ?? 0) + 1;
            $db->save('images', $imageId, $image);
            echo json_encode(['success' => true, 'favorited' => true, 'count' => $image['favorites']]);
        }
        break;
        
    case 'report':
        require_once __DIR__ . '/../includes/moderation.php';
        $mod = new Moderation($db);
        
        $type = $_POST['type'] ?? '';
        $contentId = $_POST['content_id'] ?? '';
        $reason = $_POST['reason'] ?? '';
        $category = $_POST['category'] ?? 'other';
        
        if (empty($type) || empty($contentId) || empty($reason)) {
            echo json_encode(['success' => false, 'error' => 'Missing required fields']);
            exit;
        }
        
        $result = $mod->reportContent($type, $contentId, $reason, $category, $userId);
        echo json_encode($result);
        break;
        
    case 'mute':
        require_once __DIR__ . '/../includes/moderation.php';
        $mod = new Moderation($db);
        
        $mutedUserId = $_POST['user_id'] ?? '';
        if (empty($mutedUserId)) {
            echo json_encode(['success' => false, 'error' => 'User ID required']);
            exit;
        }
        
        $result = $mod->muteUser($mutedUserId, $userId);
        echo json_encode($result);
        break;
        
    case 'unmute':
        require_once __DIR__ . '/../includes/moderation.php';
        $mod = new Moderation($db);
        
        $mutedUserId = $_POST['user_id'] ?? '';
        if (empty($mutedUserId)) {
            echo json_encode(['success' => false, 'error' => 'User ID required']);
            exit;
        }
        
        $result = $mod->unmuteUser($mutedUserId, $userId);
        echo json_encode($result);
        break;
        
    case 'rate':
        $imageId = $_POST['image_id'] ?? '';
        $rating = (int)($_POST['rating'] ?? 0);
        
        if (empty($imageId) || $rating < 1 || $rating > 5) {
            echo json_encode(['success' => false, 'error' => 'Invalid parameters']);
            exit;
        }
        
        $image = $db->get('images', $imageId);
        if (!$image) {
            echo json_encode(['success' => false, 'error' => 'Image not found']);
            exit;
        }
        
        // Save individual rating
        $ratingId = $userId . '_' . $imageId . '_rating';
        $ratingData = [
            'user_id' => $userId,
            'image_id' => $imageId,
            'rating' => $rating,
            'created_at' => time()
        ];
        $db->save('ratings', $ratingId, $ratingData);
        
        // Calculate average rating
        $allRatings = $db->getAll('ratings');
        $imageRatings = array_filter($allRatings, function($r) use ($imageId) {
            return isset($r['image_id']) && $r['image_id'] === $imageId && isset($r['rating']);
        });
        
        $sum = array_sum(array_column($imageRatings, 'rating'));
        $count = count($imageRatings);
        $avgRating = $count > 0 ? round($sum / $count, 1) : 0;
        
        $image['rating'] = $avgRating;
        $image['rating_count'] = $count;
        $db->save('images', $imageId, $image);
        
        echo json_encode([
            'success' => true, 
            'average_rating' => $avgRating,
            'rating_count' => $count
        ]);
        break;
        
    case 'tgp_like':
        require_once __DIR__ . '/../includes/tgp_manager.php';
        $tgpManager = new TGPManager($db);
        
        $postId = $_POST['post_id'] ?? $_GET['post_id'] ?? '';
        if (empty($postId)) {
            echo json_encode(['success' => false, 'error' => 'Post ID required']);
            exit;
        }
        
        $result = $tgpManager->toggleLike($postId, $userId);
        echo json_encode($result);
        break;
        
    default:
        echo json_encode(['success' => false, 'error' => 'Unknown action']);
        break;
}
