<?php
/**
 * Registration Page
 */

if (!REGISTRATION_ENABLED) {
    redirect('index.php?page=home');
}

if ($auth->isLoggedIn()) {
    redirect('index.php?page=home');
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';
    
    if ($password !== $confirmPassword) {
        $error = 'Passwords do not match';
    } else {
        $result = $auth->register($username, $email, $password);
        
        if ($result['success']) {
            if (EMAIL_VERIFICATION) {
                $success = 'Registration successful! Please check your email to verify your account.';
            } else {
                $success = 'Registration successful! You can now login.';
                header('Refresh: 2; URL=index.php?page=login');
            }
        } else {
            $error = $result['error'];
        }
    }
}

require 'templates/header.php';
?>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h2>Register</h2>
                </div>
                <div class="card-body">
                    <?php if ($error): ?>
                        <div class="alert alert-danger"><?php echo escape($error); ?></div>
                    <?php endif; ?>
                    
                    <?php if ($success): ?>
                        <div class="alert alert-success"><?php echo escape($success); ?></div>
                    <?php else: ?>
                        <form method="POST">
                            <div class="mb-3">
                                <label class="form-label">Username</label>
                                <input type="text" name="username" class="form-control" required 
                                       minlength="3" maxlength="32" 
                                       value="<?php echo escape($_POST['username'] ?? ''); ?>">
                                <small class="text-muted">3-32 characters</small>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Email</label>
                                <input type="email" name="email" class="form-control" required
                                       value="<?php echo escape($_POST['email'] ?? ''); ?>">
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Password</label>
                                <input type="password" name="password" class="form-control" required 
                                       minlength="<?php echo PASSWORD_MIN_LENGTH; ?>">
                                <small class="text-muted">Minimum <?php echo PASSWORD_MIN_LENGTH; ?> characters</small>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Confirm Password</label>
                                <input type="password" name="confirm_password" class="form-control" required>
                            </div>
                            
                            <button type="submit" class="btn btn-primary w-100">Register</button>
                        </form>
                        
                        <hr>
                        <p class="text-center mb-0">
                            Already have an account? <a href="index.php?page=login">Login here</a>
                        </p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require 'templates/footer.php'; ?>
