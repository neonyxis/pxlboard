<?php
/**
 * Enhanced Gallery Page
 * Modern image browsing with advanced features
 */

require_once 'includes/hiding.php';

$page_num = isset($_GET['p']) ? max(1, intval($_GET['p'])) : 1;
$perPage = isset($_GET['limit']) ? min(120, max(12, intval($_GET['limit']))) : 42;
$offset = ($page_num - 1) * $perPage;
$view = $_GET['view'] ?? 'grid'; // grid, list, or masonry
$sort = $_GET['sort'] ?? 'newest';
$tagMode = $_GET['tag_mode'] ?? 'any'; // any or all

// Advanced filter parameters
$filterUploader = $_GET['uploader'] ?? '';
$filterChannel = $_GET['channel'] ?? '';
$filterTags = !empty($_GET['tags']) ? explode(',', $_GET['tags']) : [];
$filterRating = $_GET['min_rating'] ?? '';
$filterDateFrom = $_GET['date_from'] ?? '';
$filterDateTo = $_GET['date_to'] ?? '';
$filterOrientation = $_GET['orientation'] ?? ''; // portrait, landscape, square
$filterMinScore = $_GET['min_score'] ?? '';

$images = $db->getAll('images');

// Filter out hidden images for logged-in users
if ($auth->isLoggedIn()) {
    $images = filterHiddenImages($images);
}

// Apply filters
if (!empty($filterUploader)) {
    $images = array_filter($images, function($img) use ($filterUploader) {
        return stripos($img['uploader'] ?? '', $filterUploader) !== false;
    });
}

if (!empty($filterChannel)) {
    $images = array_filter($images, function($img) use ($filterChannel) {
        return ($img['channel'] ?? '') === $filterChannel;
    });
}

if (!empty($filterTags)) {
    $images = array_filter($images, function($img) use ($filterTags, $tagMode) {
        $imgTags = array_map('strtolower', $img['tags'] ?? []);
        $searchTags = array_map('strtolower', $filterTags);
        
        if ($tagMode === 'all') {
            // All tags must match
            foreach ($searchTags as $tag) {
                $found = false;
                foreach ($imgTags as $imgTag) {
                    if (stripos($imgTag, $tag) !== false) {
                        $found = true;
                        break;
                    }
                }
                if (!$found) return false;
            }
            return true;
        } else {
            // Any tag matches
            foreach ($searchTags as $tag) {
                foreach ($imgTags as $imgTag) {
                    if (stripos($imgTag, $tag) !== false) {
                        return true;
                    }
                }
            }
            return false;
        }
    });
}

if (!empty($filterRating) && is_numeric($filterRating)) {
    $minRating = floatval($filterRating);
    $images = array_filter($images, function($img) use ($minRating) {
        return ($img['rating'] ?? 0) >= $minRating;
    });
}

if (!empty($filterDateFrom)) {
    $dateFrom = strtotime($filterDateFrom);
    if ($dateFrom !== false) {
        $images = array_filter($images, function($img) use ($dateFrom) {
            return ($img['uploaded_at'] ?? 0) >= $dateFrom;
        });
    }
}

if (!empty($filterDateTo)) {
    $dateTo = strtotime($filterDateTo . ' 23:59:59');
    if ($dateTo !== false) {
        $images = array_filter($images, function($img) use ($dateTo) {
            return ($img['uploaded_at'] ?? 0) <= $dateTo;
        });
    }
}

if (!empty($filterMinScore) && is_numeric($filterMinScore)) {
    $minScore = intval($filterMinScore);
    $images = array_filter($images, function($img) use ($minScore) {
        $score = ($img['likes'] ?? 0) - ($img['dislikes'] ?? 0);
        return $score >= $minScore;
    });
}

// Apply sorting
switch ($sort) {
    case 'popular':
        usort($images, function($a, $b) {
            return ($b['views'] ?? 0) - ($a['views'] ?? 0);
        });
        break;
    case 'rating':
        usort($images, function($a, $b) {
            return ($b['rating'] ?? 0) - ($a['rating'] ?? 0);
        });
        break;
    case 'favorites':
        usort($images, function($a, $b) {
            return ($b['favorites'] ?? 0) - ($a['favorites'] ?? 0);
        });
        break;
    case 'score':
        usort($images, function($a, $b) {
            $scoreA = ($a['likes'] ?? 0) - ($a['dislikes'] ?? 0);
            $scoreB = ($b['likes'] ?? 0) - ($b['dislikes'] ?? 0);
            return $scoreB - $scoreA;
        });
        break;
    case 'random':
        shuffle($images);
        break;
    case 'oldest':
        usort($images, function($a, $b) {
            return ($a['uploaded_at'] ?? 0) - ($b['uploaded_at'] ?? 0);
        });
        break;
    case 'newest':
    default:
        usort($images, function($a, $b) {
            return ($b['uploaded_at'] ?? 0) - ($a['uploaded_at'] ?? 0);
        });
        break;
}

$totalImages = count($images);
$images = array_slice($images, $offset, $perPage);
$totalPages = ceil($totalImages / $perPage);

// Get all channels for filter dropdown
$channels = $db->getAll('channels');

// Get popular tags
$allTags = [];
foreach ($db->getAll('images') as $img) {
    foreach ($img['tags'] ?? [] as $tag) {
        $tagLower = strtolower($tag);
        if (!isset($allTags[$tagLower])) {
            $allTags[$tagLower] = ['name' => $tag, 'count' => 0];
        }
        $allTags[$tagLower]['count']++;
    }
}
arsort($allTags);
$popularTags = array_slice($allTags, 0, 30);

require 'templates/header.php';
?>

<div class="enhanced-gallery">
    <!-- Gallery Header -->
    <div class="gallery-header py-4" style="background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%); color: white;">
        <div class="container-fluid px-4">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <h1 class="mb-0"><i class="bi bi-images"></i> Image Gallery</h1>
                    <p class="mb-0 small opacity-75">Browse <?php echo number_format($totalImages); ?> images</p>
                </div>
                <div class="col-md-6 text-md-end mt-3 mt-md-0">
                    <?php if ($auth->isLoggedIn()): ?>
                        <a href="index.php?page=upload" class="btn btn-light btn-sm me-2">
                            <i class="bi bi-cloud-upload"></i> Upload
                        </a>
                    <?php endif; ?>
                    <div class="btn-group btn-group-sm" role="group">
                        <a href="?<?php echo http_build_query(array_merge($_GET, ['view' => 'grid'])); ?>" 
                           class="btn btn-outline-light <?php echo $view === 'grid' ? 'active' : ''; ?>">
                            <i class="bi bi-grid-3x3"></i>
                        </a>
                        <a href="?<?php echo http_build_query(array_merge($_GET, ['view' => 'masonry'])); ?>" 
                           class="btn btn-outline-light <?php echo $view === 'masonry' ? 'active' : ''; ?>">
                            <i class="bi bi-columns-gap"></i>
                        </a>
                        <a href="?<?php echo http_build_query(array_merge($_GET, ['view' => 'list'])); ?>" 
                           class="btn btn-outline-light <?php echo $view === 'list' ? 'active' : ''; ?>">
                            <i class="bi bi-list-ul"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container-fluid px-4 mt-4">
        <div class="row">
            <!-- Sidebar Filters -->
            <div class="col-lg-2 col-md-3 mb-4">
                <div class="filters-sidebar">
                    <!-- Search/Tag Input -->
                    <div class="card mb-3 shadow-sm">
                        <div class="card-header bg-primary text-white">
                            <h6 class="mb-0"><i class="bi bi-search"></i> Search</h6>
                        </div>
                        <div class="card-body">
                            <form method="GET" action="index.php" id="filterForm">
                                <input type="hidden" name="page" value="gallery">
                                
                                <div class="mb-2">
                                    <input type="text" name="tags" class="form-control form-control-sm" 
                                           placeholder="Tags (comma-separated)" 
                                           value="<?php echo escape(implode(',', $filterTags)); ?>">
                                    <small class="text-muted">Separate tags with commas</small>
                                </div>
                                
                                <div class="mb-2">
                                    <select name="tag_mode" class="form-select form-select-sm">
                                        <option value="any" <?php echo $tagMode === 'any' ? 'selected' : ''; ?>>Match Any Tag</option>
                                        <option value="all" <?php echo $tagMode === 'all' ? 'selected' : ''; ?>>Match All Tags</option>
                                    </select>
                                </div>
                                
                                <div class="mb-2">
                                    <input type="text" name="uploader" class="form-control form-control-sm" 
                                           placeholder="Uploader" value="<?php echo escape($filterUploader); ?>">
                                </div>
                                
                                <div class="mb-2">
                                    <select name="channel" class="form-select form-select-sm">
                                        <option value="">All Channels</option>
                                        <?php foreach ($channels as $ch): ?>
                                            <option value="<?php echo $ch['id']; ?>" 
                                                    <?php echo $filterChannel === $ch['id'] ? 'selected' : ''; ?>>
                                                <?php echo escape($ch['name']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                
                                <button type="submit" class="btn btn-primary btn-sm w-100">
                                    <i class="bi bi-funnel"></i> Apply Filters
                                </button>
                                
                                <?php if (!empty($filterTags) || !empty($filterUploader) || !empty($filterChannel)): ?>
                                    <a href="?page=gallery" class="btn btn-outline-secondary btn-sm w-100 mt-2">
                                        <i class="bi bi-x-circle"></i> Clear All
                                    </a>
                                <?php endif; ?>
                            </form>
                        </div>
                    </div>

                    <!-- Sort Options -->
                    <div class="card mb-3 shadow-sm">
                        <div class="card-header bg-secondary text-white">
                            <h6 class="mb-0"><i class="bi bi-sort-down"></i> Sort By</h6>
                        </div>
                        <div class="list-group list-group-flush">
                            <a href="?<?php echo http_build_query(array_merge($_GET, ['sort' => 'newest', 'p' => 1])); ?>" 
                               class="list-group-item list-group-item-action <?php echo $sort === 'newest' ? 'active' : ''; ?>">
                                <small>Newest First</small>
                            </a>
                            <a href="?<?php echo http_build_query(array_merge($_GET, ['sort' => 'oldest', 'p' => 1])); ?>" 
                               class="list-group-item list-group-item-action <?php echo $sort === 'oldest' ? 'active' : ''; ?>">
                                <small>Oldest First</small>
                            </a>
                            <a href="?<?php echo http_build_query(array_merge($_GET, ['sort' => 'score', 'p' => 1])); ?>" 
                               class="list-group-item list-group-item-action <?php echo $sort === 'score' ? 'active' : ''; ?>">
                                <small>Highest Score</small>
                            </a>
                            <a href="?<?php echo http_build_query(array_merge($_GET, ['sort' => 'popular', 'p' => 1])); ?>" 
                               class="list-group-item list-group-item-action <?php echo $sort === 'popular' ? 'active' : ''; ?>">
                                <small>Most Viewed</small>
                            </a>
                            <a href="?<?php echo http_build_query(array_merge($_GET, ['sort' => 'favorites', 'p' => 1])); ?>" 
                               class="list-group-item list-group-item-action <?php echo $sort === 'favorites' ? 'active' : ''; ?>">
                                <small>Most Favorited</small>
                            </a>
                            <a href="?<?php echo http_build_query(array_merge($_GET, ['sort' => 'random', 'p' => 1])); ?>" 
                               class="list-group-item list-group-item-action <?php echo $sort === 'random' ? 'active' : ''; ?>">
                                <small>Random</small>
                            </a>
                        </div>
                    </div>

                    <!-- Popular Tags -->
                    <div class="card shadow-sm">
                        <div class="card-header bg-info text-white">
                            <h6 class="mb-0"><i class="bi bi-tags"></i> Popular Tags</h6>
                        </div>
                        <div class="card-body p-2" style="max-height: 300px; overflow-y: auto;">
                            <div class="tag-cloud">
                                <?php foreach ($popularTags as $tag): ?>
                                    <a href="?page=gallery&tags=<?php echo urlencode($tag['name']); ?>" 
                                       class="badge bg-secondary m-1" 
                                       style="font-size: <?php echo min(14, 10 + ($tag['count'] / 10)); ?>px;">
                                        <?php echo escape($tag['name']); ?>
                                        <span class="badge bg-dark"><?php echo $tag['count']; ?></span>
                                    </a>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Main Gallery Content -->
            <div class="col-lg-10 col-md-9">
                <!-- Results Header -->
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <div>
                        <span class="text-muted">
                            Showing <?php echo number_format(count($images)); ?> of <?php echo number_format($totalImages); ?> images
                        </span>
                        <?php if (!empty($filterTags)): ?>
                            <div class="mt-2">
                                <strong>Filtered by tags:</strong>
                                <?php foreach ($filterTags as $tag): ?>
                                    <span class="badge bg-primary"><?php echo escape($tag); ?></span>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div>
                        <select class="form-select form-select-sm" style="width: auto; display: inline-block;" 
                                onchange="window.location.href='?<?php echo http_build_query(array_merge($_GET, ['limit' => ''])); ?>&limit='+this.value">
                            <option value="12" <?php echo $perPage === 12 ? 'selected' : ''; ?>>12 per page</option>
                            <option value="24" <?php echo $perPage === 24 ? 'selected' : ''; ?>>24 per page</option>
                            <option value="42" <?php echo $perPage === 42 ? 'selected' : ''; ?>>42 per page</option>
                            <option value="60" <?php echo $perPage === 60 ? 'selected' : ''; ?>>60 per page</option>
                            <option value="100" <?php echo $perPage === 100 ? 'selected' : ''; ?>>100 per page</option>
                        </select>
                    </div>
                </div>

                <!-- Image Grid/Masonry/List -->
                <?php if (empty($images)): ?>
                    <div class="text-center py-5">
                        <i class="bi bi-images text-muted" style="font-size: 5rem;"></i>
                        <h3 class="mt-3">No images found</h3>
                        <p class="text-muted">Try adjusting your filters or search terms</p>
                    </div>
                <?php elseif ($view === 'masonry'): ?>
                    <!-- Masonry Layout -->
                    <div class="masonry-grid">
                        <?php foreach ($images as $image): ?>
                            <?php include 'templates/gallery_card.php'; ?>
                        <?php endforeach; ?>
                    </div>
                <?php elseif ($view === 'list'): ?>
                    <!-- List View -->
                    <div class="list-view">
                        <?php foreach ($images as $image): ?>
                            <div class="list-item card mb-3">
                                <div class="row g-0">
                                    <div class="col-md-3 col-lg-2">
                                        <a href="index.php?page=image&id=<?php echo $image['id']; ?>">
                                            <img src="uploads/thumbs/<?php echo escape($image['filename']); ?>" 
                                                 class="img-fluid rounded-start" 
                                                 alt="<?php echo escape($image['title']); ?>"
                                                 style="height: 150px; width: 100%; object-fit: cover;">
                                        </a>
                                    </div>
                                    <div class="col-md-9 col-lg-10">
                                        <div class="card-body">
                                            <h5 class="card-title">
                                                <a href="index.php?page=image&id=<?php echo $image['id']; ?>" class="text-decoration-none">
                                                    <?php echo escape($image['title'] ?? 'Untitled'); ?>
                                                </a>
                                            </h5>
                                            <?php if (!empty($image['description'])): ?>
                                                <p class="card-text small"><?php echo escape(substr($image['description'], 0, 150)); ?>...</p>
                                            <?php endif; ?>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <div class="text-muted small">
                                                    by <?php echo escape($image['uploader']); ?> • 
                                                    <?php echo timeAgo($image['uploaded_at']); ?>
                                                </div>
                                                <div class="stats text-muted small">
                                                    <i class="bi bi-eye"></i> <?php echo number_format($image['views'] ?? 0); ?>
                                                    <i class="bi bi-heart ms-2"></i> <?php echo number_format($image['favorites'] ?? 0); ?>
                                                    <i class="bi bi-chat ms-2"></i> <?php echo number_format($image['comments_count'] ?? 0); ?>
                                                </div>
                                            </div>
                                            <div class="mt-2">
                                                <?php if (!empty($image['tags'])): ?>
                                                    <?php foreach (array_slice($image['tags'], 0, 5) as $tag): ?>
                                                        <a href="?page=gallery&tags=<?php echo urlencode($tag); ?>" class="badge bg-secondary me-1">
                                                            <?php echo escape($tag); ?>
                                                        </a>
                                                    <?php endforeach; ?>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <!-- Grid View (Default) -->
                    <div class="image-grid row g-3">
                        <?php foreach ($images as $image): ?>
                            <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6">
                                <div class="gallery-item card h-100 border-0 shadow-sm">
                                    <a href="index.php?page=image&id=<?php echo $image['id']; ?>" class="position-relative">
                                        <img src="uploads/thumbs/<?php echo escape($image['filename']); ?>" 
                                             class="card-img-top" 
                                             alt="<?php echo escape($image['title']); ?>"
                                             loading="lazy"
                                             style="height: 200px; object-fit: cover;">
                                        <div class="image-overlay">
                                            <div class="overlay-stats">
                                                <span><i class="bi bi-eye-fill"></i> <?php echo number_format($image['views'] ?? 0); ?></span>
                                                <span><i class="bi bi-heart-fill"></i> <?php echo number_format($image['favorites'] ?? 0); ?></span>
                                            </div>
                                        </div>
                                    </a>
                                    <div class="card-body p-2">
                                        <h6 class="card-title mb-1 small">
                                            <a href="index.php?page=image&id=<?php echo $image['id']; ?>" class="text-decoration-none text-truncate d-block">
                                                <?php echo escape($image['title'] ?? 'Untitled'); ?>
                                            </a>
                                        </h6>
                                        <p class="card-text text-muted" style="font-size: 0.75rem;">
                                            <?php echo escape($image['uploader']); ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <!-- Pagination -->
                <?php if ($totalPages > 1): ?>
                    <nav class="mt-4" aria-label="Gallery pagination">
                        <ul class="pagination justify-content-center">
                            <?php if ($page_num > 1): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['p' => $page_num - 1])); ?>">
                                        <i class="bi bi-chevron-left"></i> Previous
                                    </a>
                                </li>
                            <?php endif; ?>
                            
                            <?php
                            $startPage = max(1, $page_num - 3);
                            $endPage = min($totalPages, $page_num + 3);
                            
                            if ($startPage > 1): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['p' => 1])); ?>">1</a>
                                </li>
                                <?php if ($startPage > 2): ?>
                                    <li class="page-item disabled"><span class="page-link">...</span></li>
                                <?php endif; ?>
                            <?php endif; ?>
                            
                            <?php for ($i = $startPage; $i <= $endPage; $i++): ?>
                                <li class="page-item <?php echo $i === $page_num ? 'active' : ''; ?>">
                                    <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['p' => $i])); ?>">
                                        <?php echo $i; ?>
                                    </a>
                                </li>
                            <?php endfor; ?>
                            
                            <?php if ($endPage < $totalPages): ?>
                                <?php if ($endPage < $totalPages - 1): ?>
                                    <li class="page-item disabled"><span class="page-link">...</span></li>
                                <?php endif; ?>
                                <li class="page-item">
                                    <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['p' => $totalPages])); ?>">
                                        <?php echo $totalPages; ?>
                                    </a>
                                </li>
                            <?php endif; ?>
                            
                            <?php if ($page_num < $totalPages): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['p' => $page_num + 1])); ?>">
                                        Next <i class="bi bi-chevron-right"></i>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<style>
.gallery-item {
    transition: transform 0.2s ease, box-shadow 0.2s ease;
}

.gallery-item:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 20px rgba(0,0,0,0.2) !important;
}

.image-overlay {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(to bottom, transparent 0%, rgba(0,0,0,0.8) 100%);
    opacity: 0;
    transition: opacity 0.3s ease;
    display: flex;
    align-items: flex-end;
    padding: 10px;
}

.gallery-item:hover .image-overlay {
    opacity: 1;
}

.overlay-stats {
    color: white;
    font-size: 0.85rem;
}

.overlay-stats span {
    margin-right: 10px;
}

.masonry-grid {
    column-count: 5;
    column-gap: 15px;
}

@media (max-width: 1400px) {
    .masonry-grid {
        column-count: 4;
    }
}

@media (max-width: 1200px) {
    .masonry-grid {
        column-count: 3;
    }
}

@media (max-width: 768px) {
    .masonry-grid {
        column-count: 2;
    }
}

@media (max-width: 576px) {
    .masonry-grid {
        column-count: 1;
    }
}

.masonry-grid .gallery-item {
    break-inside: avoid;
    margin-bottom: 15px;
}

.masonry-grid .gallery-item img {
    height: auto !important;
}

.tag-cloud a {
    transition: all 0.2s ease;
}

.tag-cloud a:hover {
    transform: scale(1.1);
    text-decoration: none;
}

.filters-sidebar .card {
    position: sticky;
    top: 20px;
}
</style>

<?php require 'templates/footer.php'; ?>
