<?php
/**
 * Admin Panel
 */

if (!$auth->isAdmin()) {
    redirect('index.php?page=home');
}

$message = '';
$error = '';

// Handle actions
if (isset($_GET['action'])) {
    switch ($_GET['action']) {
        case 'delete_image':
            $imageId = $_GET['id'] ?? '';
            $image = $db->get('images', $imageId);
            
            if ($image) {
                // Delete files
                @unlink(UPLOADS_DIR . '/' . $image['filename']);
                @unlink(UPLOADS_DIR . '/thumbs/' . $image['filename']);
                
                // Delete from database
                $db->delete('images', $imageId);
                
                $message = 'Image deleted successfully';
            }
            break;
            
        case 'create_channel':
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $channelName = trim($_POST['channel_name'] ?? '');
                $channelDesc = trim($_POST['channel_description'] ?? '');
                
                if (!empty($channelName)) {
                    $channelId = sanitizeFilename(strtolower(str_replace(' ', '-', $channelName)));
                    $db->save('channels', $channelId, [
                        'name' => $channelName,
                        'description' => $channelDesc,
                        'created_at' => time(),
                        'subscribers' => 0
                    ]);
                    $message = 'Channel created successfully';
                }
            }
            break;
            
        case 'delete_channel':
            $channelId = $_GET['id'] ?? '';
            if ($db->get('channels', $channelId)) {
                $db->delete('channels', $channelId);
                $message = 'Channel deleted successfully';
            }
            break;
            
        case 'save_settings':
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $settings = [
                    'site_name' => $_POST['site_name'] ?? SITE_NAME,
                    'site_description' => $_POST['site_description'] ?? SITE_DESCRIPTION,
                    'site_url' => $_POST['site_url'] ?? SITE_URL,
                    'admin_email' => $_POST['admin_email'] ?? ADMIN_EMAIL,
                    'max_upload_size' => (int)($_POST['max_upload_size'] ?? MAX_UPLOAD_SIZE),
                    'smtp_enabled' => isset($_POST['smtp_enabled']),
                    'smtp_host' => $_POST['smtp_host'] ?? '',
                    'smtp_port' => (int)($_POST['smtp_port'] ?? 587),
                    'smtp_username' => $_POST['smtp_username'] ?? '',
                    'smtp_password' => $_POST['smtp_password'] ?? '',
                    'smtp_from' => $_POST['smtp_from'] ?? '',
                    'registration_enabled' => isset($_POST['registration_enabled']),
                    'email_verification' => isset($_POST['email_verification']),
                    'default_theme' => $_POST['default_theme'] ?? DEFAULT_THEME,
                    'timezone' => $_POST['timezone'] ?? 'UTC'
                ];
                
                file_put_contents(DATA_DIR . '/settings.json', json_encode($settings, JSON_PRETTY_PRINT));
                $message = 'Settings saved successfully. Please reload the page to see changes.';
            }
            break;
    }
}

// Load current settings
$currentSettings = json_decode(file_get_contents(DATA_DIR . '/settings.json'), true);

// Get statistics
$totalImages = $db->count('images');
$totalUsers = $db->count('users');
$totalTags = $db->count('tags');
$totalBlogs = $db->count('blogs');
$totalWiki = $db->count('wiki');
$allImages = $db->getAll('images');
$totalSize = array_sum(array_column($allImages, 'size'));

require 'templates/header.php';
?>

<div class="container mt-4">
    <h2>Admin Panel</h2>
    
    <?php if ($message): ?>
        <div class="alert alert-success alert-dismissible">
            <?php echo escape($message); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible">
            <?php echo escape($error); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <ul class="nav nav-tabs mb-4">
        <li class="nav-item">
            <a class="nav-link active" data-bs-toggle="tab" href="#stats">Statistics</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="tab" href="#settings">Settings</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="tab" href="#users">Users</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="tab" href="#channels">Channels</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="tab" href="#debug">Debug</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="index.php?page=admin_content">
                <i class="bi bi-file-text"></i> Content Management
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="index.php?page=moderation">
                <i class="bi bi-shield-check"></i> Moderation
            </a>
        </li>
    </ul>
    
    <div class="tab-content">
        <!-- Statistics Tab -->
        <div class="tab-pane fade show active" id="stats">
            <div class="row mb-3">
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body text-center">
                            <h3><?php echo number_format($totalImages); ?></h3>
                            <p class="text-muted mb-0">Total Images</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body text-center">
                            <h3><?php echo number_format($totalUsers); ?></h3>
                            <p class="text-muted mb-0">Total Users</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body text-center">
                            <h3><?php echo number_format($totalTags); ?></h3>
                            <p class="text-muted mb-0">Total Tags</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body text-center">
                            <h3><?php echo formatBytes($totalSize); ?></h3>
                            <p class="text-muted mb-0">Storage Used</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body text-center">
                            <h3><?php echo number_format($totalBlogs); ?></h3>
                            <p class="text-muted mb-0">Blog Posts</p>
                            <a href="index.php?page=admin_content&tab=blogs" class="btn btn-sm btn-outline-primary mt-2">
                                Manage Blogs
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body text-center">
                            <h3><?php echo number_format($totalWiki); ?></h3>
                            <p class="text-muted mb-0">Wiki Pages</p>
                            <a href="index.php?page=admin_content&tab=wiki" class="btn btn-sm btn-outline-primary mt-2">
                                Manage Wiki
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Settings Tab -->
        <div class="tab-pane fade" id="settings">
            <form method="POST" action="index.php?page=admin&action=save_settings">
                <div class="card mb-3">
                    <div class="card-header"><h5>General Settings</h5></div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label class="form-label">Site Name</label>
                            <input type="text" name="site_name" class="form-control" 
                                   value="<?php echo escape($currentSettings['site_name']); ?>">
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Site Description</label>
                            <input type="text" name="site_description" class="form-control" 
                                   value="<?php echo escape($currentSettings['site_description']); ?>">
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Site URL</label>
                            <input type="url" name="site_url" class="form-control" 
                                   value="<?php echo escape($currentSettings['site_url']); ?>">
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Admin Email</label>
                            <input type="email" name="admin_email" class="form-control" 
                                   value="<?php echo escape($currentSettings['admin_email']); ?>">
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Max Upload Size (bytes)</label>
                            <input type="number" name="max_upload_size" class="form-control" 
                                   value="<?php echo $currentSettings['max_upload_size']; ?>">
                            <small class="text-muted">Current: <?php echo formatBytes($currentSettings['max_upload_size']); ?></small>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Default Theme</label>
                            <select name="default_theme" class="form-select">
                                <?php foreach (getAvailableThemes() as $theme): ?>
                                    <option value="<?php echo escape($theme['name']); ?>" 
                                            <?php echo $theme['name'] === $currentSettings['default_theme'] ? 'selected' : ''; ?>>
                                        <?php echo escape($theme['display_name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Timezone</label>
                            <input type="text" name="timezone" class="form-control" 
                                   value="<?php echo escape($currentSettings['timezone']); ?>">
                        </div>
                    </div>
                </div>
                
                <div class="card mb-3">
                    <div class="card-header"><h5>Registration Settings</h5></div>
                    <div class="card-body">
                        <div class="form-check mb-2">
                            <input class="form-check-input" type="checkbox" name="registration_enabled" 
                                   <?php echo $currentSettings['registration_enabled'] ? 'checked' : ''; ?>>
                            <label class="form-check-label">Enable User Registration</label>
                        </div>
                        
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="email_verification" 
                                   <?php echo $currentSettings['email_verification'] ? 'checked' : ''; ?>>
                            <label class="form-check-label">Require Email Verification</label>
                        </div>
                    </div>
                </div>
                
                <div class="card mb-3">
                    <div class="card-header"><h5>SMTP Settings</h5></div>
                    <div class="card-body">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" name="smtp_enabled" 
                                   <?php echo $currentSettings['smtp_enabled'] ? 'checked' : ''; ?>>
                            <label class="form-check-label">Enable SMTP</label>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">SMTP Host</label>
                            <input type="text" name="smtp_host" class="form-control" 
                                   value="<?php echo escape($currentSettings['smtp_host'] ?? ''); ?>">
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">SMTP Port</label>
                            <input type="number" name="smtp_port" class="form-control" 
                                   value="<?php echo $currentSettings['smtp_port'] ?? 587; ?>">
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">SMTP Username</label>
                            <input type="text" name="smtp_username" class="form-control" 
                                   value="<?php echo escape($currentSettings['smtp_username'] ?? ''); ?>">
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">SMTP Password</label>
                            <input type="password" name="smtp_password" class="form-control" 
                                   value="<?php echo escape($currentSettings['smtp_password'] ?? ''); ?>">
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">From Email</label>
                            <input type="email" name="smtp_from" class="form-control" 
                                   value="<?php echo escape($currentSettings['smtp_from'] ?? ''); ?>">
                        </div>
                    </div>
                </div>
                
                <button type="submit" class="btn btn-primary">Save Settings</button>
            </form>
        </div>
        
        <!-- Users Tab -->
        <div class="tab-pane fade" id="users">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Registered</th>
                            <th>Verified</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($db->getAll('users') as $user): ?>
                            <tr>
                                <td><?php echo escape($user['username']); ?></td>
                                <td><?php echo escape($user['email']); ?></td>
                                <td>
                                    <span class="badge <?php echo $user['role'] === 'admin' ? 'bg-danger' : 'bg-secondary'; ?>">
                                        <?php echo escape($user['role']); ?>
                                    </span>
                                </td>
                                <td><?php echo date('Y-m-d H:i', $user['created_at']); ?></td>
                                <td><?php echo $user['verified'] ? '✓' : '✗'; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- Channels Tab -->
        <div class="tab-pane fade" id="channels">
            <div class="card mb-3">
                <div class="card-header">
                    <h5>Create New Channel</h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="index.php?page=admin&action=create_channel">
                        <div class="row g-3">
                            <div class="col-md-4">
                                <input type="text" name="channel_name" class="form-control" placeholder="Channel Name" required>
                            </div>
                            <div class="col-md-6">
                                <input type="text" name="channel_description" class="form-control" placeholder="Description">
                            </div>
                            <div class="col-md-2">
                                <button type="submit" class="btn btn-primary w-100">Create</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            
            <h5>Existing Channels</h5>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Description</th>
                            <th>Images</th>
                            <th>Created</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $channels = $db->getAll('channels');
                        $allImages = $db->getAll('images');
                        foreach ($channels as $channel): 
                            $imageCount = count(array_filter($allImages, function($img) use ($channel) {
                                return ($img['channel'] ?? '') === $channel['id'];
                            }));
                        ?>
                            <tr>
                                <td><strong><?php echo escape($channel['name']); ?></strong></td>
                                <td><?php echo escape($channel['description']); ?></td>
                                <td><?php echo $imageCount; ?></td>
                                <td><?php echo date('Y-m-d', $channel['created_at']); ?></td>
                                <td>
                                    <a href="index.php?page=channel&id=<?php echo $channel['id']; ?>" class="btn btn-sm btn-primary">View</a>
                                    <a href="index.php?page=admin&action=delete_channel&id=<?php echo $channel['id']; ?>" 
                                       class="btn btn-sm btn-danger"
                                       onclick="return confirm('Delete this channel? Images will not be deleted.')">
                                        Delete
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- Debug Tab -->
        <div class="tab-pane fade" id="debug">
            <!-- System Version -->
            <div class="card mb-3">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0"><i class="bi bi-info-circle"></i> System Version</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <table class="table table-sm">
                                <tr>
                                    <th width="40%">PXLBoard Version:</th>
                                    <td><span class="badge bg-success"><?php echo VERSION; ?></span></td>
                                </tr>
                                <tr>
                                    <th>Installation Date:</th>
                                    <td>
                                        <?php 
                                        $lockFile = DATA_DIR . '/installed.lock';
                                        if (file_exists($lockFile)) {
                                            echo file_get_contents($lockFile);
                                        } else {
                                            echo 'Unknown';
                                        }
                                        ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th>PHP Version:</th>
                                    <td><?php echo phpversion(); ?></td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <table class="table table-sm">
                                <tr>
                                    <th width="40%">Server Software:</th>
                                    <td><?php echo $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown'; ?></td>
                                </tr>
                                <tr>
                                    <th>Document Root:</th>
                                    <td><code><?php echo $_SERVER['DOCUMENT_ROOT'] ?? 'Unknown'; ?></code></td>
                                </tr>
                                <tr>
                                    <th>Server Time:</th>
                                    <td><?php echo date('Y-m-d H:i:s T'); ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Path Configuration -->
            <div class="card mb-3">
                <div class="card-header">
                    <h5 class="mb-0"><i class="bi bi-folder"></i> Path Configuration</h5>
                </div>
                <div class="card-body">
                    <table class="table table-sm">
                        <tr>
                            <th width="30%">Base Directory:</th>
                            <td><code><?php echo BASE_DIR; ?></code></td>
                        </tr>
                        <tr>
                            <th>Data Directory:</th>
                            <td>
                                <code><?php echo DATA_DIR; ?></code>
                                <?php if (is_writable(DATA_DIR)): ?>
                                    <span class="badge bg-success">Writable</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">Not Writable</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <th>Uploads Directory:</th>
                            <td>
                                <code><?php echo UPLOADS_DIR; ?></code>
                                <?php if (is_writable(UPLOADS_DIR)): ?>
                                    <span class="badge bg-success">Writable</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">Not Writable</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <th>Themes Directory:</th>
                            <td><code><?php echo THEMES_DIR; ?></code></td>
                        </tr>
                        <tr>
                            <th>Site URL:</th>
                            <td><code><?php echo SITE_URL; ?></code></td>
                        </tr>
                        <tr>
                            <th>URL Prefix:</th>
                            <td><code><?php echo getBasePrefix() ?: '/'; ?></code></td>
                        </tr>
                        <tr>
                            <th>Script Name:</th>
                            <td><code><?php echo $_SERVER['SCRIPT_NAME'] ?? 'N/A'; ?></code></td>
                        </tr>
                        <tr>
                            <th>Request URI:</th>
                            <td><code><?php echo $_SERVER['REQUEST_URI'] ?? 'N/A'; ?></code></td>
                        </tr>
                    </table>
                </div>
            </div>

            <!-- PHP Configuration -->
            <div class="card mb-3">
                <div class="card-header">
                    <h5 class="mb-0"><i class="bi bi-code-square"></i> PHP Configuration</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <table class="table table-sm">
                                <tr>
                                    <th width="50%">Max Upload Size:</th>
                                    <td><?php echo ini_get('upload_max_filesize'); ?></td>
                                </tr>
                                <tr>
                                    <th>Max POST Size:</th>
                                    <td><?php echo ini_get('post_max_size'); ?></td>
                                </tr>
                                <tr>
                                    <th>Memory Limit:</th>
                                    <td><?php echo ini_get('memory_limit'); ?></td>
                                </tr>
                                <tr>
                                    <th>Max Execution Time:</th>
                                    <td><?php echo ini_get('max_execution_time'); ?>s</td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <table class="table table-sm">
                                <tr>
                                    <th width="50%">Display Errors:</th>
                                    <td><?php echo ini_get('display_errors') ? 'On' : 'Off'; ?></td>
                                </tr>
                                <tr>
                                    <th>Error Reporting:</th>
                                    <td><?php echo error_reporting(); ?></td>
                                </tr>
                                <tr>
                                    <th>GD Library:</th>
                                    <td>
                                        <?php if (extension_loaded('gd')): ?>
                                            <span class="badge bg-success">Installed</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">Missing</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th>JSON Extension:</th>
                                    <td>
                                        <?php if (extension_loaded('json')): ?>
                                            <span class="badge bg-success">Installed</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">Missing</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Database Statistics -->
            <div class="card mb-3">
                <div class="card-header">
                    <h5 class="mb-0"><i class="bi bi-database"></i> Database Statistics</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <?php
                        $collections = [
                            'users' => 'Users',
                            'images' => 'Images',
                            'comments' => 'Comments',
                            'tags' => 'Tags',
                            'channels' => 'Channels',
                            'favorites' => 'Favorites',
                            'ratings' => 'Ratings',
                            'blog_posts' => 'Blog Posts',
                            'wiki_pages' => 'Wiki Pages',
                            'forum_topics' => 'Forum Topics',
                            'notifications' => 'Notifications',
                        ];
                        foreach ($collections as $collection => $label):
                            $count = $db->count($collection);
                        ?>
                        <div class="col-md-3 mb-2">
                            <div class="card bg-light">
                                <div class="card-body p-2 text-center">
                                    <small class="text-muted"><?php echo $label; ?></small>
                                    <h5 class="mb-0"><?php echo number_format($count); ?></h5>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <!-- Recent Errors Log -->
            <div class="card mb-3">
                <div class="card-header">
                    <h5 class="mb-0"><i class="bi bi-exclamation-triangle"></i> Recent PHP Errors</h5>
                </div>
                <div class="card-body">
                    <?php
                    $errorLog = ini_get('error_log');
                    if ($errorLog && file_exists($errorLog) && is_readable($errorLog)):
                        $errors = file($errorLog);
                        $recentErrors = array_slice(array_reverse($errors), 0, 20);
                    ?>
                    <pre class="bg-dark text-light p-3" style="max-height: 300px; overflow-y: auto;"><?php 
                        foreach ($recentErrors as $error) {
                            echo htmlspecialchars($error);
                        }
                    ?></pre>
                    <?php else: ?>
                    <p class="text-muted">Error log not accessible or not configured.</p>
                    <p><small>Error log path: <code><?php echo $errorLog ?: 'Not set'; ?></code></small></p>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Quick Diagnostics -->
            <div class="card mb-3">
                <div class="card-header">
                    <h5 class="mb-0"><i class="bi bi-clipboard-check"></i> Quick Diagnostics</h5>
                </div>
                <div class="card-body">
                    <table class="table table-sm">
                        <tr>
                            <th width="40%">.htaccess file exists:</th>
                            <td>
                                <?php if (file_exists(BASE_DIR . '/.htaccess')): ?>
                                    <span class="badge bg-success">Yes</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">No</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <th>mod_rewrite enabled:</th>
                            <td>
                                <?php if (function_exists('apache_get_modules') && in_array('mod_rewrite', apache_get_modules())): ?>
                                    <span class="badge bg-success">Yes</span>
                                <?php else: ?>
                                    <span class="badge bg-warning">Unknown/Not Apache</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <th>Session Active:</th>
                            <td>
                                <?php if (session_status() === PHP_SESSION_ACTIVE): ?>
                                    <span class="badge bg-success">Yes</span>
                                    <small>(ID: <?php echo session_id(); ?>)</small>
                                <?php else: ?>
                                    <span class="badge bg-danger">No</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <th>Settings file exists:</th>
                            <td>
                                <?php if (file_exists(DATA_DIR . '/settings.json')): ?>
                                    <span class="badge bg-success">Yes</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">No</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <th>Uploads/thumbs directory:</th>
                            <td>
                                <?php if (is_dir(UPLOADS_DIR . '/thumbs')): ?>
                                    <span class="badge bg-success">Exists</span>
                                    <?php if (is_writable(UPLOADS_DIR . '/thumbs')): ?>
                                        <span class="badge bg-success">Writable</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">Not Writable</span>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <span class="badge bg-danger">Missing</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <th>Total disk usage:</th>
                            <td>
                                <?php 
                                $totalSize = 0;
                                if (is_dir(UPLOADS_DIR)) {
                                    foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator(UPLOADS_DIR)) as $file) {
                                        if ($file->isFile()) {
                                            $totalSize += $file->getSize();
                                        }
                                    }
                                }
                                echo formatBytes($totalSize);
                                ?>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>

            <!-- Action Buttons -->
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0"><i class="bi bi-tools"></i> Maintenance Tools</h5>
                </div>
                <div class="card-body">
                    <div class="row g-2">
                        <div class="col-md-4">
                            <a href="<?php echo BASE_DIR; ?>/diagnostic.php" class="btn btn-outline-primary w-100" target="_blank">
                                <i class="bi bi-file-medical"></i> Full Diagnostic Report
                            </a>
                        </div>
                        <div class="col-md-4">
                            <button class="btn btn-outline-info w-100" onclick="window.location.reload();">
                                <i class="bi bi-arrow-clockwise"></i> Refresh Page
                            </button>
                        </div>
                        <div class="col-md-4">
                            <button class="btn btn-outline-secondary w-100" onclick="navigator.clipboard.writeText('<?php echo VERSION; ?>')">
                                <i class="bi bi-clipboard"></i> Copy Version
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require 'templates/footer.php'; ?>
