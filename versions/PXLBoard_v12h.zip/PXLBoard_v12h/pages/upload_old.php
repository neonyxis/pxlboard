<?php
/**
 * Upload Page
 */

if (!$auth->isLoggedIn()) {
    redirect('index.php?page=login');
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $tags = trim($_POST['tags'] ?? '');
    $channel = $_POST['channel'] ?? '';
    
    if (!isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
        $error = 'Please select an image to upload';
    } elseif ($_FILES['image']['size'] > MAX_UPLOAD_SIZE) {
        $error = 'File size exceeds maximum allowed size of ' . formatBytes(MAX_UPLOAD_SIZE);
    } else {
        $extension = getFileExtension($_FILES['image']['name']);
        
        if (!in_array($extension, ALLOWED_EXTENSIONS)) {
            $error = 'Invalid file type. Allowed types: ' . implode(', ', ALLOWED_EXTENSIONS);
        } else {
            // Generate unique filename
            $filename = uniqid() . '.' . $extension;
            $uploadPath = UPLOADS_DIR . '/' . $filename;
            $thumbPath = UPLOADS_DIR . '/thumbs/' . $filename;
            
            // Create uploads directories if they don't exist
            if (!is_dir(UPLOADS_DIR)) {
                mkdir(UPLOADS_DIR, 0755, true);
            }
            if (!is_dir(UPLOADS_DIR . '/thumbs')) {
                mkdir(UPLOADS_DIR . '/thumbs', 0755, true);
            }
            
            if (move_uploaded_file($_FILES['image']['tmp_name'], $uploadPath)) {
                // Generate thumbnail
                generateThumbnail($uploadPath, $thumbPath, THUMBNAIL_WIDTH, THUMBNAIL_HEIGHT);
                
                // Get image dimensions
                $imageInfo = getimagesize($uploadPath);
                
                // Parse tags
                $tagsArray = array_filter(array_map('trim', explode(',', $tags)));
                
                // Save to database
                $imageId = $db->getNextId('images');
                $imageData = [
                    'title' => !empty($title) ? $title : 'Untitled',
                    'description' => $description,
                    'filename' => $filename,
                    'original_filename' => sanitizeFilename($_FILES['image']['name']),
                    'size' => $_FILES['image']['size'],
                    'width' => $imageInfo[0],
                    'height' => $imageInfo[1],
                    'mime_type' => $imageInfo['mime'],
                    'tags' => $tagsArray,
                    'channel' => $channel,
                    'uploader' => $_SESSION['username'],
                    'uploader_id' => $_SESSION['user_id'],
                    'uploaded_at' => time(),
                    'views' => 0,
                    'favorites' => 0,
                    'comments_count' => 0
                ];
                
                if ($db->save('images', $imageId, $imageData)) {
                    // Update tag counts
                    foreach ($tagsArray as $tag) {
                        $tagData = $db->get('tags', md5($tag));
                        if ($tagData) {
                            $tagData['count']++;
                        } else {
                            $tagData = ['name' => $tag, 'count' => 1];
                        }
                        $db->save('tags', md5($tag), $tagData);
                    }
                    
                    $success = 'Image uploaded successfully!';
                    header('Refresh: 1; URL=index.php?page=image&id=' . $imageId);
                }
            } else {
                $error = 'Failed to upload file';
            }
        }
    }
}

require 'templates/header.php';
?>

<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h2>Upload Image</h2>
                </div>
                <div class="card-body">
                    <?php if ($error): ?>
                        <div class="alert alert-danger"><?php echo escape($error); ?></div>
                    <?php endif; ?>
                    
                    <?php if ($success): ?>
                        <div class="alert alert-success"><?php echo escape($success); ?></div>
                    <?php endif; ?>
                    
                    <form method="POST" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label class="form-label">Image File *</label>
                            <input type="file" name="image" class="form-control" accept="image/*" required>
                            <small class="text-muted">
                                Allowed types: <?php echo implode(', ', ALLOWED_EXTENSIONS); ?> | 
                                Max size: <?php echo formatBytes(MAX_UPLOAD_SIZE); ?>
                            </small>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Title</label>
                            <input type="text" name="title" class="form-control" maxlength="200" value="<?php echo escape($_POST['title'] ?? ''); ?>">
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Description</label>
                            <textarea name="description" class="form-control" rows="4"><?php echo escape($_POST['description'] ?? ''); ?></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Channel (optional)</label>
                            <select name="channel" class="form-select">
                                <option value="">-- None --</option>
                                <?php
                                $channels = $db->getAll('channels');
                                foreach ($channels as $ch):
                                ?>
                                    <option value="<?php echo escape($ch['id']); ?>" 
                                            <?php echo ($_GET['channel'] ?? '') === $ch['id'] ? 'selected' : ''; ?>>
                                        <?php echo escape($ch['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Tags (comma-separated)</label>
                            <input type="text" name="tags" class="form-control" placeholder="nature, landscape, photography" value="<?php echo escape($_POST['tags'] ?? ''); ?>">
                            <small class="text-muted">Separate tags with commas</small>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">Upload</button>
                        <a href="index.php?page=home" class="btn btn-secondary">Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require 'templates/footer.php'; ?>
