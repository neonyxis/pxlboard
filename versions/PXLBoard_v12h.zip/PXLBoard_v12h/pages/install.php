<?php
/**
 * Installation Page - v12h
 * Supports FlatFile, MySQL, and SQLite databases
 */

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $siteName = $_POST['site_name'] ?? '';
    $siteUrl = $_POST['site_url'] ?? '';
    $adminUsername = $_POST['admin_username'] ?? '';
    $adminEmail = $_POST['admin_email'] ?? '';
    $adminPassword = $_POST['admin_password'] ?? '';
    $dbType = $_POST['db_type'] ?? 'flatfile';
    
    // Validate
    if (empty($siteName) || empty($siteUrl) || empty($adminUsername) || empty($adminEmail) || empty($adminPassword)) {
        $error = 'All fields are required';
    } elseif (strlen($adminPassword) < PASSWORD_MIN_LENGTH) {
        $error = 'Password must be at least ' . PASSWORD_MIN_LENGTH . ' characters';
    } else {
        // Create database configuration
        $dbConfig = ['type' => $dbType];
        
        if ($dbType === 'mysql') {
            $dbConfig['host'] = $_POST['db_host'] ?? 'localhost';
            $dbConfig['dbname'] = $_POST['db_name'] ?? '';
            $dbConfig['username'] = $_POST['db_username'] ?? '';
            $dbConfig['password'] = $_POST['db_password'] ?? '';
            $dbConfig['prefix'] = $_POST['db_prefix'] ?? 'pxl_';
            
            if (empty($dbConfig['dbname']) || empty($dbConfig['username'])) {
                $error = 'MySQL database name and username are required';
            }
        } elseif ($dbType === 'sqlite') {
            $dbConfig['path'] = DATA_DIR . '/database.sqlite';
        } else {
            $dbConfig['path'] = DATA_DIR;
        }
        
        if (!$error) {
            // Save database configuration
            file_put_contents(DATA_DIR . '/db_config.json', json_encode($dbConfig, JSON_PRETTY_PRINT));
            
            // Create settings
            $settings = [
                'site_name' => $siteName,
                'site_description' => $_POST['site_description'] ?? '',
                'site_url' => rtrim($siteUrl, '/'),
                'admin_email' => $adminEmail,
                'max_upload_size' => 10485760,
                'smtp_enabled' => false,
                'registration_enabled' => true,
                'email_verification' => false,
                'default_theme' => 'default',
                'timezone' => 'UTC',
                'db_type' => $dbType
            ];
            
            file_put_contents(DATA_DIR . '/settings.json', json_encode($settings, JSON_PRETTY_PRINT));
            
            // Initialize database with configuration
            require_once BASE_DIR . '/includes/database.php';
            $db = DatabaseFactory::create($dbConfig);
            
            // Create admin user
            $adminId = 'admin_' . uniqid();
            $adminData = [
                'username' => $adminUsername,
                'email' => $adminEmail,
                'password' => password_hash($adminPassword, PASSWORD_DEFAULT),
                'role' => 'admin',
                'created_at' => time(),
                'verified' => true
            ];
            
            $db->save('users', $adminId, $adminData);
            
            // Create installation lock
            file_put_contents(DATA_DIR . '/installed.lock', date('Y-m-d H:i:s'));
            
            // Auto-patch .htaccess RewriteBase to match the actual subdirectory.
            $htaccessPath = BASE_DIR . '/.htaccess';
            if (file_exists($htaccessPath)) {
                $rewriteBase = dirname($_SERVER['SCRIPT_NAME']);
                if ($rewriteBase !== '/') {
                    $rewriteBase = rtrim($rewriteBase, '/') . '/';
                }
                $htaccess = file_get_contents($htaccessPath);
                $htaccess = preg_replace(
                    '/^(\s*)RewriteBase\s+.*$/m',
                    '$1RewriteBase ' . $rewriteBase,
                    $htaccess
                );
                @file_put_contents($htaccessPath, $htaccess);
            }
            
            $success = 'Installation completed successfully! You can now log in.';
            
            // Redirect to login after 2 seconds
            header('Refresh: 2; URL=index.php?page=login');
        }
    }
}

require 'templates/header.php';
?>

<style>
.db-option {
    border: 2px solid #ddd;
    border-radius: 8px;
    padding: 15px;
    margin-bottom: 15px;
    cursor: pointer;
    transition: all 0.3s;
}
.db-option:hover {
    border-color: #0d6efd;
    background-color: #f8f9fa;
}
.db-option.selected {
    border-color: #0d6efd;
    background-color: #e7f3ff;
}
.db-details {
    display: none;
    margin-top: 15px;
    padding: 15px;
    background-color: #f8f9fa;
    border-radius: 5px;
}
.db-details.show {
    display: block;
}
</style>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">
                    <h2>Install PXLBoard v12h</h2>
                </div>
                <div class="card-body">
                    <?php if ($error): ?>
                        <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
                    <?php endif; ?>
                    
                    <?php if ($success): ?>
                        <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
                    <?php else: ?>
                        <form method="POST" id="installForm">
                            <h4>Site Settings</h4>
                            
                            <div class="mb-3">
                                <label class="form-label">Site Name</label>
                                <input type="text" name="site_name" class="form-control" required value="PXLBoard">
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Site Description</label>
                                <input type="text" name="site_description" class="form-control" value="An image board system">
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Site URL (without trailing slash)</label>
                                <input type="url" name="site_url" class="form-control" required 
                                       value="<?php echo (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['SCRIPT_NAME']); ?>">
                            </div>
                            
                            <hr class="my-4">
                            <h4>Database Configuration</h4>
                            <p class="text-muted">Choose your preferred database backend</p>
                            
                            <div class="db-option" onclick="selectDatabase('flatfile')">
                                <input type="radio" name="db_type" value="flatfile" id="db_flatfile" checked>
                                <label for="db_flatfile" style="cursor: pointer; margin-left: 10px;">
                                    <strong>Flat File (JSON)</strong>
                                    <br>
                                    <small class="text-muted">Simple, no database server required. Best for small to medium sites.</small>
                                </label>
                            </div>
                            
                            <div class="db-option" onclick="selectDatabase('sqlite')">
                                <input type="radio" name="db_type" value="sqlite" id="db_sqlite">
                                <label for="db_sqlite" style="cursor: pointer; margin-left: 10px;">
                                    <strong>SQLite</strong>
                                    <br>
                                    <small class="text-muted">Lightweight SQL database. Good balance of performance and simplicity.</small>
                                </label>
                            </div>
                            
                            <div class="db-option" onclick="selectDatabase('mysql')">
                                <input type="radio" name="db_type" value="mysql" id="db_mysql">
                                <label for="db_mysql" style="cursor: pointer; margin-left: 10px;">
                                    <strong>MySQL / MariaDB</strong>
                                    <br>
                                    <small class="text-muted">Full-featured database server. Best for large, high-traffic sites.</small>
                                </label>
                                
                                <div id="mysql_config" class="db-details">
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Host</label>
                                            <input type="text" name="db_host" class="form-control" value="localhost">
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Database Name</label>
                                            <input type="text" name="db_name" class="form-control">
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Username</label>
                                            <input type="text" name="db_username" class="form-control">
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Password</label>
                                            <input type="password" name="db_password" class="form-control">
                                        </div>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Table Prefix</label>
                                        <input type="text" name="db_prefix" class="form-control" value="pxl_">
                                    </div>
                                </div>
                            </div>
                            
                            <hr class="my-4">
                            <h4>Administrator Account</h4>
                            
                            <div class="mb-3">
                                <label class="form-label">Username</label>
                                <input type="text" name="admin_username" class="form-control" required value="admin">
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Email</label>
                                <input type="email" name="admin_email" class="form-control" required>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Password (min <?php echo PASSWORD_MIN_LENGTH; ?> characters)</label>
                                <input type="password" name="admin_password" class="form-control" required>
                            </div>
                            
                            <button type="submit" class="btn btn-primary btn-lg">Install PXLBoard</button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function selectDatabase(type) {
    // Update radio buttons
    document.getElementById('db_flatfile').checked = (type === 'flatfile');
    document.getElementById('db_sqlite').checked = (type === 'sqlite');
    document.getElementById('db_mysql').checked = (type === 'mysql');
    
    // Update visual selection
    document.querySelectorAll('.db-option').forEach(opt => opt.classList.remove('selected'));
    event.currentTarget.classList.add('selected');
    
    // Show/hide MySQL config
    const mysqlConfig = document.getElementById('mysql_config');
    if (type === 'mysql') {
        mysqlConfig.classList.add('show');
    } else {
        mysqlConfig.classList.remove('show');
    }
}

// Initialize
document.addEventListener('DOMContentLoaded', function() {
    document.querySelector('.db-option').classList.add('selected');
});
</script>

<?php require 'templates/footer.php'; ?>
