<?php
/**
 * Admin Content Management Panel
 * For managing blogs and wiki pages
 * Version: 11-2
 */

if (!$auth->isAdmin()) {
    redirect('index.php?page=home');
}

$message = '';
$error = '';
$activeTab = $_GET['tab'] ?? 'blogs';

// Handle blog actions
if (isset($_GET['action']) && strpos($_GET['action'], 'blog_') === 0) {
    switch ($_GET['action']) {
        case 'blog_delete':
            $blogId = $_GET['id'] ?? '';
            if ($blogId && $db->get('blogs', $blogId)) {
                $db->delete('blogs', $blogId);
                $message = 'Blog post deleted successfully';
            } else {
                $error = 'Blog post not found';
            }
            break;
            
        case 'blog_toggle_publish':
            $blogId = $_GET['id'] ?? '';
            $blog = $db->get('blogs', $blogId);
            if ($blog) {
                $blog['published'] = !($blog['published'] ?? true);
                $db->save('blogs', $blogId, $blog);
                $message = $blog['published'] ? 'Blog post published' : 'Blog post unpublished';
            }
            break;
            
        case 'blog_feature':
            $blogId = $_GET['id'] ?? '';
            $blog = $db->get('blogs', $blogId);
            if ($blog) {
                $blog['featured'] = !($blog['featured'] ?? false);
                $db->save('blogs', $blogId, $blog);
                $message = $blog['featured'] ? 'Blog post featured' : 'Blog post unfeatured';
            }
            break;
    }
}

// Handle wiki actions
if (isset($_GET['action']) && strpos($_GET['action'], 'wiki_') === 0) {
    switch ($_GET['action']) {
        case 'wiki_delete':
            $wikiId = $_GET['id'] ?? '';
            if ($wikiId && $db->get('wiki', $wikiId)) {
                $db->delete('wiki', $wikiId);
                $message = 'Wiki page deleted successfully';
            } else {
                $error = 'Wiki page not found';
            }
            break;
            
        case 'wiki_toggle_publish':
            $wikiId = $_GET['id'] ?? '';
            $wiki = $db->get('wiki', $wikiId);
            if ($wiki) {
                $wiki['published'] = !($wiki['published'] ?? true);
                $db->save('wiki', $wikiId, $wiki);
                $message = $wiki['published'] ? 'Wiki page published' : 'Wiki page unpublished';
            }
            break;
            
        case 'wiki_lock':
            $wikiId = $_GET['id'] ?? '';
            $wiki = $db->get('wiki', $wikiId);
            if ($wiki) {
                $wiki['locked'] = !($wiki['locked'] ?? false);
                $db->save('wiki', $wikiId, $wiki);
                $message = $wiki['locked'] ? 'Wiki page locked' : 'Wiki page unlocked';
            }
            break;
            
        case 'wiki_revert':
            $wikiId = $_GET['id'] ?? '';
            $version = intval($_GET['version'] ?? 0);
            $wiki = $db->get('wiki', $wikiId);
            
            if ($wiki && isset($wiki['revisions'][$version])) {
                // Save current as new revision
                $revisions = $wiki['revisions'] ?? [];
                $revisions[] = [
                    'content' => $wiki['content'],
                    'timestamp' => time(),
                    'author' => $wiki['author'] ?? 'Unknown'
                ];
                
                // Revert to selected version
                $wiki['content'] = $wiki['revisions'][$version]['content'];
                $wiki['revisions'] = $revisions;
                $wiki['last_modified'] = time();
                $wiki['last_modified_by'] = $_SESSION['user']['username'];
                
                $db->save('wiki', $wikiId, $wiki);
                $message = 'Wiki page reverted to version ' . ($version + 1);
            }
            break;
    }
}

// Get all blogs
$allBlogs = $db->getAll('blogs');
usort($allBlogs, function($a, $b) {
    return ($b['created_at'] ?? 0) - ($a['created_at'] ?? 0);
});

// Get all wiki pages
$allWiki = $db->getAll('wiki');
usort($allWiki, function($a, $b) {
    return strcmp($a['title'] ?? '', $b['title'] ?? '');
});

// Calculate statistics
$stats = [
    'blogs' => [
        'total' => count($allBlogs),
        'published' => count(array_filter($allBlogs, fn($b) => $b['published'] ?? true)),
        'featured' => count(array_filter($allBlogs, fn($b) => $b['featured'] ?? false)),
        'drafts' => count(array_filter($allBlogs, fn($b) => !($b['published'] ?? true)))
    ],
    'wiki' => [
        'total' => count($allWiki),
        'published' => count(array_filter($allWiki, fn($w) => $w['published'] ?? true)),
        'locked' => count(array_filter($allWiki, fn($w) => $w['locked'] ?? false)),
        'drafts' => count(array_filter($allWiki, fn($w) => !($w['published'] ?? true)))
    ]
];

?>

<div class="admin-container">
    <h1>📝 Content Management</h1>
    
    <?php if ($message): ?>
        <div class="alert alert-success"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    
    <!-- Statistics Dashboard -->
    <div class="stats-grid">
        <div class="stat-card">
            <h3>📰 Blogs</h3>
            <div class="stat-number"><?= $stats['blogs']['total'] ?></div>
            <div class="stat-details">
                <span>✅ Published: <?= $stats['blogs']['published'] ?></span>
                <span>⭐ Featured: <?= $stats['blogs']['featured'] ?></span>
                <span>📝 Drafts: <?= $stats['blogs']['drafts'] ?></span>
            </div>
        </div>
        
        <div class="stat-card">
            <h3>📚 Wiki Pages</h3>
            <div class="stat-number"><?= $stats['wiki']['total'] ?></div>
            <div class="stat-details">
                <span>✅ Published: <?= $stats['wiki']['published'] ?></span>
                <span>🔒 Locked: <?= $stats['wiki']['locked'] ?></span>
                <span>📝 Drafts: <?= $stats['wiki']['drafts'] ?></span>
            </div>
        </div>
    </div>
    
    <!-- Tab Navigation -->
    <div class="tabs">
        <a href="?page=admin_content&tab=blogs" class="tab <?= $activeTab === 'blogs' ? 'active' : '' ?>">
            📰 Manage Blogs
        </a>
        <a href="?page=admin_content&tab=wiki" class="tab <?= $activeTab === 'wiki' ? 'active' : '' ?>">
            📚 Manage Wiki
        </a>
    </div>
    
    <!-- Blog Management Tab -->
    <?php if ($activeTab === 'blogs'): ?>
        <div class="tab-content">
            <div class="section-header">
                <h2>Blog Management</h2>
                <a href="?page=blog_edit" class="btn btn-primary">➕ Create New Blog Post</a>
            </div>
            
            <?php if (empty($allBlogs)): ?>
                <div class="empty-state">
                    <p>No blog posts found. Create your first blog post to get started!</p>
                    <a href="?page=blog_edit" class="btn btn-primary">Create Blog Post</a>
                </div>
            <?php else: ?>
                <div class="content-table">
                    <table>
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Author</th>
                                <th>Status</th>
                                <th>Created</th>
                                <th>Views</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($allBlogs as $id => $blog): ?>
                                <tr class="<?= !($blog['published'] ?? true) ? 'unpublished' : '' ?>">
                                    <td>
                                        <strong><?= htmlspecialchars($blog['title'] ?? 'Untitled') ?></strong>
                                        <?php if ($blog['featured'] ?? false): ?>
                                            <span class="badge badge-featured">⭐ Featured</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= htmlspecialchars($blog['author'] ?? 'Unknown') ?></td>
                                    <td>
                                        <?php if ($blog['published'] ?? true): ?>
                                            <span class="badge badge-published">✅ Published</span>
                                        <?php else: ?>
                                            <span class="badge badge-draft">📝 Draft</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= date('M j, Y', $blog['created_at'] ?? time()) ?></td>
                                    <td><?= $blog['views'] ?? 0 ?></td>
                                    <td class="actions">
                                        <a href="?page=blogs&id=<?= urlencode($id) ?>" 
                                           class="btn btn-sm" title="View">👁️</a>
                                        <a href="?page=blog_edit&id=<?= urlencode($id) ?>" 
                                           class="btn btn-sm" title="Edit">✏️</a>
                                        <a href="?page=admin_content&tab=blogs&action=blog_toggle_publish&id=<?= urlencode($id) ?>" 
                                           class="btn btn-sm" 
                                           title="<?= ($blog['published'] ?? true) ? 'Unpublish' : 'Publish' ?>">
                                            <?= ($blog['published'] ?? true) ? '👁️' : '🔒' ?>
                                        </a>
                                        <a href="?page=admin_content&tab=blogs&action=blog_feature&id=<?= urlencode($id) ?>" 
                                           class="btn btn-sm" 
                                           title="<?= ($blog['featured'] ?? false) ? 'Unfeature' : 'Feature' ?>">
                                            <?= ($blog['featured'] ?? false) ? '⭐' : '☆' ?>
                                        </a>
                                        <a href="?page=admin_content&tab=blogs&action=blog_delete&id=<?= urlencode($id) ?>" 
                                           class="btn btn-sm btn-danger" 
                                           onclick="return confirm('Are you sure you want to delete this blog post?')"
                                           title="Delete">🗑️</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>
    
    <!-- Wiki Management Tab -->
    <?php if ($activeTab === 'wiki'): ?>
        <div class="tab-content">
            <div class="section-header">
                <h2>Wiki Management</h2>
                <a href="?page=wiki_edit" class="btn btn-primary">➕ Create New Wiki Page</a>
            </div>
            
            <?php if (empty($allWiki)): ?>
                <div class="empty-state">
                    <p>No wiki pages found. Create your first wiki page to get started!</p>
                    <a href="?page=wiki_edit" class="btn btn-primary">Create Wiki Page</a>
                </div>
            <?php else: ?>
                <div class="content-table">
                    <table>
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Slug</th>
                                <th>Status</th>
                                <th>Created</th>
                                <th>Last Modified</th>
                                <th>Revisions</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($allWiki as $id => $wiki): ?>
                                <tr class="<?= !($wiki['published'] ?? true) ? 'unpublished' : '' ?>">
                                    <td>
                                        <strong><?= htmlspecialchars($wiki['title'] ?? 'Untitled') ?></strong>
                                        <?php if ($wiki['locked'] ?? false): ?>
                                            <span class="badge badge-locked">🔒 Locked</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><code><?= htmlspecialchars($wiki['slug'] ?? $id) ?></code></td>
                                    <td>
                                        <?php if ($wiki['published'] ?? true): ?>
                                            <span class="badge badge-published">✅ Published</span>
                                        <?php else: ?>
                                            <span class="badge badge-draft">📝 Draft</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= date('M j, Y', $wiki['created_at'] ?? time()) ?></td>
                                    <td>
                                        <?= isset($wiki['last_modified']) ? date('M j, Y', $wiki['last_modified']) : 'Never' ?>
                                        <?php if (isset($wiki['last_modified_by'])): ?>
                                            <br><small>by <?= htmlspecialchars($wiki['last_modified_by']) ?></small>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= count($wiki['revisions'] ?? []) ?></td>
                                    <td class="actions">
                                        <a href="?page=wiki&slug=<?= urlencode($wiki['slug'] ?? $id) ?>" 
                                           class="btn btn-sm" title="View">👁️</a>
                                        <a href="?page=wiki_edit&slug=<?= urlencode($wiki['slug'] ?? $id) ?>" 
                                           class="btn btn-sm" title="Edit">✏️</a>
                                        <a href="?page=admin_content&tab=wiki&action=wiki_toggle_publish&id=<?= urlencode($id) ?>" 
                                           class="btn btn-sm" 
                                           title="<?= ($wiki['published'] ?? true) ? 'Unpublish' : 'Publish' ?>">
                                            <?= ($wiki['published'] ?? true) ? '👁️' : '🔒' ?>
                                        </a>
                                        <a href="?page=admin_content&tab=wiki&action=wiki_lock&id=<?= urlencode($id) ?>" 
                                           class="btn btn-sm" 
                                           title="<?= ($wiki['locked'] ?? false) ? 'Unlock' : 'Lock' ?>">
                                            <?= ($wiki['locked'] ?? false) ? '🔓' : '🔒' ?>
                                        </a>
                                        <?php if (count($wiki['revisions'] ?? []) > 0): ?>
                                            <a href="#" class="btn btn-sm" 
                                               onclick="toggleRevisions('wiki-<?= urlencode($id) ?>'); return false;"
                                               title="View Revisions">📋</a>
                                        <?php endif; ?>
                                        <a href="?page=admin_content&tab=wiki&action=wiki_delete&id=<?= urlencode($id) ?>" 
                                           class="btn btn-sm btn-danger" 
                                           onclick="return confirm('Are you sure you want to delete this wiki page?')"
                                           title="Delete">🗑️</a>
                                    </td>
                                </tr>
                                <?php if (count($wiki['revisions'] ?? []) > 0): ?>
                                    <tr id="wiki-<?= urlencode($id) ?>-revisions" class="revisions-row" style="display: none;">
                                        <td colspan="7">
                                            <div class="revisions-panel">
                                                <h4>Revision History</h4>
                                                <table class="revisions-table">
                                                    <thead>
                                                        <tr>
                                                            <th>Version</th>
                                                            <th>Timestamp</th>
                                                            <th>Author</th>
                                                            <th>Actions</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php foreach (array_reverse($wiki['revisions'], true) as $version => $revision): ?>
                                                            <tr>
                                                                <td>#<?= $version + 1 ?></td>
                                                                <td><?= date('M j, Y g:i A', $revision['timestamp'] ?? time()) ?></td>
                                                                <td><?= htmlspecialchars($revision['author'] ?? 'Unknown') ?></td>
                                                                <td>
                                                                    <a href="?page=admin_content&tab=wiki&action=wiki_revert&id=<?= urlencode($id) ?>&version=<?= $version ?>"
                                                                       class="btn btn-sm"
                                                                       onclick="return confirm('Revert to this version?')">
                                                                        ↩️ Revert
                                                                    </a>
                                                                </td>
                                                            </tr>
                                                        <?php endforeach; ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>

<style>
.admin-container {
    padding: 20px;
    max-width: 1400px;
    margin: 0 auto;
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 20px;
    margin: 20px 0;
}

.stat-card {
    background: var(--bg-secondary, #f5f5f5);
    border-radius: 8px;
    padding: 20px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.stat-card h3 {
    margin: 0 0 10px 0;
    font-size: 1.2em;
}

.stat-number {
    font-size: 3em;
    font-weight: bold;
    color: var(--primary-color, #007bff);
    margin: 10px 0;
}

.stat-details {
    display: flex;
    flex-direction: column;
    gap: 5px;
    font-size: 0.9em;
    color: var(--text-secondary, #666);
}

.tabs {
    display: flex;
    gap: 10px;
    border-bottom: 2px solid var(--border-color, #ddd);
    margin: 30px 0 20px 0;
}

.tab {
    padding: 10px 20px;
    background: transparent;
    border: none;
    border-bottom: 3px solid transparent;
    cursor: pointer;
    text-decoration: none;
    color: var(--text-primary, #333);
    transition: all 0.3s;
}

.tab:hover {
    background: var(--bg-hover, #f0f0f0);
}

.tab.active {
    border-bottom-color: var(--primary-color, #007bff);
    color: var(--primary-color, #007bff);
    font-weight: bold;
}

.section-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

.content-table {
    overflow-x: auto;
}

.content-table table {
    width: 100%;
    border-collapse: collapse;
    background: var(--bg-primary, #fff);
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.content-table th {
    background: var(--bg-secondary, #f5f5f5);
    padding: 12px;
    text-align: left;
    font-weight: bold;
    border-bottom: 2px solid var(--border-color, #ddd);
}

.content-table td {
    padding: 12px;
    border-bottom: 1px solid var(--border-color, #eee);
}

.content-table tr:hover {
    background: var(--bg-hover, #f9f9f9);
}

.content-table tr.unpublished {
    opacity: 0.6;
}

.actions {
    white-space: nowrap;
}

.badge {
    display: inline-block;
    padding: 3px 8px;
    border-radius: 12px;
    font-size: 0.85em;
    font-weight: bold;
    margin-left: 5px;
}

.badge-published {
    background: #d4edda;
    color: #155724;
}

.badge-draft {
    background: #fff3cd;
    color: #856404;
}

.badge-featured {
    background: #ffeaa7;
    color: #d63031;
}

.badge-locked {
    background: #f8d7da;
    color: #721c24;
}

.btn-sm {
    padding: 5px 10px;
    font-size: 0.9em;
    margin: 0 2px;
    text-decoration: none;
    display: inline-block;
    border-radius: 4px;
    background: var(--bg-secondary, #f5f5f5);
    color: var(--text-primary, #333);
    border: 1px solid var(--border-color, #ddd);
}

.btn-sm:hover {
    background: var(--bg-hover, #e0e0e0);
}

.btn-danger {
    background: #dc3545;
    color: white;
    border-color: #dc3545;
}

.btn-danger:hover {
    background: #c82333;
}

.empty-state {
    text-align: center;
    padding: 60px 20px;
    color: var(--text-secondary, #666);
}

.empty-state p {
    font-size: 1.2em;
    margin-bottom: 20px;
}

.alert {
    padding: 15px;
    border-radius: 4px;
    margin-bottom: 20px;
}

.alert-success {
    background: #d4edda;
    color: #155724;
    border: 1px solid #c3e6cb;
}

.alert-error {
    background: #f8d7da;
    color: #721c24;
    border: 1px solid #f5c6cb;
}

.revisions-row {
    background: var(--bg-secondary, #f9f9f9);
}

.revisions-panel {
    padding: 20px;
}

.revisions-panel h4 {
    margin: 0 0 15px 0;
}

.revisions-table {
    width: 100%;
    margin-top: 10px;
}

.revisions-table th,
.revisions-table td {
    padding: 8px;
    text-align: left;
    border-bottom: 1px solid var(--border-color, #ddd);
}

.revisions-table th {
    background: var(--bg-hover, #f0f0f0);
    font-weight: bold;
}
</style>

<script>
function toggleRevisions(id) {
    const row = document.getElementById(id + '-revisions');
    if (row) {
        row.style.display = row.style.display === 'none' ? 'table-row' : 'none';
    }
}
</script>
