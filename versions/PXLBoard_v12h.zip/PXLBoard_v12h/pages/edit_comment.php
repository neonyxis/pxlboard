<?php
/**
 * Edit Comment Page
 */

if (!$auth->isLoggedIn()) {
    redirect('index.php?page=login');
}

$commentId = $_GET['id'] ?? '';
$comment = $db->get('comments', $commentId);

if (!$comment) {
    require 'pages/404.php';
    exit;
}

// Only allow comment owner or admin to edit
if ($_SESSION['user_id'] !== $comment['user_id'] && !$auth->isAdmin()) {
    redirect('index.php?page=image&id=' . $comment['image_id']);
}

$message = '';
$error = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_comment'])) {
    $newContent = trim($_POST['content'] ?? '');
    $editReason = trim($_POST['edit_reason'] ?? '');
    
    if (empty($newContent)) {
        $error = 'Comment cannot be empty';
    } else {
        // Initialize edit history if not present
        if (!isset($comment['edit_history'])) {
            $comment['edit_history'] = [];
        }
        
        // Add current content to history
        $comment['edit_history'][] = [
            'content' => $comment['comment'],
            'edited_at' => time(),
            'edited_by' => $_SESSION['username'],
            'reason' => $editReason
        ];
        
        // Update comment
        $comment['comment'] = $newContent;
        $comment['edited_at'] = time();
        $comment['last_editor'] = $_SESSION['username'];
        
        if ($db->save('comments', $commentId, $comment)) {
            $message = 'Comment updated successfully';
            // Redirect to image page after short delay
            header('refresh:2;url=index.php?page=image&id=' . $comment['image_id']);
        } else {
            $error = 'Failed to update comment';
        }
    }
}

require 'templates/header.php';
?>

<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h4><i class="bi bi-pencil-square"></i> Edit Comment</h4>
                </div>
                <div class="card-body">
                    <?php if ($message): ?>
                        <div class="alert alert-success alert-dismissible fade show">
                            <i class="bi bi-check-circle"></i> <?php echo htmlspecialchars($message); ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($error): ?>
                        <div class="alert alert-danger alert-dismissible fade show">
                            <i class="bi bi-exclamation-triangle"></i> <?php echo htmlspecialchars($error); ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>
                    
                    <div class="mb-3">
                        <small class="text-muted">
                            Originally posted by <strong><?php echo htmlspecialchars($comment['username']); ?></strong>
                            on <?php echo date('Y-m-d H:i', $comment['created_at']); ?>
                        </small>
                    </div>
                    
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Comment</label>
                            <textarea name="content" class="form-control" rows="5" required><?php echo htmlspecialchars($comment['comment']); ?></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Edit Reason (optional)</label>
                            <input type="text" name="edit_reason" class="form-control" 
                                   placeholder="e.g., Fixed typo, Added clarification">
                            <small class="text-muted">
                                Briefly explain why you're editing this comment
                            </small>
                        </div>
                        
                        <div class="d-flex justify-content-between">
                            <a href="index.php?page=image&id=<?php echo htmlspecialchars($comment['image_id']); ?>" 
                               class="btn btn-secondary">
                                <i class="bi bi-x-circle"></i> Cancel
                            </a>
                            <button type="submit" name="save_comment" class="btn btn-primary">
                                <i class="bi bi-check-circle"></i> Save Changes
                            </button>
                        </div>
                    </form>
                    
                    <?php if (!empty($comment['edit_history'])): ?>
                        <hr class="my-4">
                        <h5>Edit History (<?php echo count($comment['edit_history']); ?>)</h5>
                        <p class="text-muted small">
                            <a href="index.php?page=comment_history&id=<?php echo $commentId; ?>">
                                View full edit history
                            </a>
                        </p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require 'templates/footer.php'; ?>
