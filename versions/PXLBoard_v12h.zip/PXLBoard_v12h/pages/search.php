<?php
/**
 * Search Page
 */

$query = trim($_GET['q'] ?? '');
$results = [];

if (!empty($query)) {
    $allImages = $db->getAll('images');
    
    foreach ($allImages as $image) {
        // Search in title, description, and tags
        $match = false;
        
        if (stripos($image['title'], $query) !== false) {
            $match = true;
        } elseif (!empty($image['description']) && stripos($image['description'], $query) !== false) {
            $match = true;
        } elseif (!empty($image['tags'])) {
            foreach ($image['tags'] as $tag) {
                if (stripos($tag, $query) !== false) {
                    $match = true;
                    break;
                }
            }
        }
        
        if ($match) {
            $results[] = $image;
        }
    }
}

require 'templates/header.php';
?>

<div class="container mt-4">
    <h2>Search Results</h2>
    
    <form method="GET" action="index.php" class="mb-4">
        <input type="hidden" name="page" value="search">
        <div class="row g-2">
            <div class="col-auto flex-grow-1">
                <input type="text" name="q" class="form-control" placeholder="Search..." 
                       value="<?php echo escape($query); ?>" autofocus>
            </div>
            <div class="col-auto">
                <button type="submit" class="btn btn-primary">Search</button>
            </div>
        </div>
    </form>
    
    <?php if (!empty($query)): ?>
        <p class="text-muted">Found <?php echo count($results); ?> result(s) for "<?php echo escape($query); ?>"</p>
        
        <div class="row">
            <?php if (empty($results)): ?>
                <div class="col-12 text-center py-5">
                    <h3>No results found</h3>
                    <p class="text-muted">Try different keywords or browse <a href="index.php?page=tags">all tags</a></p>
                </div>
            <?php else: ?>
                <?php foreach ($results as $image): ?>
                    <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                        <div class="card image-card">
                            <a href="index.php?page=image&id=<?php echo escape($image['id']); ?>">
                                <img src="uploads/thumbs/<?php echo escape($image['filename']); ?>" 
                                     class="card-img-top" 
                                     alt="<?php echo escape($image['title']); ?>">
                            </a>
                            <div class="card-body">
                                <h6 class="card-title">
                                    <a href="index.php?page=image&id=<?php echo escape($image['id']); ?>">
                                        <?php echo escape($image['title']); ?>
                                    </a>
                                </h6>
                                <p class="card-text small text-muted">
                                    <?php echo escape($image['uploader']); ?>
                                </p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>

<?php require 'templates/footer.php'; ?>
