<?php
/**
 * PXLBoard - PHP Imageboard System
 * Entry Point
 */

session_start();

// Configuration
require_once 'config/config.php';
require_once 'includes/functions.php';
require_once 'includes/database.php';
require_once 'includes/auth.php';
require_once 'includes/rbac.php';

// Initialize database
// Load database configuration if it exists
$dbConfigFile = DATA_DIR . '/db_config.json';
if (file_exists($dbConfigFile)) {
    $dbConfig = json_decode(file_get_contents($dbConfigFile), true);
    $db = DatabaseFactory::create($dbConfig);
} else {
    // Fallback to FlatFile for backward compatibility
    $db = new FlatFileDB(DATA_DIR);
}

// Initialize authentication
$auth = new Auth($db);

// Initialize RBAC
$rbac = new RBAC($db);

// Router
$page = $_GET['page'] ?? 'home';
$action = $_GET['action'] ?? '';

// Check if installed
if (!file_exists(DATA_DIR . '/installed.lock') && $page !== 'install') {
    header('Location: index.php?page=install');
    exit;
}

// Route handling
switch ($page) {
    case 'install':
        require 'pages/install.php';
        break;
    case 'home':
        require 'pages/home.php';
        break;
    case 'gallery':
        require 'pages/gallery.php';
        break;
    case 'upload':
        require 'pages/upload.php';
        break;
    case 'image':
        require 'pages/image.php';
        break;
    case 'login':
        require 'pages/login.php';
        break;
    case 'register':
        require 'pages/register.php';
        break;
    case 'logout':
        require 'pages/logout.php';
        break;
    case 'profile':
        require 'pages/profile.php';
        break;
    case 'user':
        require 'pages/user.php';
        break;
    case 'admin':
        require 'pages/admin.php';
        break;
    case 'search':
        require 'pages/search.php';
        break;
    case 'tags':
        require 'pages/tags.php';
        break;
    case 'wiki':
        require 'pages/wiki.php';
        break;
    case 'wiki_edit':
        require 'pages/wiki_edit.php';
        break;
    case 'wiki_history':
        require 'pages/wiki_history.php';
        break;
    case 'admin_content':
        if ($auth->isAdmin()) {
            require 'pages/admin_content.php';
        } else {
            header('Location: index.php');
            exit;
        }
        break;
    case 'blogs':
        require 'pages/blogs.php';
        break;
    case 'blog_edit':
        require 'pages/blog_edit.php';
        break;
    case 'forums':
        require 'pages/forums.php';
        break;
    case 'channel':
        require 'pages/channel.php';
        break;
    case 'extensions':
        require 'pages/extensions.php';
        break;
    case 'moderation':
        if ($auth->isAdmin()) {
            require 'pages/moderation.php';
        } else {
            header('Location: index.php');
            exit;
        }
        break;
    case 'admin_forums':
        if ($auth->isAdmin()) {
            require 'pages/admin_forums.php';
        } else {
            header('Location: index.php');
            exit;
        }
        break;
    case 'api':
        require 'pages/api.php';
        break;
    case 'boards':
        require 'pages/boards.php';
        break;
    case 'board':
        require 'pages/board.php';
        break;
    case 'board_thread':
        require 'pages/board_thread.php';
        break;
    case 'create_board':
        require 'pages/create_board.php';
        break;
    case 'community_portal':
        require 'pages/community_portal.php';
        break;
    case 'gallery_enhanced':
        require 'pages/gallery_enhanced.php';
        break;
    case 'boards_enhanced':
        require 'pages/boards_with_thumbnails.php';
        break;
    case 'tgp':
        require 'pages/tgp.php';
        break;
    case 'tgp_create':
        require 'pages/tgp_create.php';
        break;
    case 'tgp_view':
        require 'pages/tgp_view.php';
        break;
    default:
        require 'pages/404.php';
        break;
}
