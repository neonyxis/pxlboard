# PXLBoard v11-2e - Installation & Upgrade Guide

## Quick Start

### New Installation
1. Extract `PXLBoard_v11-2e.zip` to your web directory
2. Visit `http://yoursite.com/install.php` (or `/subdirectory/install.php`)
3. Fill in the installation form
4. The installer will auto-configure paths and .htaccess
5. Log in with your admin credentials

### Upgrade from 11-2d

#### Automatic Method
1. **Backup your data directory** (important!)
   ```bash
   cp -r data data_backup_11-2d
   ```

2. **Extract new version** over existing installation
   - Replace all files EXCEPT the `data/` directory
   - Keep your existing `data/` folder intact

3. **Clean up corrupted data** (if you experienced profile bugs):
   ```bash
   # Check for and remove null.json if it exists
   rm -f data/users/null.json
   ```

4. **Test the upgrade**
   - Visit your site
   - Log in as admin
   - Check Admin Panel → Debug tab
   - Verify version shows as "11-2e"

#### Manual .htaccess Fix (Subdirectory Deployments Only)

If your site is in a subdirectory (e.g., `/pxlboard/V11d/`) and URLs aren't working:

1. Open `.htaccess` in a text editor
2. Find the line: `RewriteBase /`
3. Change it to your subdirectory path:
   ```apache
   RewriteBase /pxlboard/V11d/
   ```
4. Save and test

**OR** re-run the installer to auto-configure (this won't delete your data).

## What Gets Updated

### Files Modified
- `config/config.php` - Version number
- `includes/database.php` - ID injection fix
- `includes/functions.php` - URL generation
- `pages/profile.php` - Null guard
- `pages/install.php` - Auto-configuration
- `pages/admin.php` - Debug panel
- `templates/header.php` - Version badge
- `.htaccess` - Documentation

### Files Added
- `VERSION_NOTES_11-2e.md` - Release notes

### Your Data
**NOT MODIFIED**:
- `/data/` directory (all your content)
- `/uploads/` directory (all your images)
- `/data/settings.json` (your configuration)

## New Features Access

### Debug Panel
1. Log in as admin
2. Go to **Admin Panel**
3. Click the **Debug** tab
4. View:
   - System version and info
   - Path configuration
   - PHP settings
   - Database statistics
   - Recent errors
   - Quick diagnostics

### Version Badge
- Visible in navbar (admins only)
- Visible in footer (all users)
- Click "Copy Version" in Debug panel

## Troubleshooting

### URLs Still Broken After Upgrade

**Symptom**: `/user/john` gives 404 error

**Solution**:
1. Check your `SITE_URL` in Admin Panel → Settings
2. Make sure it includes the subdirectory if applicable
   - Good: `https://example.com/pxlboard/V11d`
   - Bad: `https://example.com`
3. Update `.htaccess` RewriteBase to match your subdirectory
4. Or re-run installer

### Profile Page Shows Warnings

**Symptom**: "Warning: Trying to access array offset on null"

**Solution**:
```bash
# Remove corrupted null.json file
rm -f data/users/null.json

# Users will need to log in again
```

### Debug Tab Not Showing

**Verification**:
1. Log in as admin
2. Check session: Admin Panel should be accessible
3. Hard refresh: Ctrl+F5 (or Cmd+Shift+R on Mac)

### Can't Access Admin Panel

**Symptom**: Redirected to home page

**Solution**:
```bash
# Verify your user is admin
cat data/users/admin_*.json | grep role
# Should show: "role": "admin"

# If not, manually edit the JSON file:
# Change "role": "user" to "role": "admin"
```

## Rollback Instructions

If you need to roll back to 11-2d:

1. **Stop!** - Keep your current `data/` directory
2. Download PXLBoard v11-2d
3. Extract over your installation
4. Restore backed up data:
   ```bash
   cp -r data_backup_11-2d/* data/
   ```
5. Visit your site - should work on 11-2d

## Support

### Check These First
1. **Debug Panel** - See errors and system info
2. **Error Log** - In Debug panel or server logs
3. **File Permissions** - Data and uploads must be writable
4. **Apache mod_rewrite** - Must be enabled

### Common Issues

**Issue**: Images not uploading
- Check: `uploads/` directory permissions (755 or 777)
- Check: `uploads/thumbs/` exists

**Issue**: Settings not saving
- Check: `data/` directory permissions (755 or 777)
- Check: `data/settings.json` is writable

**Issue**: User profiles broken
- Remove: `data/users/null.json` if exists
- Check: All user JSON files have valid `id` field

## Configuration Check

After upgrade, verify in **Admin → Debug**:

✅ Version shows "11-2e"  
✅ Data directory is writable  
✅ Uploads directory is writable  
✅ .htaccess file exists  
✅ RewriteBase matches your path  
✅ No null.json in users directory  

## Performance Notes

- Debug panel loads on-demand only
- No impact on regular pages
- Error log viewer reads last 20 lines only
- Version badge adds <1KB overhead

---

**Need Help?**
Check `VERSION_NOTES_11-2e.md` for detailed technical changes.
