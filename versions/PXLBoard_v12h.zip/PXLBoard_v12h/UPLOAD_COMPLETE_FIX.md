# Upload Fix - Complete Troubleshooting Guide

## What I Fixed

I've completely rewritten the upload.php file with these improvements:

### 1. **Simplified File Handling** ❌ Old Way
The old version used complex JavaScript with `DataTransfer` API that doesn't work in all browsers.

### 2. **Better Error Detection** ✅ New Way
- Checks if files are actually selected
- Validates each upload error code
- Shows meaningful error messages
- Debug mode available

### 3. **Removed Complex JavaScript** ✅ Fixed
- No more drag & drop complications
- No more file array manipulation
- Simple, standard file input
- Works in ALL browsers

### 4. **Added Debug Mode** ✅ New Feature
Visit: `index.php?page=upload&debug=1` to see:
- Exactly what's happening during upload
- File paths being used
- Permission issues
- Database operations

---

## How to Test the Fix

### Step 1: Access Debug Mode
```
http://yoursite.com/index.php?page=upload&debug=1
```

This will show you diagnostic information about what's happening.

### Step 2: Try a Simple Upload
1. Click "Select Image(s)" button
2. Choose ONE image file
3. Click "Upload Images"
4. Check the debug output

### Step 3: Check the Error Message
If it still doesn't work, the error message will tell you EXACTLY what's wrong:

#### Common Error Messages:

**"Upload directory is not writable"**
```bash
# Fix permissions
chmod 755 uploads
chmod 755 uploads/thumbs
sudo chown www-data:www-data uploads uploads/thumbs
```

**"File exceeds upload_max_filesize"**
```bash
# Check your PHP settings
php -i | grep upload_max_filesize

# Increase in .htaccess (already done)
# OR in php.ini:
upload_max_filesize = 20M
post_max_size = 22M
```

**"Missing temporary folder"**
```bash
# Check PHP temp directory
php -i | grep upload_tmp_dir

# If empty, add to php.ini:
upload_tmp_dir = /tmp
```

**"Failed to write file to disk"**
```bash
# Check disk space
df -h

# Check permissions on temp directory
ls -ld /tmp
```

---

## Debug Output Explained

When you enable debug mode, you'll see messages like:

```
POST request received
FILES array: present
Files detected: 1
Processing file: photo.jpg
File validated successfully
Upload path: /var/www/html/uploads/img_xyz.jpg
Created uploads dir: success
File moved successfully
Thumbnail created: success
Generated image ID: 1
Saved to database successfully
```

If you see **ERROR** in any line, that's your problem!

---

## Most Common Issues

### Issue #1: "No files selected" but you DID select files

**Cause:** Form encoding issue

**Check:** Look at the form tag in your browser's inspector:
```html
<form method="POST" enctype="multipart/form-data">
```

If `enctype` is missing, files won't upload!

**Fix:** Already fixed in new version

---

### Issue #2: Upload works but no thumbnail

**Cause:** GD library not installed

**Check:**
```bash
php -m | grep -i gd
```

**Fix:**
```bash
# Ubuntu/Debian
sudo apt-get install php-gd php-mbstring
sudo systemctl restart apache2

# CentOS/RHEL  
sudo yum install php-gd
sudo systemctl restart httpd
```

---

### Issue #3: "Permission denied" errors

**Cause:** Web server can't write to uploads directory

**Check:**
```bash
# What user is Apache running as?
ps aux | grep apache2 | head -1

# Check uploads directory permissions
ls -ld uploads
```

**Fix:**
```bash
# If Apache runs as www-data:
sudo chown -R www-data:www-data uploads
chmod 755 uploads
chmod 755 uploads/thumbs

# If Apache runs as apache:
sudo chown -R apache:apache uploads
chmod 755 uploads
chmod 755 uploads/thumbs
```

---

### Issue #4: Database error

**Cause:** Database directory not writable

**Check:**
```bash
ls -ld data/images
```

**Fix:**
```bash
chmod 755 data
chmod 755 data/images
sudo chown -R www-data:www-data data
```

---

## Testing Checklist

Use this checklist to test:

### Before Upload
- [ ] Navigate to upload page - loads without error
- [ ] Click "Select Image(s)" - file picker opens
- [ ] Select an image - file name appears
- [ ] Check debug link is visible in card header

### During Upload
- [ ] Click "Upload Images" button
- [ ] Page refreshes (normal POST behavior)
- [ ] Check for success or error message
- [ ] If error, read the message carefully

### After Upload (if successful)
- [ ] Success message appears
- [ ] Link to uploaded image appears
- [ ] Click link - image page loads
- [ ] Image displays correctly
- [ ] Thumbnail exists in gallery

### Verify Files
```bash
# Check uploaded file exists
ls -la uploads/
# Should see a file like: img_xyz.jpg

# Check thumbnail exists
ls -la uploads/thumbs/
# Should see same filename

# Check database entry
ls -la data/images/
# Should see img_1.json or similar

# View database content
cat data/images/img_1.json
```

---

## PHP Configuration Check

Run this to check your PHP settings:

```bash
php -i | grep -E 'upload_max_filesize|post_max_size|max_file_uploads|file_uploads'
```

Should show:
```
file_uploads => On
upload_max_filesize => 10M (or higher)
post_max_size => 12M (or higher)
max_file_uploads => 20
```

---

## Apache Configuration Check

Make sure mod_rewrite and file uploads are working:

```bash
# Check if Apache can handle uploads
apache2 -M | grep rewrite

# Check your .htaccess is being read
# Add this temporarily to .htaccess:
# php_value display_errors On

# Visit your site - if you see errors, .htaccess works
# Remove that line after testing!
```

---

## Advanced Debugging

If you still can't upload, add this to the TOP of `pages/upload.php`:

```php
<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Log everything
error_log("=== UPLOAD DEBUG ===");
error_log("POST: " . print_r($_POST, true));
error_log("FILES: " . print_r($_FILES, true));
error_log("SERVER: " . print_r($_SERVER, true));
```

Then check your error log:
```bash
tail -f /var/log/apache2/error.log
```

---

## What Changed in the New Version

| Old Version | New Version | Why |
|-------------|-------------|-----|
| Complex drag & drop | Simple file input | Browser compatibility |
| DataTransfer API | Standard file array | Works everywhere |
| Hidden errors | Detailed error messages | Easy debugging |
| No debug info | Debug mode available | Troubleshooting |
| Generic errors | Specific error codes | Know exact problem |

---

## Key Differences

### Old upload.php:
```javascript
// Used JavaScript to manipulate files
const dataTransfer = new DataTransfer();
dataTransfer.items.add(file);
fileInput.files = dataTransfer.files;
// ^^^ This fails in many browsers!
```

### New upload.php:
```html
<!-- Simple, standard HTML -->
<input type="file" name="images[]" multiple>
<!-- ^^^ Works in ALL browsers! -->
```

---

## File Structure After Fix

```
pxlboard/
├── pages/
│   ├── upload.php          # ✅ NEW FIXED VERSION
│   └── upload_backup.php   # Old version (backup)
├── uploads/                # Created automatically
│   ├── img_abc123.jpg      # Uploaded images
│   └── thumbs/
│       └── img_abc123.jpg  # Thumbnails
└── data/
    └── images/
        ├── img_1.json      # Image metadata
        └── _counter.txt    # ID counter
```

---

## Quick Start Guide

### 1. Deploy the Fixed Files
The new `upload.php` is ready to use.

### 2. Test with Debug Mode
Visit: `http://yoursite.com/index.php?page=upload&debug=1`

### 3. Try Uploading
- Select ONE small image (< 1MB)
- Fill in title
- Click Upload
- Read any error messages

### 4. Check Debug Output
The debug section will tell you EXACTLY what happened.

### 5. Fix Any Issues
Follow the error message instructions above.

---

## Still Not Working?

### Get the Debug Log

1. Enable debug mode: `?page=upload&debug=1`
2. Try uploading
3. Screenshot the debug output
4. Send it to me!

The debug output shows:
- Whether POST was received
- If files are in the request
- Each processing step
- Where it failed

---

## Summary of Fixes

✅ **Removed complex JavaScript** - No more DataTransfer API issues
✅ **Added comprehensive error handling** - Know exactly what's wrong
✅ **Added debug mode** - See what's happening
✅ **Fixed function name** - generateThumbnail instead of createThumbnail
✅ **Better file validation** - Check for all error codes
✅ **Clearer error messages** - Actionable feedback
✅ **Simplified form** - Works in all browsers
✅ **Added permission checks** - Detect write issues

---

## Expected Behavior

### Success Flow:
1. Select image → File name shows
2. Click Upload → Page refreshes
3. Green success message appears
4. "View your uploads" links appear
5. Click link → Image page opens
6. Image displays perfectly

### Error Flow:
1. Select image → File name shows
2. Click Upload → Page refreshes
3. Red error message appears
4. Error is specific and actionable
5. Debug mode shows exact issue
6. Fix issue and try again

---

## Final Notes

The new upload system is:
- **Simpler** - No complex JavaScript
- **More reliable** - Standard HTML forms
- **Better debugged** - Know what's wrong
- **Cross-browser** - Works everywhere
- **User-friendly** - Clear error messages

Try it now with debug mode enabled and you'll see exactly what's happening!

**Test URL:** `http://yoursite.com/index.php?page=upload&debug=1`

---

**Updated:** January 31, 2026
**Version:** 2.0 (Complete Rewrite)
**Status:** Ready for testing
