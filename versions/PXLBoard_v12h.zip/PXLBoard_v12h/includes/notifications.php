<?php
/**
 * Notification System
 * Handles email and in-app notifications
 */

class NotificationSystem {
    private $db;
    
    // Notification types
    const TYPE_COMMENT = 'comment';
    const TYPE_REPLY = 'reply';
    const TYPE_FAVORITE = 'favorite';
    const TYPE_LIKE = 'like';
    const TYPE_MENTION = 'mention';
    const TYPE_FOLLOW = 'follow';
    const TYPE_REPORT_UPDATE = 'report_update';
    const TYPE_ADMIN_MESSAGE = 'admin_message';
    const TYPE_WELCOME = 'welcome';
    const TYPE_THREAD_REPLY = 'thread_reply';
    const TYPE_BOARD_POST = 'board_post';
    const TYPE_TAG_WATCH = 'tag_watch';
    const TYPE_USER_WATCH = 'user_watch';
    const TYPE_IMAGE_APPROVED = 'image_approved';
    const TYPE_IMAGE_REJECTED = 'image_rejected';
    const TYPE_COMMENT_EDIT = 'comment_edit';
    const TYPE_WIKI_EDIT = 'wiki_edit';
    const TYPE_BLOG_POST = 'blog_post';
    const TYPE_VOTE_MILESTONE = 'vote_milestone';
    const TYPE_BADGE_EARNED = 'badge_earned';
    const TYPE_MODERATION_ACTION = 'moderation_action';
    const TYPE_SYSTEM_ANNOUNCEMENT = 'system_announcement';
    
    public function __construct($db) {
        $this->db = $db;
        $this->initDirectory();
    }
    
    /**
     * Initialize notifications directory
     */
    private function initDirectory() {
        $dir = DATA_DIR . '/notifications';
        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }
    }
    
    /**
     * Create a notification
     * @param string $userId Recipient user ID
     * @param string $type Notification type
     * @param string $title Notification title
     * @param string $message Notification message
     * @param array $data Additional data
     * @param bool $sendEmail Send email notification
     * @return array
     */
    public function create($userId, $type, $title, $message, $data = [], $sendEmail = false) {
        $notificationId = uniqid('notif_', true);
        
        $notification = [
            'user_id' => $userId,
            'type' => $type,
            'title' => $title,
            'message' => $message,
            'data' => $data,
            'created_at' => time(),
            'read' => false,
            'read_at' => null
        ];
        
        // Save notification
        $this->db->save('notifications', $notificationId, $notification);
        
        // Send email if requested and user has email notifications enabled
        if ($sendEmail) {
            $user = $this->db->get('users', $userId);
            if ($user && $this->shouldSendEmail($user, $type)) {
                $this->sendEmailNotification($user, $notification);
            }
        }
        
        return ['success' => true, 'notification_id' => $notificationId];
    }
    
    /**
     * Get notifications for a user
     * @param string $userId User ID
     * @param bool $unreadOnly Get only unread notifications
     * @param int $limit Limit number of results
     * @return array
     */
    public function getUserNotifications($userId, $unreadOnly = false, $limit = 50) {
        $notifications = $this->db->getAll('notifications');
        $userNotifications = [];
        
        foreach ($notifications as $notification) {
            if ($notification['user_id'] === $userId) {
                if (!$unreadOnly || !$notification['read']) {
                    $userNotifications[] = $notification;
                }
            }
        }
        
        // Sort by created_at descending
        usort($userNotifications, function($a, $b) {
            return $b['created_at'] - $a['created_at'];
        });
        
        return array_slice($userNotifications, 0, $limit);
    }
    
    /**
     * Get unread notification count
     * @param string $userId User ID
     * @return int
     */
    public function getUnreadCount($userId) {
        $notifications = $this->getUserNotifications($userId, true);
        return count($notifications);
    }
    
    /**
     * Mark notification as read
     * @param string $notificationId Notification ID
     * @return bool
     */
    public function markAsRead($notificationId) {
        $notification = $this->db->get('notifications', $notificationId);
        if (!$notification) {
            return false;
        }
        
        $notification['read'] = true;
        $notification['read_at'] = time();
        
        return $this->db->save('notifications', $notificationId, $notification);
    }
    
    /**
     * Mark all notifications as read for a user
     * @param string $userId User ID
     * @return int Number of notifications marked
     */
    public function markAllAsRead($userId) {
        $notifications = $this->getUserNotifications($userId, true);
        $count = 0;
        
        foreach ($notifications as $notification) {
            if ($this->markAsRead($notification['id'])) {
                $count++;
            }
        }
        
        return $count;
    }
    
    /**
     * Delete a notification
     * @param string $notificationId Notification ID
     * @return bool
     */
    public function delete($notificationId) {
        return $this->db->delete('notifications', $notificationId);
    }
    
    /**
     * Delete old notifications (older than 30 days)
     * @return int Number of deleted notifications
     */
    public function cleanOldNotifications() {
        $notifications = $this->db->getAll('notifications');
        $cutoff = time() - (30 * 24 * 60 * 60); // 30 days ago
        $count = 0;
        
        foreach ($notifications as $notification) {
            if ($notification['created_at'] < $cutoff) {
                if ($this->db->delete('notifications', $notification['id'])) {
                    $count++;
                }
            }
        }
        
        return $count;
    }
    
    /**
     * Check if email notification should be sent
     * @param array $user User data
     * @param string $type Notification type
     * @return bool
     */
    private function shouldSendEmail($user, $type) {
        // Check if SMTP is enabled
        if (!SMTP_ENABLED) {
            return false;
        }
        
        // Check user preferences
        $emailPrefs = $user['email_notifications'] ?? [];
        
        // If no preferences set, use defaults
        if (empty($emailPrefs)) {
            $defaultPrefs = [
                self::TYPE_COMMENT => true,
                self::TYPE_REPLY => true,
                self::TYPE_FAVORITE => false,
                self::TYPE_LIKE => false,
                self::TYPE_MENTION => true,
                self::TYPE_FOLLOW => true,
                self::TYPE_REPORT_UPDATE => true,
                self::TYPE_ADMIN_MESSAGE => true,
                self::TYPE_WELCOME => true
            ];
            return $defaultPrefs[$type] ?? false;
        }
        
        return $emailPrefs[$type] ?? false;
    }
    
    /**
     * Send email notification
     * @param array $user User data
     * @param array $notification Notification data
     * @return bool
     */
    private function sendEmailNotification($user, $notification) {
        $to = $user['email'];
        $subject = '[' . SITE_NAME . '] ' . $notification['title'];
        
        // Build HTML email
        $htmlMessage = $this->buildHtmlEmail($user, $notification);
        
        // Build plain text fallback
        $textMessage = "Hello " . $user['username'] . ",\n\n";
        $textMessage .= $notification['message'] . "\n\n";
        
        // Add action link if available
        if (isset($notification['data']['link'])) {
            $textMessage .= "View: " . SITE_URL . $notification['data']['link'] . "\n\n";
        }
        
        $textMessage .= "---\n";
        $textMessage .= "You can manage your email notification preferences in your profile settings.\n";
        $textMessage .= SITE_URL . "/index.php?page=profile\n";
        
        return sendEmail($to, $subject, $htmlMessage, true);
    }
    
    /**
     * Build HTML email template
     * @param array $user User data
     * @param array $notification Notification data
     * @return string HTML email content
     */
    private function buildHtmlEmail($user, $notification) {
        $actionLink = isset($notification['data']['link']) 
            ? SITE_URL . $notification['data']['link'] 
            : SITE_URL;
        
        $actionButton = isset($notification['data']['link']) 
            ? '<a href="' . htmlspecialchars($actionLink) . '" style="display: inline-block; padding: 12px 24px; background-color: #0d6efd; color: #ffffff; text-decoration: none; border-radius: 5px; margin: 20px 0;">View Now</a>'
            : '';
        
        $html = '<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>' . htmlspecialchars($notification['title']) . '</title>
</head>
<body style="margin: 0; padding: 0; font-family: Arial, sans-serif; background-color: #f5f5f5;">
    <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f5f5f5; padding: 20px;">
        <tr>
            <td align="center">
                <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 10px; overflow: hidden; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                    <!-- Header -->
                    <tr>
                        <td style="background-color: #0d6efd; padding: 30px; text-align: center;">
                            <h1 style="margin: 0; color: #ffffff; font-size: 24px;">' . htmlspecialchars(SITE_NAME) . '</h1>
                        </td>
                    </tr>
                    
                    <!-- Content -->
                    <tr>
                        <td style="padding: 40px 30px;">
                            <p style="margin: 0 0 10px; font-size: 16px; color: #333333;">Hello ' . htmlspecialchars($user['username']) . ',</p>
                            
                            <h2 style="margin: 20px 0 15px; font-size: 20px; color: #333333;">' . htmlspecialchars($notification['title']) . '</h2>
                            
                            <p style="margin: 0 0 20px; font-size: 14px; line-height: 1.6; color: #666666;">' . nl2br(htmlspecialchars($notification['message'])) . '</p>
                            
                            ' . $actionButton . '
                        </td>
                    </tr>
                    
                    <!-- Footer -->
                    <tr>
                        <td style="background-color: #f8f9fa; padding: 20px 30px; border-top: 1px solid #dee2e6;">
                            <p style="margin: 0 0 10px; font-size: 12px; color: #6c757d;">
                                You can manage your notification preferences in your 
                                <a href="' . SITE_URL . '/index.php?page=profile" style="color: #0d6efd; text-decoration: none;">profile settings</a>.
                            </p>
                            <p style="margin: 0; font-size: 12px; color: #6c757d;">
                                &copy; ' . date('Y') . ' ' . htmlspecialchars(SITE_NAME) . '. All rights reserved.
                            </p>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>';
        
        return $html;
    }
    
    /**
     * Notify on new comment
     * @param string $imageId Image ID
     * @param string $commenterId Commenter user ID
     * @param string $comment Comment text
     */
    public function notifyNewComment($imageId, $commenterId, $comment) {
        $image = $this->db->get('images', $imageId);
        if (!$image) {
            return;
        }
        
        $commenter = $this->db->get('users', $commenterId);
        $imageOwnerId = $image['uploader_id'];
        
        // Don't notify if commenting on own image
        if ($imageOwnerId === $commenterId) {
            return;
        }
        
        $title = 'New comment on your image';
        $message = ($commenter['username'] ?? 'Someone') . ' commented on your image "' . $image['title'] . '"';
        
        $data = [
            'link' => '/index.php?page=image&id=' . $imageId . '#comments',
            'image_id' => $imageId,
            'commenter_id' => $commenterId
        ];
        
        $this->create($imageOwnerId, self::TYPE_COMMENT, $title, $message, $data, true);
    }
    
    /**
     * Notify on comment reply
     * @param string $parentCommentId Parent comment ID
     * @param string $replierId Replier user ID
     * @param string $reply Reply text
     */
    public function notifyCommentReply($parentCommentId, $replierId, $reply) {
        $parentComment = $this->db->get('comments', $parentCommentId);
        if (!$parentComment) {
            return;
        }
        
        $parentAuthorId = $parentComment['user_id'];
        
        // Don't notify if replying to own comment
        if ($parentAuthorId === $replierId) {
            return;
        }
        
        $replier = $this->db->get('users', $replierId);
        
        $title = 'New reply to your comment';
        $message = ($replier['username'] ?? 'Someone') . ' replied to your comment';
        
        $data = [
            'link' => '/index.php?page=image&id=' . $parentComment['image_id'] . '#comment-' . $parentCommentId,
            'comment_id' => $parentCommentId,
            'replier_id' => $replierId
        ];
        
        $this->create($parentAuthorId, self::TYPE_REPLY, $title, $message, $data, true);
    }
    
    /**
     * Notify on new favorite
     * @param string $imageId Image ID
     * @param string $favoriterId User who favorited
     */
    public function notifyNewFavorite($imageId, $favoriterId) {
        $image = $this->db->get('images', $imageId);
        if (!$image) {
            return;
        }
        
        $imageOwnerId = $image['uploader_id'];
        
        // Don't notify if favoriting own image
        if ($imageOwnerId === $favoriterId) {
            return;
        }
        
        $favoriter = $this->db->get('users', $favoriterId);
        
        $title = 'Someone favorited your image';
        $message = ($favoriter['username'] ?? 'Someone') . ' favorited your image "' . $image['title'] . '"';
        
        $data = [
            'link' => '/index.php?page=image&id=' . $imageId,
            'image_id' => $imageId,
            'favoriter_id' => $favoriterId
        ];
        
        $this->create($imageOwnerId, self::TYPE_FAVORITE, $title, $message, $data, false);
    }
    
    /**
     * Send welcome email to new user
     * @param string $userId User ID
     */
    public function sendWelcomeEmail($userId) {
        $user = $this->db->get('users', $userId);
        if (!$user) {
            return;
        }
        
        $title = 'Welcome to ' . SITE_NAME;
        $message = "Welcome to " . SITE_NAME . "!\n\n";
        $message .= "Thank you for joining our community. Here are some things you can do:\n";
        $message .= "- Upload and share images\n";
        $message .= "- Comment and rate images\n";
        $message .= "- Create favorites collections\n";
        $message .= "- Participate in forums\n\n";
        $message .= "Get started: " . SITE_URL . "/index.php?page=upload";
        
        $data = ['link' => '/index.php?page=home'];
        
        $this->create($userId, self::TYPE_WELCOME, $title, $message, $data, true);
    }
    
    /**
     * Get notification HTML badge
     * @param string $userId User ID
     * @return string HTML
     */
    public function getNotificationBadge($userId) {
        $count = $this->getUnreadCount($userId);
        
        if ($count > 0) {
            return '<span class="badge bg-danger rounded-pill">' . ($count > 99 ? '99+' : $count) . '</span>';
        }
        
        return '';
    }
    
    /**
     * Get notifications HTML list
     * @param string $userId User ID
     * @param int $limit Limit
     * @return string HTML
     */
    public function getNotificationsHtml($userId, $limit = 10) {
        $notifications = $this->getUserNotifications($userId, false, $limit);
        
        if (empty($notifications)) {
            return '<div class="text-center text-muted py-3">No notifications</div>';
        }
        
        $html = '<div class="list-group list-group-flush">';
        
        foreach ($notifications as $notification) {
            $unreadClass = $notification['read'] ? '' : 'list-group-item-primary';
            $icon = $this->getNotificationIcon($notification['type']);
            $timeAgo = timeAgo($notification['created_at']);
            
            $link = $notification['data']['link'] ?? '#';
            
            $html .= '<a href="' . htmlspecialchars($link) . '" class="list-group-item list-group-item-action ' . $unreadClass . '">';
            $html .= '<div class="d-flex w-100 justify-content-between">';
            $html .= '<h6 class="mb-1"><i class="bi bi-' . $icon . '"></i> ' . htmlspecialchars($notification['title']) . '</h6>';
            $html .= '<small>' . $timeAgo . '</small>';
            $html .= '</div>';
            $html .= '<p class="mb-1 small">' . htmlspecialchars($notification['message']) . '</p>';
            $html .= '</a>';
        }
        
        $html .= '</div>';
        
        return $html;
    }
    
    /**
     * Get icon for notification type
     * @param string $type Notification type
     * @return string Bootstrap icon name
     */
    private function getNotificationIcon($type) {
        $icons = [
            self::TYPE_COMMENT => 'chat-left-text',
            self::TYPE_REPLY => 'reply',
            self::TYPE_FAVORITE => 'star-fill',
            self::TYPE_LIKE => 'heart-fill',
            self::TYPE_MENTION => 'at',
            self::TYPE_FOLLOW => 'person-plus',
            self::TYPE_REPORT_UPDATE => 'flag',
            self::TYPE_ADMIN_MESSAGE => 'shield-check',
            self::TYPE_WELCOME => 'hand-thumbs-up'
        ];
        
        return $icons[$type] ?? 'bell';
    }
}
