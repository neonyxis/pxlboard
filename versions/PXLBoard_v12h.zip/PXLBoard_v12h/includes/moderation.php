<?php
/**
 * Moderation System
 * Handles bans, reports, and mutes
 */

class Moderation {
    private $db;
    
    public function __construct($db) {
        $this->db = $db;
        $this->initDirectories();
    }
    
    private function initDirectories() {
        $dirs = [
            DATA_DIR . '/bans',
            DATA_DIR . '/reports',
            DATA_DIR . '/mutes'
        ];
        
        foreach ($dirs as $dir) {
            if (!is_dir($dir)) {
                @mkdir($dir, 0755, true);
            }
        }
    }
    
    // ============================================
    // BAN SYSTEM
    // ============================================
    
    /**
     * Ban a user
     * @param string $userId User ID to ban
     * @param string $reason Ban reason
     * @param string $bannedBy Admin user ID
     * @param int $duration Duration in seconds (0 = permanent)
     * @param bool $ipBan Also ban IP address
     * @return array
     */
    public function banUser($userId, $reason, $bannedBy, $duration = 0, $ipBan = false) {
        $user = $this->db->get('users', $userId);
        if (!$user) {
            return ['success' => false, 'error' => 'User not found'];
        }
        
        $banId = uniqid('ban_', true);
        $expiresAt = $duration > 0 ? time() + $duration : 0;
        
        $banData = [
            'user_id' => $userId,
            'username' => $user['username'],
            'reason' => $reason,
            'banned_by' => $bannedBy,
            'created_at' => time(),
            'expires_at' => $expiresAt,
            'is_permanent' => $duration === 0,
            'ip_address' => $ipBan ? $_SERVER['REMOTE_ADDR'] : null,
            'is_ip_ban' => $ipBan,
            'is_active' => true
        ];
        
        if ($this->db->save('bans', $banId, $banData)) {
            // Update user status
            $user['is_banned'] = true;
            $user['ban_id'] = $banId;
            $this->db->save('users', $userId, $user);
            
            // Log the action
            $this->logModAction('ban_user', $bannedBy, $userId, $reason);
            
            return ['success' => true, 'ban_id' => $banId];
        }
        
        return ['success' => false, 'error' => 'Failed to ban user'];
    }
    
    /**
     * Unban a user
     * @param string $userId User ID to unban
     * @param string $unbannedBy Admin user ID
     * @return array
     */
    public function unbanUser($userId, $unbannedBy) {
        $user = $this->db->get('users', $userId);
        if (!$user || !isset($user['ban_id'])) {
            return ['success' => false, 'error' => 'User is not banned'];
        }
        
        $ban = $this->db->get('bans', $user['ban_id']);
        if ($ban) {
            $ban['is_active'] = false;
            $ban['unbanned_at'] = time();
            $ban['unbanned_by'] = $unbannedBy;
            $this->db->save('bans', $user['ban_id'], $ban);
        }
        
        $user['is_banned'] = false;
        unset($user['ban_id']);
        $this->db->save('users', $userId, $user);
        
        $this->logModAction('unban_user', $unbannedBy, $userId, 'Ban lifted');
        
        return ['success' => true];
    }
    
    /**
     * Check if a user is banned
     * @param string $userId User ID
     * @return bool|array False if not banned, ban data if banned
     */
    public function isBanned($userId) {
        $user = $this->db->get('users', $userId);
        if (!$user || !isset($user['is_banned']) || !$user['is_banned']) {
            return false;
        }
        
        if (!isset($user['ban_id'])) {
            return false;
        }
        
        $ban = $this->db->get('bans', $user['ban_id']);
        if (!$ban || !$ban['is_active']) {
            return false;
        }
        
        // Check if temporary ban has expired
        if (!$ban['is_permanent'] && $ban['expires_at'] > 0 && time() > $ban['expires_at']) {
            $this->unbanUser($userId, 'system');
            return false;
        }
        
        return $ban;
    }
    
    /**
     * Check if an IP is banned
     * @param string $ip IP address
     * @return bool
     */
    public function isIpBanned($ip) {
        $bans = $this->db->getAll('bans');
        foreach ($bans as $ban) {
            if ($ban['is_active'] && $ban['is_ip_ban'] && $ban['ip_address'] === $ip) {
                // Check expiration
                if (!$ban['is_permanent'] && $ban['expires_at'] > 0 && time() > $ban['expires_at']) {
                    $ban['is_active'] = false;
                    $this->db->save('bans', $ban['id'], $ban);
                    continue;
                }
                return true;
            }
        }
        return false;
    }
    
    /**
     * Get all active bans
     * @return array
     */
    public function getActiveBans() {
        $bans = $this->db->getAll('bans');
        $activeBans = [];
        
        foreach ($bans as $ban) {
            if ($ban['is_active']) {
                // Check if expired
                if (!$ban['is_permanent'] && $ban['expires_at'] > 0 && time() > $ban['expires_at']) {
                    $ban['is_active'] = false;
                    $this->db->save('bans', $ban['id'], $ban);
                } else {
                    $activeBans[] = $ban;
                }
            }
        }
        
        return $activeBans;
    }
    
    /**
     * Get ban history for a user
     * @param string $userId User ID
     * @return array
     */
    public function getUserBanHistory($userId) {
        $bans = $this->db->getAll('bans');
        $userBans = [];
        
        foreach ($bans as $ban) {
            if ($ban['user_id'] === $userId) {
                $userBans[] = $ban;
            }
        }
        
        return $userBans;
    }
    
    // ============================================
    // REPORT SYSTEM
    // ============================================
    
    /**
     * Report content
     * @param string $type Type: 'image', 'comment', 'user', 'forum_post'
     * @param string $contentId Content ID
     * @param string $reason Report reason
     * @param string $category Category: 'spam', 'offensive', 'copyright', 'illegal', 'other'
     * @param string $reportedBy Reporter user ID
     * @return array
     */
    public function reportContent($type, $contentId, $reason, $category, $reportedBy) {
        // Check if already reported by this user
        $existingReports = $this->db->getAll('reports');
        foreach ($existingReports as $report) {
            if ($report['type'] === $type && 
                $report['content_id'] === $contentId && 
                $report['reported_by'] === $reportedBy &&
                $report['status'] === 'pending') {
                return ['success' => false, 'error' => 'You have already reported this content'];
            }
        }
        
        $reportId = uniqid('report_', true);
        $reportData = [
            'type' => $type,
            'content_id' => $contentId,
            'reason' => $reason,
            'category' => $category,
            'reported_by' => $reportedBy,
            'created_at' => time(),
            'status' => 'pending', // pending, reviewed, dismissed, actioned
            'reviewed_by' => null,
            'reviewed_at' => null,
            'moderator_notes' => null
        ];
        
        if ($this->db->save('reports', $reportId, $reportData)) {
            // Send notification to admins
            $this->notifyModerators('new_report', $reportId);
            
            return ['success' => true, 'report_id' => $reportId];
        }
        
        return ['success' => false, 'error' => 'Failed to submit report'];
    }
    
    /**
     * Get all pending reports
     * @return array
     */
    public function getPendingReports() {
        $reports = $this->db->getAll('reports');
        $pending = [];
        
        foreach ($reports as $report) {
            if ($report['status'] === 'pending') {
                // Enhance with content info
                $report['content_info'] = $this->getReportContentInfo($report['type'], $report['content_id']);
                $pending[] = $report;
            }
        }
        
        return $pending;
    }
    
    /**
     * Get report by ID
     * @param string $reportId Report ID
     * @return array|null
     */
    public function getReport($reportId) {
        $report = $this->db->get('reports', $reportId);
        if ($report) {
            $report['content_info'] = $this->getReportContentInfo($report['type'], $report['content_id']);
        }
        return $report;
    }
    
    /**
     * Process a report
     * @param string $reportId Report ID
     * @param string $action 'dismiss', 'delete_content', 'ban_user', 'warn_user'
     * @param string $moderatorId Moderator user ID
     * @param string $notes Moderator notes
     * @return array
     */
    public function processReport($reportId, $action, $moderatorId, $notes = '') {
        $report = $this->db->get('reports', $reportId);
        if (!$report) {
            return ['success' => false, 'error' => 'Report not found'];
        }
        
        $report['status'] = 'reviewed';
        $report['reviewed_by'] = $moderatorId;
        $report['reviewed_at'] = time();
        $report['moderator_notes'] = $notes;
        $report['action_taken'] = $action;
        
        // Execute the action
        switch ($action) {
            case 'delete_content':
                $this->deleteReportedContent($report['type'], $report['content_id']);
                break;
            case 'ban_user':
                // Get content owner
                $contentOwner = $this->getContentOwner($report['type'], $report['content_id']);
                if ($contentOwner) {
                    $this->banUser($contentOwner, "Content violation: " . $report['reason'], $moderatorId, 86400 * 7); // 7 day ban
                }
                break;
            case 'warn_user':
                // TODO: Implement warning system
                break;
            case 'dismiss':
                $report['status'] = 'dismissed';
                break;
        }
        
        $this->db->save('reports', $reportId, $report);
        $this->logModAction('process_report', $moderatorId, $reportId, $action);
        
        return ['success' => true];
    }
    
    /**
     * Get content info for a report
     * @param string $type Content type
     * @param string $contentId Content ID
     * @return array|null
     */
    private function getReportContentInfo($type, $contentId) {
        switch ($type) {
            case 'image':
                return $this->db->get('images', $contentId);
            case 'comment':
                return $this->db->get('comments', $contentId);
            case 'user':
                return $this->db->get('users', $contentId);
            case 'forum_post':
                $topic = $this->db->get('forum_topics', $contentId);
                if (!$topic) {
                    $topic = $this->db->get('forum_replies', $contentId);
                }
                return $topic;
            default:
                return null;
        }
    }
    
    /**
     * Delete reported content
     * @param string $type Content type
     * @param string $contentId Content ID
     * @return bool
     */
    private function deleteReportedContent($type, $contentId) {
        switch ($type) {
            case 'image':
                // TODO: Also delete image file
                return $this->db->delete('images', $contentId);
            case 'comment':
                return $this->db->delete('comments', $contentId);
            case 'forum_post':
                $topic = $this->db->get('forum_topics', $contentId);
                if ($topic) {
                    return $this->db->delete('forum_topics', $contentId);
                } else {
                    return $this->db->delete('forum_replies', $contentId);
                }
            default:
                return false;
        }
    }
    
    /**
     * Get content owner
     * @param string $type Content type
     * @param string $contentId Content ID
     * @return string|null User ID
     */
    private function getContentOwner($type, $contentId) {
        $content = $this->getReportContentInfo($type, $contentId);
        if ($content && isset($content['user_id'])) {
            return $content['user_id'];
        }
        return null;
    }
    
    // ============================================
    // MUTE SYSTEM
    // ============================================
    
    /**
     * Mute a user
     * @param string $mutedUserId User ID to mute
     * @param string $mutedBy User ID doing the muting
     * @return array
     */
    public function muteUser($mutedUserId, $mutedBy) {
        if ($mutedUserId === $mutedBy) {
            return ['success' => false, 'error' => 'Cannot mute yourself'];
        }
        
        // Check if already muted
        $muteId = $mutedBy . '_' . $mutedUserId;
        $existing = $this->db->get('mutes', $muteId);
        if ($existing) {
            return ['success' => false, 'error' => 'User already muted'];
        }
        
        $muteData = [
            'muted_user_id' => $mutedUserId,
            'muted_by' => $mutedBy,
            'created_at' => time()
        ];
        
        if ($this->db->save('mutes', $muteId, $muteData)) {
            return ['success' => true];
        }
        
        return ['success' => false, 'error' => 'Failed to mute user'];
    }
    
    /**
     * Unmute a user
     * @param string $mutedUserId User ID to unmute
     * @param string $mutedBy User ID doing the unmuting
     * @return array
     */
    public function unmuteUser($mutedUserId, $mutedBy) {
        $muteId = $mutedBy . '_' . $mutedUserId;
        if ($this->db->delete('mutes', $muteId)) {
            return ['success' => true];
        }
        return ['success' => false, 'error' => 'Failed to unmute user'];
    }
    
    /**
     * Check if a user is muted by another user
     * @param string $mutedUserId User ID to check
     * @param string $checkingUser User ID checking
     * @return bool
     */
    public function isMuted($mutedUserId, $checkingUser) {
        $muteId = $checkingUser . '_' . $mutedUserId;
        return $this->db->get('mutes', $muteId) !== null;
    }
    
    /**
     * Get all users muted by a user
     * @param string $userId User ID
     * @return array
     */
    public function getMutedUsers($userId) {
        $mutes = $this->db->getAll('mutes');
        $mutedUsers = [];
        
        foreach ($mutes as $mute) {
            if ($mute['muted_by'] === $userId) {
                $user = $this->db->get('users', $mute['muted_user_id']);
                if ($user) {
                    $mutedUsers[] = [
                        'user_id' => $mute['muted_user_id'],
                        'username' => $user['username'],
                        'muted_at' => $mute['created_at']
                    ];
                }
            }
        }
        
        return $mutedUsers;
    }
    
    // ============================================
    // HELPER FUNCTIONS
    // ============================================
    
    /**
     * Log moderation action
     * @param string $action Action type
     * @param string $moderatorId Moderator user ID
     * @param string $targetId Target ID
     * @param string $reason Reason
     */
    private function logModAction($action, $moderatorId, $targetId, $reason) {
        $logId = uniqid('modlog_', true);
        $logData = [
            'action' => $action,
            'moderator_id' => $moderatorId,
            'target_id' => $targetId,
            'reason' => $reason,
            'timestamp' => time(),
            'ip_address' => $_SERVER['REMOTE_ADDR']
        ];
        
        $logFile = DATA_DIR . '/mod_log.json';
        $logs = [];
        
        if (file_exists($logFile)) {
            $logs = json_decode(file_get_contents($logFile), true) ?: [];
        }
        
        $logs[] = $logData;
        
        // Keep only last 1000 logs
        if (count($logs) > 1000) {
            $logs = array_slice($logs, -1000);
        }
        
        file_put_contents($logFile, json_encode($logs, JSON_PRETTY_PRINT));
    }
    
    /**
     * Get moderation logs
     * @param int $limit Number of logs to retrieve
     * @return array
     */
    public function getModLogs($limit = 100) {
        $logFile = DATA_DIR . '/mod_log.json';
        if (!file_exists($logFile)) {
            return [];
        }
        
        $logs = json_decode(file_get_contents($logFile), true) ?: [];
        
        // Sort by timestamp descending
        usort($logs, function($a, $b) {
            return $b['timestamp'] - $a['timestamp'];
        });
        
        return array_slice($logs, 0, $limit);
    }
    
    /**
     * Send notification to moderators
     * @param string $type Notification type
     * @param string $contentId Related content ID
     */
    private function notifyModerators($type, $contentId) {
        // Get all moderators and admins
        $users = $this->db->getAll('users');
        $moderators = [];
        
        foreach ($users as $user) {
            if (isset($user['role']) && ($user['role'] === 'admin' || $user['role'] === 'moderator')) {
                $moderators[] = $user['id'];
            }
        }
        
        // TODO: Implement actual notification system (email, in-app, etc.)
        // For now, just log it
        $this->logModAction('notification_sent', 'system', $contentId, $type);
    }
    
    /**
     * Get moderation statistics
     * @return array
     */
    public function getStats() {
        return [
            'total_bans' => $this->db->count('bans'),
            'active_bans' => count($this->getActiveBans()),
            'pending_reports' => count($this->getPendingReports()),
            'total_reports' => $this->db->count('reports'),
            'total_mutes' => $this->db->count('mutes')
        ];
    }
}
