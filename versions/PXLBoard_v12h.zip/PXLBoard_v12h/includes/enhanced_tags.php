<?php
/**
 * Enhanced Tag System
 * Inspired by DPBooru's tag categorization and Shimmie2's tag management
 */

class EnhancedTagSystem {
    private $db;
    private $tagTypes = [
        'artist' => ['color' => '#ba92f0', 'icon' => 'palette'],
        'character' => ['color' => '#48c774', 'icon' => 'person'],
        'species' => ['color' => '#f14668', 'icon' => 'bug'],
        'general' => ['color' => '#3273dc', 'icon' => 'tag'],
        'meta' => ['color' => '#ffdd57', 'icon' => 'info-circle'],
        'rating' => ['color' => '#ff6b6b', 'icon' => 'shield-check'],
        'content' => ['color' => '#4ecdc4', 'icon' => 'image']
    ];
    
    public function __construct($database) {
        $this->db = $database;
    }
    
    /**
     * Parse tags from input string
     * Supports DPBooru-style tag prefixes (artist:, character:, etc.)
     */
    public function parseTags($tagString) {
        $tags = [];
        $rawTags = array_map('trim', explode(',', $tagString));
        
        foreach ($rawTags as $tag) {
            if (empty($tag)) continue;
            
            $tagData = $this->parseTagWithType($tag);
            $tags[] = $tagData;
        }
        
        return $tags;
    }
    
    /**
     * Parse individual tag and determine type
     */
    private function parseTagWithType($tag) {
        $type = 'general';
        $name = $tag;
        
        // Check for type prefix (e.g., "artist:john_doe")
        if (strpos($tag, ':') !== false) {
            list($prefix, $name) = explode(':', $tag, 2);
            $prefix = strtolower(trim($prefix));
            
            if (isset($this->tagTypes[$prefix])) {
                $type = $prefix;
            }
        }
        
        // Auto-detect common tag types
        if ($type === 'general') {
            $type = $this->autoDetectTagType($name);
        }
        
        // Normalize tag name
        $name = $this->normalizeTagName($name);
        
        return [
            'name' => $name,
            'type' => $type,
            'full_tag' => $type . ':' . $name,
            'color' => $this->tagTypes[$type]['color'] ?? '#3273dc',
            'icon' => $this->tagTypes[$type]['icon'] ?? 'tag'
        ];
    }
    
    /**
     * Auto-detect tag type based on name patterns
     */
    private function autoDetectTagType($name) {
        // Artist detection (common suffixes/prefixes)
        if (preg_match('/^(drawn_by|animated_by|by_)/i', $name)) {
            return 'artist';
        }
        
        // Meta tags
        $metaTags = ['original', 'oc', 'commission', 'wip', 'sketch', 'colored', 'unfinished'];
        if (in_array(strtolower($name), $metaTags)) {
            return 'meta';
        }
        
        // Rating tags
        $ratingTags = ['safe', 'questionable', 'explicit', 'sfw', 'nsfw'];
        if (in_array(strtolower($name), $ratingTags)) {
            return 'rating';
        }
        
        return 'general';
    }
    
    /**
     * Normalize tag name (lowercase, replace spaces with underscores)
     */
    private function normalizeTagName($name) {
        $name = strtolower(trim($name));
        $name = preg_replace('/\s+/', '_', $name);
        $name = preg_replace('/[^a-z0-9_-]/', '', $name);
        return $name;
    }
    
    /**
     * Save tags for an image
     */
    public function saveImageTags($imageId, $tags) {
        $tagData = $this->parseTags($tags);
        $savedTags = [];
        
        foreach ($tagData as $tag) {
            $this->incrementTagCount($tag['name'], $tag['type']);
            $savedTags[] = $tag;
        }
        
        // Save to image metadata
        $this->db->update('images', $imageId, [
            'tags' => array_column($savedTags, 'name'),
            'tag_data' => $savedTags
        ]);
        
        return $savedTags;
    }
    
    /**
     * Get tag suggestions (autocomplete)
     */
    public function getTagSuggestions($query, $limit = 10) {
        $allTags = $this->getAllTags();
        $query = strtolower($query);
        $suggestions = [];
        
        foreach ($allTags as $tag) {
            if (strpos(strtolower($tag['name']), $query) === 0) {
                $suggestions[] = $tag;
            }
            if (count($suggestions) >= $limit) break;
        }
        
        return $suggestions;
    }
    
    /**
     * Get all tags with metadata
     */
    public function getAllTags() {
        $images = $this->db->getAll('images');
        $tagCounts = [];
        
        foreach ($images as $image) {
            if (!isset($image['tag_data'])) continue;
            
            foreach ($image['tag_data'] as $tag) {
                $name = $tag['name'];
                if (!isset($tagCounts[$name])) {
                    $tagCounts[$name] = [
                        'name' => $name,
                        'type' => $tag['type'] ?? 'general',
                        'count' => 0,
                        'color' => $tag['color'] ?? '#3273dc',
                        'icon' => $tag['icon'] ?? 'tag'
                    ];
                }
                $tagCounts[$name]['count']++;
            }
        }
        
        // Sort by count
        usort($tagCounts, function($a, $b) {
            return $b['count'] - $a['count'];
        });
        
        return $tagCounts;
    }
    
    /**
     * Get popular tags
     */
    public function getPopularTags($limit = 50) {
        $tags = $this->getAllTags();
        return array_slice($tags, 0, $limit);
    }
    
    /**
     * Get tags by type
     */
    public function getTagsByType($type) {
        $allTags = $this->getAllTags();
        return array_filter($allTags, function($tag) use ($type) {
            return $tag['type'] === $type;
        });
    }
    
    /**
     * Search images by tags (with AND/OR logic)
     */
    public function searchByTags($tagQuery) {
        $images = $this->db->getAll('images');
        $searchTags = array_map('trim', explode(',', strtolower($tagQuery)));
        $results = [];
        
        foreach ($images as $image) {
            if (!isset($image['tags'])) continue;
            
            $imageTags = array_map('strtolower', $image['tags']);
            $matches = array_intersect($searchTags, $imageTags);
            
            // If all search tags match (AND logic)
            if (count($matches) === count($searchTags)) {
                $results[] = $image;
            }
        }
        
        return $results;
    }
    
    /**
     * Increment tag usage count
     */
    private function incrementTagCount($name, $type) {
        $tagsFile = 'data/tag_counts.json';
        $tagCounts = [];
        
        if (file_exists($tagsFile)) {
            $tagCounts = json_decode(file_get_contents($tagsFile), true) ?? [];
        }
        
        if (!isset($tagCounts[$name])) {
            $tagCounts[$name] = [
                'count' => 0,
                'type' => $type,
                'first_used' => time()
            ];
        }
        
        $tagCounts[$name]['count']++;
        $tagCounts[$name]['last_used'] = time();
        
        file_put_contents($tagsFile, json_encode($tagCounts, JSON_PRETTY_PRINT));
    }
    
    /**
     * Get tag cloud data (for visualization)
     */
    public function getTagCloud($minCount = 1, $maxTags = 100) {
        $tags = $this->getAllTags();
        
        // Filter by minimum count
        $tags = array_filter($tags, function($tag) use ($minCount) {
            return $tag['count'] >= $minCount;
        });
        
        // Limit number of tags
        $tags = array_slice($tags, 0, $maxTags);
        
        // Calculate size classes (1-5)
        $counts = array_column($tags, 'count');
        $minCount = min($counts);
        $maxCount = max($counts);
        $range = $maxCount - $minCount;
        
        foreach ($tags as &$tag) {
            if ($range > 0) {
                $normalized = ($tag['count'] - $minCount) / $range;
                $tag['size_class'] = ceil($normalized * 5);
            } else {
                $tag['size_class'] = 3;
            }
        }
        
        return $tags;
    }
    
    /**
     * Merge tags (for aliases)
     */
    public function mergeTags($fromTag, $toTag) {
        $images = $this->db->getAll('images');
        $updated = 0;
        
        foreach ($images as $image) {
            if (!isset($image['tags'])) continue;
            
            $tags = $image['tags'];
            $changed = false;
            
            foreach ($tags as $i => $tag) {
                if (strtolower($tag) === strtolower($fromTag)) {
                    $tags[$i] = $toTag;
                    $changed = true;
                }
            }
            
            if ($changed) {
                $this->db->update('images', $image['id'], ['tags' => array_unique($tags)]);
                $updated++;
            }
        }
        
        return $updated;
    }
    
    /**
     * Get related tags (tags that appear together)
     */
    public function getRelatedTags($tagName, $limit = 10) {
        $images = $this->db->getAll('images');
        $coOccurrence = [];
        
        foreach ($images as $image) {
            if (!isset($image['tags'])) continue;
            
            $tags = array_map('strtolower', $image['tags']);
            if (!in_array(strtolower($tagName), $tags)) continue;
            
            foreach ($tags as $tag) {
                if (strtolower($tag) === strtolower($tagName)) continue;
                
                if (!isset($coOccurrence[$tag])) {
                    $coOccurrence[$tag] = 0;
                }
                $coOccurrence[$tag]++;
            }
        }
        
        arsort($coOccurrence);
        return array_slice($coOccurrence, 0, $limit, true);
    }
    
    /**
     * Get tag statistics
     */
    public function getTagStatistics() {
        $tags = $this->getAllTags();
        $types = array_count_values(array_column($tags, 'type'));
        
        return [
            'total_tags' => count($tags),
            'total_uses' => array_sum(array_column($tags, 'count')),
            'types' => $types,
            'most_popular' => array_slice($tags, 0, 10),
            'avg_uses_per_tag' => count($tags) > 0 ? 
                                 array_sum(array_column($tags, 'count')) / count($tags) : 0
        ];
    }
    
    /**
     * Render tag badge HTML
     */
    public function renderTagBadge($tag, $showCount = false) {
        if (is_string($tag)) {
            $tagData = $this->parseTagWithType($tag);
        } else {
            $tagData = $tag;
        }
        
        $color = $tagData['color'] ?? '#3273dc';
        $icon = $tagData['icon'] ?? 'tag';
        $type = $tagData['type'] ?? 'general';
        $name = $tagData['name'] ?? $tag;
        
        $html = sprintf(
            '<a href="index.php?page=search&q=%s" class="badge tag-%s me-1 mb-1" style="background-color: %s; text-decoration: none;">',
            urlencode($name),
            escape($type),
            escape($color)
        );
        
        $html .= sprintf('<i class="bi bi-%s"></i> ', escape($icon));
        $html .= escape(str_replace('_', ' ', $name));
        
        if ($showCount && isset($tagData['count'])) {
            $html .= sprintf(' <span class="badge bg-light text-dark ms-1">%d</span>', $tagData['count']);
        }
        
        $html .= '</a>';
        
        return $html;
    }
}
