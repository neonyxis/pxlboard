<?php
/**
 * Multi-Database Handler - Supports FlatFile, MySQL, and SQLite
 * PXLBoard v12h
 */

interface DatabaseInterface {
    public function save($collection, $id, $data);
    public function get($collection, $id);
    public function delete($collection, $id);
    public function getAll($collection, $limit = null, $offset = 0);
    public function count($collection);
    public function search($collection, $field, $value);
    public function getNextId($collection);
}

class FlatFileDB implements DatabaseInterface {
    private $dataDir;
    
    public function __construct($dataDir) {
        $this->dataDir = $dataDir;
        $this->init();
    }
    
    private function init() {
        // Create base data directory first
        if (!is_dir($this->dataDir)) {
            @mkdir($this->dataDir, 0755, true);
        }
        
        $dirs = [
            $this->dataDir,
            $this->dataDir . '/users',
            $this->dataDir . '/images',
            $this->dataDir . '/tags',
            $this->dataDir . '/comments',
            $this->dataDir . '/sessions',
            $this->dataDir . '/cache',
            $this->dataDir . '/ratings',
            $this->dataDir . '/favorites',
            $this->dataDir . '/forum_topics',
            $this->dataDir . '/forum_replies',
            $this->dataDir . '/channels',
            $this->dataDir . '/extensions',
            $this->dataDir . '/blog_posts',
            $this->dataDir . '/blog_comments',
            $this->dataDir . '/wiki_pages',
            $this->dataDir . '/wiki_revisions',
            $this->dataDir . '/notifications',
            $this->dataDir . '/moderation_queue',
            $this->dataDir . '/user_hides',
            $this->dataDir . '/boards',
            $this->dataDir . '/board_threads',
            $this->dataDir . '/board_posts',
            $this->dataDir . '/tgp_posts',
            $this->dataDir . '/tgp_likes'
        ];
        
        foreach ($dirs as $dir) {
            if (!is_dir($dir)) {
                @mkdir($dir, 0755, true);
            }
        }
        
        // Create .htaccess to protect data directory
        $htaccess = $this->dataDir . '/.htaccess';
        if (!file_exists($htaccess)) {
            @file_put_contents($htaccess, "Deny from all\n");
        }
    }
    
    public function save($collection, $id, $data) {
        $file = $this->dataDir . '/' . $collection . '/' . $id . '.json';
        $data['updated_at'] = time();
        return file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT)) !== false;
    }
    
    public function get($collection, $id) {
        $file = $this->dataDir . '/' . $collection . '/' . $id . '.json';
        if (!file_exists($file)) {
            return null;
        }
        $data = json_decode(file_get_contents($file), true);
        if ($data !== null) {
            $data['id'] = $id;
        }
        return $data;
    }
    
    public function delete($collection, $id) {
        $file = $this->dataDir . '/' . $collection . '/' . $id . '.json';
        if (file_exists($file)) {
            return unlink($file);
        }
        return false;
    }
    
    public function getAll($collection, $limit = null, $offset = 0) {
        $dir = $this->dataDir . '/' . $collection;
        if (!is_dir($dir)) {
            return [];
        }
        
        $files = glob($dir . '/*.json');
        $items = [];
        
        // Sort by modification time (newest first)
        usort($files, function($a, $b) {
            return filemtime($b) - filemtime($a);
        });
        
        if ($limit !== null) {
            $files = array_slice($files, $offset, $limit);
        }
        
        foreach ($files as $file) {
            $data = json_decode(file_get_contents($file), true);
            $data['id'] = basename($file, '.json');
            $items[] = $data;
        }
        
        return $items;
    }
    
    public function count($collection) {
        $dir = $this->dataDir . '/' . $collection;
        if (!is_dir($dir)) {
            return 0;
        }
        return count(glob($dir . '/*.json'));
    }
    
    public function search($collection, $field, $value) {
        $items = $this->getAll($collection);
        $results = [];
        
        foreach ($items as $item) {
            if (isset($item[$field]) && stripos((string)$item[$field], (string)$value) !== false) {
                $results[] = $item;
            }
        }
        
        return $results;
    }
    
    public function getNextId($collection) {
        $counterFile = $this->dataDir . '/' . $collection . '/_counter.txt';
        
        if (!file_exists($counterFile)) {
            file_put_contents($counterFile, '1');
            return 1;
        }
        
        $counter = (int)file_get_contents($counterFile);
        $counter++;
        file_put_contents($counterFile, $counter);
        
        return $counter;
    }
}

class MySQLDB implements DatabaseInterface {
    private $pdo;
    private $prefix;
    
    public function __construct($host, $dbname, $username, $password, $prefix = 'pxl_') {
        $this->prefix = $prefix;
        $dsn = "mysql:host=$host;dbname=$dbname;charset=utf8mb4";
        $this->pdo = new PDO($dsn, $username, $password, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]);
        $this->init();
    }
    
    private function init() {
        // Create main data table if it doesn't exist
        $this->pdo->exec("CREATE TABLE IF NOT EXISTS {$this->prefix}data (
            collection VARCHAR(50) NOT NULL,
            id VARCHAR(255) NOT NULL,
            data LONGTEXT NOT NULL,
            updated_at INT UNSIGNED NOT NULL,
            PRIMARY KEY (collection, id),
            INDEX idx_collection (collection),
            INDEX idx_updated_at (updated_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }
    
    public function save($collection, $id, $data) {
        $data['updated_at'] = time();
        $jsonData = json_encode($data);
        
        $stmt = $this->pdo->prepare("
            INSERT INTO {$this->prefix}data (collection, id, data, updated_at) 
            VALUES (?, ?, ?, ?) 
            ON DUPLICATE KEY UPDATE data = ?, updated_at = ?
        ");
        
        return $stmt->execute([
            $collection, $id, $jsonData, $data['updated_at'],
            $jsonData, $data['updated_at']
        ]);
    }
    
    public function get($collection, $id) {
        $stmt = $this->pdo->prepare("
            SELECT data FROM {$this->prefix}data 
            WHERE collection = ? AND id = ?
        ");
        $stmt->execute([$collection, $id]);
        $result = $stmt->fetch();
        
        if ($result) {
            $data = json_decode($result['data'], true);
            $data['id'] = $id;
            return $data;
        }
        return null;
    }
    
    public function delete($collection, $id) {
        $stmt = $this->pdo->prepare("
            DELETE FROM {$this->prefix}data 
            WHERE collection = ? AND id = ?
        ");
        return $stmt->execute([$collection, $id]);
    }
    
    public function getAll($collection, $limit = null, $offset = 0) {
        $sql = "SELECT id, data FROM {$this->prefix}data 
                WHERE collection = ? 
                ORDER BY updated_at DESC";
        
        if ($limit !== null) {
            $sql .= " LIMIT ? OFFSET ?";
        }
        
        $stmt = $this->pdo->prepare($sql);
        
        if ($limit !== null) {
            $stmt->execute([$collection, $limit, $offset]);
        } else {
            $stmt->execute([$collection]);
        }
        
        $items = [];
        while ($row = $stmt->fetch()) {
            $data = json_decode($row['data'], true);
            $data['id'] = $row['id'];
            $items[] = $data;
        }
        
        return $items;
    }
    
    public function count($collection) {
        $stmt = $this->pdo->prepare("
            SELECT COUNT(*) FROM {$this->prefix}data 
            WHERE collection = ?
        ");
        $stmt->execute([$collection]);
        return (int)$stmt->fetchColumn();
    }
    
    public function search($collection, $field, $value) {
        $items = $this->getAll($collection);
        $results = [];
        
        foreach ($items as $item) {
            if (isset($item[$field]) && stripos((string)$item[$field], (string)$value) !== false) {
                $results[] = $item;
            }
        }
        
        return $results;
    }
    
    public function getNextId($collection) {
        $stmt = $this->pdo->prepare("
            SELECT MAX(CAST(SUBSTRING(id, LOCATE('_', id) + 1) AS UNSIGNED)) as max_id
            FROM {$this->prefix}data 
            WHERE collection = ? AND id REGEXP '^[a-z]+_[0-9]+$'
        ");
        $stmt->execute([$collection]);
        $result = $stmt->fetch();
        return ($result['max_id'] ?? 0) + 1;
    }
}

class SQLiteDB implements DatabaseInterface {
    private $pdo;
    private $dbPath;
    
    public function __construct($dbPath) {
        $this->dbPath = $dbPath;
        
        // Ensure directory exists
        $dir = dirname($dbPath);
        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }
        
        $this->pdo = new PDO("sqlite:$dbPath", null, null, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]);
        
        $this->init();
    }
    
    private function init() {
        // Create main data table if it doesn't exist
        $this->pdo->exec("CREATE TABLE IF NOT EXISTS data (
            collection TEXT NOT NULL,
            id TEXT NOT NULL,
            data TEXT NOT NULL,
            updated_at INTEGER NOT NULL,
            PRIMARY KEY (collection, id)
        )");
        
        // Create indices
        $this->pdo->exec("CREATE INDEX IF NOT EXISTS idx_collection ON data(collection)");
        $this->pdo->exec("CREATE INDEX IF NOT EXISTS idx_updated_at ON data(updated_at)");
    }
    
    public function save($collection, $id, $data) {
        $data['updated_at'] = time();
        $jsonData = json_encode($data);
        
        $stmt = $this->pdo->prepare("
            INSERT OR REPLACE INTO data (collection, id, data, updated_at) 
            VALUES (?, ?, ?, ?)
        ");
        
        return $stmt->execute([$collection, $id, $jsonData, $data['updated_at']]);
    }
    
    public function get($collection, $id) {
        $stmt = $this->pdo->prepare("
            SELECT data FROM data 
            WHERE collection = ? AND id = ?
        ");
        $stmt->execute([$collection, $id]);
        $result = $stmt->fetch();
        
        if ($result) {
            $data = json_decode($result['data'], true);
            $data['id'] = $id;
            return $data;
        }
        return null;
    }
    
    public function delete($collection, $id) {
        $stmt = $this->pdo->prepare("
            DELETE FROM data 
            WHERE collection = ? AND id = ?
        ");
        return $stmt->execute([$collection, $id]);
    }
    
    public function getAll($collection, $limit = null, $offset = 0) {
        $sql = "SELECT id, data FROM data 
                WHERE collection = ? 
                ORDER BY updated_at DESC";
        
        if ($limit !== null) {
            $sql .= " LIMIT ? OFFSET ?";
        }
        
        $stmt = $this->pdo->prepare($sql);
        
        if ($limit !== null) {
            $stmt->execute([$collection, $limit, $offset]);
        } else {
            $stmt->execute([$collection]);
        }
        
        $items = [];
        while ($row = $stmt->fetch()) {
            $data = json_decode($row['data'], true);
            $data['id'] = $row['id'];
            $items[] = $data;
        }
        
        return $items;
    }
    
    public function count($collection) {
        $stmt = $this->pdo->prepare("
            SELECT COUNT(*) FROM data 
            WHERE collection = ?
        ");
        $stmt->execute([$collection]);
        return (int)$stmt->fetchColumn();
    }
    
    public function search($collection, $field, $value) {
        $items = $this->getAll($collection);
        $results = [];
        
        foreach ($items as $item) {
            if (isset($item[$field]) && stripos((string)$item[$field], (string)$value) !== false) {
                $results[] = $item;
            }
        }
        
        return $results;
    }
    
    public function getNextId($collection) {
        $stmt = $this->pdo->prepare("
            SELECT id FROM data 
            WHERE collection = ? 
            ORDER BY updated_at DESC 
            LIMIT 1
        ");
        $stmt->execute([$collection]);
        $result = $stmt->fetch();
        
        if ($result && preg_match('/_(\d+)$/', $result['id'], $matches)) {
            return intval($matches[1]) + 1;
        }
        return 1;
    }
}

// Database Factory
class DatabaseFactory {
    public static function create($config) {
        $type = $config['type'] ?? 'flatfile';
        
        switch ($type) {
            case 'mysql':
                return new MySQLDB(
                    $config['host'],
                    $config['dbname'],
                    $config['username'],
                    $config['password'],
                    $config['prefix'] ?? 'pxl_'
                );
            
            case 'sqlite':
                return new SQLiteDB($config['path'] ?? DATA_DIR . '/database.sqlite');
            
            case 'flatfile':
            default:
                return new FlatFileDB($config['path'] ?? DATA_DIR);
        }
    }
}
