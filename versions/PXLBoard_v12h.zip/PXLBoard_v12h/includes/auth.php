<?php
/**
 * Authentication Functions
 */

class Auth {
    private $db;
    
    public function __construct($db) {
        $this->db = $db;
    }
    
    public function register($username, $email, $password) {
        // Validate input
        if (strlen($username) < 3 || strlen($username) > 32) {
            return ['success' => false, 'error' => 'Username must be 3-32 characters'];
        }
        
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return ['success' => false, 'error' => 'Invalid email address'];
        }
        
        if (strlen($password) < PASSWORD_MIN_LENGTH) {
            return ['success' => false, 'error' => 'Password must be at least ' . PASSWORD_MIN_LENGTH . ' characters'];
        }
        
        // Check if username exists
        $users = $this->db->getAll('users');
        foreach ($users as $user) {
            if (strtolower($user['username']) === strtolower($username)) {
                return ['success' => false, 'error' => 'Username already exists'];
            }
            if (strtolower($user['email']) === strtolower($email)) {
                return ['success' => false, 'error' => 'Email already registered'];
            }
        }
        
        // Create user
        $userId = uniqid('user_', true);
        $userData = [
            'username' => $username,
            'email' => $email,
            'password' => password_hash($password, PASSWORD_DEFAULT),
            'role' => 'user',
            'created_at' => time(),
            'verified' => !EMAIL_VERIFICATION,
            'verification_token' => EMAIL_VERIFICATION ? bin2hex(random_bytes(16)) : null
        ];
        
        if ($this->db->save('users', $userId, $userData)) {
            if (EMAIL_VERIFICATION && SMTP_ENABLED) {
                $this->sendVerificationEmail($email, $userData['verification_token']);
            }
            return ['success' => true, 'user_id' => $userId];
        }
        
        return ['success' => false, 'error' => 'Failed to create user'];
    }
    
    public function login($username, $password) {
        $users = $this->db->getAll('users');
        
        foreach ($users as $user) {
            if (strtolower($user['username']) === strtolower($username) || 
                strtolower($user['email']) === strtolower($username)) {
                
                if (password_verify($password, $user['password'])) {
                    if (EMAIL_VERIFICATION && !$user['verified']) {
                        return ['success' => false, 'error' => 'Please verify your email address'];
                    }
                    
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['role'] = $user['role'];
                    $_SESSION['login_time'] = time();
                    
                    return ['success' => true];
                }
            }
        }
        
        return ['success' => false, 'error' => 'Invalid username or password'];
    }
    
    public function logout() {
        session_destroy();
        return true;
    }
    
    public function isLoggedIn() {
        return isset($_SESSION['user_id']) && isset($_SESSION['login_time']) && 
               (time() - $_SESSION['login_time']) < SESSION_LIFETIME;
    }
    
    public function isAdmin() {
        return $this->isLoggedIn() && $_SESSION['role'] === 'admin';
    }
    
    public function getCurrentUser() {
        if (!$this->isLoggedIn()) {
            return null;
        }
        return $this->db->get('users', $_SESSION['user_id']);
    }
    
    public function verifyEmail($token) {
        $users = $this->db->getAll('users');
        
        foreach ($users as $user) {
            if (isset($user['verification_token']) && $user['verification_token'] === $token) {
                $user['verified'] = true;
                $user['verification_token'] = null;
                $this->db->save('users', $user['id'], $user);
                return true;
            }
        }
        
        return false;
    }
    
    private function sendVerificationEmail($email, $token) {
        $subject = 'Verify your ' . SITE_NAME . ' account';
        $verifyUrl = SITE_URL . '/index.php?page=verify&token=' . $token;
        $message = "Please click the following link to verify your email address:\n\n" . $verifyUrl;
        
        sendEmail($email, $subject, $message);
    }
}
