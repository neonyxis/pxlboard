<?php
/**
 * Image Hiding System
 * Allows users to hide images they don't want to see
 */

class HidingSystem {
    private $db;
    private $userId;
    
    public function __construct($db, $userId) {
        $this->db = $db;
        $this->userId = $userId;
    }
    
    /**
     * Hide an image for the current user
     */
    public function hideImage($imageId) {
        if (!$this->userId) {
            return false;
        }
        
        $hideData = $this->getUserHides();
        
        // Add to hidden images if not already hidden
        if (!in_array($imageId, $hideData['hidden_images'])) {
            $hideData['hidden_images'][] = $imageId;
            $hideData['hidden_count'] = count($hideData['hidden_images']);
            return $this->db->save('user_hides', $this->userId, $hideData);
        }
        
        return true;
    }
    
    /**
     * Unhide an image for the current user
     */
    public function unhideImage($imageId) {
        if (!$this->userId) {
            return false;
        }
        
        $hideData = $this->getUserHides();
        
        // Remove from hidden images
        $hideData['hidden_images'] = array_values(array_filter(
            $hideData['hidden_images'],
            function($id) use ($imageId) {
                return $id !== $imageId;
            }
        ));
        
        $hideData['hidden_count'] = count($hideData['hidden_images']);
        return $this->db->save('user_hides', $this->userId, $hideData);
    }
    
    /**
     * Check if an image is hidden by the current user
     */
    public function isImageHidden($imageId) {
        if (!$this->userId) {
            return false;
        }
        
        $hideData = $this->getUserHides();
        return in_array($imageId, $hideData['hidden_images']);
    }
    
    /**
     * Get all hidden images for the current user
     */
    public function getHiddenImages() {
        if (!$this->userId) {
            return [];
        }
        
        $hideData = $this->getUserHides();
        return $hideData['hidden_images'];
    }
    
    /**
     * Get hide data for the current user
     */
    private function getUserHides() {
        $hideData = $this->db->get('user_hides', $this->userId);
        
        if (!$hideData) {
            $hideData = [
                'user_id' => $this->userId,
                'hidden_images' => [],
                'hidden_count' => 0,
                'created_at' => time()
            ];
        }
        
        return $hideData;
    }
    
    /**
     * Filter out hidden images from an array of images
     */
    public function filterHiddenImages($images) {
        if (!$this->userId) {
            return $images;
        }
        
        $hiddenImages = $this->getHiddenImages();
        
        return array_filter($images, function($image) use ($hiddenImages) {
            $imageId = is_array($image) ? $image['id'] : $image;
            return !in_array($imageId, $hiddenImages);
        });
    }
    
    /**
     * Get count of hidden images
     */
    public function getHiddenCount() {
        if (!$this->userId) {
            return 0;
        }
        
        $hideData = $this->getUserHides();
        return $hideData['hidden_count'] ?? 0;
    }
    
    /**
     * Clear all hidden images for the current user
     */
    public function clearAllHides() {
        if (!$this->userId) {
            return false;
        }
        
        return $this->db->delete('user_hides', $this->userId);
    }
}

/**
 * Global helper functions
 */

/**
 * Get hiding system instance for current user
 */
function getHidingSystem() {
    global $db, $auth;
    
    if (!$auth->isLoggedIn()) {
        return null;
    }
    
    return new HidingSystem($db, $_SESSION['user_id']);
}

/**
 * Check if an image is hidden
 */
function isImageHidden($imageId) {
    $hiding = getHidingSystem();
    return $hiding ? $hiding->isImageHidden($imageId) : false;
}

/**
 * Filter hidden images from array
 */
function filterHiddenImages($images) {
    $hiding = getHidingSystem();
    return $hiding ? $hiding->filterHiddenImages($images) : $images;
}
