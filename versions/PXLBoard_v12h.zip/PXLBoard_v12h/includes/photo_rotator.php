<?php
/**
 * Photo Rotator Widget
 * Displays a rotating showcase of images
 */

class PhotoRotator {
    private $db;
    private $rotationInterval = 5000; // milliseconds
    
    public function __construct($db) {
        $this->db = $db;
    }
    
    /**
     * Get images for rotation
     */
    public function getRotationImages($count = 10, $criteria = 'random') {
        $allImages = $this->db->getAll('images');
        
        switch ($criteria) {
            case 'newest':
                usort($allImages, function($a, $b) {
                    return ($b['uploaded_at'] ?? 0) - ($a['uploaded_at'] ?? 0);
                });
                break;
            case 'popular':
                usort($allImages, function($a, $b) {
                    return ($b['views'] ?? 0) - ($a['views'] ?? 0);
                });
                break;
            case 'top_rated':
                usort($allImages, function($a, $b) {
                    return ($b['rating'] ?? 0) - ($a['rating'] ?? 0);
                });
                break;
            case 'featured':
                $allImages = array_filter($allImages, function($img) {
                    return $img['is_featured'] ?? false;
                });
                break;
            case 'random':
            default:
                shuffle($allImages);
                break;
        }
        
        return array_slice($allImages, 0, $count);
    }
    
    /**
     * Render rotator HTML
     */
    public function render($options = []) {
        $count = $options['count'] ?? 10;
        $criteria = $options['criteria'] ?? 'random';
        $height = $options['height'] ?? '500px';
        $showControls = $options['show_controls'] ?? true;
        $showIndicators = $options['show_indicators'] ?? true;
        $autoplay = $options['autoplay'] ?? true;
        $interval = $options['interval'] ?? $this->rotationInterval;
        
        $images = $this->getRotationImages($count, $criteria);
        
        if (empty($images)) {
            return '<div class="alert alert-info">No images available for rotation</div>';
        }
        
        $uniqueId = 'rotator-' . uniqid();
        
        ob_start();
        ?>
        <div id="<?php echo $uniqueId; ?>" class="carousel slide photo-rotator" data-bs-ride="<?php echo $autoplay ? 'carousel' : 'false'; ?>" data-bs-interval="<?php echo $interval; ?>">
            <?php if ($showIndicators): ?>
                <div class="carousel-indicators">
                    <?php foreach ($images as $index => $image): ?>
                        <button type="button" 
                                data-bs-target="#<?php echo $uniqueId; ?>" 
                                data-bs-slide-to="<?php echo $index; ?>" 
                                <?php echo $index === 0 ? 'class="active" aria-current="true"' : ''; ?>
                                aria-label="Slide <?php echo $index + 1; ?>"></button>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            
            <div class="carousel-inner" style="height: <?php echo $height; ?>;">
                <?php foreach ($images as $index => $image): ?>
                    <div class="carousel-item <?php echo $index === 0 ? 'active' : ''; ?>">
                        <img src="uploads/<?php echo escape($image['filename']); ?>" 
                             class="d-block w-100" 
                             alt="<?php echo escape($image['title'] ?? 'Image'); ?>"
                             style="height: <?php echo $height; ?>; object-fit: cover;">
                        <div class="carousel-caption d-none d-md-block">
                            <div class="caption-content bg-dark bg-opacity-75 p-3 rounded">
                                <h5>
                                    <a href="index.php?page=image&id=<?php echo $image['id']; ?>" class="text-white text-decoration-none">
                                        <?php echo escape($image['title'] ?? 'Untitled'); ?>
                                    </a>
                                </h5>
                                <?php if (!empty($image['description'])): ?>
                                    <p><?php echo escape(substr($image['description'], 0, 100)); ?>...</p>
                                <?php endif; ?>
                                <div class="small">
                                    <i class="bi bi-person"></i> <?php echo escape($image['uploader']); ?>
                                    <span class="ms-3"><i class="bi bi-eye"></i> <?php echo number_format($image['views'] ?? 0); ?></span>
                                    <span class="ms-3"><i class="bi bi-heart"></i> <?php echo number_format($image['favorites'] ?? 0); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            
            <?php if ($showControls): ?>
                <button class="carousel-control-prev" type="button" data-bs-target="#<?php echo $uniqueId; ?>" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#<?php echo $uniqueId; ?>" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>
            <?php endif; ?>
        </div>
        
        <style>
        .photo-rotator .carousel-item img {
            filter: brightness(0.8);
        }
        
        .photo-rotator .carousel-caption {
            bottom: 20px;
        }
        
        .photo-rotator .caption-content {
            display: inline-block;
            max-width: 600px;
            margin: 0 auto;
        }
        
        .photo-rotator .carousel-control-prev,
        .photo-rotator .carousel-control-next {
            width: 5%;
            opacity: 0.7;
        }
        
        .photo-rotator .carousel-control-prev:hover,
        .photo-rotator .carousel-control-next:hover {
            opacity: 1;
        }
        
        .photo-rotator .carousel-indicators button {
            width: 10px;
            height: 10px;
            border-radius: 50%;
        }
        </style>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Render compact rotator (small thumbnails)
     */
    public function renderCompact($options = []) {
        $count = $options['count'] ?? 5;
        $criteria = $options['criteria'] ?? 'random';
        $interval = $options['interval'] ?? $this->rotationInterval;
        
        $images = $this->getRotationImages($count, $criteria);
        
        if (empty($images)) {
            return '<div class="alert alert-info">No images available</div>';
        }
        
        $uniqueId = 'compact-rotator-' . uniqid();
        
        ob_start();
        ?>
        <div class="compact-rotator" id="<?php echo $uniqueId; ?>">
            <div class="rotator-track">
                <?php foreach ($images as $image): ?>
                    <a href="index.php?page=image&id=<?php echo $image['id']; ?>" class="rotator-item">
                        <img src="uploads/thumbs/<?php echo escape($image['filename']); ?>" 
                             alt="<?php echo escape($image['title'] ?? 'Image'); ?>">
                        <div class="item-overlay">
                            <div class="item-title"><?php echo escape($image['title'] ?? 'Untitled'); ?></div>
                        </div>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
        
        <style>
        .compact-rotator {
            overflow: hidden;
            position: relative;
        }
        
        .rotator-track {
            display: flex;
            animation: scroll-horizontal <?php echo ($interval * count($images) / 1000); ?>s linear infinite;
        }
        
        .rotator-item {
            flex: 0 0 200px;
            height: 150px;
            margin-right: 10px;
            position: relative;
            overflow: hidden;
            border-radius: 8px;
        }
        
        .rotator-item img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.3s ease;
        }
        
        .rotator-item:hover img {
            transform: scale(1.1);
        }
        
        .item-overlay {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            background: linear-gradient(to top, rgba(0,0,0,0.8), transparent);
            padding: 10px;
            opacity: 0;
            transition: opacity 0.3s ease;
        }
        
        .rotator-item:hover .item-overlay {
            opacity: 1;
        }
        
        .item-title {
            color: white;
            font-size: 0.9rem;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        @keyframes scroll-horizontal {
            0% {
                transform: translateX(0);
            }
            100% {
                transform: translateX(calc(-210px * <?php echo count($images); ?>));
            }
        }
        
        .compact-rotator:hover .rotator-track {
            animation-play-state: paused;
        }
        </style>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Render grid rotator (changes images in a grid)
     */
    public function renderGrid($options = []) {
        $count = $options['count'] ?? 6;
        $criteria = $options['criteria'] ?? 'random';
        $columns = $options['columns'] ?? 3;
        $interval = $options['interval'] ?? $this->rotationInterval;
        
        $images = $this->getRotationImages($count * 3, $criteria); // Get 3x images for rotation
        
        if (empty($images)) {
            return '<div class="alert alert-info">No images available</div>';
        }
        
        $uniqueId = 'grid-rotator-' . uniqid();
        
        ob_start();
        ?>
        <div class="grid-rotator" id="<?php echo $uniqueId; ?>">
            <div class="row g-2">
                <?php for ($i = 0; $i < $count; $i++): ?>
                    <div class="col-<?php echo 12 / $columns; ?>">
                        <div class="grid-item" data-item-index="<?php echo $i; ?>">
                            <img src="uploads/thumbs/<?php echo escape($images[$i]['filename']); ?>" 
                                 alt="<?php echo escape($images[$i]['title'] ?? 'Image'); ?>"
                                 class="img-fluid rounded">
                        </div>
                    </div>
                <?php endfor; ?>
            </div>
        </div>
        
        <script>
        (function() {
            const images = <?php echo json_encode(array_map(function($img) {
                return [
                    'filename' => $img['filename'],
                    'title' => $img['title'] ?? 'Untitled',
                    'id' => $img['id']
                ];
            }, $images)); ?>;
            
            const gridItems = document.querySelectorAll('#<?php echo $uniqueId; ?> .grid-item');
            let currentIndices = Array.from({length: <?php echo $count; ?>}, (_, i) => i);
            
            function rotateImage(itemIndex) {
                const availableImages = images.filter((_, i) => !currentIndices.includes(i));
                if (availableImages.length === 0) return;
                
                const randomImage = availableImages[Math.floor(Math.random() * availableImages.length)];
                const newIndex = images.indexOf(randomImage);
                
                const item = gridItems[itemIndex];
                const img = item.querySelector('img');
                
                img.style.opacity = '0';
                setTimeout(() => {
                    img.src = 'uploads/thumbs/' + randomImage.filename;
                    img.alt = randomImage.title;
                    currentIndices[itemIndex] = newIndex;
                    img.style.opacity = '1';
                }, 300);
            }
            
            setInterval(() => {
                const randomItemIndex = Math.floor(Math.random() * <?php echo $count; ?>);
                rotateImage(randomItemIndex);
            }, <?php echo $interval; ?>);
        })();
        </script>
        
        <style>
        .grid-rotator .grid-item img {
            height: 200px;
            width: 100%;
            object-fit: cover;
            transition: opacity 0.3s ease, transform 0.3s ease;
        }
        
        .grid-rotator .grid-item:hover img {
            transform: scale(1.05);
        }
        </style>
        <?php
        return ob_get_clean();
    }
}
