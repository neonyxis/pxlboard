<?php
/**
 * SMTP Email Handler
 * Handles SMTP email sending with support for various providers
 */

class SMTPMailer {
    private $host;
    private $port;
    private $username;
    private $password;
    private $from_email;
    private $from_name;
    private $use_tls;
    
    public function __construct($config = []) {
        $this->host = $config['host'] ?? SMTP_HOST ?? '';
        $this->port = $config['port'] ?? SMTP_PORT ?? 587;
        $this->username = $config['username'] ?? SMTP_USERNAME ?? '';
        $this->password = $config['password'] ?? SMTP_PASSWORD ?? '';
        $this->from_email = $config['from'] ?? SMTP_FROM ?? '';
        $this->from_name = $config['from_name'] ?? SITE_NAME ?? 'PXLBoard';
        $this->use_tls = $config['use_tls'] ?? SMTP_USE_TLS ?? true;
    }
    
    /**
     * Send an email via SMTP
     * @param string $to Recipient email
     * @param string $subject Email subject
     * @param string $body Email body (HTML or plain text)
     * @param bool $isHTML Whether body is HTML
     * @param array $attachments Array of file paths to attach
     * @return array Result with success status and message
     */
    public function send($to, $subject, $body, $isHTML = true, $attachments = []) {
        try {
            // Validate inputs
            if (empty($to) || !filter_var($to, FILTER_VALIDATE_EMAIL)) {
                return ['success' => false, 'error' => 'Invalid recipient email'];
            }
            
            if (empty($this->host) || empty($this->username) || empty($this->password)) {
                return ['success' => false, 'error' => 'SMTP not configured'];
            }
            
            // Create socket connection
            $socket = $this->connect();
            if (!$socket) {
                return ['success' => false, 'error' => 'Could not connect to SMTP server'];
            }
            
            // SMTP handshake
            $this->command($socket, "EHLO " . $_SERVER['SERVER_NAME']);
            
            // Start TLS if enabled
            if ($this->use_tls && $this->port != 465) {
                $this->command($socket, "STARTTLS");
                stream_socket_enable_crypto($socket, true, STREAM_CRYPTO_METHOD_TLS_CLIENT);
                $this->command($socket, "EHLO " . $_SERVER['SERVER_NAME']);
            }
            
            // Authenticate
            $this->command($socket, "AUTH LOGIN");
            $this->command($socket, base64_encode($this->username));
            $this->command($socket, base64_encode($this->password));
            
            // Send email
            $this->command($socket, "MAIL FROM:<{$this->from_email}>");
            $this->command($socket, "RCPT TO:<{$to}>");
            $this->command($socket, "DATA");
            
            // Build message
            $message = $this->buildMessage($to, $subject, $body, $isHTML, $attachments);
            fputs($socket, $message . "\r\n.\r\n");
            fgets($socket, 512);
            
            // Close connection
            $this->command($socket, "QUIT");
            fclose($socket);
            
            return ['success' => true, 'message' => 'Email sent successfully'];
            
        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Connect to SMTP server
     * @return resource|false Socket resource or false on failure
     */
    private function connect() {
        $timeout = 30;
        $errno = 0;
        $errstr = '';
        
        if ($this->port == 465) {
            // SSL connection
            $socket = @fsockopen("ssl://{$this->host}", $this->port, $errno, $errstr, $timeout);
        } else {
            // Regular connection (will use STARTTLS if enabled)
            $socket = @fsockopen($this->host, $this->port, $errno, $errstr, $timeout);
        }
        
        if (!$socket) {
            return false;
        }
        
        fgets($socket, 512);
        return $socket;
    }
    
    /**
     * Send SMTP command and get response
     * @param resource $socket Socket resource
     * @param string $command SMTP command
     * @return string Server response
     */
    private function command($socket, $command) {
        fputs($socket, $command . "\r\n");
        return fgets($socket, 512);
    }
    
    /**
     * Build email message with headers and body
     * @param string $to Recipient email
     * @param string $subject Email subject
     * @param string $body Email body
     * @param bool $isHTML Whether body is HTML
     * @param array $attachments File attachments
     * @return string Complete email message
     */
    private function buildMessage($to, $subject, $body, $isHTML, $attachments) {
        $boundary = md5(uniqid(time()));
        $headers = [];
        
        // Basic headers
        $headers[] = "From: {$this->from_name} <{$this->from_email}>";
        $headers[] = "To: {$to}";
        $headers[] = "Subject: {$subject}";
        $headers[] = "Date: " . date('r');
        $headers[] = "Message-ID: <" . md5(uniqid()) . "@" . $_SERVER['SERVER_NAME'] . ">";
        $headers[] = "MIME-Version: 1.0";
        
        if (!empty($attachments)) {
            $headers[] = "Content-Type: multipart/mixed; boundary=\"{$boundary}\"";
        } elseif ($isHTML) {
            $headers[] = "Content-Type: text/html; charset=UTF-8";
        } else {
            $headers[] = "Content-Type: text/plain; charset=UTF-8";
        }
        
        $message = implode("\r\n", $headers) . "\r\n\r\n";
        
        // Add body
        if (!empty($attachments)) {
            $message .= "--{$boundary}\r\n";
            $message .= "Content-Type: " . ($isHTML ? "text/html" : "text/plain") . "; charset=UTF-8\r\n";
            $message .= "Content-Transfer-Encoding: 8bit\r\n\r\n";
            $message .= $body . "\r\n\r\n";
            
            // Add attachments
            foreach ($attachments as $file) {
                if (file_exists($file)) {
                    $filename = basename($file);
                    $content = chunk_split(base64_encode(file_get_contents($file)));
                    $message .= "--{$boundary}\r\n";
                    $message .= "Content-Type: application/octet-stream; name=\"{$filename}\"\r\n";
                    $message .= "Content-Transfer-Encoding: base64\r\n";
                    $message .= "Content-Disposition: attachment; filename=\"{$filename}\"\r\n\r\n";
                    $message .= $content . "\r\n";
                }
            }
            
            $message .= "--{$boundary}--";
        } else {
            $message .= $body;
        }
        
        return $message;
    }
    
    /**
     * Send notification email with template
     * @param string $to Recipient email
     * @param string $type Notification type
     * @param array $data Notification data
     * @return array Result
     */
    public function sendNotification($to, $type, $data) {
        $templates = [
            'comment' => [
                'subject' => 'New comment on your image',
                'body' => '<p>Hi {username},</p><p><strong>{commenter}</strong> commented on your image "<strong>{image_title}</strong>":</p><blockquote>{comment}</blockquote><p><a href="{link}">View comment</a></p>'
            ],
            'reply' => [
                'subject' => 'New reply to your comment',
                'body' => '<p>Hi {username},</p><p><strong>{replier}</strong> replied to your comment:</p><blockquote>{reply}</blockquote><p><a href="{link}">View reply</a></p>'
            ],
            'mention' => [
                'subject' => 'You were mentioned',
                'body' => '<p>Hi {username},</p><p><strong>{mentioner}</strong> mentioned you in a {context}:</p><blockquote>{content}</blockquote><p><a href="{link}">View mention</a></p>'
            ],
            'follow' => [
                'subject' => 'New follower',
                'body' => '<p>Hi {username},</p><p><strong>{follower}</strong> is now following you!</p><p><a href="{link}">View profile</a></p>'
            ],
            'thread_reply' => [
                'subject' => 'New reply in thread',
                'body' => '<p>Hi {username},</p><p><strong>{replier}</strong> replied to the thread "<strong>{thread_title}</strong>":</p><blockquote>{reply}</blockquote><p><a href="{link}">View thread</a></p>'
            ]
        ];
        
        $template = $templates[$type] ?? [
            'subject' => 'New notification',
            'body' => '<p>Hi {username},</p><p>You have a new notification.</p><p><a href="{link}">View notification</a></p>'
        ];
        
        // Replace placeholders
        $subject = $template['subject'];
        $body = $template['body'];
        
        foreach ($data as $key => $value) {
            $body = str_replace('{' . $key . '}', htmlspecialchars($value), $body);
            $subject = str_replace('{' . $key . '}', $value, $subject);
        }
        
        // Add footer
        $body .= '<hr><p style="color: #666; font-size: 12px;">This is an automated notification from ' . SITE_NAME . '. To manage your notification preferences, visit your <a href="' . SITE_URL . '/index.php?page=profile_settings">account settings</a>.</p>';
        
        return $this->send($to, $subject, $body, true);
    }
}
