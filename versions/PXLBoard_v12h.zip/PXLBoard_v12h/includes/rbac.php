<?php
/**
 * Role-Based Access Control (RBAC) System
 */

class RBAC {
    private $db;
    private $roles;
    private $permissions;
    
    public function __construct($db) {
        $this->db = $db;
        $this->loadRolesAndPermissions();
    }
    
    /**
     * Load roles and permissions from config
     */
    private function loadRolesAndPermissions() {
        $rolesFile = DATA_DIR . '/roles.json';
        
        if (file_exists($rolesFile)) {
            $data = json_decode(file_get_contents($rolesFile), true);
            $this->roles = $data['roles'] ?? $this->getDefaultRoles();
            $this->permissions = $data['permissions'] ?? $this->getDefaultPermissions();
        } else {
            $this->roles = $this->getDefaultRoles();
            $this->permissions = $this->getDefaultPermissions();
            $this->saveRolesAndPermissions();
        }
    }
    
    /**
     * Get default roles
     */
    private function getDefaultRoles() {
        return [
            'guest' => [
                'name' => 'Guest',
                'description' => 'Not logged in',
                'permissions' => ['view_images', 'search_images']
            ],
            'user' => [
                'name' => 'User',
                'description' => 'Regular registered user',
                'permissions' => [
                    'view_images',
                    'search_images',
                    'upload_images',
                    'comment',
                    'rate_images',
                    'favorite_images',
                    'create_forum_posts',
                    'edit_own_content',
                    'delete_own_content',
                    'mute_users'
                ]
            ],
            'moderator' => [
                'name' => 'Moderator',
                'description' => 'Community moderator',
                'permissions' => [
                    'view_images',
                    'search_images',
                    'upload_images',
                    'comment',
                    'rate_images',
                    'favorite_images',
                    'create_forum_posts',
                    'edit_own_content',
                    'delete_own_content',
                    'mute_users',
                    'delete_comments',
                    'delete_images',
                    'ban_users',
                    'view_reports',
                    'process_reports',
                    'view_mod_logs',
                    'pin_forum_posts',
                    'lock_forum_posts'
                ]
            ],
            'admin' => [
                'name' => 'Administrator',
                'description' => 'Full system access',
                'permissions' => [
                    'view_images',
                    'search_images',
                    'upload_images',
                    'comment',
                    'rate_images',
                    'favorite_images',
                    'create_forum_posts',
                    'edit_own_content',
                    'delete_own_content',
                    'mute_users',
                    'delete_comments',
                    'delete_images',
                    'ban_users',
                    'view_reports',
                    'process_reports',
                    'view_mod_logs',
                    'pin_forum_posts',
                    'lock_forum_posts',
                    'manage_users',
                    'manage_channels',
                    'manage_extensions',
                    'manage_settings',
                    'manage_roles',
                    'view_admin_panel',
                    'edit_any_content',
                    'delete_any_content'
                ]
            ]
        ];
    }
    
    /**
     * Get default permissions
     */
    private function getDefaultPermissions() {
        return [
            'view_images' => 'View images in gallery',
            'search_images' => 'Search for images',
            'upload_images' => 'Upload new images',
            'comment' => 'Post comments',
            'rate_images' => 'Rate images',
            'favorite_images' => 'Add images to favorites',
            'create_forum_posts' => 'Create forum topics and replies',
            'edit_own_content' => 'Edit own images and comments',
            'delete_own_content' => 'Delete own images and comments',
            'edit_any_content' => 'Edit any user content',
            'delete_any_content' => 'Delete any user content',
            'mute_users' => 'Mute other users',
            'delete_comments' => 'Delete any comments',
            'delete_images' => 'Delete any images',
            'ban_users' => 'Ban users',
            'view_reports' => 'View user reports',
            'process_reports' => 'Process user reports',
            'view_mod_logs' => 'View moderation logs',
            'pin_forum_posts' => 'Pin forum topics',
            'lock_forum_posts' => 'Lock forum topics',
            'manage_users' => 'Manage user accounts',
            'manage_channels' => 'Create and manage channels',
            'manage_extensions' => 'Install and manage extensions',
            'manage_settings' => 'Change site settings',
            'manage_roles' => 'Create and edit roles',
            'view_admin_panel' => 'Access admin panel'
        ];
    }
    
    /**
     * Save roles and permissions to file
     */
    private function saveRolesAndPermissions() {
        $data = [
            'roles' => $this->roles,
            'permissions' => $this->permissions
        ];
        file_put_contents(DATA_DIR . '/roles.json', json_encode($data, JSON_PRETTY_PRINT));
    }
    
    /**
     * Check if a user has a permission
     * @param string $userId User ID (null for guest)
     * @param string $permission Permission to check
     * @return bool
     */
    public function hasPermission($userId, $permission) {
        if ($userId === null) {
            // Guest user
            return $this->roleHasPermission('guest', $permission);
        }
        
        $user = $this->db->get('users', $userId);
        if (!$user) {
            return false;
        }
        
        $role = $user['role'] ?? 'user';
        return $this->roleHasPermission($role, $permission);
    }
    
    /**
     * Check if a role has a permission
     * @param string $role Role name
     * @param string $permission Permission to check
     * @return bool
     */
    public function roleHasPermission($role, $permission) {
        if (!isset($this->roles[$role])) {
            return false;
        }
        
        return in_array($permission, $this->roles[$role]['permissions']);
    }
    
    /**
     * Get user role
     * @param string $userId User ID
     * @return string
     */
    public function getUserRole($userId) {
        if ($userId === null) {
            return 'guest';
        }
        
        $user = $this->db->get('users', $userId);
        return $user['role'] ?? 'user';
    }
    
    /**
     * Set user role
     * @param string $userId User ID
     * @param string $role New role
     * @return bool
     */
    public function setUserRole($userId, $role) {
        if (!isset($this->roles[$role])) {
            return false;
        }
        
        $user = $this->db->get('users', $userId);
        if (!$user) {
            return false;
        }
        
        $user['role'] = $role;
        return $this->db->save('users', $userId, $user);
    }
    
    /**
     * Get all roles
     * @return array
     */
    public function getRoles() {
        return $this->roles;
    }
    
    /**
     * Get all permissions
     * @return array
     */
    public function getPermissions() {
        return $this->permissions;
    }
    
    /**
     * Create custom role
     * @param string $roleId Role ID
     * @param string $name Role name
     * @param string $description Role description
     * @param array $permissions Array of permissions
     * @return bool
     */
    public function createRole($roleId, $name, $description, $permissions) {
        if (isset($this->roles[$roleId])) {
            return false; // Role already exists
        }
        
        $this->roles[$roleId] = [
            'name' => $name,
            'description' => $description,
            'permissions' => $permissions
        ];
        
        $this->saveRolesAndPermissions();
        return true;
    }
    
    /**
     * Update role
     * @param string $roleId Role ID
     * @param array $data Role data
     * @return bool
     */
    public function updateRole($roleId, $data) {
        if (!isset($this->roles[$roleId])) {
            return false;
        }
        
        if (in_array($roleId, ['guest', 'user', 'moderator', 'admin'])) {
            // Can only update permissions for default roles
            if (isset($data['permissions'])) {
                $this->roles[$roleId]['permissions'] = $data['permissions'];
            }
        } else {
            // Custom roles can be fully updated
            $this->roles[$roleId] = array_merge($this->roles[$roleId], $data);
        }
        
        $this->saveRolesAndPermissions();
        return true;
    }
    
    /**
     * Delete custom role
     * @param string $roleId Role ID
     * @return bool
     */
    public function deleteRole($roleId) {
        // Cannot delete default roles
        if (in_array($roleId, ['guest', 'user', 'moderator', 'admin'])) {
            return false;
        }
        
        if (!isset($this->roles[$roleId])) {
            return false;
        }
        
        // Update all users with this role to 'user'
        $users = $this->db->getAll('users');
        foreach ($users as $user) {
            if ($user['role'] === $roleId) {
                $user['role'] = 'user';
                $this->db->save('users', $user['id'], $user);
            }
        }
        
        unset($this->roles[$roleId]);
        $this->saveRolesAndPermissions();
        return true;
    }
    
    /**
     * Require permission (redirect if not authorized)
     * @param string $permission Permission required
     * @param string $redirectUrl URL to redirect to
     */
    public function requirePermission($permission, $redirectUrl = 'index.php') {
        $userId = $_SESSION['user_id'] ?? null;
        
        if (!$this->hasPermission($userId, $permission)) {
            header('Location: ' . $redirectUrl);
            exit;
        }
    }
    
    /**
     * Check if user is admin (backward compatibility)
     * @param string $userId User ID
     * @return bool
     */
    public function isAdmin($userId) {
        return $this->getUserRole($userId) === 'admin';
    }
    
    /**
     * Check if user is moderator or admin
     * @param string $userId User ID
     * @return bool
     */
    public function isModerator($userId) {
        $role = $this->getUserRole($userId);
        return in_array($role, ['moderator', 'admin']);
    }
}
